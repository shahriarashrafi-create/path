Journey-v43-mission-running-screen

Changes:
- Added the new 1:2 mission-running background requested by the user.
- Start Mission now opens a real running-mission screen instead of the temporary screen.
- Mission title from the setup screen is shown by itself above the subtasks.
- Added 4 editable subtask rows. Text is saved live per stage.
- A subtask checkbox becomes active when the row has text. Checking it strikes through the subtask; unchecking restores it.
- Countdown starts automatically from the selected 5/10/20/30 minute duration.
- Pause/resume works and preserves remaining time.
- Green check completes the mission, awards XP/coins/combo, and returns to the progress path.
- Red X fails the mission, resets combo according to existing rules, and returns to the progress path.
- Only one mission can be active at a time.
- Leaving the running screen does not reset the timer; returning to the active stage restores its current remaining time.
- Tapping the active stage in the progress path opens its running screen directly.
- Existing 7 progress artworks / 21 stage touch calibration remains unchanged.
- Stage setup value alignment refined: time/importance slightly lower, repeat/reminder further lower as requested.
- Header and Bottom Bar remain above every screen inside the safe area.

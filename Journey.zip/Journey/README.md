# Journey

Initial Android project for the Journey app.

## Current screen

- Full-screen 9:17 fantasy Journey background
- Background extends under transparent Android status/navigation bars
- No interactive UI has been added yet

## Build

```bash
./gradlew assembleDebug
```

The debug APK is produced under `app/build/outputs/apk/debug/`.

Legacy v67 — Tree of Exponential Growth (درخت تصاعد)

Base: Legacy v65 progress-path-closed.

Tree changes:
- Uses the approved clean palace/portal background with only the first blue beam baked into the image.
- All people circles, branch lines, and blue orb controls are now created in code.
- The central orb on the first blue line stays as a + add control; every tap can create another direct person circle.
- Every created person circle gets a glowing blue line above it and an orb control.
- A branch orb shows + when it can add/open the next level and − when its child branch is open; tapping − collapses that branch.
- Tree grows upward and becomes vertically scrollable as depth increases.
- Tapping any person circle opens that person's card with PV, GPV, count, target PV, target GPV, and target count.
- Person cards include Edit so the name and all six values can be updated and saved.
- Tree data and expanded/collapsed branch states persist in SharedPreferences.
- Uses the existing glowing orb asset for + / − controls.

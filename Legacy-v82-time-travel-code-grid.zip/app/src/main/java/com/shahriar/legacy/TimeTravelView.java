package com.shahriar.legacy;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Code-rendered Time Travel / weekly time-sheet UI.
 * The only bitmap asset used by this feature is the page background.
 * The glass panel, calendar grid, controls, event cards and states are drawn here.
 */
public class TimeTravelView extends View {
    private final MainActivity activity;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final android.content.SharedPreferences prefs;
    private final android.view.ScaleGestureDetector scaleDetector;
    private final RectF panel = new RectF(), titleBar = new RectF(), scheduleRegion = new RectF(), bottomBar = new RectF();
    private final RectF topPrev = new RectF(), topNext = new RectF(), calButton = new RectF(), mapButton = new RectF(), bottomPrev = new RectF(), bottomNext = new RectF();
    private final HashMap<String,RectF> eventRects = new HashMap<>();
    private final String[] dayNames={"شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"};
    private float zoom=1f,panX=0f,panY=0f,lastX,lastY,downX,downY;
    private boolean moved=false, scaling=false;
    private int weekOffset=0;
    private static final int START_MIN=7*60, END_MIN=24*60;
    private static final String PREF_NAME="legacy_timesheet_v2";

    static class Entry {
        String id,title,weekKey; int day,start,end; boolean fixed;
        Entry(String id){this.id=id;}
    }

    public TimeTravelView(MainActivity a){
        super(a); activity=a; prefs=a.getSharedPreferences(PREF_NAME,Context.MODE_PRIVATE);
        setFocusable(true);setClickable(true);setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        text.setTypeface(Typeface.create("sans",Typeface.NORMAL));
        scaleDetector=new android.view.ScaleGestureDetector(a,new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScaleBegin(android.view.ScaleGestureDetector d){scaling=true;return true;}
            @Override public boolean onScale(android.view.ScaleGestureDetector d){float old=zoom;zoom=Math.max(.40f,Math.min(1.55f,zoom*d.getScaleFactor()));if(Math.abs(old-zoom)>.001f){clampPan();invalidate();}return true;}
            @Override public void onScaleEnd(android.view.ScaleGestureDetector d){scaling=false;clampPan();invalidate();}
        });
    }

    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    private float sp(float v){return v*getResources().getDisplayMetrics().scaledDensity;}
    private int clamp(int v,int lo,int hi){return Math.max(lo,Math.min(hi,v));}

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){
        float side=Math.max(dp(12),w*.032f);
        float top=Math.max(dp(188),h*.255f);
        float bottom=Math.min(h-dp(18),h*.895f);
        if(bottom-top<dp(430)) { top=Math.max(dp(160),h*.235f); bottom=h-dp(18); }
        panel.set(side,top,w-side,bottom);
        float titleH=Math.min(dp(62),panel.height()*.105f);
        float bottomH=Math.min(dp(72),panel.height()*.12f);
        titleBar.set(panel.left,panel.top,panel.right,panel.top+titleH);
        bottomBar.set(panel.left,panel.bottom-bottomH,panel.right,panel.bottom);
        scheduleRegion.set(panel.left+dp(8),titleBar.bottom,panel.right-dp(8),bottomBar.top-dp(4));
        float b=dp(44),cy=titleBar.centerY();
        topPrev.set(panel.left+dp(14),cy-b/2,panel.left+dp(14)+b,cy+b/2);
        topNext.set(panel.right-dp(14)-b,cy-b/2,panel.right-dp(14),cy+b/2);
        float bb=dp(52), by=bottomBar.centerY();
        calButton.set(panel.left+dp(18),by-bb/2,panel.left+dp(18)+bb,by+bb/2);
        mapButton.set(panel.right-dp(18)-bb,by-bb/2,panel.right-dp(18),by+bb/2);
        float capW=Math.min(dp(170),panel.width()*.36f),capH=dp(42),cx=panel.centerX();
        bottomPrev.set(cx-capW/2,by-capH/2,cx,by+capH/2);
        bottomNext.set(cx,by-capH/2,cx+capW/2,by+capH/2);
        clampPan();
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        drawGlassPanel(c);
        drawTitle(c);
        drawSchedule(c);
        drawBottomControls(c);
    }

    private void drawGlassPanel(Canvas c){
        p.setStyle(Paint.Style.FILL);p.setColor(0xBB073C72);p.setShadowLayer(dp(14),0,dp(4),0xAA1F8DFF);c.drawRoundRect(panel,dp(24),dp(24),p);p.clearShadowLayer();
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.6f));p.setColor(0xCC8BD9FF);c.drawRoundRect(panel,dp(24),dp(24),p);
        p.setStrokeWidth(dp(.8f));p.setColor(0x663EEBFF);RectF inner=new RectF(panel);inner.inset(dp(3),dp(3));c.drawRoundRect(inner,dp(21),dp(21),p);
    }

    private void drawTitle(Canvas c){
        drawGlassButton(c,topPrev,false);drawGlassButton(c,topNext,false);
        drawArrow(c,topPrev,true);drawArrow(c,topNext,false);
        text.setTextAlign(Paint.Align.CENTER);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(sp(25));text.setColor(0xFFE8F9FF);text.setShadowLayer(dp(7),0,0,0xFF27A9FF);
        drawCentered(c,"سفر در زمان",panel.centerX(),titleBar.centerY()+dp(1),text);text.clearShadowLayer();
    }

    private float regionBaseX(){return scheduleRegion.left+(scheduleRegion.width()-scheduleRegion.width()*zoom)/2f+panX;}
    private float regionBaseY(){return scheduleRegion.top+(scheduleRegion.height()-scheduleRegion.height()*zoom)/2f+panY;}
    private void clampPan(){
        if(scheduleRegion.width()<=0)return;
        float ex=Math.max(0,(scheduleRegion.width()*zoom-scheduleRegion.width())/2f),ey=Math.max(0,(scheduleRegion.height()*zoom-scheduleRegion.height())/2f);
        if(ex<=0)panX=0;else panX=Math.max(-ex,Math.min(ex,panX));
        if(ey<=0)panY=0;else panY=Math.max(-ey,Math.min(ey,panY));
    }

    private void drawSchedule(Canvas c){
        c.save();c.clipRect(scheduleRegion);
        c.translate(regionBaseX(),regionBaseY());c.scale(zoom,zoom);
        float W=scheduleRegion.width(),H=scheduleRegion.height();
        float dayH=Math.min(dp(52),H*.105f), hourW=Math.min(dp(49),W*.12f), gridTop=dayH, gridH=H-dayH;
        float dayW=(W-hourW)/7f,rowH=gridH/17f;
        int today=currentDayIndex();
        // day cards
        for(int d=0;d<7;d++){
            RectF dr=new RectF(hourW+d*dayW+dp(2),dp(2),hourW+(d+1)*dayW-dp(2),dayH-dp(4));
            boolean current=weekOffset==0&&d==today;
            p.setStyle(Paint.Style.FILL);p.setColor(current?0xB21879E7:0x52184E86);c.drawRoundRect(dr,dp(10),dp(10),p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(current?dp(1.6f):dp(.8f));p.setColor(current?0xFFD6F5FF:0x5558BFFF);if(current){p.setShadowLayer(dp(8),0,0,0xCC2AA8FF);}c.drawRoundRect(dr,dp(10),dp(10),p);p.clearShadowLayer();
            long dm=weekStartMillis()+d*86400000L;int[] j=jalaliForMillis(dm);
            text.setTextAlign(Paint.Align.CENTER);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setColor(0xFFE7F6FF);text.setTextSize(sp(9.5f));c.drawText(dayNames[d],dr.centerX(),dr.top+dp(19),text);
            text.setTextSize(sp(11));text.setTypeface(Typeface.create("sans",Typeface.NORMAL));c.drawText(faDigits(String.valueOf(j[2])),dr.centerX(),dr.top+dp(37),text);
        }
        // current-day column
        if(weekOffset==0&&today>=0){p.setStyle(Paint.Style.FILL);p.setColor(0x201FA6FF);c.drawRect(hourW+today*dayW,gridTop,hourW+(today+1)*dayW,H,p);}
        // grid background
        p.setStyle(Paint.Style.FILL);p.setColor(0x2D061D38);c.drawRect(0,gridTop,W,H,p);
        // lines
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.65f));p.setColor(0x7740B5FF);
        for(int d=0;d<=7;d++){float x=hourW+d*dayW;c.drawLine(x,gridTop,x,H,p);}c.drawLine(hourW,gridTop,hourW,H,p);
        for(int r=0;r<=17;r++){float y=gridTop+r*rowH;c.drawLine(0,y,W,y,p);}
        // hour labels
        text.setTextAlign(Paint.Align.CENTER);text.setTypeface(Typeface.create("sans",Typeface.NORMAL));text.setTextSize(sp(9.3f));text.setColor(0xFFE5F7FF);
        for(int h=7;h<=24;h++){float y=gridTop+(h-7)*rowH;if(h==24)y-=dp(2);c.drawText(String.format(Locale.US,"%02d:00",h),hourW*.48f,y+dp(4),text);}
        // events
        eventRects.clear();
        ArrayList<Entry> list=entriesForWeek();Collections.sort(list,(a,b)->a.day!=b.day?a.day-b.day:a.start-b.start);
        for(Entry e:list){
            float left=hourW+e.day*dayW+dp(2.5f),right=hourW+(e.day+1)*dayW-dp(2.5f);
            float top=gridTop+((e.start-START_MIN)/60f)*rowH+dp(1.5f),bottom=gridTop+((e.end-START_MIN)/60f)*rowH-dp(1.5f);
            bottom=Math.max(top+dp(18),Math.min(H-dp(1),bottom));RectF er=new RectF(left,top,right,bottom);eventRects.put(e.id,er);
            int st=statusFor(e.id);
            int fill=st==1?0xCC238F69:st==2?0xCCB44361:0xC82265A4;
            int stroke=st==1?0xFF8DFFD5:st==2?0xFFFF9AB0:0xFF8DDCFF;
            p.setStyle(Paint.Style.FILL);p.setColor(fill);p.setShadowLayer(dp(4),0,dp(1),stroke&0x66FFFFFF);c.drawRoundRect(er,dp(7),dp(7),p);p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(stroke);c.drawRoundRect(er,dp(7),dp(7),p);
            text.setTextAlign(Paint.Align.CENTER);text.setColor(Color.WHITE);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(sp(8.6f));
            String title=ellipsize(e.title,Math.max(4,(int)(er.width()/dp(7.2f))));float ty=er.centerY()+dp(3);if(er.height()>dp(34))ty=er.top+dp(15);c.drawText(title,er.centerX(),ty,text);
            if(er.height()>dp(38)){text.setTypeface(Typeface.create("sans",Typeface.NORMAL));text.setTextSize(sp(7.4f));text.setColor(0xFFD9F5FF);String tm=timeText(e.start)+"–"+timeText(e.end)+(e.fixed?"  ↻":"");c.drawText(tm,er.centerX(),Math.min(er.bottom-dp(6),ty+dp(15)),text);}
        }
        // border around schedule
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0xAA79D9FF);c.drawRoundRect(new RectF(0,gridTop,W,H),dp(12),dp(12),p);
        c.restore();
    }

    private void drawBottomControls(Canvas c){
        drawGlassButton(c,calButton,true);drawCalendarIcon(c,calButton);
        drawGlassButton(c,mapButton,true);drawMapIcon(c,mapButton);
        RectF capsule=new RectF(bottomPrev.left,bottomPrev.top,bottomNext.right,bottomNext.bottom);p.setStyle(Paint.Style.FILL);p.setColor(0x43184B7B);c.drawRoundRect(capsule,capsule.height()/2,capsule.height()/2,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0xAA76CCFF);c.drawRoundRect(capsule,capsule.height()/2,capsule.height()/2,p);
        drawArrow(c,bottomPrev,true);drawArrow(c,bottomNext,false);
        p.setColor(0x4456C7FF);p.setStrokeWidth(dp(1));c.drawLine(capsule.centerX(),capsule.top+dp(8),capsule.centerX(),capsule.bottom-dp(8),p);
    }

    private void drawGlassButton(Canvas c,RectF r,boolean strong){p.setStyle(Paint.Style.FILL);p.setColor(strong?0x68134678:0x49164B7A);c.drawRoundRect(r,dp(10),dp(10),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0xAA78D0FF);c.drawRoundRect(r,dp(10),dp(10),p);}
    private void drawArrow(Canvas c,RectF r,boolean left){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.2f));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setColor(0xFFF3FCFF);float cx=r.centerX(),cy=r.centerY(),s=Math.min(r.width(),r.height())*.20f;Path path=new Path();if(left){path.moveTo(cx+s,cy-s);path.lineTo(cx-s,cy);path.lineTo(cx+s,cy+s);}else{path.moveTo(cx-s,cy-s);path.lineTo(cx+s,cy);path.lineTo(cx-s,cy+s);}c.drawPath(path,p);p.setStrokeCap(Paint.Cap.BUTT);}
    private void drawCalendarIcon(Canvas c,RectF r){float w=r.width()*.48f,h=r.height()*.43f,cx=r.centerX(),cy=r.centerY()+dp(2);RectF q=new RectF(cx-w/2,cy-h/2,cx+w/2,cy+h/2);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.8f));p.setColor(Color.WHITE);c.drawRoundRect(q,dp(3),dp(3),p);c.drawLine(q.left,q.top+dp(7),q.right,q.top+dp(7),p);c.drawLine(q.left+dp(6),q.top-dp(3),q.left+dp(6),q.top+dp(4),p);c.drawLine(q.right-dp(6),q.top-dp(3),q.right-dp(6),q.top+dp(4),p);}
    private void drawMapIcon(Canvas c,RectF r){float cx=r.centerX(),cy=r.centerY(),s=r.width()*.22f;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.8f));p.setColor(Color.WHITE);Path q=new Path();q.moveTo(cx-s*1.5f,cy-s);q.lineTo(cx-s*.5f,cy-s*1.35f);q.lineTo(cx+s*.5f,cy-s);q.lineTo(cx+s*1.5f,cy-s*1.35f);q.lineTo(cx+s*1.5f,cy+s);q.lineTo(cx+s*.5f,cy+s*1.35f);q.lineTo(cx-s*.5f,cy+s);q.lineTo(cx-s*1.5f,cy+s*1.35f);q.close();c.drawPath(q,p);c.drawLine(cx-s*.5f,cy-s*1.35f,cx-s*.5f,cy+s,p);c.drawLine(cx+s*.5f,cy-s,cx+s*.5f,cy+s*1.35f,p);}

    @Override public boolean onTouchEvent(MotionEvent e){
        scaleDetector.onTouchEvent(e);if(e.getPointerCount()>1){moved=true;return true;}
        float x=e.getX(),y=e.getY();
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN: downX=lastX=x;downY=lastY=y;moved=false;return true;
            case MotionEvent.ACTION_MOVE:
                float dx=x-lastX,dy=y-lastY;if(Math.hypot(x-downX,y-downY)>dp(7))moved=true;
                if(moved&&scheduleRegion.contains(downX,downY)&&!scaling){panX+=dx;panY+=dy;clampPan();invalidate();}
                lastX=x;lastY=y;return true;
            case MotionEvent.ACTION_UP:
                if(!moved&&!scaling){performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);handleTap(x,y);}scaling=false;return true;
            case MotionEvent.ACTION_CANCEL: scaling=false;return true;
        }
        return true;
    }

    private void handleTap(float x,float y){
        if(topPrev.contains(x,y)||bottomPrev.contains(x,y)){changeWeek(-1);return;}
        if(topNext.contains(x,y)||bottomNext.contains(x,y)){changeWeek(1);return;}
        if(calButton.contains(x,y)){showWeekPicker();return;}
        if(mapButton.contains(x,y)){showOverview();return;}
        if(!scheduleRegion.contains(x,y))return;
        float lx=(x-regionBaseX())/zoom,ly=(y-regionBaseY())/zoom;
        for(Entry en:entriesForWeek()){RectF rr=eventRects.get(en.id);if(rr!=null&&rr.contains(lx,ly)){showEntryActions(en);return;}}
        float W=scheduleRegion.width(),H=scheduleRegion.height(),dayH=Math.min(dp(52),H*.105f),hourW=Math.min(dp(49),W*.12f),gridTop=dayH,gridH=H-dayH,dayW=(W-hourW)/7f,rowH=gridH/17f;
        if(ly<gridTop||lx<hourW)return;int day=(int)((lx-hourW)/dayW);if(day<0||day>6)return;
        float mins=((ly-gridTop)/rowH)*60f;int start=START_MIN+Math.round(mins/30f)*30;start=clamp(start,START_MIN,END_MIN-30);int end=Math.min(END_MIN,start+60);showEntryEditor(null,day,start,end);
    }

    private void changeWeek(int delta){int n=clamp(weekOffset+delta,-10,10);if(n==weekOffset){Toast.makeText(activity,"تاریخچه تا ۱۰ هفته در دسترس است",Toast.LENGTH_SHORT).show();return;}weekOffset=n;zoom=1f;panX=panY=0;invalidate();}

    private long currentWeekStartMillis(){return weekStartMillis(0);}
    private long weekStartMillis(){return weekStartMillis(weekOffset);}
    private long weekStartMillis(int off){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);int dow=c.get(Calendar.DAY_OF_WEEK);int delta=(dow-Calendar.SATURDAY+7)%7;c.add(Calendar.DAY_OF_MONTH,-delta+off*7);return c.getTimeInMillis();}
    private String weekKey(){return weekKeyFor(weekStartMillis());}
    private String weekKeyFor(long ms){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date(ms));}
    private int currentDayIndex(){Calendar c=Calendar.getInstance();return (c.get(Calendar.DAY_OF_WEEK)-Calendar.SATURDAY+7)%7;}

    private ArrayList<String> ids(){String raw=prefs.getString("ids","");ArrayList<String> out=new ArrayList<>();if(raw!=null&&!raw.trim().isEmpty())for(String s:raw.split(","))if(!s.trim().isEmpty())out.add(s.trim());return out;}
    private void saveIds(ArrayList<String> ids){StringBuilder b=new StringBuilder();for(String id:ids){if(b.length()>0)b.append(',');b.append(id);}prefs.edit().putString("ids",b.toString()).apply();}
    private Entry read(String id){if(!prefs.contains("e_"+id+"_title"))return null;Entry e=new Entry(id);e.title=prefs.getString("e_"+id+"_title","");e.day=prefs.getInt("e_"+id+"_day",0);e.start=prefs.getInt("e_"+id+"_start",START_MIN);e.end=prefs.getInt("e_"+id+"_end",Math.min(END_MIN,e.start+60));e.fixed=prefs.getBoolean("e_"+id+"_fixed",true);e.weekKey=prefs.getString("e_"+id+"_week",weekKey());return e;}
    private void write(Entry e){prefs.edit().putString("e_"+e.id+"_title",e.title).putInt("e_"+e.id+"_day",e.day).putInt("e_"+e.id+"_start",e.start).putInt("e_"+e.id+"_end",e.end).putBoolean("e_"+e.id+"_fixed",e.fixed).putString("e_"+e.id+"_week",e.weekKey).apply();ArrayList<String> a=ids();if(!a.contains(e.id)){a.add(e.id);saveIds(a);}}
    private void delete(Entry e){ArrayList<String> a=ids();a.remove(e.id);saveIds(a);android.content.SharedPreferences.Editor ed=prefs.edit();String pre="e_"+e.id+"_";ed.remove(pre+"title").remove(pre+"day").remove(pre+"start").remove(pre+"end").remove(pre+"fixed").remove(pre+"week");for(int i=-10;i<=10;i++)ed.remove("st_"+weekKeyFor(weekStartMillis(i))+"_"+e.id);ed.apply();invalidate();}
    private ArrayList<Entry> entriesForWeek(){String wk=weekKey();ArrayList<Entry> out=new ArrayList<>();for(String id:ids()){Entry e=read(id);if(e!=null&&(e.fixed||wk.equals(e.weekKey)))out.add(e);}return out;}
    private int statusFor(String id){return prefs.getInt("st_"+weekKey()+"_"+id,0);}
    private void setStatus(String id,int st){prefs.edit().putInt("st_"+weekKey()+"_"+id,st).apply();invalidate();}

    private void saveMerged(Entry e){
        ArrayList<Entry> all=entriesForWeek();for(Entry q:all){if(q.id.equals(e.id))continue;if(q.day==e.day&&q.fixed==e.fixed&&safe(q.title).equalsIgnoreCase(safe(e.title))&&(e.fixed||safe(q.weekKey).equals(safe(e.weekKey)))&&q.end>=e.start&&e.end>=q.start){e.start=Math.min(e.start,q.start);e.end=Math.max(e.end,q.end);delete(q);}}
        write(e);invalidate();
    }
    private String safe(String s){return s==null?"":s.trim();}

    private GradientDrawable fieldBg(int fill,int stroke,float radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(Math.max(1,Math.round(dp(1))),stroke);return g;}
    private TextView label(String s,float size,int color){TextView v=new TextView(activity);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.CENTER);v.setTypeface(Typeface.create("sans",Typeface.BOLD));return v;}
    private TextView button(String s,int fill){TextView v=label(s,14,Color.WHITE);v.setBackground(fieldBg(fill,0x776ED6FF,14));v.setPadding((int)dp(10),0,(int)dp(10),0);v.setClickable(true);return v;}
    private LinearLayout dialogCard(){LinearLayout card=new LinearLayout(activity);card.setOrientation(LinearLayout.VERTICAL);card.setPadding((int)dp(18),(int)dp(16),(int)dp(18),(int)dp(16));card.setBackground(fieldBg(0xF20A3156,0xCC79D8FF,24));card.setElevation(dp(18));return card;}
    private Dialog baseDialog(View body){Dialog d=new Dialog(activity);d.requestWindowFeature(Window.FEATURE_NO_TITLE);d.setContentView(body);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min((int)(getResources().getDisplayMetrics().widthPixels*.92f),(int)dp(520));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.55f;w.setAttributes(lp);}return d;}

    private void showEntryEditor(Entry src,int day,int start,int end){
        final Entry e=src==null?new Entry(String.valueOf(System.currentTimeMillis())):src;boolean creating=src==null;if(creating){e.day=day;e.start=start;e.end=end;e.fixed=true;e.weekKey=weekKey();e.title="";}
        LinearLayout card=dialogCard();TextView head=label(creating?"برنامه جدید":"ویرایش برنامه",21,0xFFE8FAFF);card.addView(head,new LinearLayout.LayoutParams(-1,(int)dp(46)));
        EditText title=new EditText(activity);title.setSingleLine(true);title.setText(e.title);title.setHint("عنوان برنامه");title.setHintTextColor(0x889FD4F3);title.setTextColor(Color.WHITE);title.setTextSize(15);title.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);title.setPadding((int)dp(12),0,(int)dp(12),0);title.setBackground(fieldBg(0x66164D79,0x6659C8FF,13));LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-1,(int)dp(50));tlp.bottomMargin=(int)dp(9);card.addView(title,tlp);
        final int[] dd={e.day},ss={e.start},ee={e.end};final boolean[] ff={e.fixed};
        TextView dayField=button(dayNames[dd[0]],0x55164D79),startField=button(timeText(ss[0]),0x55164D79),endField=button(timeText(ee[0]),0x55164D79);LinearLayout row=new LinearLayout(activity);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.addView(dayField,new LinearLayout.LayoutParams(0,(int)dp(46),1));LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams((int)dp(7),1);View g1=new View(activity);row.addView(g1,gap);row.addView(startField,new LinearLayout.LayoutParams(0,(int)dp(46),1));View g2=new View(activity);row.addView(g2,new LinearLayout.LayoutParams((int)dp(7),1));row.addView(endField,new LinearLayout.LayoutParams(0,(int)dp(46),1));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,(int)dp(46));rlp.bottomMargin=(int)dp(9);card.addView(row,rlp);
        TextView fixed=button("تکرار هفتگی  ✓",0x663D72A9);card.addView(fixed,new LinearLayout.LayoutParams(-1,(int)dp(46)));
        dayField.setOnClickListener(v->showDayPicker(dd[0],n->{dd[0]=n;dayField.setText(dayNames[n]);}));startField.setOnClickListener(v->showTimePicker(ss[0],n->{ss[0]=n;if(ee[0]<=ss[0])ee[0]=Math.min(END_MIN,ss[0]+60);startField.setText(timeText(ss[0]));endField.setText(timeText(ee[0]));},false));endField.setOnClickListener(v->showTimePicker(ee[0],n->{ee[0]=Math.max(ss[0]+30,n);endField.setText(timeText(ee[0]));},true));fixed.setOnClickListener(v->{ff[0]=!ff[0];fixed.setText(ff[0]?"تکرار هفتگی  ✓":"فقط همین هفته");fixed.setBackground(fieldBg(ff[0]?0x663D72A9:0x55164D79,0x776ED6FF,14));});
        LinearLayout actions=new LinearLayout(activity);actions.setOrientation(LinearLayout.HORIZONTAL);TextView cancel=button("لغو",0x55405B72),save=button("ذخیره",0xCC1769C8);actions.addView(cancel,new LinearLayout.LayoutParams(0,(int)dp(48),1));View ag=new View(activity);actions.addView(ag,new LinearLayout.LayoutParams((int)dp(8),1));actions.addView(save,new LinearLayout.LayoutParams(0,(int)dp(48),1));LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,(int)dp(48));alp.topMargin=(int)dp(12);card.addView(actions,alp);
        Dialog d=baseDialog(card);cancel.setOnClickListener(v->d.dismiss());save.setOnClickListener(v->{String t=title.getText().toString().trim();if(t.isEmpty()){title.setError("عنوان را وارد کن");return;}e.title=t;e.day=dd[0];e.start=clamp(ss[0],START_MIN,END_MIN-30);e.end=clamp(Math.max(e.start+30,ee[0]),e.start+30,END_MIN);e.fixed=ff[0];if(!e.fixed)e.weekKey=weekKey();saveMerged(e);d.dismiss();});d.show();
    }

    interface IntPick{void onPick(int n);}
    private void showDayPicker(int selected,IntPick cb){ArrayList<String> a=new ArrayList<>();for(String s:dayNames)a.add(s);showChoice("روز",a,selected,n->cb.onPick(n));}
    private void showTimePicker(int selected,IntPick cb,boolean allow24){ArrayList<String>a=new ArrayList<>();ArrayList<Integer> vals=new ArrayList<>();for(int m=START_MIN;m<=END_MIN;m+=30){if(!allow24&&m==END_MIN)continue;a.add(timeText(m));vals.add(m);}int sel=0;for(int i=0;i<vals.size();i++)if(vals.get(i)==selected)sel=i;final ArrayList<Integer> f=vals;showChoice("زمان",a,sel,n->cb.onPick(f.get(n)));}
    private void showChoice(String title,ArrayList<String> options,int selected,IntPick cb){LinearLayout card=dialogCard();card.addView(label(title,19,0xFFEAF9FF),new LinearLayout.LayoutParams(-1,(int)dp(42)));ScrollView sc=new ScrollView(activity);LinearLayout list=new LinearLayout(activity);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);int max=Math.min(options.size(),22);for(int i=0;i<options.size();i++){final int idx=i;TextView r=button((i==selected?"✓  ":"")+options.get(i),i==selected?0x884B89C7:0x44164D79);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(42));lp.bottomMargin=(int)dp(4);list.addView(r,lp);r.setOnClickListener(v->{cb.onPick(idx);Dialog dd=(Dialog)sc.getTag();if(dd!=null)dd.dismiss();});}card.addView(sc,new LinearLayout.LayoutParams(-1,(int)Math.min(dp(440),dp(46)*max)));Dialog d=baseDialog(card);sc.setTag(d);d.show();}

    private void showEntryActions(Entry e){LinearLayout card=dialogCard();card.addView(label(e.title,20,0xFFEAF9FF),new LinearLayout.LayoutParams(-1,(int)dp(48)));TextView info=label(dayNames[e.day]+"   "+timeText(e.start)+" – "+timeText(e.end)+(e.fixed?"   • هفتگی":""),12,0xFFC9E9FF);card.addView(info,new LinearLayout.LayoutParams(-1,(int)dp(34)));TextView edit=button("ویرایش",0xAA1D66A5),done=button("انجام شد",0xAA257E60),fail=button("انجام نشد",0xAAA03D58),del=button("حذف",0x668A3850);TextView[] bs={edit,done,fail,del};for(TextView b:bs){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(44));lp.bottomMargin=(int)dp(6);card.addView(b,lp);}Dialog d=baseDialog(card);edit.setOnClickListener(v->{d.dismiss();showEntryEditor(e,e.day,e.start,e.end);});done.setOnClickListener(v->{setStatus(e.id,1);d.dismiss();});fail.setOnClickListener(v->{setStatus(e.id,2);d.dismiss();});del.setOnClickListener(v->{d.dismiss();confirmDelete(e);});d.show();}
    private void confirmDelete(Entry e){LinearLayout card=dialogCard();card.addView(label("حذف برنامه؟",20,0xFFFFEDF2),new LinearLayout.LayoutParams(-1,(int)dp(50)));TextView note=label("این برنامه از جدول حذف می‌شود.",13,0xFFCEE8F7);card.addView(note,new LinearLayout.LayoutParams(-1,(int)dp(40)));LinearLayout a=new LinearLayout(activity);TextView no=button("لغو",0x55405B72),yes=button("حذف",0xAAB44361);a.addView(no,new LinearLayout.LayoutParams(0,(int)dp(46),1));View gap=new View(activity);a.addView(gap,new LinearLayout.LayoutParams((int)dp(8),1));a.addView(yes,new LinearLayout.LayoutParams(0,(int)dp(46),1));card.addView(a,new LinearLayout.LayoutParams(-1,(int)dp(46)));Dialog d=baseDialog(card);no.setOnClickListener(v->d.dismiss());yes.setOnClickListener(v->{delete(e);d.dismiss();});d.show();}

    private void showWeekPicker(){LinearLayout card=dialogCard();card.addView(label("انتخاب هفته",20,0xFFEAF9FF),new LinearLayout.LayoutParams(-1,(int)dp(46)));ScrollView sc=new ScrollView(activity);LinearLayout list=new LinearLayout(activity);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);for(int o=-10;o<=10;o++){final int off=o;long s=weekStartMillis(off),e=s+6*86400000L;int[] a=jalaliForMillis(s),b=jalaliForMillis(e);String cap=faDigits(a[0]+"/"+two(a[1])+"/"+two(a[2]))+"  تا  "+faDigits(b[0]+"/"+two(b[1])+"/"+two(b[2]));TextView row=button((off==weekOffset?"✓  ":"")+cap,off==weekOffset?0x884B89C7:0x44164D79);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(44));lp.bottomMargin=(int)dp(5);list.addView(row,lp);row.setOnClickListener(v->{weekOffset=off;zoom=1;panX=panY=0;invalidate();Dialog dd=(Dialog)sc.getTag();if(dd!=null)dd.dismiss();});}card.addView(sc,new LinearLayout.LayoutParams(-1,(int)dp(430)));Dialog d=baseDialog(card);sc.setTag(d);d.show();}

    private void showOverview(){LinearLayout card=dialogCard();card.addView(label("نمای کلی هفته",20,0xFFEAF9FF),new LinearLayout.LayoutParams(-1,(int)dp(46)));ArrayList<Entry> es=entriesForWeek();Collections.sort(es,(a,b)->a.day!=b.day?a.day-b.day:a.start-b.start);ScrollView sc=new ScrollView(activity);LinearLayout list=new LinearLayout(activity);list.setOrientation(LinearLayout.VERTICAL);if(es.isEmpty()){TextView empty=label("هنوز برنامه‌ای ثبت نشده",13,0xFFBFDDF1);list.addView(empty,new LinearLayout.LayoutParams(-1,(int)dp(60)));}else for(Entry e:es){int st=statusFor(e.id);String mark=st==1?"✓  ":st==2?"×  ":"";TextView row=button(mark+dayNames[e.day]+"  •  "+timeText(e.start)+"  •  "+e.title,st==1?0x66257E60:st==2?0x66A03D58:0x44164D79);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(44));lp.bottomMargin=(int)dp(5);list.addView(row,lp);row.setOnClickListener(v->{Dialog dd=(Dialog)sc.getTag();if(dd!=null)dd.dismiss();showEntryActions(e);});}card.addView(sc,new LinearLayout.LayoutParams(-1,(int)Math.min(dp(330),Math.max(dp(80),es.size()*dp(49)))));TextView reset=button("ریست این هفته (حفظ برنامه‌های ثابت)",0x667E4F79);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,(int)dp(46));rp.topMargin=(int)dp(9);card.addView(reset,rp);Dialog d=baseDialog(card);sc.setTag(d);reset.setOnClickListener(v->{d.dismiss();confirmResetWeek();});d.show();}
    private void confirmResetWeek(){LinearLayout card=dialogCard();card.addView(label("ریست هفته",20,0xFFFFEDF2),new LinearLayout.LayoutParams(-1,(int)dp(48)));card.addView(label("برنامه‌های یک‌باره پاک می‌شوند؛ برنامه‌های ثابت باقی می‌مانند.",12,0xFFCEE8F7),new LinearLayout.LayoutParams(-1,(int)dp(52)));LinearLayout a=new LinearLayout(activity);TextView no=button("لغو",0x55405B72),yes=button("ریست",0xAA8D4B67);a.addView(no,new LinearLayout.LayoutParams(0,(int)dp(46),1));View gap=new View(activity);a.addView(gap,new LinearLayout.LayoutParams((int)dp(8),1));a.addView(yes,new LinearLayout.LayoutParams(0,(int)dp(46),1));card.addView(a,new LinearLayout.LayoutParams(-1,(int)dp(46)));Dialog d=baseDialog(card);no.setOnClickListener(v->d.dismiss());yes.setOnClickListener(v->{resetWeek();d.dismiss();});d.show();}
    private void resetWeek(){String wk=weekKey();ArrayList<String> all=ids();for(String id:new ArrayList<>(all)){Entry e=read(id);if(e==null)continue;if(!e.fixed&&wk.equals(e.weekKey))delete(e);else prefs.edit().remove("st_"+wk+"_"+id).apply();}invalidate();}

    private String ellipsize(String s,int max){if(s==null)return "";return s.length()<=max?s:s.substring(0,Math.max(1,max-1))+"…";}
    private String timeText(int min){if(min>=END_MIN)return "24:00";return String.format(Locale.US,"%02d:%02d",min/60,min%60);}
    private String two(int n){return n<10?"0"+n:String.valueOf(n);}
    private void drawCentered(Canvas c,String s,float x,float y,Paint pt){Paint.FontMetrics fm=pt.getFontMetrics();c.drawText(s,x,y-(fm.ascent+fm.descent)/2f,pt);}
    private String faDigits(String s){String en="0123456789",fa="۰۱۲۳۴۵۶۷۸۹";StringBuilder b=new StringBuilder();for(char ch:s.toCharArray()){int i=en.indexOf(ch);b.append(i>=0?fa.charAt(i):ch);}return b.toString();}

    private int[] jalaliForMillis(long millis){Calendar c=Calendar.getInstance();c.setTimeInMillis(millis);return gregorianToJalali(c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}
    private int[] gregorianToJalali(int gy,int gm,int gd){
        int[] gdm={0,31,59,90,120,151,181,212,243,273,304,334};int gy2=(gm>2)?(gy+1):gy;long days=355666L+365L*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400+gd+gdm[gm-1];int jy=-1595+33*(int)(days/12053);days%=12053;jy+=4*(int)(days/1461);days%=1461;if(days>365){jy+=(int)((days-1)/365);days=(days-1)%365;}int jm,jd;if(days<186){jm=1+(int)(days/31);jd=1+(int)(days%31);}else{jm=7+(int)((days-186)/30);jd=1+(int)((days-186)%30);}return new int[]{jy,jm,jd};
    }
}

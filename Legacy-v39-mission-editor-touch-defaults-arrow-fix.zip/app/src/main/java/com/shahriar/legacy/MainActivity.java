package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.text.InputType;
import android.view.*;
import android.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content, activeBar;
    private TextView hudLevel, hudXpText, hudCoinText, hudComboText; private XpBarView hudXpBar;
    private long lastBackAt = 0;
    private boolean isHome = true;
    private int homeGeneration = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","جنگل شکوفایی","سفر در زمان","مرکز خرید","جام جهانی"};
    // Touch centers measured against the current 768x1536 Home artwork.
    // Order matches names: Progress, Dream Palace, Growth Forest, Time Travel, Shop, World Cup.
    private final float[][] centers = {{0.510f,0.773f},{0.195f,0.542f},{0.715f,0.606f},{0.842f,0.426f},{0.320f,0.325f},{0.845f,0.217f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }
    @Override protected void onResume(){ super.onResume(); }
    @Override protected void onDestroy(){ super.onDestroy(); }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void showHome(){
        isHome = true;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        setContentView(root);
        root.setFitsSystemWindows(true);

        ImageView home=new ImageView(this); home.setImageResource(R.drawable.home_background);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // Legacy HUD reference final polish: premium RPG HUD.
        FrameLayout header=new FrameLayout(this);
        header.setPadding(dp(4),0,dp(4),0);
        header.setBackground(new HudBackground());
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(46),Gravity.TOP);
        hp.setMargins(dp(8),dp(4),dp(8),0);
        root.addView(header,hp);

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(1),0,dp(1),0);
        header.addView(row,new FrameLayout.LayoutParams(-1,-1));

        ImageView avatar=new ImageView(this);
        avatar.setImageResource(R.drawable.avatar_legacy);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        avatar.setContentDescription("آواتار"); avatar.setElevation(dp(2));
        LinearLayout.LayoutParams avLp=new LinearLayout.LayoutParams(dp(45),dp(45));
        avLp.setMargins(dp(2),0,dp(4),0); row.addView(avatar,avLp);

        loadGameState();
        hudLevel=tv("LV "+gameLevel,13,0xFFFFE7A0); TextView level=hudLevel;
        level.setGravity(Gravity.CENTER);
        level.setShadowLayer(dp(1),0,0,0x665E3A00);
        LinearLayout.LayoutParams levelLp=new LinearLayout.LayoutParams(dp(40),dp(34));
        levelLp.setMargins(0,0,dp(1),0); row.addView(level,levelLp);

        LinearLayout xpGroup=new LinearLayout(this);
        xpGroup.setOrientation(LinearLayout.VERTICAL);
        xpGroup.setGravity(Gravity.CENTER_VERTICAL);
        XpBarView xp=new XpBarView(this); hudXpBar=xp;
        xp.setProgress(gameXp,xpNeeded(gameLevel));
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(9));
        xpLp.setMargins(0,dp(4),0,0); xpGroup.addView(xp,xpLp);
        hudXpText=tv(gameXp+" / "+xpNeeded(gameLevel)+" XP",8,0xFFE5F7FF); TextView xpTxt=hudXpText;
        xpTxt.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        xpGroup.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(14)));
        LinearLayout.LayoutParams xpgLp=new LinearLayout.LayoutParams(dp(110),dp(35));
        xpgLp.setMargins(0,0,dp(3),0); row.addView(xpGroup,xpgLp);

        LinearLayout coinBox=glassCapsule();
        ImageView coinIcon=new ImageView(this);
        coinIcon.setImageResource(R.drawable.hud_coin); coinIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        coinBox.addView(coinIcon,new LinearLayout.LayoutParams(dp(24),dp(24)));
        hudCoinText=tv(String.valueOf(gameCoins),13,0xFFFFF3CF); TextView coin=hudCoinText; coin.setPadding(dp(1),0,0,0);
        coinBox.addView(coin,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(25));
        coinLp.setMargins(0,0,dp(1),0); row.addView(coinBox,coinLp);

        LinearLayout comboBox=glassCapsule();
        comboBox.setClickable(true);
        comboBox.setContentDescription("Combo");
        comboBox.setOnClickListener(v->showGameSettings());
        ImageView flame=new ImageView(this); flame.setImageResource(R.drawable.hud_flame);
        flame.setScaleType(ImageView.ScaleType.FIT_CENTER);
        comboBox.addView(flame,new LinearLayout.LayoutParams(dp(22),dp(25)));
        hudComboText=tv(String.valueOf(gameCombo),13,Color.WHITE); TextView combo=hudComboText; comboBox.addView(combo,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(44),dp(25));
        comboLp.setMargins(0,0,dp(1),0); row.addView(comboBox,comboLp);

        ImageView gear=new ImageView(this); gear.setImageResource(R.drawable.hud_gear);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER); gear.setPadding(dp(4),dp(4),dp(4),dp(4));
        gear.setContentDescription("تنظیمات");
        gear.setOnClickListener(v->showGameSettings());
        row.addView(gear,new LinearLayout.LayoutParams(dp(34),dp(40)));

        // Hit targets follow the six labels baked into the selected 768x1536 Home artwork.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=768f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            int hitW=Math.max(dp(118), Math.round(245f*scale));
            int hitH=Math.max(dp(48), Math.round(72f*scale));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=Math.round(offsetX + srcW*centers[i][0]*scale);
                int cy=Math.round(offsetY + srcH*centers[i][1]*scale);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-hitW/2; lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==MotionEvent.ACTION_DOWN){ v.setAlpha(.55f); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->{ if(idx==0) showProgressPath(); else showPlaceholder(names[idx]); }); content.addView(hit,lp);
            }
        });
        header.bringToFront();
    }

    private LinearLayout glassCapsule(){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0x3803080E,dp(12)); g.setStroke(dp(1),0x225D7180); box.setBackground(g);
        return box;
    }

    private class XpBarView extends View {
        private final Paint p=new Paint(1); private int value=0,max=100;
        XpBarView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void setProgress(int v,int m){ value=Math.max(0,v); max=Math.max(1,m); invalidate(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float h=getHeight(), r=h/2f; RectF track=new RectF(dp(1),dp(1),getWidth()-dp(1),h-dp(1));
            p.setStyle(Paint.Style.FILL); p.setColor(0xAA071522); c.drawRoundRect(track,r,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xAA5EB8E8); c.drawRoundRect(track,r,r,p);
            float frac=Math.min(1f,value/(float)max);
            if(frac>0f){ RectF fill=new RectF(track.left,track.top,track.left+track.width()*frac,track.bottom);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF25E6FF); p.setShadowLayer(dp(4),0,0,0xCC19D9FF); c.drawRoundRect(fill,r,r,p); p.clearShadowLayer(); }
            else { p.setStyle(Paint.Style.FILL); p.setColor(0xFF36E8FF); p.setShadowLayer(dp(3),0,0,0xAA28DFFF); c.drawCircle(track.left+dp(2),h/2f,dp(1.3f),p); p.clearShadowLayer(); }
        }
    }

    private class HudBackground extends android.graphics.drawable.Drawable {
        private final Paint fill=new Paint(1), stroke=new Paint(1), bottomGlow=new Paint(1), topAccent=new Paint(1);
        HudBackground(){
            fill.setColor(0xED08131F); fill.setStyle(Paint.Style.FILL);
            stroke.setColor(0x3D8398A6); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            bottomGlow.setColor(0xA027D5FF); bottomGlow.setStyle(Paint.Style.STROKE); bottomGlow.setStrokeWidth(dp(1));
            topAccent.setColor(0xF0E8BD62); topAccent.setStyle(Paint.Style.STROKE); topAccent.setStrokeWidth(dp(1));
        }
        private Path shape(){
            RectF b=new RectF(getBounds()); float c=dp(7); Path p=new Path();
            p.moveTo(b.left+c,b.top); p.lineTo(b.right-c,b.top); p.lineTo(b.right,b.top+c);
            p.lineTo(b.right,b.bottom-c); p.lineTo(b.right-c,b.bottom); p.lineTo(b.left+c,b.bottom);
            p.lineTo(b.left,b.bottom-c); p.lineTo(b.left,b.top+c); p.close(); return p;
        }
        @Override public void draw(Canvas c){
            RectF b=new RectF(getBounds()); Path p=shape(); c.drawPath(p,fill); c.drawPath(p,stroke);
            c.drawLine(b.left+dp(11),b.bottom-dp(1),b.right-dp(11),b.bottom-dp(1),bottomGlow);
            c.drawLine(b.left+dp(12),b.top+dp(1),b.right-dp(12),b.top+dp(1),topAccent);
        }
        @Override public void setAlpha(int a){} @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){ return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private class CoinView extends View {
        Paint p=new Paint(1); CoinView(android.content.Context c){super(c);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float r=Math.min(getWidth(),getHeight())*.43f, x=getWidth()/2f,y=getHeight()/2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFB82E); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xFFFFF0A8); c.drawCircle(x,y,r-dp(1),p);
            p.setColor(0xFFD98A00); c.drawCircle(x,y,r-dp(3),p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF8C5A00); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(10));
            c.drawText("L",x,y-(p.ascent()+p.descent())/2,p);
        }
    }

    private int gameLevel=1, gameXp=0, gameCoins=0, gameCombo=0, comboWindowMinutes=30; private long lastSuccessAt=0;
    private SharedPreferences gamePrefs;
    private int xpNeeded(int level){ return 100+Math.max(0,level-1)*50; }
    private void loadGameState(){ gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gameLevel=gamePrefs.getInt("level",1);gameXp=gamePrefs.getInt("xp",0);gameCoins=gamePrefs.getInt("coins",0);gameCombo=gamePrefs.getInt("combo",0);lastSuccessAt=gamePrefs.getLong("lastSuccessAt",0);comboWindowMinutes=gamePrefs.getInt("comboWindowMinutes",30);expireComboIfNeeded(); }
    private void saveGameState(){ if(gamePrefs==null)gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gamePrefs.edit().putInt("level",gameLevel).putInt("xp",gameXp).putInt("coins",gameCoins).putInt("combo",gameCombo).putLong("lastSuccessAt",lastSuccessAt).putInt("comboWindowMinutes",comboWindowMinutes).apply();updateHud(); }
    private void updateHud(){ if(hudLevel!=null)hudLevel.setText("LV "+gameLevel);if(hudXpBar!=null)hudXpBar.setProgress(gameXp,xpNeeded(gameLevel));if(hudXpText!=null)hudXpText.setText(gameXp+" / "+xpNeeded(gameLevel)+" XP");if(hudCoinText!=null)hudCoinText.setText(String.valueOf(gameCoins));if(hudComboText!=null)hudComboText.setText(String.valueOf(gameCombo)); }
    private float comboMultiplier(){return gameCombo>=10?3f:gameCombo>=7?2f:gameCombo>=3?1.5f:1f;}
    private void expireComboIfNeeded(){if(gameCombo>0&&lastSuccessAt>0&&System.currentTimeMillis()-lastSuccessAt>comboWindowMinutes*60000L){gameCombo=0;lastSuccessAt=0;if(gamePrefs!=null)gamePrefs.edit().putInt("combo",0).putLong("lastSuccessAt",0).apply();}}

    private int[] missionTimes={5,10,20,30,45};
    private String mf(int s,int k,String f){return "m_"+s+"_"+k+"_"+f;}
    private String mv(int s,int k,String f,String d){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);return progressPrefs.getString(mf(s,k,f),d);}
    private void ms(int s,int k,String f,String v){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);progressPrefs.edit().putString(mf(s,k,f),v).apply();}
    private GradientDrawable sel(boolean on){GradientDrawable g=bg(0x12FFFFFF,dp(18));if(on)g.setStroke(dp(2),0xFF2477E8);return g;}
    private TextView eh(String t,int z){TextView v=tv(t,z,0xFF17345D);v.setGravity(Gravity.CENTER);return v;}

    private void showMissionEditor(final int section,final int slot){
        isHome=false;++homeGeneration;content.removeAllViews();
        FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(R.drawable.mission_editor_reference);art.setScaleType(ImageView.ScaleType.FIT_XY);
        e.addView(art,new FrameLayout.LayoutParams(-1,-1));

        final String old=progressTitle(section,slot);
        final EditText title=new EditText(this);title.setSingleLine(true);title.setText(old.length()==0?"عنوان":old);
        title.setTextSize(15);title.setTextColor(0xFF17345D);title.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        title.setPadding(dp(8),0,dp(8),0);title.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams tl=new FrameLayout.LayoutParams(0,0);e.addView(title,tl);

        final TextView circleTitle=eh(old,16);circleTitle.setTextColor(0xFF17345D);
        FrameLayout.LayoutParams cl=new FrameLayout.LayoutParams(0,0);e.addView(circleTitle,cl);

        final int[] imp={Integer.parseInt(mv(section,slot,"importance","0"))};
        final TextView[] iv={eh("",1),eh("",1),eh("",1)};
        for(TextView v:iv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        int saved=Integer.parseInt(mv(section,slot,"minutes","10"));final int[] ti={1};
        for(int i=0;i<missionTimes.length;i++)if(missionTimes[i]==saved)ti[0]=i;
        final TextView minus=eh("",1),time=eh(missionTimes[ti[0]]+" دقیقه",15),plus=eh("",1);
        e.addView(minus,new FrameLayout.LayoutParams(0,0));e.addView(time,new FrameLayout.LayoutParams(0,0));e.addView(plus,new FrameLayout.LayoutParams(0,0));

        final int[] rp={Integer.parseInt(mv(section,slot,"repeat","1"))};
        final TextView[] rv={eh("",1),eh("",1)};
        for(TextView v:rv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        final TextView start=eh("Start Mission",1);start.setTextColor(Color.TRANSPARENT);start.setBackgroundColor(Color.TRANSPARENT);
        e.addView(start,new FrameLayout.LayoutParams(0,0));

        // Exact responsive hit areas from the approved 768x1536 artwork.
        e.addOnLayoutChangeListener((v,l,t,r,bt,ol,ot,or,ob)->{
            int w=e.getWidth(),h=e.getHeight();
            java.util.function.BiConsumer<View,float[]> place=(view,q)->{
                FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();
                p.width=Math.round(w*q[2]);p.height=Math.round(h*q[3]);
                p.leftMargin=Math.round(w*q[0]);p.topMargin=Math.round(h*q[1]);view.setLayoutParams(p);
            };
            place.accept(title,new float[]{.379f,.410f,.440f,.040f});
            place.accept(circleTitle,new float[]{.527f,.151f,.307f,.158f});
            place.accept(iv[0],new float[]{.370f,.488f,.180f,.048f});
            place.accept(iv[1],new float[]{.558f,.488f,.180f,.048f});
            place.accept(iv[2],new float[]{.746f,.488f,.180f,.048f});
            place.accept(minus,new float[]{.382f,.565f,.090f,.055f});
            place.accept(time,new float[]{.470f,.565f,.250f,.055f});
            place.accept(plus,new float[]{.718f,.565f,.090f,.055f});
            place.accept(rv[0],new float[]{.380f,.643f,.250f,.065f});
            place.accept(rv[1],new float[]{.642f,.643f,.265f,.065f});
            place.accept(start,new float[]{.130f,.785f,.740f,.075f});
        });

        // Defaults are visible immediately.
        for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));
        for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));
        time.setText(missionTimes[ti[0]]+" دقیقه");

        title.setOnFocusChangeListener((v,has)->{
            if(has&&"عنوان".contentEquals(title.getText()))title.setText("");
            if(!has){String x=title.getText().toString().trim();
                if(x.length()==0){title.setText("عنوان");circleTitle.setText("");progressPrefs.edit().remove("title_"+section+"_"+slot).apply();}
                else{progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();circleTitle.setText(x);}
            }
        });
        title.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence x,int a,int b,int c){}
            public void onTextChanged(CharSequence x,int a,int b,int c){String q=x.toString().trim();circleTitle.setText("عنوان".equals(q)?"":q);}
            public void afterTextChanged(android.text.Editable x){}
        });
        for(int i=0;i<3;i++){final int q=i;iv[i].setClickable(true);iv[i].setOnClickListener(v->{imp[0]=q;ms(section,slot,"importance",""+q);for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));});}
        minus.setClickable(true);plus.setClickable(true);
        minus.setOnClickListener(v->{if(ti[0]>0)ti[0]--;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        plus.setOnClickListener(v->{if(ti[0]<missionTimes.length-1)ti[0]++;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        for(int i=0;i<2;i++){final int q=i;rv[i].setClickable(true);rv[i].setOnClickListener(v->{rp[0]=q;ms(section,slot,"repeat",""+q);for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));});}
        start.setClickable(true);start.setOnClickListener(v->{String x=title.getText().toString().trim();if(x.length()==0||"عنوان".equals(x)){Toast.makeText(this,"عنوان مأموریت را وارد کنید",Toast.LENGTH_SHORT).show();return;}progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();Toast.makeText(this,"Mission ready",Toast.LENGTH_SHORT).show();});
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
    }

    // Progress Path rebuild: visual structure only. Mission logic will be added step by step.
    private ScrollView progressScroll;
    private LinearLayout progressPages;
    private int progressSectionCount=1;
    private SharedPreferences progressPrefs;

    private String progressTitle(int section,int slot){
        if(progressPrefs==null) progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        return progressPrefs.getString("title_"+section+"_"+slot,"");
    }
    private void askProgressTitle(final int section,final int slot,final TextView label){
        final EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setText(progressTitle(section,slot));
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(this)
            .setTitle("عنوان مأموریت")
            .setView(input)
            .setPositiveButton("تأیید",(d,w)->{
                String title=input.getText().toString().trim();
                if(title.length()==0) return;
                if(progressPrefs==null) progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
                progressPrefs.edit().putString("title_"+section+"_"+slot,title).apply();
                label.setText(title);
            })
            .setNegativeButton("لغو",null)
            .show();
    }

    private void showProgressPath(){
        isHome=false; ++homeGeneration; content.removeAllViews();
        progressSectionCount=1;
        progressScroll=new ScrollView(this);
        progressScroll.setFillViewport(true);
        progressScroll.setClipToPadding(false);
        progressScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        progressScroll.setBackgroundColor(Color.TRANSPARENT);
        progressPages=new LinearLayout(this);
        progressPages.setOrientation(LinearLayout.VERTICAL);
        progressPages.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        progressScroll.addView(progressPages,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1);
        lp.topMargin=0;
        content.addView(progressScroll,lp);
        addProgressSection(false);
    }

    private void refreshProgressArrows(){if(progressPages==null)return;for(int i=0;i<progressPages.getChildCount();i++){View p=progressPages.getChildAt(i);View u=p.findViewWithTag("progress_up"),d=p.findViewWithTag("progress_down");if(u!=null){u.setVisibility(i==0?View.VISIBLE:View.GONE);u.setEnabled(i==0);}if(d!=null)d.setVisibility(i==0&&progressSectionCount>1?View.VISIBLE:View.GONE);}}

    private void addProgressSection(boolean animateToNew){
        final int sectionNumber=progressSectionCount;
        final FrameLayout page=new FrameLayout(this);
        int w=getResources().getDisplayMetrics().widthPixels;
        int pageHeight=Math.round(w*2f);

        ImageView art=new ImageView(this);
        art.setImageResource(sectionNumber%2==1?R.drawable.progress_path_first:R.drawable.progress_path_second);
        art.setScaleType(ImageView.ScaleType.FIT_XY);
        page.addView(art,new FrameLayout.LayoutParams(-1,-1));

        // Tiny naked up-arrow: top-left, no circle/square/background.
        TextView up=tv("↑",22,0xFF174FD6);
        up.setContentDescription("ادامه مسیر"); up.setTag("progress_up");
        up.setBackgroundColor(Color.TRANSPARENT);
        up.setShadowLayer(dp(2),0,dp(1),0xAAFFFFFF);
        up.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.TOP|Gravity.LEFT);
        ap.leftMargin=dp(8);
        ap.topMargin=dp(52);
        page.addView(up,ap);
        up.setOnClickListener(v->{
            progressSectionCount++;
            addProgressSection(true);
        });

        // Touch centers measured from the supplied 768x1536 progress artworks.
        // Odd pages: 3 circles on the left. Even pages: 3 circles on the right.
        final float[][] odd={{0.3667f,0.2370f},{0.2377f,0.4891f},{0.3096f,0.7581f}};
        final float[][] even={{0.6333f,0.2370f},{0.7623f,0.4891f},{0.6904f,0.7581f}};
        final float[][] pts=(sectionNumber%2==1)?odd:even;
        final int circleSize=Math.round(w*0.318f);

        for(int i=0;i<3;i++){
            final int slot=i;
            TextView mission=tv(progressTitle(sectionNumber,slot),14,0xFF162D54);
            mission.setGravity(Gravity.CENTER);
            mission.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            mission.setMaxLines(2);
            mission.setPadding(0,0,0,0);
            mission.setBackgroundColor(Color.TRANSPARENT);
            mission.setContentDescription("جایگاه مأموریت "+(slot+1));
            int cx=Math.round(w*pts[i][0]);
            int cy=Math.round(pageHeight*pts[i][1]);
            FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(circleSize,circleSize);
            mp.leftMargin=cx-circleSize/2;
            mp.topMargin=cy-circleSize/2;
            page.addView(mission,mp);
            mission.setOnClickListener(v->showMissionEditor(sectionNumber,slot));
        }

        TextView down=tv("↓",22,0xFF174FD6);down.setTag("progress_down");down.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams dl=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.BOTTOM|Gravity.LEFT);dl.leftMargin=dp(8);dl.bottomMargin=dp(8);page.addView(down,dl);
        down.setOnClickListener(v->{boolean empty=true;for(int k=0;k<3;k++)if(progressTitle(sectionNumber,k).trim().length()>0)empty=false;if(!empty){Toast.makeText(this,"برای حذف صفحه، دایره‌ها باید خالی باشند",Toast.LENGTH_SHORT).show();return;}if(sectionNumber==progressSectionCount&&progressSectionCount>1){progressPages.removeView(page);progressSectionCount--;refreshProgressArrows();}});
        progressPages.addView(page,0,new LinearLayout.LayoutParams(-1,pageHeight));refreshProgressArrows();
        if(animateToNew){
            progressScroll.post(()->progressScroll.smoothScrollTo(0,0));
        }else{
            progressScroll.post(()->progressScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void showGameSettings(){
        final String[] opts={"10 دقیقه","15 دقیقه","20 دقیقه","30 دقیقه","45 دقیقه","60 دقیقه"};
        final int[] vals={10,15,20,30,45,60}; int checked=3; for(int i=0;i<vals.length;i++)if(vals[i]==comboWindowMinutes)checked=i;
        new AlertDialog.Builder(this).setTitle("مهلت ادامه Combo").setSingleChoiceItems(opts,checked,(d,which)->{comboWindowMinutes=vals[which];expireComboIfNeeded();saveGameState();d.dismiss();Toast.makeText(this,"مهلت Combo: "+comboWindowMinutes+" دقیقه",Toast.LENGTH_SHORT).show();}).setNegativeButton("بستن",null).show();
    }

    private void showPlaceholder(String title){
        isHome = false;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(Color.rgb(10,31,51));
        TextView t=tv(title,28,Color.WHITE); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,0xFFBFD4E6); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
    }
    @Override public void onBackPressed(){
        // On a section, Back returns Home. On Home, double Back exits.
        if(!isHome){ showHome(); return; }
        long now=System.currentTimeMillis();
        if(now-lastBackAt<1800){ super.onBackPressed(); }
        else { lastBackAt=now; Toast.makeText(this,"برای خروج دوباره بزنید",Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
    private float dp(float x){ return x*getResources().getDisplayMetrics().density; }
}

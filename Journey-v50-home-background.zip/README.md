Journey-v49-progress-path-final

Final closure of the Journey Progress Path / Mission flow.

Included:
- 7 stacked Progress Path artworks with 21 stages.
- Persistent mission timer based on a saved end timestamp; closing or killing the app does not reset a running mission.
- Paused missions reopen paused with their exact saved remaining time.
- If the timer expires while the app is closed, reopening shows 00:00 and ? until the user chooses Done or Fail.
- Only one active mission is allowed. Re-entering the same active stage resumes it instead of restarting its timer.
- Done = green path circle + struck-through title; Fail = red circle + struck-through title; Active = blue state.
- NEW final path interaction: a single tap on a Done/Fail circle opens that stage page for review/edit.
- NEW final path interaction: a double tap on a Done/Fail circle within 300 ms resets only that stage result.
- Reset preserves title/settings, removes Done/Fail styling, returns that stage's recorded XP/coins, and recalculates combo from remaining results.
- Result submission remains locked against duplicate rewards.
- Timer and Pause/Resume visual calibration from v48 retained.
- No Android notification/reminder scheduling in this version, per current requirement.
- Journey safe-area Header/Bottom Bar behavior remains unchanged.
- App version: 1.7 (versionCode 11).

Journey v45 — Persistent Timer / Result-Wait State

Changes in this stage:
1. Active mission survives app/activity restarts using the persisted end timestamp.
2. On cold launch, if a mission is active, Journey reopens that mission instead of resetting the timer.
3. When the timer reaches 00:00 it does NOT auto-complete.
4. The center Pause/Resume control changes to a question mark (?) at 00:00 and waits for the user to choose Done or Fail.
5. The zero-time/result-wait state is persisted, so reopening the app still shows 00:00 and ?.
6. Timer visual position moved ~0.5 mm upward relative to v44.
7. Pause/Resume moved ~1 mm upward and its overlay icon is slightly smaller.
8. Existing 7 path images, 21 nodes, subtasks, Header/Bottom Bar, Done/Fail buttons, and stage settings remain intact.
9. Notifications are intentionally not added in this version.

# Legacy v96 — Hero Themes + Unified Glass UI

This build continues directly from `Legacy-v95-all-discussed-fixes.zip` and keeps all existing gameplay/data state shared while adding a visual Hero system.

## Hero system
- Three selectable Heroes from the HUD avatar.
- Hero 1 is the default and is always free.
- Hero 2 costs 10 coins each time the user switches to it.
- Hero 3 costs 25 coins each time the user switches to it.
- Paid Heroes are not permanently unlocked; switching away and returning charges again.
- Paid switches require confirmation and are blocked when the coin balance is insufficient.
- The active Hero persists through app restarts and is included in normal SharedPreferences backup/restore.
- Hero selection changes visuals only. Missions, Done/Fail state, XP, coins, level, combo, Tree data, Time Travel, Dream Palace, Shop purchases and World Cup progress remain shared.

## 30 synchronized visual states
Each Hero has a matching 10-image set:
1. Home
2. Progress Path — first section artwork
3. Progress Path — second section artwork
4. Mission editor
5. Running mission
6. Tree
7. Dream Palace
8. Time Travel
9. Shop
10. World Cup

Progress Path mission-circle coordinates and sizes are calibrated separately for every supplied Hero artwork so titles, states and touch targets stay centered on the baked circles. Mission-editor form/touch rectangles are also calibrated per Hero because those supplied artworks intentionally place the glass controls at slightly different vertical positions.

## Unified UI
- Airy white / blue / glass design language across HUD, dialogs, cards and overlays.
- Header, Home Next Step, active-mission bar, Shop, World Cup, Time Travel, Dream Crop/Viewer, Settings, Backup/Restore and mission dialogs share the same visual language.
- Old gold Android accent replaced by blue.
- Status and navigation bars use the light game theme.
- Pre-load/fallback surfaces use the same light blue base.
- Day-start time selector is an in-app themed picker instead of the stock Android time dialog.
- Time Travel dialogs use the same instant glass dialog theme.

## Icons and notifications
- Fixed launcher icon uses the approved minimal white/blue Tree emblem so it matches the app's marble/sky-blue visual theme.
- Mission notifications are native Android notifications: mission title + live remaining-time countdown, with only the native Done / Later / Fail actions.
- The old duplicated custom notification action card is no longer used.

## Presence reward
- A 5-coin presence reward accrues one cent at a time over 2 minutes while the app is in the foreground.
- Leaving the app discards only the fractional cents; completed whole coins remain and the same 5-coin cycle resumes next time.
- A new 5-coin cycle becomes available 3 hours after the previous 5 coins are fully completed.
- Mission/shop coin changes remain independent from the presence-reward progress.

## Existing v95 behavior retained
- Time Travel week transitions/conflict checking/statuses.
- Full backup/restore.
- Home Next Step and Home/Tree To-Do.
- Shop purchase archive/refunds and one-time/infinite rewards.
- Mission timer, notifications, music, subtasks, rewards and Restore behavior.

## Version
- Android versionCode: 55
- Android versionName: 1.51

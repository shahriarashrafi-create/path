package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.text.InputType;
import android.view.*;
import android.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content;
    private View activeBar, hudHeader;
    private boolean isRunningMissionScreen=false;
    private final java.util.HashMap<String,TextView> progressMissionViews=new java.util.HashMap<>();
    private int progressNewMissionSection=-1,progressNewMissionSlot=-1,progressResultAnimSection=-1,progressResultAnimSlot=-1;
    private String treeRecentStatsNodeId=null;
    private TextView hudLevel, hudXpText, hudCoinText, hudComboText, shopCoinChip; private XpBarView hudXpBar;
    private ImageView hudAvatar;
    private int currentMissionEditorSection=-1,currentMissionEditorSlot=-1;
    private boolean isProgressPathScreen=false, isMissionEditorScreen=false, isPlaceholderScreen=false, isTreeScreen=false;
    private int pendingProgressFocusSection=-1,pendingProgressFocusSlot=-1;
    private boolean isDreamPalaceScreen=false, isDreamViewerScreen=false, isTimeTravelScreen=false, isShopScreen=false, isWorldCupScreen=false;
    private android.content.SharedPreferences dreamPrefs;
    private int dreamPage=0, dreamViewerSlot=-1;
    private boolean dreamViewerSequenceMode=false;
    private int pendingDreamSlot=-1;
    private boolean pendingDreamEditing=false, pendingDreamReturnToViewer=false, pendingDreamSequenceMode=false;
    private String pendingDreamTempPath=null, pendingDreamOriginalTempPath=null;
    private boolean dreamPageAnimating=false, dreamViewerAnimating=false;
    private static final int REQ_DREAM_IMAGE=4102;
    private static final int REQ_FULL_BACKUP_EXPORT=5103;
    private static final int REQ_FULL_BACKUP_IMPORT=5104;
    private android.media.SoundPool uiSoundPool;
    private int uiClickSoundId=0,sfxConfirmId=0,sfxFailId=0,sfxRestoreId=0,sfxSubtaskId=0,sfxMusicId=0,sfxToggleId=0,sfxResetId=0,sfxRewardId=0,sfxStartId=0,sfxTimerEndId=0;
    private final java.util.HashSet<Integer> readySfxIds=new java.util.HashSet<>();
    private Runnable homeActiveTick, dailyResetTick;
    private String lastObservedMissionDay="";
    private boolean isHome = true;
    private long lastHomeBackAt=0L;
    private int homeGeneration = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","درخت تصاعد","سفر در زمان","مرکز خرید","جام جهانی"};
    private static class ShopItem{
        String id,title,subtitle;
        int price,iconIndex;
        boolean oneTime;
        ShopItem(String id,String title,String subtitle,int price,int iconIndex){this(id,title,subtitle,price,iconIndex,false);}
        ShopItem(String id,String title,String subtitle,int price,int iconIndex,boolean oneTime){this.id=id;this.title=title;this.subtitle=subtitle;this.price=price;this.iconIndex=iconIndex;this.oneTime=oneTime;}
    }
    private static class ShopPurchase{
        String purchaseId,itemId,title;
        int price,iconIndex;
        boolean oneTime;
        long boughtAt;
        ShopPurchase(String purchaseId,String itemId,String title,int price,int iconIndex,boolean oneTime,long boughtAt){this.purchaseId=purchaseId;this.itemId=itemId;this.title=title;this.price=price;this.iconIndex=iconIndex;this.oneTime=oneTime;this.boughtAt=boughtAt;}
    }
    private final String[] shopRewardIcons={"☕","🎬","🍿","🍰","🎁","🛍️","🍫","🍔","🍕","🍹","📚","🎮","🎧","🧸","🏆","⭐","🎟️","💡","🚗","🛌"};
    private final String[] shopRewardIconNames={"قهوه","فیلم","پاپ‌کورن","دسر","هدیه","خرید","شکلات","برگر","پیتزا","نوشیدنی","کتاب","بازی","موسیقی","عروسک","جام","ستاره","بلیت","ایده","ماشین","استراحت"};
    private String treeFocusNodeId=null;
    private float treeSavedScale=1f,treeSavedPanX=0f,treeSavedPanY=0f;
    private boolean treeViewStateValid=false;
    private String treeHistoryViewDate=null;
    private final java.util.LinkedHashMap<String,java.util.HashMap<String,String>> treeHistoryData=new java.util.LinkedHashMap<>();
    private final java.util.HashMap<String,float[]> treeLastPositions=new java.util.HashMap<>();
    private boolean treeAnimateNextLayout=false;
    private TreeIconView treeExpandAllButton=null;
    // Touch centers measured against the current 768x1536 Home artwork.
    // Order matches names: Progress, Dream Palace, Growth Forest, Time Travel, Shop, World Cup.
    private final float[][] centers = {{0.198f,0.686f},{0.500f,0.686f},{0.802f,0.686f},{0.198f,0.852f},{0.500f,0.852f},{0.804f,0.852f}};

    private static class HomeNextMissionData{
        int section,slot,minutes,xp,coins;
        String title="";
        String state="";
        boolean exists=false;
    }

    @Override public void onCreate(Bundle b){ super.onCreate(b); applySystemChrome(); try{setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);}catch(Exception ignored){} initUiClickSound(); showHome(); }
    @Override protected void onResume(){
        super.onResume();
        loadGameState(); updateHud();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        if(progressPrefs.getBoolean("active",false)){long end=progressPrefs.getLong("active_end",0L);if(end>System.currentTimeMillis())MissionNotification.showRunning(this);else MissionNotification.showFinished(this);}
        startPresenceRewardLoop();
        if(isRunningMissionScreen&&!progressPrefs.getBoolean("active",false)){stopMissionTimer();stopMissionMusic();showProgressPath();consumePendingMissionFeedback();startDailyResetTicker();return;}
        refreshProgressMissionVisuals();
        if(isTreeScreen)showTreePage();
        if(!isRunningMissionScreen&&!isTimeTravelScreen&&!isDreamPalaceScreen&&!isDreamViewerScreen)addActiveMissionBar();
        consumePendingMissionFeedback();
        startDailyResetTicker();
    }
    @Override protected void onPause(){
        stopPresenceRewardLoop(true);
        super.onPause();
        if(dailyResetTick!=null){missionHandler.removeCallbacks(dailyResetTick);dailyResetTick=null;}
    }
    @Override protected void onDestroy(){
        stopPresenceRewardLoop(true);
        try{if(uiSoundPool!=null){uiSoundPool.release();uiSoundPool=null;}}catch(Exception ignored){}
        super.onDestroy();
    }
    private void initUiClickSound(){
        try{
            android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_GAME).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            uiSoundPool=new android.media.SoundPool.Builder().setMaxStreams(8).setAudioAttributes(aa).build();
            uiSoundPool.setOnLoadCompleteListener((sp,id,status)->{if(status==0)readySfxIds.add(id);});
            uiClickSoundId=uiSoundPool.load(this,R.raw.ui_click,1);
            sfxConfirmId=uiSoundPool.load(this,R.raw.sfx_confirm,1);
            sfxFailId=uiSoundPool.load(this,R.raw.sfx_fail,1);
            sfxRestoreId=uiSoundPool.load(this,R.raw.sfx_restore,1);
            sfxSubtaskId=uiSoundPool.load(this,R.raw.sfx_subtask,1);
            sfxMusicId=uiSoundPool.load(this,R.raw.sfx_music,1);
            sfxToggleId=uiSoundPool.load(this,R.raw.sfx_toggle,1);
            sfxResetId=uiSoundPool.load(this,R.raw.sfx_reset,1);
            sfxRewardId=uiSoundPool.load(this,R.raw.sfx_reward,1);
            sfxStartId=uiSoundPool.load(this,R.raw.sfx_start,1);
            sfxTimerEndId=uiSoundPool.load(this,R.raw.sfx_timer_end,1);
        }catch(Exception ignored){uiSoundPool=null;readySfxIds.clear();}
    }
    private SharedPreferences appSettingsPrefs(){
        return getSharedPreferences("legacy_app_settings",MODE_PRIVATE);
    }

    // Unified airy blue/glass visual language used by every Legacy surface.
    private static final int THEME_PRIMARY=0xFF2F8DFF;
    private static final int THEME_PRIMARY_2=0xFF72C9FF;
    private static final int THEME_VIOLET=0xFF7567F3;
    private static final int THEME_TEXT=0xFF17345D;
    private static final int THEME_MUTED=0xFF60758F;
    private static final int THEME_FALLBACK=0xFFEAF4FF;
    private static final int THEME_GLASS=0xEAF8FBFF;

    private int activeHero(){
        int h=appSettingsPrefs().getInt("active_hero",1);
        return h<1||h>3?1:h;
    }
    private int heroPick(int h1,int h2,int h3){int h=activeHero();return h==2?h2:(h==3?h3:h1);}
    private int heroAvatarResource(){return heroPick(R.drawable.hero1_avatar,R.drawable.hero2_avatar,R.drawable.hero3_avatar);}
    private int heroHomeBackground(){return heroPick(R.drawable.hero1_home,R.drawable.hero2_home,R.drawable.hero3_home);}
    private int heroProgressFirstBackground(){return heroPick(R.drawable.hero1_progress_first,R.drawable.hero2_progress_first,R.drawable.hero3_progress_first);}
    private int heroProgressSecondBackground(){return heroPick(R.drawable.hero1_progress_second,R.drawable.hero2_progress_second,R.drawable.hero3_progress_second);}
    private int heroMissionEditorBackground(){return heroPick(R.drawable.hero1_mission_editor,R.drawable.hero2_mission_editor,R.drawable.hero3_mission_editor);}
    private int heroMissionRunningBackground(){return heroPick(R.drawable.hero1_mission_running,R.drawable.hero2_mission_running,R.drawable.hero3_mission_running);}
    private int heroTreeBackground(){return heroPick(R.drawable.hero1_tree,R.drawable.hero2_tree,R.drawable.hero3_tree);}
    private int heroDreamBackground(){return heroPick(R.drawable.hero1_dream,R.drawable.hero2_dream,R.drawable.hero3_dream);}
    private int heroTimeBackground(){return heroPick(R.drawable.hero1_time,R.drawable.hero2_time,R.drawable.hero3_time);}
    private int heroShopBackground(){return heroPick(R.drawable.hero1_shop,R.drawable.hero2_shop,R.drawable.hero3_shop);}
    private int heroWorldBackground(){return heroPick(R.drawable.hero1_world,R.drawable.hero2_world,R.drawable.hero3_world);}

    private void applySystemChrome(){
        try{
            getWindow().setStatusBarColor(0xFFF0F7FF);
            getWindow().setNavigationBarColor(0xFFF0F7FF);
            int flags=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if(android.os.Build.VERSION.SDK_INT>=26)flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }catch(Exception ignored){}
    }

    private void refreshCurrentVisualPage(){
        if(isHome){showHome();return;}
        if(isMissionEditorScreen&&currentMissionEditorSection>0&&currentMissionEditorSlot>=0){showMissionEditor(currentMissionEditorSection,currentMissionEditorSlot);return;}
        if(isRunningMissionScreen){resumeActiveMission();return;}
        if(isProgressPathScreen){showProgressPath();return;}
        if(isTreeScreen){showTreePage();return;}
        if(isDreamPalaceScreen){showDreamPalace(dreamPage);return;}
        if(isTimeTravelScreen){showTimeTravel();return;}
        if(isShopScreen){showShopCenter();return;}
        if(isWorldCupScreen){showWorldCup();return;}
        if(hudAvatar!=null)hudAvatar.setImageResource(heroAvatarResource());
    }

    private void applyHeroSelection(int hero,int cost){
        if(hero<1||hero>3)return;
        if(hero==activeHero())return;
        loadGameState();
        if(cost>0){
            if(gameCoins<cost){showHeroInsufficientCoins(cost);return;}
            gameCoins-=cost;saveGameState();
        }
        appSettingsPrefs().edit().putInt("active_hero",hero).apply();
        if(hudAvatar!=null)hudAvatar.setImageResource(heroAvatarResource());
        refreshCurrentVisualPage();
    }

    private void showHeroInsufficientCoins(int cost){
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView t=tv("برای این انتخاب "+cost+" سکه لازم است. موجودی: "+gameCoins,13,THEME_MUTED);t.setGravity(Gravity.CENTER);t.setPadding(dp(6),dp(4),dp(6),dp(4));b.addView(t,new LinearLayout.LayoutParams(-1,-2));
        buildPastelDialog("●","سکه کافی نیست","هیرو تغییر نکرد",0xFFE65268,b,"باشه",THEME_PRIMARY,null,null,null).show();
    }

    private void confirmHeroSelection(final int hero,final int cost){
        loadGameState();
        if(gameCoins<cost){showHeroInsufficientCoins(cost);return;}
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView t=tv("با انتخاب این هیرو "+cost+" سکه از حسابت کم می‌شود.",13,THEME_MUTED);t.setGravity(Gravity.CENTER);t.setPadding(dp(6),dp(4),dp(6),dp(4));b.addView(t,new LinearLayout.LayoutParams(-1,-2));
        buildPastelDialog("✦","انتخاب هیرو","",THEME_PRIMARY,b,"انتخاب",THEME_PRIMARY,()->applyHeroSelection(hero,cost),"لغو",null).show();
    }

    private void showHeroPicker(){
        loadGameState();
        final Dialog[] ref={null};
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final int selected=activeHero();
        for(int hero=1;hero<=3;hero++){
            final int h=hero;final int cost=h==1?0:(h==2?10:25);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setPadding(dp(9),dp(7),dp(9),dp(7));
            GradientDrawable rg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{h==selected?0xFFF0F7FF:0xFFF9FBFF,h==selected?0xFFE4F2FF:0xFFF2F7FF});rg.setCornerRadius(dp(18));rg.setStroke(Math.max(1,dp(h==selected?2:1)),h==selected?0xAA4A9DFF:0x334D8DFF);row.setBackground(rg);row.setClickable(true);row.setFocusable(true);
            ImageView av=new ImageView(this);av.setImageResource(h==1?R.drawable.hero1_avatar:(h==2?R.drawable.hero2_avatar:R.drawable.hero3_avatar));av.setScaleType(ImageView.ScaleType.CENTER_CROP);GradientDrawable mask=bg(0xFFF4F9FF,dp(999));mask.setStroke(Math.max(1,dp(1)),0x8854A9FF);av.setBackground(mask);av.setClipToOutline(true);row.addView(av,new LinearLayout.LayoutParams(dp(62),dp(62)));
            LinearLayout texts=new LinearLayout(this);texts.setOrientation(LinearLayout.VERTICAL);texts.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);texts.setPadding(dp(10),0,dp(10),0);TextView name=tv("هیرو "+h,15,THEME_TEXT);name.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);TextView price=tv(cost==0?"رایگان":cost+" سکه برای هر بار انتخاب",11,cost==0?0xFF238A62:THEME_MUTED);price.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);price.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);texts.addView(name,new LinearLayout.LayoutParams(-1,dp(28)));texts.addView(price,new LinearLayout.LayoutParams(-1,dp(24)));row.addView(texts,new LinearLayout.LayoutParams(0,dp(62),1f));
            TextView state=tv(h==selected?"فعال":"›",h==selected?11:22,h==selected?THEME_PRIMARY:0xFF6A85A2);state.setGravity(Gravity.CENTER);if(h==selected){GradientDrawable sg=bg(0xFFE8F4FF,dp(999));sg.setStroke(Math.max(1,dp(1)),0x6654A9FF);state.setBackground(sg);}row.addView(state,new LinearLayout.LayoutParams(h==selected?dp(50):dp(32),dp(32)));
            LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(78));rlp.bottomMargin=dp(8);body.addView(row,rlp);
            row.setOnClickListener(v->{playViewSound(v);if(ref[0]!=null)ref[0].dismiss();if(h==selected)return;if(cost==0)applyHeroSelection(h,0);else confirmHeroSelection(h,cost);});
        }
        ref[0]=buildPastelDialog("✦","انتخاب هیرو","",THEME_PRIMARY,body,null,0,null,"بستن",null);ref[0].show();
    }
    private boolean isSfxEnabled(){
        return appSettingsPrefs().getBoolean("sfx_enabled",true);
    }
    private boolean isMusicEnabled(){
        return appSettingsPrefs().getBoolean("music_enabled",true);
    }
    private boolean isNotificationsEnabled(){
        return appSettingsPrefs().getBoolean("notifications_enabled",true);
    }
    private void setMissionMusicOutput(){
        try{
            if(missionPlayer!=null){
                boolean on=isMusicEnabled()&&!missionMuted;
                missionPlayer.setVolume(on?1f:0f,on?1f:0f);
            }
        }catch(Exception ignored){}
    }
    private void playSfx(int soundId,float volume){
        try{if(!isSfxEnabled())return;if(uiSoundPool!=null&&soundId!=0&&readySfxIds.contains(soundId))uiSoundPool.play(soundId,Math.max(.55f,volume),Math.max(.55f,volume),1,0,1f);}catch(Exception ignored){}
    }
    private void playUiClick(){playSfx(uiClickSoundId,.65f);}
    private int soundForView(View v){
        StringBuilder q=new StringBuilder();
        try{CharSequence cd=v.getContentDescription();if(cd!=null)q.append(cd).append(' ');}catch(Exception ignored){}
        if(v instanceof TextView){CharSequence tx=((TextView)v).getText();if(tx!=null)q.append(tx);}
        String x=q.toString().toLowerCase(java.util.Locale.ROOT);
        if(x.contains("restore")||x.contains("ریستور")||x.contains("بازیابی"))return sfxRestoreId;
        if(x.contains("fail")||x.contains("delete")||x.contains("حذف")||x.contains("انجام نشد"))return sfxFailId;
        if(x.contains("done")||x.contains("complete")||x.contains("انجام شد")||x.contains("تکمیل"))return sfxConfirmId;
        if(x.contains("subtask")||x.contains("ساب"))return sfxSubtaskId;
        if(x.contains("music")||x.contains("موسیقی")||x.contains("آهنگ"))return sfxMusicId;
        if(x.contains("sound")||x.contains("صدا")||x.contains("mute"))return sfxToggleId;
        if(x.contains("reset")||x.contains("restart")||x.contains("later")||x.contains("توقف")||x.contains("pause"))return sfxResetId;
        if(x.contains("start")||x.contains("continue")||x.contains("شروع")||x.contains("ادامه"))return sfxStartId;
        return uiClickSoundId;
    }
    private void playViewSound(View v){
        int id=soundForView(v);
        float vol=(id==sfxFailId?.82f:id==sfxRewardId?.86f:id==sfxStartId?.76f:id==sfxConfirmId?.78f:.68f);
        playSfx(id,vol);
    }
    // Package-visible bridge so the code-rendered Time Travel view uses the exact same
    // click / confirm / fail sound language as the rest of Legacy.
    void playTimeTravelUiSound(View v){
        if(v==null) playUiClick(); else playViewSound(v);
    }
    private View clickableViewAt(View v,float rawX,float rawY){
        if(v==null||v.getVisibility()!=View.VISIBLE||v.getAlpha()<=0f)return null;
        int[] loc=new int[2];try{v.getLocationOnScreen(loc);}catch(Exception e){return null;}
        if(rawX<loc[0]||rawY<loc[1]||rawX>loc[0]+v.getWidth()||rawY>loc[1]+v.getHeight())return null;
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=g.getChildCount()-1;i>=0;i--){View hit=clickableViewAt(g.getChildAt(i),rawX,rawY);if(hit!=null)return hit;}}
        return v.isClickable()?v:null;
    }
    @Override public boolean dispatchTouchEvent(MotionEvent ev){
        return super.dispatchTouchEvent(ev);
    }
    private void enableAutoSize(TextView v,int minSp,int maxSp){
        if(v==null)return;
        if(android.os.Build.VERSION.SDK_INT>=26){
            try{v.setAutoSizeTextTypeUniformWithConfiguration(minSp,maxSp,1,android.util.TypedValue.COMPLEX_UNIT_SP);}catch(Exception ignored){}
        }
    }
    private android.graphics.RectF fitCenterRect(int boxW,int boxH,float srcW,float srcH){
        if(boxW<=0||boxH<=0||srcW<=0||srcH<=0)return new android.graphics.RectF(0,0,boxW,boxH);
        float scale=Math.min(boxW/srcW,boxH/srcH);
        float w=srcW*scale,h=srcH*scale;
        float left=(boxW-w)/2f,top=(boxH-h)/2f;
        return new android.graphics.RectF(left,top,left+w,top+h);
    }
    private void placeOnCanvas(FrameLayout.LayoutParams p,android.graphics.RectF canvas,float[] q){
        p.width=Math.round(canvas.width()*q[2]);p.height=Math.round(canvas.height()*q[3]);
        p.leftMargin=Math.round(canvas.left+canvas.width()*q[0]);p.topMargin=Math.round(canvas.top+canvas.height()*q[1]);
    }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    private android.graphics.drawable.Drawable pressRipple(int color){
        GradientDrawable mask=new GradientDrawable();mask.setShape(GradientDrawable.OVAL);mask.setColor(Color.WHITE);
        return new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(color),null,mask);
    }

    // Soft blue/purple dialog language used across mission popups.
    private GradientDrawable pastelCardBg(int accent){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFFFCFDFF,0xFFF3F7FF,0xFFF8F4FF});
        g.setCornerRadius(dp(24));g.setStroke(Math.max(1,Math.round(dp(.7f))),withAlpha(accent,0x66));return g;
    }
    private GradientDrawable pastelButtonBg(int c1,int c2){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{c1,c2});g.setCornerRadius(dp(14));return g;
    }
    private TextView dialogButton(String text,int c1,int c2,boolean light){
        TextView b=tv(text,14,light?0xFF17345D:Color.WHITE);b.setGravity(Gravity.CENTER);b.setBackground(pastelButtonBg(c1,c2));b.setElevation(dp(2));b.setPadding(dp(8),0,dp(8),0);return b;
    }
    private TextView rewardChip(String text,int textColor,int fill,int stroke){
        TextView v=tv(text,13,textColor);v.setGravity(Gravity.CENTER);GradientDrawable g=bg(fill,dp(13));g.setStroke(Math.max(1,dp(1)),stroke);v.setBackground(g);v.setPadding(dp(10),0,dp(10),0);return v;
    }
    private Dialog buildPastelDialog(String icon,String title,String subtitle,int accent,View body,String positive,int positiveColor,Runnable positiveAction,String negative,Runnable negativeAction){
        final Dialog d=new Dialog(this,R.style.InstantDialogTheme);d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(20),dp(14),dp(20),dp(20));card.setBackground(pastelCardBg(accent));card.setElevation(dp(6));
        FrameLayout top=new FrameLayout(this);card.addView(top,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView close=tv("×",22,0xFF29436E);close.setGravity(Gravity.CENTER);FrameLayout.LayoutParams xlp=new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.RIGHT|Gravity.TOP);top.addView(close,xlp);
        final TextView ico=tv(icon==null?"✦":icon,28,accent);ico.setGravity(Gravity.CENTER);GradientDrawable ig=bg(0xEAF3F7FF,dp(999));ig.setStroke(Math.max(1,dp(1)),0x443B7CFF);ico.setBackground(ig);FrameLayout.LayoutParams ilp=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.CENTER);top.addView(ico,ilp);
        if("تنظیمات".equals(title)){
            LinearLayout backupTools=new LinearLayout(this);backupTools.setOrientation(LinearLayout.HORIZONTAL);backupTools.setGravity(Gravity.CENTER);backupTools.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            ImageView exportIcon=settingsHeaderIcon(R.drawable.ic_backup_export,"خروجی پشتیبان");
            ImageView importIcon=settingsHeaderIcon(R.drawable.ic_backup_import,"بارگذاری پشتیبان");
            backupTools.addView(exportIcon,new LinearLayout.LayoutParams(dp(38),dp(38)));
            backupTools.addView(importIcon,new LinearLayout.LayoutParams(dp(38),dp(38)));
            FrameLayout.LayoutParams btlp=new FrameLayout.LayoutParams(dp(80),dp(42),Gravity.LEFT|Gravity.TOP);btlp.leftMargin=0;btlp.topMargin=dp(3);top.addView(backupTools,btlp);
            exportIcon.setOnClickListener(v->{playViewSound(v);d.dismiss();launchFullBackupExport();});
            importIcon.setOnClickListener(v->{playViewSound(v);d.dismiss();launchFullBackupImport();});
        }
        TextView t=tv(title==null?"":title,19,0xFF142C54);t.setGravity(Gravity.CENTER);card.addView(t,new LinearLayout.LayoutParams(-1,dp(34)));
        if(subtitle!=null&&subtitle.trim().length()>0){TextView sub=tv(subtitle,13,0xFF536785);sub.setGravity(Gravity.CENTER);sub.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);sub.setPadding(dp(6),0,dp(6),0);card.addView(sub,new LinearLayout.LayoutParams(-1,-2));}
        if(body!=null){LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,-2);blp.topMargin=dp(12);card.addView(body,blp);}
        if((positive!=null&&positive.length()>0)||(negative!=null&&negative.length()>0)){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(52));rlp.topMargin=dp(14);card.addView(row,rlp);
            if(positive!=null&&positive.length()>0){TextView ok=dialogButton(positive,positiveColor,0xFF7B61FF,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1f);lp.setMargins(dp(5),0,0,0);row.addView(ok,lp);ok.setOnClickListener(v->{playViewSound(v);d.dismiss();if(positiveAction!=null)positiveAction.run();});}
            if(negative!=null&&negative.length()>0){TextView no=dialogButton(negative,0xFFF8FAFF,0xFFEFF3FB,true);GradientDrawable ng=pastelButtonBg(0xFFF8FAFF,0xFFEFF3FB);ng.setStroke(Math.max(1,dp(1)),0x334D6B9A);no.setBackground(ng);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1f);lp.setMargins(0,0,dp(5),0);row.addView(no,lp);no.setOnClickListener(v->{playViewSound(v);d.dismiss();if(negativeAction!=null)negativeAction.run();});}
        }
        close.setOnClickListener(v->{playViewSound(v);d.dismiss();});
        d.setContentView(card);d.setCanceledOnTouchOutside(true);
        // Configure the dialog window BEFORE show() so Android never gets a frame to run a slide-in transition.
        Window pre=d.getWindow();
        if(pre!=null){
            pre.setWindowAnimations(0);
            pre.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams a=pre.getAttributes();
            a.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(390));
            a.height=WindowManager.LayoutParams.WRAP_CONTENT;a.gravity=Gravity.CENTER;a.dimAmount=.26f;
            pre.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);pre.setAttributes(a);
        }
        d.setOnShowListener(x->{
            Window w=d.getWindow();if(w!=null){w.setWindowAnimations(0);WindowManager.LayoutParams a=w.getAttributes();a.gravity=Gravity.CENTER;w.setAttributes(a);}
            card.animate().cancel();card.setTranslationX(0f);card.setTranslationY(0f);card.setScaleX(1f);card.setScaleY(1f);card.setAlpha(1f);
            ico.animate().cancel();ico.setTranslationX(0f);ico.setTranslationY(0f);ico.setScaleX(1f);ico.setScaleY(1f);ico.setAlpha(1f);
        });
        return d;
    }
    private void showPastelInputDialog(String title,String initial,Runnable afterSave,java.util.function.Consumer<String> saver){
        EditText input=new EditText(this);input.setSingleLine(true);input.setText(initial==null?"":initial);input.setSelection(input.getText().length());input.setTextSize(15);input.setTextColor(0xFF17345D);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(12),0,dp(12),0);GradientDrawable ig=bg(0xFFF5F8FF,dp(14));ig.setStroke(Math.max(1,dp(1)),0x443B7CFF);input.setBackground(ig);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.addView(input,new LinearLayout.LayoutParams(-1,dp(50)));
        final Dialog[] ref={null};ref[0]=buildPastelDialog("✎",title,"",0xFF4E8CFF,body,"ذخیره",0xFF3F8CFF,()->{String n=input.getText().toString().trim();if(n.length()>0){saver.accept(n);if(afterSave!=null)afterSave.run();}},"لغو",null);ref[0].show();
    }

    private void showHome(){
        lastHomeBackAt=0L;
        stopMissionTimer();
        stopHomeActiveTicker();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome = true; isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;isTreeScreen=false;isDreamPalaceScreen=false;isDreamViewerScreen=false;isTimeTravelScreen=false;isShopScreen=false;isWorldCupScreen=false;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(THEME_FALLBACK);
        activeBar=null;progressMissionViews.clear();
        setContentView(root);
        root.setFitsSystemWindows(true);

        ImageView home=new ImageView(this); home.setImageResource(heroHomeBackground());
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // Legacy HUD reference final polish: premium RPG HUD.
        FrameLayout header=new FrameLayout(this); hudHeader=header;
        header.setPadding(dp(7),0,dp(7),0);
        header.setBackground(new HudBackground());
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(52),Gravity.TOP);
        hp.setMargins(dp(10),dp(6),dp(10),0);
        root.addView(header,hp); header.setVisibility(View.VISIBLE);

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(1),0,dp(1),0);
        header.addView(row,new FrameLayout.LayoutParams(-1,-1));

        ImageView avatar=new ImageView(this); hudAvatar=avatar;
        avatar.setImageResource(heroAvatarResource());
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable avatarMask=bg(0xFFF4F9FF,dp(999));avatarMask.setStroke(Math.max(1,dp(1)),0x8854A9FF);avatar.setBackground(avatarMask);avatar.setClipToOutline(true);
        avatar.setContentDescription("انتخاب هیرو"); avatar.setElevation(dp(2));
        avatar.setClickable(true);avatar.setFocusable(true);avatar.setOnClickListener(v->{playUiClick();showHeroPicker();});
        LinearLayout.LayoutParams avLp=new LinearLayout.LayoutParams(dp(40),dp(40));
        avLp.setMargins(dp(2),0,dp(6),0); row.addView(avatar,avLp);

        loadGameState();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        hudLevel=tv("LV "+gameLevel,12,THEME_TEXT); TextView level=hudLevel;
        level.setGravity(Gravity.CENTER);
        level.setShadowLayer(dp(1),0,0,0x55FFFFFF);
        LinearLayout.LayoutParams levelLp=new LinearLayout.LayoutParams(dp(38),dp(34));
        levelLp.setMargins(0,0,dp(1),0); row.addView(level,levelLp);

        LinearLayout xpGroup=new LinearLayout(this);
        xpGroup.setOrientation(LinearLayout.VERTICAL);
        xpGroup.setGravity(Gravity.CENTER_VERTICAL);
        XpBarView xp=new XpBarView(this); hudXpBar=xp;
        xp.setProgress(gameXp,xpNeeded(gameLevel));
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(9));
        xpLp.setMargins(0,dp(4),0,0); xpGroup.addView(xp,xpLp);
        hudXpText=tv(gameXp+" / "+xpNeeded(gameLevel)+" XP",8,0xFF315D87); TextView xpTxt=hudXpText;
        xpTxt.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        xpGroup.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(14)));
        LinearLayout.LayoutParams xpgLp=new LinearLayout.LayoutParams(dp(112),dp(36));
        xpgLp.setMargins(0,0,dp(3),0); row.addView(xpGroup,xpgLp);

        LinearLayout coinBox=glassCapsule();
        ImageView coinIcon=new ImageView(this);
        coinIcon.setImageResource(R.drawable.hud_coin); coinIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        coinBox.addView(coinIcon,new LinearLayout.LayoutParams(dp(24),dp(24)));
        hudCoinText=tv(presenceCoinText(),13,THEME_TEXT); TextView coin=hudCoinText; coin.setPadding(dp(1),0,0,0);
        coinBox.addView(coin,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(25));
        coinLp.setMargins(0,0,dp(1),0); row.addView(coinBox,coinLp);

        LinearLayout comboBox=glassCapsule();
        comboBox.setClickable(true);
        comboBox.setContentDescription("Combo");
        comboBox.setOnClickListener(v->{playViewSound(v);showGameSettings();});
        ImageView flame=new ImageView(this); flame.setImageResource(R.drawable.hud_flame);
        flame.setScaleType(ImageView.ScaleType.FIT_CENTER);
        comboBox.addView(flame,new LinearLayout.LayoutParams(dp(22),dp(25)));
        hudComboText=tv(String.valueOf(gameCombo),13,THEME_TEXT); TextView combo=hudComboText; comboBox.addView(combo,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(44),dp(25));
        comboLp.setMargins(0,0,dp(1),0); row.addView(comboBox,comboLp);

        ImageView gear=new ImageView(this); gear.setImageResource(R.drawable.hud_gear);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER); gear.setPadding(dp(4),dp(4),dp(4),dp(4));
        gear.setContentDescription("تنظیمات");
        gear.setOnClickListener(v->{playViewSound(v);showAppSettings();});
        row.addView(gear,new LinearLayout.LayoutParams(dp(34),dp(40)));

        // Hit targets follow the six labels baked into the selected 768x1536 Home artwork.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=768f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            // The touch zones sit on the signboards and slightly above their text,
            // matching the new 768x1536 fantasy Home artwork.
            int hitW=Math.max(dp(112), Math.round(205f*scale));
            int hitH=Math.max(dp(120), Math.round(220f*scale));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=Math.round(offsetX + srcW*centers[i][0]*scale);
                int cy=Math.round(offsetY + srcH*centers[i][1]*scale);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-hitW/2; lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==MotionEvent.ACTION_DOWN){ v.setAlpha(.55f); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->{ if(idx==0)playSfx(sfxStartId,.74f);else playUiClick(); if(idx==0) showProgressPath(); else if(idx==1) showDreamPalace(0); else if(idx==2) showTreePage(); else if(idx==3) showTimeTravel(); else if(idx==4) showShopCenter(); else showWorldCup(); }); content.addView(hit,lp);
            }
        });
        addHomeTodoShortcut();
        addHomeNextStepCard();
        addActiveMissionBar();
        header.bringToFront();
    }

    private HomeNextMissionData nextHomeMissionData(){
        HomeNextMissionData out=new HomeNextMissionData();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        int savedSections=Math.max(1,progressPrefs.getInt("progress_section_count",Math.max(1,progressSectionCount)));
        // Same order used by Progress Path auto-scroll: the first unresolved circle from the bottom.
        for(int s=1;s<=savedSections;s++){
            for(int slot=2;slot>=0;slot--){
                String state=missionState(s,slot);
                if("done".equals(state)||"fail".equals(state))continue;
                String title=progressTitle(s,slot).trim();
                if(title.length()==0)continue;
                out.exists=true;out.section=s;out.slot=slot;out.title=title;out.state=state;
                try{out.minutes=Math.max(1,Integer.parseInt(mv(s,slot,"minutes","10")));}catch(Exception ignored){out.minutes=10;}
                out.xp=baseXpForImportance(s,slot);out.coins=baseCoinsForImportance(s,slot);return out;
            }
        }
        return out;
    }

    private TextView homeNextRewardChip(String text){
        TextView chip=tv(text,12,0xFF2D669A);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(8),0,dp(8),0);
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xEAF4FAFF,0xDDE6F3FF});
        g.setCornerRadius(dp(999));g.setStroke(Math.max(1,Math.round(dp(.8f))),0x7754A9FF);chip.setBackground(g);
        chip.setShadowLayer(dp(2),0,0,0x334E8CFF);return chip;
    }

    private GradientDrawable homeNextCardBackground(){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xF5F9FCFF,0xEEF0F7FF,0xF3EAF4FF});
        g.setCornerRadius(dp(24));g.setStroke(Math.max(1,Math.round(dp(1.35f))),0xAA54A9FF);return g;
    }

    private void focusProgressMission(int section,int slot){
        pendingProgressFocusSection=section;pendingProgressFocusSlot=slot;showProgressPath();
    }

    private void startHomeNextMission(HomeNextMissionData data){
        if(data==null||!data.exists)return;
        playSfx(sfxStartId,.78f);
        if("active".equals(data.state)){resumeActiveMission();return;}
        startRunningMission(data.section,data.slot,data.title,data.minutes);
    }

    private void addHomeNextStepCard(){
        if(root==null||!isHome)return;
        try{View old=root.findViewWithTag("home_next_step_card");if(old!=null)root.removeView(old);}catch(Exception ignored){}
        final HomeNextMissionData data=nextHomeMissionData();if(!data.exists)return;

        FrameLayout shell=new FrameLayout(this);shell.setTag("home_next_step_card");shell.setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        FrameLayout.LayoutParams slp=new FrameLayout.LayoutParams(dp(210),dp(158),Gravity.TOP|Gravity.LEFT);slp.leftMargin=dp(16);slp.topMargin=dp(86);

        View halo=new View(this);GradientDrawable hg=bg(0x284CB8FF,dp(29));hg.setStroke(Math.max(1,dp(2)),0x884CB8FF);halo.setBackground(hg);halo.setLayerType(View.LAYER_TYPE_SOFTWARE,null);halo.setAlpha(.98f);
        FrameLayout.LayoutParams hlp=new FrameLayout.LayoutParams(dp(220),dp(168));hlp.leftMargin=-dp(5);hlp.topMargin=-dp(5);shell.addView(halo,hlp);

        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);card.setPadding(dp(13),dp(10),dp(13),dp(10));card.setBackground(homeNextCardBackground());card.setElevation(dp(8));card.setLayerType(View.LAYER_TYPE_SOFTWARE,null);shell.addView(card,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout headerRow=new LinearLayout(this);headerRow.setOrientation(LinearLayout.HORIZONTAL);headerRow.setGravity(Gravity.CENTER_VERTICAL);headerRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView arrow=tv("‹",23,THEME_PRIMARY);arrow.setGravity(Gravity.CENTER);arrow.setShadowLayer(dp(3),0,0,0x4454A9FF);
        TextView head=tv("قدم بعدی",16,THEME_TEXT);head.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        headerRow.addView(arrow,new LinearLayout.LayoutParams(dp(24),dp(27)));headerRow.addView(head,new LinearLayout.LayoutParams(0,dp(27),1f));card.addView(headerRow,new LinearLayout.LayoutParams(-1,dp(29)));
        headerRow.setOnClickListener(v->{playUiClick();focusProgressMission(data.section,data.slot);});

        View divider1=new View(this);divider1.setBackgroundColor(0x4454A9FF);LinearLayout.LayoutParams d1=new LinearLayout.LayoutParams(-1,Math.max(1,dp(1)));d1.topMargin=dp(3);card.addView(divider1,d1);

        LinearLayout middle=new LinearLayout(this);middle.setOrientation(LinearLayout.HORIZONTAL);middle.setGravity(Gravity.CENTER_VERTICAL);middle.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,0,1f);mlp.topMargin=dp(5);card.addView(middle,mlp);
        TextView play=tv("▶",21,Color.WHITE);play.setGravity(Gravity.CENTER);GradientDrawable pg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xFF45B7FF,0xFF5878EE});pg.setCornerRadius(dp(999));pg.setStroke(Math.max(1,Math.round(dp(1.2f))),0xCCDBF4FF);play.setBackground(pg);play.setShadowLayer(dp(4),0,0,0x6654A9FF);play.setContentDescription("Start Mission");
        LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(dp(52),dp(52));plp.rightMargin=dp(12);middle.addView(play,plp);

        LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);details.setGravity(Gravity.CENTER_VERTICAL);details.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);middle.addView(details,new LinearLayout.LayoutParams(0,-2,1f));
        TextView missionTitle=tv(data.title,16,THEME_TEXT);missionTitle.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);missionTitle.setMaxLines(2);missionTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);enableAutoSize(missionTitle,11,16);missionTitle.setShadowLayer(dp(1),0,dp(1),0x55FFFFFF);details.addView(missionTitle,new LinearLayout.LayoutParams(-1,-2));
        TextView time=tv("◷  "+data.minutes+" دقیقه",12,THEME_MUTED);time.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);time.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);LinearLayout.LayoutParams tmlp=new LinearLayout.LayoutParams(-1,dp(22));tmlp.topMargin=dp(2);details.addView(time,tmlp);
        details.setOnClickListener(v->{playUiClick();focusProgressMission(data.section,data.slot);});missionTitle.setOnClickListener(v->{playUiClick();focusProgressMission(data.section,data.slot);});
        play.setOnClickListener(v->startHomeNextMission(data));

        View divider2=new View(this);divider2.setBackgroundColor(0x4454A9FF);LinearLayout.LayoutParams d2=new LinearLayout.LayoutParams(-1,Math.max(1,dp(1)));d2.bottomMargin=dp(5);card.addView(divider2,d2);
        LinearLayout rewards=new LinearLayout(this);rewards.setOrientation(LinearLayout.HORIZONTAL);rewards.setGravity(Gravity.CENTER);rewards.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);card.addView(rewards,new LinearLayout.LayoutParams(-1,dp(27)));
        TextView xp=homeNextRewardChip("✦ +"+data.xp+" XP"),coin=homeNextRewardChip("◉ +"+data.coins+" Coin");
        LinearLayout.LayoutParams rlp1=new LinearLayout.LayoutParams(0,dp(27),1f);rlp1.rightMargin=dp(4);LinearLayout.LayoutParams rlp2=new LinearLayout.LayoutParams(0,dp(27),1f);rlp2.leftMargin=dp(4);rewards.addView(xp,rlp1);rewards.addView(coin,rlp2);

        root.addView(shell,slp);if(hudHeader!=null)hudHeader.bringToFront();if(activeBar!=null)activeBar.bringToFront();
    }

    private String mainTreeNodeId(){ensureTreeGraphV2();return "root";}

    private void removeHomeOnlyOverlays(){
        if(root==null)return;
        try{View v=root.findViewWithTag("home_next_step_card");if(v!=null)root.removeView(v);}catch(Exception ignored){}
        try{View v=root.findViewWithTag("home_todo_shortcut");if(v!=null)root.removeView(v);}catch(Exception ignored){}
    }

    private void addHomeTodoShortcut(){
        if(root==null||!isHome)return;try{View old=root.findViewWithTag("home_todo_shortcut");if(old!=null)root.removeView(old);}catch(Exception ignored){}
        TreeIconView icon=treeIcon(1);icon.setTag("home_todo_shortcut");icon.setContentDescription("To Do");
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.TOP|Gravity.RIGHT);lp.topMargin=dp(66);lp.rightMargin=dp(13);root.addView(icon,lp);
        icon.setOnClickListener(v->{playUiClick();showHomeTodoPanel(false);});if(hudHeader!=null)hudHeader.bringToFront();
    }

    private void showHomeTodoPanel(boolean teamTab){
        showTodoPanelForNode(mainTreeNodeId(),teamTab,true);
    }

    private void showTodoPanelForNode(final String ownerId,boolean initialTeam,boolean fromHome){
        ensureTreeGraphV2();
        final boolean[] team={initialTeam};
        final String[] teamTarget={firstTeamTodoTarget(ownerId)};
        final String ownerName=treeNodeVal(ownerId,"name","بدون نام");

        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);outer.setPadding(0,0,0,dp(2));
        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);tabs.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);tabs.setGravity(Gravity.CENTER);
        TextView selfTab=tv("خود",13,0xFF17345D),teamTabView=tv("تیم",13,0xFF17345D);
        LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(0,dp(40),1f);stp.leftMargin=dp(4);tabs.addView(selfTab,stp);
        LinearLayout.LayoutParams ttp=new LinearLayout.LayoutParams(0,dp(40),1f);ttp.rightMargin=dp(4);tabs.addView(teamTabView,ttp);
        outer.addView(tabs,new LinearLayout.LayoutParams(-1,dp(40)));

        LinearLayout addRow=new LinearLayout(this);addRow.setOrientation(LinearLayout.HORIZONTAL);addRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);addRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams arlp=new LinearLayout.LayoutParams(-1,dp(44));arlp.topMargin=dp(7);outer.addView(addRow,arlp);
        EditText input=(EditText)treeField("کار جدید...","");input.setSingleLine(true);input.setTextSize(13);input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);input.setPadding(dp(10),0,dp(10),0);addRow.addView(input,new LinearLayout.LayoutParams(0,dp(40),1f));
        TextView target=dialogButton("انتخاب فرد",0xFFF7FAFF,0xFFEFF4FF,true);target.setTextSize(11);LinearLayout.LayoutParams trp=new LinearLayout.LayoutParams(dp(84),dp(38));trp.leftMargin=dp(5);addRow.addView(target,trp);
        TextView add=dialogButton("+",0xFF347FC5,0xFF536BC9,false);add.setTextSize(17);LinearLayout.LayoutParams adp=new LinearLayout.LayoutParams(dp(40),dp(38));adp.leftMargin=dp(5);addRow.addView(add,adp);

        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);scroll.setVerticalScrollBarEnabled(false);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        final LinearLayout.LayoutParams scrollLp=new LinearLayout.LayoutParams(-1,dp(72));scrollLp.topMargin=dp(7);outer.addView(scroll,scrollLp);

        final Dialog[] ref={null};final Runnable[] render={null};final Runnable[] updateTabs={null};
        updateTabs[0]=()->{
            selfTab.setBackground(homeTodoTabBg(!team[0]));teamTabView.setBackground(homeTodoTabBg(team[0]));
            selfTab.setTextColor(!team[0]?Color.WHITE:0xFF355270);teamTabView.setTextColor(team[0]?Color.WHITE:0xFF355270);
            target.setVisibility(team[0]?View.VISIBLE:View.GONE);
            String tn=teamTarget[0];target.setText(tn==null?"انتخاب فرد":treeNodeVal(tn,"name","فرد"));
        };
        render[0]=()->{
            list.removeAllViews();java.util.ArrayList<String[]> rows=team[0]?aggregatedTeamTodos(ownerId):selfTodos(ownerId);
            int contentH;
            if(rows.isEmpty()){
                TextView none=tv(team[0]?"برای تیم کاری ثبت نشده":"کاری ثبت نشده",12,0xFF8794A7);none.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);none.setGravity(Gravity.CENTER);list.addView(none,new LinearLayout.LayoutParams(-1,dp(62)));contentH=dp(70);
            }else{
                for(String[] r:rows){
                    final String nodeId=r[0],itemId=r[1],todoText=r[2];final boolean checked="1".equals(r[3]);
                    LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setPadding(dp(5),dp(2),dp(3),dp(2));
                    GradientDrawable rg=bg(checked?0xFFF0F3F6:0xFFF8FAFD,dp(12));rg.setStroke(Math.max(1,dp(1)),checked?0x223F607F:0x2D4D8DFF);row.setBackground(rg);
                    LinearLayout textWrap=new LinearLayout(this);textWrap.setOrientation(LinearLayout.VERTICAL);textWrap.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);textWrap.setGravity(Gravity.CENTER_VERTICAL);
                    CheckBox cb=new CheckBox(this);cb.setText(todoText);cb.setChecked(checked);cb.setTextSize(13);cb.setTextColor(checked?0xFF8792A4:0xFF17345D);cb.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);cb.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);try{cb.setButtonTintList(ColorStateList.valueOf(0xFF347FC5));}catch(Exception ignored){}if(checked)cb.setPaintFlags(cb.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);textWrap.addView(cb,new LinearLayout.LayoutParams(-1,dp(team[0]?34:44)));
                    if(team[0]){TextView who=tv(treeNodeVal(nodeId,"name","فرد"),10,0xFF7890A8);who.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);who.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);who.setPadding(dp(10),0,dp(10),0);textWrap.addView(who,new LinearLayout.LayoutParams(-1,dp(18)));}
                    row.addView(textWrap,new LinearLayout.LayoutParams(0,-1,1f));
                    TextView edit=tv("✎",15,0xFF2A72B8);edit.setGravity(Gravity.CENTER);TreeIconView del=treeIcon(2);row.addView(edit,new LinearLayout.LayoutParams(dp(34),dp(42)));row.addView(del,new LinearLayout.LayoutParams(dp(36),dp(36)));
                    cb.setOnCheckedChangeListener((b,on)->{setTreeTodoChecked(nodeId,itemId,on);b.post(render[0]);});
                    edit.setOnClickListener(v->{playUiClick();showPastelInputDialog("ویرایش کار",todoText,render[0],value->renameTreeTodoItem(nodeId,itemId,value));});
                    del.setOnClickListener(v->{playSfx(sfxFailId,.55f);deleteTreeTodoItem(nodeId,itemId);render[0].run();});
                    LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(team[0]?58:52));rp.bottomMargin=dp(5);list.addView(row,rp);
                }
                contentH=Math.min(dp(286),dp(6)+rows.size()*dp(team[0]?63:57));
            }
            scrollLp.height=Math.max(dp(70),contentH);scroll.setLayoutParams(scrollLp);
        };
        selfTab.setOnClickListener(v->{playUiClick();team[0]=false;updateTabs[0].run();render[0].run();});
        teamTabView.setOnClickListener(v->{playUiClick();team[0]=true;if(teamTarget[0]==null)teamTarget[0]=firstTeamTodoTarget(ownerId);updateTabs[0].run();render[0].run();});
        target.setOnClickListener(v->{playUiClick();showTeamTodoTargetPicker(ownerId,teamTarget[0],picked->{teamTarget[0]=picked;updateTabs[0].run();});});
        Runnable addItem=()->{String n=input.getText().toString().trim();if(n.length()==0)return;String node=team[0]?teamTarget[0]:ownerId;if(node==null){Toast.makeText(this,"ابتدا یک نفر از تیم انتخاب کنید",Toast.LENGTH_SHORT).show();return;}addTreeTodoItem(node,n);input.setText("");render[0].run();};
        add.setOnClickListener(v->{playSfx(sfxStartId,.6f);addItem.run();});
        input.setOnEditorActionListener((v,action,event)->{boolean enter=event!=null&&event.getKeyCode()==android.view.KeyEvent.KEYCODE_ENTER&&event.getAction()==android.view.KeyEvent.ACTION_DOWN;if(action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE||enter){addItem.run();return true;}return false;});
        updateTabs[0].run();render[0].run();
        ref[0]=buildPastelDialog("☑","To Do",ownerName,0xFF3D7EBE,outer,null,0,null,null,null);ref[0].show();
        ref[0].setOnDismissListener(x->{saveTreeSnapshotToday();if(fromHome){if(isHome)addHomeTodoShortcut();}else if(isTreeScreen)showTreePage();});
    }

    private GradientDrawable homeTodoTabBg(boolean active){GradientDrawable g=bg(active?0xFF3D78B5:0xFFF2F6FD,dp(12));g.setStroke(Math.max(1,dp(1)),active?0xFF76B8E9:0x334D8DFF);return g;}
    private java.util.ArrayList<String[]> selfTodos(String ownerId){java.util.ArrayList<String[]> out=new java.util.ArrayList<>();for(String[] t:treeTodoItems(ownerId))out.add(new String[]{ownerId,t[0],t[1],t[2]});sortHomeTodoRows(out);return out;}
    private java.util.ArrayList<String> treeDescendants(String ownerId){java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();collectTreeSubtree(ownerId,set);set.remove(ownerId);java.util.ArrayList<String> out=new java.util.ArrayList<>();for(String id:treeNodeIds())if(set.contains(id))out.add(id);return out;}
    private java.util.ArrayList<String[]> aggregatedTeamTodos(String ownerId){java.util.ArrayList<String[]> out=new java.util.ArrayList<>();for(String id:treeDescendants(ownerId))for(String[] t:treeTodoItems(id))out.add(new String[]{id,t[0],t[1],t[2]});sortHomeTodoRows(out);return out;}
    private void sortHomeTodoRows(java.util.ArrayList<String[]> rows){java.util.Collections.sort(rows,(a,b)->{boolean ad="1".equals(a[3]),bd="1".equals(b[3]);if(ad!=bd)return ad?1:-1;return Long.compare(treeTimestamp(b[1]),treeTimestamp(a[1]));});}
    private String firstTeamTodoTarget(String ownerId){java.util.ArrayList<String> ids=treeDescendants(ownerId);return ids.isEmpty()?null:ids.get(0);}
    private void showTeamTodoTargetPicker(String ownerId,String current,java.util.function.Consumer<String> choose){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);final Dialog[] ref={null};
        for(String id:treeDescendants(ownerId)){TextView row=settingsRow(treeNodeVal(id,"name","بدون نام"),id.equals(current)?"✓":"");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(42));lp.bottomMargin=dp(4);body.addView(row,lp);final String pick=id;row.setOnClickListener(v->{playUiClick();if(ref[0]!=null)ref[0].dismiss();choose.accept(pick);});}
        if(body.getChildCount()==0){TextView none=tv("هنوز عضوی در تیم نیست",12,0xFF8794A7);none.setGravity(Gravity.CENTER);body.addView(none,new LinearLayout.LayoutParams(-1,dp(48)));}
        ref[0]=buildPastelDialog("◎","انتخاب فرد","کار جدید برای چه کسی است؟",0xFF3D7EBE,body,null,0,null,null,null);ref[0].show();
    }

    private LinearLayout glassCapsule(){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0xCFF7FBFF,dp(13)); g.setStroke(Math.max(1,Math.round(dp(.9f))),0x6654A9FF); box.setBackground(g);
        return box;
    }

    private class XpBarView extends View {
        private final Paint p=new Paint(1); private int value=0,max=100;
        XpBarView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void setProgress(int v,int m){ value=Math.max(0,v); max=Math.max(1,m); invalidate(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float h=getHeight(), r=h/2f; RectF track=new RectF(dp(1),dp(1),getWidth()-dp(1),h-dp(1));
            p.setStyle(Paint.Style.FILL); p.setColor(0xCFE4EFFA); c.drawRoundRect(track,r,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xAA6BB9ED); c.drawRoundRect(track,r,r,p);
            float frac=Math.min(1f,value/(float)max);
            if(frac>0f){ RectF fill=new RectF(track.left,track.top,track.left+track.width()*frac,track.bottom);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF25E6FF); p.setShadowLayer(dp(4),0,0,0xCC19D9FF); c.drawRoundRect(fill,r,r,p); p.clearShadowLayer(); }
            else { p.setStyle(Paint.Style.FILL); p.setColor(0xFF36E8FF); p.setShadowLayer(dp(3),0,0,0xAA28DFFF); c.drawCircle(track.left+dp(2),h/2f,dp(1.3f),p); p.clearShadowLayer(); }
        }
    }

    private class HudBackground extends android.graphics.drawable.Drawable {
        private final Paint fill=new Paint(1), stroke=new Paint(1), bottomGlow=new Paint(1), topAccent=new Paint(1);
        HudBackground(){
            fill.setColor(0xEAF8FBFF); fill.setStyle(Paint.Style.FILL);
            stroke.setColor(0x7754A9FF); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            bottomGlow.setColor(0xAA42B9FF); bottomGlow.setStyle(Paint.Style.STROKE); bottomGlow.setStrokeWidth(dp(1));
            topAccent.setColor(0xCCFFFFFF); topAccent.setStyle(Paint.Style.STROKE); topAccent.setStrokeWidth(dp(1));
        }
        private Path shape(){
            RectF b=new RectF(getBounds()); float c=dp(7); Path p=new Path();
            p.moveTo(b.left+c,b.top); p.lineTo(b.right-c,b.top); p.lineTo(b.right,b.top+c);
            p.lineTo(b.right,b.bottom-c); p.lineTo(b.right-c,b.bottom); p.lineTo(b.left+c,b.bottom);
            p.lineTo(b.left,b.bottom-c); p.lineTo(b.left,b.top+c); p.close(); return p;
        }
        @Override public void draw(Canvas c){
            RectF b=new RectF(getBounds()); Path p=shape(); c.drawPath(p,fill); c.drawPath(p,stroke);
            c.drawLine(b.left+dp(11),b.bottom-dp(1),b.right-dp(11),b.bottom-dp(1),bottomGlow);
            c.drawLine(b.left+dp(12),b.top+dp(1),b.right-dp(12),b.top+dp(1),topAccent);
        }
        @Override public void setAlpha(int a){} @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){ return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private class CoinView extends View {
        Paint p=new Paint(1); CoinView(android.content.Context c){super(c);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float r=Math.min(getWidth(),getHeight())*.43f, x=getWidth()/2f,y=getHeight()/2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF72C9FF); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xFFF1FAFF); c.drawCircle(x,y,r-dp(1),p);
            p.setColor(0xFF2F8DFF); c.drawCircle(x,y,r-dp(3),p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFFFFF); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(10));
            c.drawText("L",x,y-(p.ascent()+p.descent())/2,p);
        }
    }

    private int gameLevel=1, gameXp=0, gameCoins=0, gameCombo=0, comboWindowMinutes=30; private long lastSuccessAt=0;
    private SharedPreferences gamePrefs;
    private static final int PRESENCE_REWARD_COINS=5;
    private static final long PRESENCE_REWARD_COOLDOWN_MS=3L*60L*60L*1000L;
    private static final long PRESENCE_REWARD_CENT_STEP_MS=240L;
    private int presenceRewardFractionCents=0;
    private boolean presenceRewardForeground=false;
    private Runnable presenceRewardTick=null;
    private int xpNeeded(int level){ return 100+Math.max(0,level-1)*50; }
    private void loadGameState(){ gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gameLevel=gamePrefs.getInt("level",1);gameXp=gamePrefs.getInt("xp",0);gameCoins=gamePrefs.getInt("coins",0);gameCombo=gamePrefs.getInt("combo",0);lastSuccessAt=gamePrefs.getLong("lastSuccessAt",0);comboWindowMinutes=gamePrefs.getInt("comboWindowMinutes",30);expireComboIfNeeded(); }
    private void saveGameState(){ if(gamePrefs==null)gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gamePrefs.edit().putInt("level",gameLevel).putInt("xp",gameXp).putInt("coins",gameCoins).putInt("combo",gameCombo).putLong("lastSuccessAt",lastSuccessAt).putInt("comboWindowMinutes",comboWindowMinutes).apply();updateHud(); }
    private String presenceCoinTextFor(int whole){return presenceRewardFractionCents>0?String.format(java.util.Locale.US,"%d.%02d",whole,presenceRewardFractionCents):String.valueOf(whole);}
    private String presenceCoinText(){return presenceCoinTextFor(gameCoins);}
    private void updateHud(){ if(hudLevel!=null)hudLevel.setText("LV "+gameLevel);if(hudXpBar!=null)hudXpBar.setProgress(gameXp,xpNeeded(gameLevel));if(hudXpText!=null)hudXpText.setText(gameXp+" / "+xpNeeded(gameLevel)+" XP");if(hudCoinText!=null)hudCoinText.setText(presenceCoinText());if(shopCoinChip!=null&&shopCoinChip.getParent()!=null)shopCoinChip.setText("●  "+presenceCoinText());if(hudComboText!=null)hudComboText.setText(String.valueOf(gameCombo)); }
    private void showHudState(int level,int xp,int coins,int combo){if(hudLevel!=null)hudLevel.setText("LV "+level);if(hudXpBar!=null)hudXpBar.setProgress(xp,xpNeeded(level));if(hudXpText!=null)hudXpText.setText(xp+" / "+xpNeeded(level)+" XP");if(hudCoinText!=null)hudCoinText.setText(presenceCoinTextFor(coins));if(hudComboText!=null)hudComboText.setText(String.valueOf(combo));}
    private void startPresenceRewardLoop(){
        if(gamePrefs==null)gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);
        if(presenceRewardTick!=null)missionHandler.removeCallbacks(presenceRewardTick);
        presenceRewardForeground=true;presenceRewardFractionCents=0;updateHud();
        presenceRewardTick=new Runnable(){public void run(){
            if(!presenceRewardForeground)return;
            if(gamePrefs==null)gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);
            long now=System.currentTimeMillis(),nextAt=gamePrefs.getLong("presence_reward_next_at",0L);
            int earned=Math.max(0,Math.min(PRESENCE_REWARD_COINS-1,gamePrefs.getInt("presence_reward_earned",0)));
            if(nextAt>0L){
                if(now<nextAt){missionHandler.postDelayed(this,Math.max(250L,nextAt-now));return;}
                gamePrefs.edit().putLong("presence_reward_next_at",0L).putInt("presence_reward_earned",0).apply();earned=0;
            }
            presenceRewardFractionCents++;
            if(presenceRewardFractionCents>=100){
                presenceRewardFractionCents=0;gameCoins++;earned++;
                SharedPreferences.Editor ed=gamePrefs.edit().putInt("coins",gameCoins);
                if(earned>=PRESENCE_REWARD_COINS){
                    long readyAt=System.currentTimeMillis()+PRESENCE_REWARD_COOLDOWN_MS;
                    ed.putInt("presence_reward_earned",0).putLong("presence_reward_next_at",readyAt).commit();
                    updateHud();if(hudCoinText!=null){hudCoinText.animate().cancel();hudCoinText.setScaleX(1f);hudCoinText.setScaleY(1f);hudCoinText.animate().scaleX(1.12f).scaleY(1.12f).setDuration(150).withEndAction(()->hudCoinText.animate().scaleX(1f).scaleY(1f).setDuration(220).start()).start();}
                    missionHandler.postDelayed(this,PRESENCE_REWARD_COOLDOWN_MS);return;
                }else ed.putInt("presence_reward_earned",earned).putLong("presence_reward_next_at",0L).commit();
            }
            updateHud();missionHandler.postDelayed(this,PRESENCE_REWARD_CENT_STEP_MS);
        }};
        missionHandler.postDelayed(presenceRewardTick,PRESENCE_REWARD_CENT_STEP_MS);
    }
    private void stopPresenceRewardLoop(boolean discardFraction){
        presenceRewardForeground=false;if(presenceRewardTick!=null)missionHandler.removeCallbacks(presenceRewardTick);presenceRewardTick=null;
        if(discardFraction&&presenceRewardFractionCents!=0){presenceRewardFractionCents=0;updateHud();}
    }
    private void pulseHudRewards(){View[] vs={hudXpText,hudCoinText,hudComboText,hudLevel};for(View v:vs)if(v!=null){v.setScaleX(1f);v.setScaleY(1f);v.animate().scaleX(1.18f).scaleY(1.18f).setDuration(260).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(360).start()).start();}if(hudXpBar!=null){hudXpBar.setScaleY(1f);hudXpBar.animate().scaleY(1.5f).setDuration(260).withEndAction(()->hudXpBar.animate().scaleY(1f).setDuration(360).start()).start();}}
    private float comboMultiplier(){return gameCombo>=10?3f:gameCombo>=7?2f:gameCombo>=3?1.5f:1f;}
    private int missionImportance(int section,int slot){
        try{return Math.max(0,Math.min(2,Integer.parseInt(mv(section,slot,"importance","0"))));}catch(Exception ignored){return 0;}
    }
    private int baseXpForImportance(int section,int slot){
        int importance=missionImportance(section,slot);
        return importance==2?35:importance==1?20:10;
    }
    private int baseCoinsForImportance(int section,int slot){
        int importance=missionImportance(section,slot);
        return importance==2?7:importance==1?4:2;
    }
    private void expireComboIfNeeded(){if(gameCombo>0&&lastSuccessAt>0&&System.currentTimeMillis()-lastSuccessAt>comboWindowMinutes*60000L){gameCombo=0;lastSuccessAt=0;if(gamePrefs!=null)gamePrefs.edit().putInt("combo",0).putLong("lastSuccessAt",0).apply();}}

    private int[] missionTimes={5,10,20,30,45};
    private String mf(int s,int k,String f){return "m_"+s+"_"+k+"_"+f;}
    private String mv(int s,int k,String f,String d){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);return progressPrefs.getString(mf(s,k,f),d);}
    private void ms(int s,int k,String f,String v){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);progressPrefs.edit().putString(mf(s,k,f),v).apply();}
    private GradientDrawable sel(boolean on){GradientDrawable g=bg(on?0x183B82F6:Color.TRANSPARENT,dp(999));if(on)g.setStroke(Math.max(2,Math.round(dp(1.8f))),0xFF2477E8);return g;}
    private TextView eh(String t,int z){TextView v=tv(t,z,0xFF17345D);v.setGravity(Gravity.CENTER);return v;}

    private int dayStartMinutes(){return appSettingsPrefs().getInt("day_start_minutes",6*60);}
    private long logicalNowMillis(){return System.currentTimeMillis()-dayStartMinutes()*60L*1000L;}
    private String logicalDayKey(String pattern){
        java.text.SimpleDateFormat f=new java.text.SimpleDateFormat(pattern,java.util.Locale.US);
        return f.format(new java.util.Date(logicalNowMillis()));
    }
    private int[] gregorianToJalali(int gy,int gm,int gd){
        int[] gdm={0,31,59,90,120,151,181,212,243,273,304,334};int jy;
        if(gy>1600){jy=979;gy-=1600;}else{jy=0;gy-=621;}
        int gy2=gm>2?gy+1:gy;int days=365*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400-80+gd+gdm[Math.max(0,Math.min(11,gm-1))];
        jy+=33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365;}
        int jm,jd;if(days<186){jm=1+days/31;jd=1+days%31;}else{jm=7+(days-186)/30;jd=1+(days-186)%30;}return new int[]{jy,jm,jd};
    }
    private int[] jalaliForMillis(long millis){java.util.Calendar c=java.util.Calendar.getInstance();c.setTimeInMillis(millis);return gregorianToJalali(c.get(java.util.Calendar.YEAR),c.get(java.util.Calendar.MONTH)+1,c.get(java.util.Calendar.DAY_OF_MONTH));}
    private String logicalJalaliDateKey(){int[] j=jalaliForMillis(logicalNowMillis());return String.format(java.util.Locale.US,"%04d-%02d-%02d",j[0],j[1],j[2]);}
    private String logicalJalaliCompactKey(){int[] j=jalaliForMillis(logicalNowMillis());return String.format(java.util.Locale.US,"%04d%02d%02d",j[0],j[1],j[2]);}
    private String normalizeDateStorageKey(String raw){
        if(raw==null||raw.trim().length()==0)return "";String x=raw.trim();try{String[] a=x.split("-");if(a.length==3){int y=Integer.parseInt(a[0]),m=Integer.parseInt(a[1]),d=Integer.parseInt(a[2]);if(y>1700){int[] j=gregorianToJalali(y,m,d);return String.format(java.util.Locale.US,"%04d-%02d-%02d",j[0],j[1],j[2]);}return String.format(java.util.Locale.US,"%04d-%02d-%02d",y,m,d);}}catch(Exception ignored){}return x;
    }
    private String formatPersianDateKey(String raw){return normalizeDateStorageKey(raw).replace('-', '/');}
    private String formatDayStart(){int m=dayStartMinutes();return String.format(java.util.Locale.US,"%02d:%02d",m/60,m%60);}
    private String missionDay(){return logicalJalaliCompactKey();}
    private String legacyMissionDay(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US);return f.format(new java.util.Date(logicalNowMillis()));}
    private boolean isCurrentMissionDayKey(String day){return missionDay().equals(day)||legacyMissionDay().equals(day);}
    private void startDailyResetTicker(){
        if(dailyResetTick!=null)missionHandler.removeCallbacks(dailyResetTick);
        lastObservedMissionDay=missionDay();
        dailyResetTick=new Runnable(){public void run(){
            String nowDay=missionDay();
            if(!nowDay.equals(lastObservedMissionDay)){lastObservedMissionDay=nowDay;applyDailyMissionResets();refreshProgressMissionVisuals();if(isTreeScreen)showTreePage();}
            missionHandler.postDelayed(this,60000L);
        }};
        missionHandler.postDelayed(dailyResetTick,60000L);
    }
    private String missionState(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressTitle(section,slot).trim().length()==0)return "empty";
        if(progressPrefs.getBoolean("active",false)&&progressPrefs.getInt("active_s",-1)==section&&progressPrefs.getInt("active_k",-1)==slot)return "active";
        String state=mv(section,slot,"state","ready");
        if("active".equals(state))state="ready";
        return state;
    }
    private void setMissionState(int section,int slot,String state){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        SharedPreferences.Editor ed=progressPrefs.edit().putString(mf(section,slot,"state"),state);
        if("done".equals(state)||"fail".equals(state)){ed.putString(mf(section,slot,"state_day"),missionDay());progressResultAnimSection=section;progressResultAnimSlot=slot;}
        else ed.remove(mf(section,slot,"state_day"));
        ed.apply();
    }

    private void saveMissionRewardSnapshot(int section,int slot){
        if(section<1||slot<0)return;if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit()
            .putBoolean(mf(section,slot,"reward_snapshot"),true)
            .putInt(mf(section,slot,"prev_level"),gameLevel)
            .putInt(mf(section,slot,"prev_xp"),gameXp)
            .putInt(mf(section,slot,"prev_coins"),gameCoins)
            .putInt(mf(section,slot,"prev_combo"),gameCombo)
            .putLong(mf(section,slot,"prev_last_success"),lastSuccessAt)
            .putInt(mf(section,slot,"reward_xp"),0)
            .putInt(mf(section,slot,"reward_coins"),0)
            .remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at"))
            .apply();
    }
    private void recordMissionReward(int section,int slot,int xp,int coins){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putInt(mf(section,slot,"reward_xp"),xp).putInt(mf(section,slot,"reward_coins"),coins)
            .putString(mf(section,slot,"reward_outcome"),xp>0?"done":"fail").putLong(mf(section,slot,"reward_at"),System.currentTimeMillis()).apply();
    }
    private long lifetimeXp(){long total=gameXp;for(int l=1;l<gameLevel;l++)total+=xpNeeded(l);return total;}
    private void setLifetimeXp(long total){total=Math.max(0,total);int level=1;while(total>=xpNeeded(level)){total-=xpNeeded(level);level++;if(level>10000)break;}gameLevel=level;gameXp=(int)Math.max(0,total);}
    private void clearMissionRewardSnapshot(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit()
            .remove(mf(section,slot,"reward_snapshot")).remove(mf(section,slot,"prev_level")).remove(mf(section,slot,"prev_xp"))
            .remove(mf(section,slot,"prev_coins")).remove(mf(section,slot,"prev_combo")).remove(mf(section,slot,"prev_last_success"))
            .remove(mf(section,slot,"reward_xp")).remove(mf(section,slot,"reward_coins")).remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at")).apply();
    }
    private void restoreMissionAndRewards(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressPrefs.getBoolean(mf(section,slot,"reward_snapshot"),false)){
            int earnedXp=progressPrefs.getInt(mf(section,slot,"reward_xp"),0),earnedCoins=progressPrefs.getInt(mf(section,slot,"reward_coins"),0),prevCombo=progressPrefs.getInt(mf(section,slot,"prev_combo"),gameCombo);long prevLast=progressPrefs.getLong(mf(section,slot,"prev_last_success"),lastSuccessAt),rewardAt=progressPrefs.getLong(mf(section,slot,"reward_at"),0);String outcome=progressPrefs.getString(mf(section,slot,"reward_outcome"),earnedXp>0?"done":"fail");
            if(earnedXp>0)setLifetimeXp(lifetimeXp()-earnedXp);if(earnedCoins>0)gameCoins=Math.max(0,gameCoins-earnedCoins);
            if("done".equals(outcome)){
                if(rewardAt>0&&Math.abs(lastSuccessAt-rewardAt)<2500){gameCombo=prevCombo;lastSuccessAt=prevLast;}else if(gameCombo>0)gameCombo=Math.max(0,gameCombo-1);
            }else if("fail".equals(outcome)){
                if(lastSuccessAt==0||lastSuccessAt<=rewardAt){gameCombo=prevCombo;lastSuccessAt=prevLast;}
            }
            saveGameState();
        }
        clearMissionRewardSnapshot(section,slot);setMissionState(section,slot,"ready");refreshProgressMissionVisuals();showProgressPath();animateRestoreFeedback();
    }
    private LinearLayout restoreRewardBody(int section,int slot){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);
        TextView note=tv("همه اثرهای این نتیجه به حالت قبل برمی‌گردد.",13,0xFF60708B);note.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(note,new LinearLayout.LayoutParams(-1,dp(36)));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);body.addView(row,new LinearLayout.LayoutParams(-1,dp(46)));
        int xp=progressPrefs.getInt(mf(section,slot,"reward_xp"),0),coins=progressPrefs.getInt(mf(section,slot,"reward_coins"),0),prevCombo=progressPrefs.getInt(mf(section,slot,"prev_combo"),gameCombo);
        TextView a=rewardChip((xp>0?"−":"")+xp+" XP",0xFF0878D8,0xFFEAF7FF,0x553C9DFF);TextView b=rewardChip((coins>0?"−":"")+coins+" Coin",0xFF2F78B8,0xFFEAF6FF,0x5554A9FF);TextView c=rewardChip("Combo → "+prevCombo,0xFF9A4C17,0xFFFFF0E6,0x55FF9A53);
        row.addView(a,new LinearLayout.LayoutParams(0,dp(38),1f));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(0,dp(38),1f);blp.setMargins(dp(6),0,dp(6),0);row.addView(b,blp);row.addView(c,new LinearLayout.LayoutParams(0,dp(38),1f));return body;
    }
    private void showRestoreMissionDialog(int section,int slot){
        Dialog d=buildPastelDialog("↻","Restore Mission?",progressTitle(section,slot),0xFF26A8F2,restoreRewardBody(section,slot),"Restore",0xFF2D9DFF,()->restoreMissionAndRewards(section,slot),"Cancel",null);d.show();
    }
    private void showDeleteMissionDialog(int section,int slot){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView m=tv("این مأموریت و ساب‌تسک‌هایش از مسیر حذف می‌شود.",13,0xFF68758D);m.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(m,new LinearLayout.LayoutParams(-1,dp(42)));
        Dialog d=buildPastelDialog("⌫","Delete Mission?",progressTitle(section,slot),0xFFFF6078,body,"Delete",0xFFFF5268,()->{clearMissionSlot(section,slot);showProgressPath();},"Cancel",null);d.show();
    }
    private void showActiveMissionWarning(){
        Dialog d=buildPastelDialog("!","یک مأموریت در حال اجراست","",0xFFFF6B82,null,"ادامه مأموریت",0xFF4E8CFF,()->resumeActiveMission(),"بستن",null);d.show();
    }
    private void showCompletedMissionLockedDialog(String title){
        LinearLayout body=null;
        Dialog d=buildPastelDialog("✓","ماموریت قبلاً ثبت نتیجه شده",title,0xFF6B8FFF,body,"باشه",0xFF4E8CFF,null,null,null);d.show();
    }
    private void applyDailyMissionResets(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        String today=missionDay();
        int count=Math.max(1,progressPrefs.getInt("progress_section_count",1));
        for(int s=1;s<=count;s++)for(int k=0;k<3;k++){
            if(progressTitle(s,k).trim().length()==0)continue;
            if(!"1".equals(mv(s,k,"repeat","1")))continue;
            String state=missionState(s,k);
            if(!("done".equals(state)||"fail".equals(state)))continue;
            String day=mv(s,k,"state_day","");
            if(!isCurrentMissionDayKey(day)){
                setMissionState(s,k,"ready");
                clearMissionRewardSnapshot(s,k);
                SharedPreferences sub=getSharedPreferences("legacy_subtasks_"+s+"_"+k,MODE_PRIVATE);
                sub.edit().putString("day",today).putString("done_ids","").apply();
            }
        }
    }
    private String missionViewKey(int section,int slot){return section+":"+slot;}
    private class MissionSlotView extends TextView{
        private String visualState="";
        private float stateReveal=1f;
        private final Paint stateFill=new Paint(Paint.ANTI_ALIAS_FLAG);
        private android.animation.ValueAnimator stateAnimator=null;
        MissionSlotView(android.content.Context c){super(c);setWillNotDraw(false);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setVisualState(String s){
            String next=s==null?"":s;boolean first=visualState.length()==0;boolean changed=!next.equals(visualState);visualState=next;
            if(stateAnimator!=null){stateAnimator.cancel();stateAnimator=null;}
            if(!first&&changed&&("done".equals(next)||"fail".equals(next))){stateReveal=0f;stateAnimator=android.animation.ValueAnimator.ofFloat(0f,1f);stateAnimator.setDuration(240);stateAnimator.setInterpolator(new android.view.animation.DecelerateInterpolator());stateAnimator.addUpdateListener(a->{stateReveal=(Float)a.getAnimatedValue();invalidate();});stateAnimator.start();}
            else{stateReveal=1f;invalidate();}
        }
        void animateResultReveal(){if(stateAnimator!=null)stateAnimator.cancel();stateReveal=0f;setScaleX(.96f);setScaleY(.96f);stateAnimator=android.animation.ValueAnimator.ofFloat(0f,1f);stateAnimator.setDuration(240);stateAnimator.setInterpolator(new android.view.animation.DecelerateInterpolator());stateAnimator.addUpdateListener(a->{stateReveal=(Float)a.getAnimatedValue();float q=.96f+.04f*stateReveal;setScaleX(q);setScaleY(q);invalidate();});stateAnimator.addListener(new android.animation.AnimatorListenerAdapter(){@Override public void onAnimationEnd(android.animation.Animator a){setScaleX(1f);setScaleY(1f);}});stateAnimator.start();}
        @Override protected void onDraw(Canvas c){
            int fillColor=Color.TRANSPARENT;
            if("done".equals(visualState))fillColor=0xFF0B8F4D;else if("fail".equals(visualState))fillColor=0xFF8B1E32;
            float r=Math.max(0f,Math.min(getWidth(),getHeight())*.5f-dp(4));
            if(fillColor!=Color.TRANSPARENT){stateFill.setStyle(Paint.Style.FILL);stateFill.setColor(withAlpha(fillColor,Math.round(255*stateReveal)));stateFill.clearShadowLayer();c.drawCircle(getWidth()/2f,getHeight()/2f,r,stateFill);}
            if("active".equals(visualState)){stateFill.setStyle(Paint.Style.STROKE);stateFill.setStrokeWidth(dp(2.2f));stateFill.setColor(0xD955C8FF);stateFill.setShadowLayer(dp(5),0,0,0x8855C8FF);c.drawCircle(getWidth()/2f,getHeight()/2f,Math.max(0,r-dp(1)),stateFill);stateFill.clearShadowLayer();}
            super.onDraw(c);
        }
    }
    private void styleMissionSlot(TextView mission,String state){
        if(mission instanceof MissionSlotView)((MissionSlotView)mission).setVisualState(state);
        mission.setAlpha(1f);mission.setBackgroundColor(Color.TRANSPARENT);mission.setShadowLayer(0,0,0,Color.TRANSPARENT);mission.setPaintFlags(mission.getPaintFlags()&~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);mission.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        float targetScale="active".equals(state)?1.055f:1f;mission.setScaleX(targetScale);mission.setScaleY(targetScale);mission.setElevation("active".equals(state)?dp(4):0f);
        if("done".equals(state)||"fail".equals(state)){mission.setTextColor(0xFFFFFFFF);mission.setShadowLayer(dp(1.2f),0,dp(.6f),0x55000000);}
        else if("active".equals(state)){mission.setTextColor(0xFF102D58);mission.setShadowLayer(dp(1.1f),0,0,0x66FFFFFF);}
        else mission.setTextColor(0xFF162D54);
    }
    private String missionVisualState(int section,int slot){
        return missionState(section,slot);
    }
    private void refreshProgressMissionVisuals(){
        if(progressMissionViews.isEmpty())return;
        for(java.util.Map.Entry<String,TextView> entry:progressMissionViews.entrySet()){
            try{
                String[] p=entry.getKey().split(":");
                int s=Integer.parseInt(p[0]),k=Integer.parseInt(p[1]);
                TextView v=entry.getValue();
                v.setText(progressTitle(s,k));
                styleMissionSlot(v,missionVisualState(s,k));
            }catch(Exception ignored){}
        }
    }
    private void showMissionSlotMenu(final int section,final int slot){
        String title=progressTitle(section,slot);if(title.trim().length()==0){showMissionEditor(section,slot);return;}
        String state=missionState(section,slot);
        if("active".equals(state)){resumeActiveMission();return;}
        java.util.ArrayList<String> items=new java.util.ArrayList<>();
        if("done".equals(state)||"fail".equals(state))items.add("Restore");
        items.add("ویرایش مأموریت");items.add("حذف مأموریت");
        final String[] arr=items.toArray(new String[0]);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(0,dp(2),0,0);
        final Dialog[] menu={null};
        for(String item:arr){
            boolean danger="حذف مأموریت".equals(item);
            TextView choice=tv(item,14,danger?0xFFD9435B:0xFF17345D);choice.setGravity(Gravity.CENTER);
            GradientDrawable cg=bg(danger?0xFFFFF3F5:0xFFF5F8FF,dp(14));cg.setStroke(Math.max(1,Math.round(dp(.7f))),danger?0x44FF6078:0x334E8CFF);choice.setBackground(cg);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.setMargins(0,dp(4),0,dp(4));body.addView(choice,cp);
            choice.setOnClickListener(v->{playViewSound(v);menu[0].dismiss();String chosen=((TextView)v).getText().toString();if("Restore".equals(chosen))showRestoreMissionDialog(section,slot);else if("ویرایش مأموریت".equals(chosen))showMissionEditor(section,slot);else if("حذف مأموریت".equals(chosen))showDeleteMissionDialog(section,slot);});
        }
        menu[0]=buildPastelDialog("✦",title,"مدیریت مأموریت",0xFF4E8CFF,body,null,0,null,"بستن",null);menu[0].show();
    }
    private void confirmDeleteMission(final int section,final int slot){showDeleteMissionDialog(section,slot);}

    private float[] missionEditorRect(float[] q,boolean startButton){
        int h=activeHero();
        if(h==1)return q;
        if(startButton){
            if(h==2)return new float[]{.117188f,.826823f,.753906f,.097005f};
            return new float[]{.123698f,.820964f,.751302f,.083984f};
        }
        // The three supplied editor artworks intentionally place the glass form at
        // slightly different heights.  Transform the hero-1 calibrated hit/label
        // rectangles into the matching panel coordinate system for each artwork.
        float hx=h==2?300f:302f, hy=h==2?659f:715f;
        float sx=h==2?.970f:.967f, sy=h==2?.976f:.952f;
        float x=(hx+(q[0]*768f-285f)*sx)/768f;
        float y=(hy+(q[1]*1536f-617f)*sy)/1536f;
        return new float[]{x,y,q[2]*sx,q[3]*sy};
    }

    private void showMissionEditor(final int section,final int slot){
        stopHomeActiveTicker();removeHomeOnlyOverlays();
        isHome=false;isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=true;isPlaceholderScreen=false;currentMissionEditorSection=section;currentMissionEditorSlot=slot;++homeGeneration;getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);content.removeAllViews();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);applyDailyMissionResets();
        FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(heroMissionEditorBackground());art.setScaleType(ImageView.ScaleType.FIT_CENTER);
        e.addView(art,new FrameLayout.LayoutParams(-1,-1));

        final String old=progressTitle(section,slot);
        final String entryState=missionState(section,slot);
        final boolean resultLocked="done".equals(entryState)||"fail".equals(entryState);
        final EditText title=new EditText(this);title.setSingleLine(true);title.setText(old.length()==0?"عنوان":old);
        title.setTextSize(14);title.setTextColor(0xFF17345D);title.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        title.setPadding(dp(8),0,dp(8),0);title.setBackgroundColor(Color.TRANSPARENT);title.setLongClickable(false);title.setTextIsSelectable(false);enableAutoSize(title,10,14);title.setOnClickListener(v->playUiClick());
        if(android.os.Build.VERSION.SDK_INT>=29){
            try{
                title.setTextCursorDrawable(getDrawable(R.drawable.editor_cursor));
                title.setTextSelectHandle(getDrawable(R.drawable.editor_handle_invisible));
                title.setTextSelectHandleLeft(getDrawable(R.drawable.editor_handle_invisible));
                title.setTextSelectHandleRight(getDrawable(R.drawable.editor_handle_invisible));
            }catch(Exception ignored){}
        }
        FrameLayout.LayoutParams tl=new FrameLayout.LayoutParams(0,0);e.addView(title,tl);

        final TextView circleTitle=eh(old,15);circleTitle.setTextColor(0xFF17345D);circleTitle.setTranslationX(dp(2.5f));circleTitle.setTranslationY(-dp(1.5f));
        FrameLayout.LayoutParams cl=new FrameLayout.LayoutParams(0,0);e.addView(circleTitle,cl);

        // Every truly new/empty mission starts from the agreed defaults.
        if(old.trim().length()==0){
            progressPrefs.edit()
                .putString(mf(section,slot,"importance"),"0")
                .putString(mf(section,slot,"minutes"),"10")
                .putString(mf(section,slot,"repeat"),"1")
                .putString(mf(section,slot,"state"),"ready")
                .remove(mf(section,slot,"state_day"))
                .apply();
        }
        final int[] imp={Integer.parseInt(mv(section,slot,"importance","0"))};
        final TextView[] iv={eh("",1),eh("",1),eh("",1)};
        for(TextView v:iv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        int saved=Integer.parseInt(mv(section,slot,"minutes","10"));final int[] ti={1};
        for(int i=0;i<missionTimes.length;i++)if(missionTimes[i]==saved)ti[0]=i;
        final TextView minus=eh("",1),time=eh(missionTimes[ti[0]]+" دقیقه",14),plus=eh("",1);time.setTranslationY(0f);
        e.addView(minus,new FrameLayout.LayoutParams(0,0));e.addView(time,new FrameLayout.LayoutParams(0,0));e.addView(plus,new FrameLayout.LayoutParams(0,0));

        final int[] rp={Integer.parseInt(mv(section,slot,"repeat","1"))};
        final TextView[] rv={eh("",1),eh("",1)};
        for(TextView v:rv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        final TextView start=eh("Start Mission",1);start.setTextColor(Color.TRANSPARENT);start.setBackgroundColor(Color.TRANSPARENT);
        e.addView(start,new FrameLayout.LayoutParams(0,0));

        // Exact responsive hit areas from the approved 768x1536 artwork.
        e.addOnLayoutChangeListener((v,l,t,r,bt,ol,ot,or,ob)->{
            android.graphics.RectF canvas=fitCenterRect(e.getWidth(),e.getHeight(),768f,1536f);
            java.util.function.BiConsumer<View,float[]> place=(view,q)->{
                FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();
                float[] target=(q[2]<=0f||q[3]<=0f)?q:missionEditorRect(q,view==start);
                placeOnCanvas(p,canvas,target);view.setLayoutParams(p);
            };
            // Pixel-calibrated from the actual 768x1536 editor artwork.
            place.accept(title,new float[]{.403646f,.419922f,.419271f,.041667f});
            // No separate title circle exists in this artwork.
            place.accept(circleTitle,new float[]{0f,0f,0f,0f});
            place.accept(iv[0],new float[]{.402344f,.505859f,.162760f,.047526f});
            place.accept(iv[1],new float[]{.575521f,.503906f,.180990f,.055339f});
            place.accept(iv[2],new float[]{.769531f,.505208f,.169271f,.048828f});
            place.accept(minus,new float[]{.402344f,.598307f,.106771f,.049479f});
            place.accept(time,new float[]{.510417f,.598307f,.194010f,.049479f});
            place.accept(plus,new float[]{.705729f,.598307f,.104167f,.049479f});
            place.accept(rv[0],new float[]{.402344f,.684896f,.256510f,.052083f});
            place.accept(rv[1],new float[]{.675781f,.684896f,.260417f,.052083f});
            place.accept(start,new float[]{.132812f,.798828f,.735677f,.074219f});
        });

        // Defaults are visible immediately.
        for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));
        for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));
        time.setText(missionTimes[ti[0]]+" دقیقه");

        title.setOnFocusChangeListener((v,has)->{
            if(has&&"عنوان".contentEquals(title.getText()))title.setText("");
            if(!has){String x=title.getText().toString().trim();
                if(x.length()==0){
                    if(resultLocked){title.setText(old);circleTitle.setText(old);}
                    else{title.setText("عنوان");circleTitle.setText("");progressPrefs.edit().remove("title_"+section+"_"+slot).putString(mf(section,slot,"state"),"ready").remove(mf(section,slot,"state_day")).apply();}
                }else{progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();if(old.trim().length()==0){progressNewMissionSection=section;progressNewMissionSlot=slot;}if(!resultLocked&&"empty".equals(missionState(section,slot)))setMissionState(section,slot,"ready");circleTitle.setText(x);}
            }
        });
        title.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence x,int a,int b,int c){}
            public void onTextChanged(CharSequence x,int a,int b,int c){String q=x.toString().trim();circleTitle.setText("عنوان".equals(q)?"":q);}
            public void afterTextChanged(android.text.Editable x){}
        });
        for(int i=0;i<3;i++){final int q=i;iv[i].setClickable(true);iv[i].setOnClickListener(v->{playViewSound(v);imp[0]=q;ms(section,slot,"importance",""+q);for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));});}
        minus.setClickable(true);plus.setClickable(true);
        minus.setOnClickListener(v->{playViewSound(v);if(ti[0]>0)ti[0]--;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        plus.setOnClickListener(v->{playViewSound(v);if(ti[0]<missionTimes.length-1)ti[0]++;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        for(int i=0;i<2;i++){final int q=i;rv[i].setClickable(true);rv[i].setOnClickListener(v->{playViewSound(v);rp[0]=q;ms(section,slot,"repeat",""+q);for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));});}
        start.setClickable(true);start.setOnClickListener(v->{playViewSound(v);
            String x=title.getText().toString().trim();
            if(x.length()==0||"عنوان".equals(x)){Toast.makeText(this,"عنوان مأموریت را وارد کنید",Toast.LENGTH_SHORT).show();return;}
            progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();
            if(old.trim().length()==0){progressNewMissionSection=section;progressNewMissionSlot=slot;}
            if("empty".equals(missionState(section,slot)))setMissionState(section,slot,"ready");
            hideKeyboard(title);
            if(resultLocked){showCompletedMissionLockedDialog(x);return;}
            if(progressPrefs.getBoolean("active",false)){
                int as=progressPrefs.getInt("active_s",-1),ak=progressPrefs.getInt("active_k",-1);
                if(as==section&&ak==slot){resumeActiveMission();return;}
                showActiveMissionWarning();return;
            }
            clearMissionRewardSnapshot(section,slot);
            startRunningMission(section,slot,x,missionTimes[ti[0]]);
        });
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
    }

    private void hideKeyboard(View v){
        try{((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}
    }

    private android.os.Handler missionHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable missionTick;
    private android.media.MediaPlayer missionPlayer; private boolean missionMuted=false; private static final int REQ_MISSION_MUSIC=9042;

    private class MissionProgressView extends View {
        private final Paint p=new Paint(1); private float fraction=0f;
        MissionProgressView(android.content.Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setFraction(float f){fraction=Math.max(0f,Math.min(1f,f));invalidate();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float sw=dp(8.5f),pad=sw/2f+dp(1.2f);
            RectF r=new RectF(pad,pad,getWidth()-pad,getHeight()-pad);
            p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(sw);p.setColor(0xECF8FBFF);c.drawArc(r,-90,360,false,p);
            if(fraction>0f){p.setColor(0xFF2A8FFF);p.setShadowLayer(dp(2.8f),0,0,0x552A8FFF);c.drawArc(r,-90,360f*fraction,false,p);p.clearShadowLayer();}
        }
    }

    private void startRunningMission(final int section,final int slot,final String title,final int minutes){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressPrefs.getBoolean("active",false)){
            int as=progressPrefs.getInt("active_s",-1),ak=progressPrefs.getInt("active_k",-1);
            if(as==section&&ak==slot){resumeActiveMission();return;}
            showActiveMissionWarning();
            return;
        }
        setMissionState(section,slot,"ready");
        final long total=minutes*60000L;
        final long endAt=System.currentTimeMillis()+total;
        progressPrefs.edit()
            .putBoolean("active",true)
            .putInt("active_s",section)
            .putInt("active_k",slot)
            .putString("active_title",title)
            .putLong("active_end",endAt)
            .putLong("active_total",total)
            .putBoolean("active_alerted",false)
            .apply();
        ensureNotificationPermission();
        cancelMissionNotification();
        scheduleMissionAlarm(endAt);
        MissionNotification.showRunning(this);
        showRunningMissionScreen(section,slot,title,endAt,total);
    }

    private void resumeActiveMission(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(!progressPrefs.getBoolean("active",false)){Toast.makeText(this,"ماموریت فعالی وجود ندارد",Toast.LENGTH_SHORT).show();showProgressPath();return;}
        int section=progressPrefs.getInt("active_s",-1),slot=progressPrefs.getInt("active_k",-1);
        long endAt=progressPrefs.getLong("active_end",0),total=progressPrefs.getLong("active_total",0);
        String title=progressPrefs.getString("active_title","");
        if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        if(section<1||slot<0||endAt<=0||total<=0){clearActiveMissionState();Toast.makeText(this,"اطلاعات مأموریت فعال ناقص بود",Toast.LENGTH_SHORT).show();showProgressPath();return;}
        MissionNotification.showRunning(this);
        showRunningMissionScreen(section,slot,title,endAt,total);
    }

    private int[] subtaskStats(int section,int slot){
        SharedPreferences sp=getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE);
        int totalCount=0,doneCount=0;
        java.util.HashSet<String> doneIds=new java.util.HashSet<>();
        if(isCurrentMissionDayKey(sp.getString("day",""))){
            for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0)doneIds.add(x.trim());
        }
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);if(p.length<2)continue;
            totalCount++;if(doneIds.contains(p[0]))doneCount++;
        }
        return new int[]{doneCount,totalCount};
    }

    private void showRunningMissionScreen(final int section,final int slot,final String title,final long endAt,final long total){
        stopHomeActiveTicker();removeHomeOnlyOverlays();
        removeActiveMissionBar();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        isHome=false;isRunningMissionScreen=true;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;++homeGeneration;content.removeAllViews();
        final FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(heroMissionRunningBackground());art.setScaleType(ImageView.ScaleType.FIT_CENTER);e.addView(art,new FrameLayout.LayoutParams(-1,-1));
        final TextView missionTitle=eh(title,14);missionTitle.setTextColor(0xFF355883);missionTitle.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);missionTitle.setMaxLines(2);missionTitle.setLineSpacing(0,1.02f);missionTitle.setGravity(Gravity.CENTER);missionTitle.setIncludeFontPadding(false);enableAutoSize(missionTitle,8,14);e.addView(missionTitle,new FrameLayout.LayoutParams(0,0));
        final MissionProgressView ring=new MissionProgressView(this);e.addView(ring,new FrameLayout.LayoutParams(0,0));
        final TextView timer=eh("",38);timer.setTextColor(0xFF071A4A);timer.setTypeface(android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL));timer.setLetterSpacing(.045f);timer.setShadowLayer(dp(1.4f),0,dp(1),0x44FFFFFF);e.addView(timer,new FrameLayout.LayoutParams(0,0));
        float rewardMult=comboMultiplier();int previewXp=Math.max(1,Math.round(baseXpForImportance(section,slot)*rewardMult)),previewCoins=Math.max(1,Math.round(baseCoinsForImportance(section,slot)*rewardMult));
        final TextView rewardPreview=eh("★ +"+previewXp+" XP     ● +"+previewCoins+" Coin",12);rewardPreview.setTextColor(0xFF285A8F);rewardPreview.setTypeface(android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL));rewardPreview.setBackground(bg(0xA8F4F8FF,dp(999)));rewardPreview.setPadding(dp(10),0,dp(10),0);e.addView(rewardPreview,new FrameLayout.LayoutParams(0,0));
        final TextView subtaskBadge=eh("",10);subtaskBadge.setTextColor(Color.WHITE);subtaskBadge.setBackground(bg(0xE84267A6,dp(999)));subtaskBadge.setPadding(dp(5),0,dp(5),0);e.addView(subtaskBadge,new FrameLayout.LayoutParams(0,0));
        final View done=new View(this),fail=new View(this),music=new View(this),sound=new View(this),reset=new View(this),subtasks=new View(this);
        done.setContentDescription("Done");fail.setContentDescription("Fail");music.setContentDescription("Choose music");sound.setContentDescription("Mute music");reset.setContentDescription("Reset mission");subtasks.setContentDescription("Subtasks");
        done.setBackground(pressRipple(0x4400D878));fail.setBackground(pressRipple(0x44FF355C));music.setBackground(pressRipple(0x334D8EFF));sound.setBackground(pressRipple(0x334D8EFF));reset.setBackground(pressRipple(0x334D8EFF));subtasks.setBackground(pressRipple(0x334D8EFF));
        e.addView(done,new FrameLayout.LayoutParams(0,0));e.addView(fail,new FrameLayout.LayoutParams(0,0));e.addView(music,new FrameLayout.LayoutParams(0,0));e.addView(sound,new FrameLayout.LayoutParams(0,0));e.addView(reset,new FrameLayout.LayoutParams(0,0));e.addView(subtasks,new FrameLayout.LayoutParams(0,0));
        e.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{android.graphics.RectF canvas=fitCenterRect(e.getWidth(),e.getHeight(),768f,1536f);java.util.function.BiConsumer<View,float[]> place=(view,q)->{FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();placeOnCanvas(p,canvas,q);view.setLayoutParams(p);};
            // Pixel-calibrated from the actual 768x1536 running-mission artwork.
            place.accept(missionTitle,new float[]{.315104f,.474609f,.367188f,.043620f});
            place.accept(ring,new float[]{.255208f,.447266f,.486979f,.243490f});
            place.accept(timer,new float[]{.332031f,.533854f,.333333f,.058594f});
            place.accept(rewardPreview,new float[]{.312500f,.603516f,.372396f,.029297f});
            place.accept(done,new float[]{.166667f,.681641f,.216146f,.108073f});place.accept(fail,new float[]{.623698f,.681641f,.216146f,.108073f});
            place.accept(music,new float[]{.128906f,.839193f,.131510f,.065104f});place.accept(sound,new float[]{.324219f,.839193f,.131510f,.065104f});place.accept(reset,new float[]{.544271f,.839193f,.131510f,.065104f});place.accept(subtasks,new float[]{.747396f,.839193f,.131510f,.065104f});
            place.accept(subtaskBadge,new float[]{.800781f,.825521f,.104167f,.022786f});
        });
        missionMuted=missionAudioPrefs().getBoolean("muted",false);
        playSavedMissionMusic();
        setMissionMusicOutput();
        if(missionTick!=null)missionHandler.removeCallbacks(missionTick);
        missionTick=new Runnable(){public void run(){
            long rem=Math.max(0,endAt-System.currentTimeMillis());
            long elapsed=Math.min(total,Math.max(0,total-rem));
            ring.setFraction(total<=0?1f:elapsed/(float)total);
            long sec=(rem+999)/1000;
            timer.setText(String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60));
            if(sec<=10)timer.setTextColor(0xFFC62845);else if(sec<=60)timer.setTextColor(0xFFC17A18);else timer.setTextColor(0xFF071A4A);
            int[] ss=subtaskStats(section,slot);subtaskBadge.setText(ss[1]>0?(ss[0]+"/"+ss[1]):"0");
            if(rem>0)missionHandler.postDelayed(this,250);
            else{
                timer.setText("00:00");
                timer.setTextColor(0xFFC62845);
                ring.setFraction(1f);
                stopMissionMusic();
                playSfx(sfxTimerEndId,.38f);
                if(progressPrefs!=null&&!progressPrefs.getBoolean("active_alerted",false))finishMissionTimerAlert();
            }
        }};missionHandler.post(missionTick);
        done.setOnClickListener(v->{playViewSound(v);completeMission(true);});fail.setOnClickListener(v->{playViewSound(v);completeMission(false);});
        music.setOnClickListener(v->{playViewSound(v);chooseMissionMusic();});
        sound.setOnClickListener(v->{
            playSfx(sfxToggleId,.72f);
            missionMuted=!missionMuted;
            missionAudioPrefs().edit().putBoolean("muted",missionMuted).apply();
            setMissionMusicOutput();
            Toast.makeText(this,missionMuted?"موسیقی بی‌صدا شد":"صدای موسیقی روشن شد",Toast.LENGTH_SHORT).show();
        });
        reset.setOnClickListener(v->{playViewSound(v);showLaterConfirm(section,slot,title);});
        subtasks.setOnClickListener(v->{playViewSound(v);showSubtasksPopup(section,slot);});
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
    }

    private SharedPreferences missionAudioPrefs(){
        return getSharedPreferences("legacy_mission_audio",MODE_PRIVATE);
    }
    // Keep the three-mode structure, but temporarily point every mode at one tiny focus loop.
    private final int[] defaultFocusMusic={R.raw.focus_calm,R.raw.focus_calm,R.raw.focus_calm};
    private final String[] defaultFocusMusicNames={"شاد","متعادل","آرام"};

    private String selectedMissionMusic(){
        SharedPreferences sp=missionAudioPrefs();
        String selected=sp.getString("selected","");
        if(selected.length()==0){
            // One-time migration from the v43 single-URI setting.
            String old=sp.getString("uri","");
            if(old.length()>0){
                selected="u:"+old;
                addUserMusicTrack(old,displayNameForUri(android.net.Uri.parse(old)));
            }else selected="d:0";
            sp.edit().putString("selected",selected).apply();
        }
        return selected;
    }
    private java.util.ArrayList<String[]> loadUserMusicTracks(){
        java.util.ArrayList<String[]> out=new java.util.ArrayList<>();
        String raw=missionAudioPrefs().getString("user_tracks","");
        for(String line:raw.split("\n")){
            if(line.trim().length()==0)continue;
            String[] parts=line.split("\t",2);
            if(parts.length<2)continue;
            try{
                out.add(new String[]{android.net.Uri.decode(parts[0]),android.net.Uri.decode(parts[1])});
            }catch(Exception ignored){}
        }
        return out;
    }
    private void saveUserMusicTracks(java.util.ArrayList<String[]> tracks){
        java.util.ArrayList<String> lines=new java.util.ArrayList<>();
        for(String[] x:tracks){
            if(x==null||x.length<2||x[0]==null||x[0].trim().length()==0)continue;
            lines.add(android.net.Uri.encode(x[0])+"\t"+android.net.Uri.encode(x[1]==null?"موسیقی":x[1]));
        }
        missionAudioPrefs().edit().putString("user_tracks",android.text.TextUtils.join("\n",lines)).apply();
    }
    private void addUserMusicTrack(String uri,String name){
        if(uri==null||uri.trim().length()==0)return;
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        for(String[] x:tracks)if(uri.equals(x[0]))return;
        tracks.add(new String[]{uri,(name==null||name.trim().length()==0)?"موسیقی گوشی":name.trim()});
        saveUserMusicTracks(tracks);
    }
    private void removeUserMusicTrack(String uri){
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        java.util.ArrayList<String[]> keep=new java.util.ArrayList<>();
        for(String[] x:tracks)if(!uri.equals(x[0]))keep.add(x);
        saveUserMusicTracks(keep);
        if(("u:"+uri).equals(selectedMissionMusic())){
            missionAudioPrefs().edit().putString("selected","d:0").apply();
            playMissionDefault(0);
        }
    }
    private String displayNameForUri(android.net.Uri uri){
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);
            if(c!=null&&c.moveToFirst()){
                int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if(i>=0){String n=c.getString(i);if(n!=null&&n.trim().length()>0)return n;}
            }
        }catch(Exception ignored){}finally{try{if(c!=null)c.close();}catch(Exception ignored){}}
        String last=uri==null?null:uri.getLastPathSegment();
        return last==null?"موسیقی گوشی":last;
    }

    private void showMissionMusicPicker(){
        final LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(4),0,dp(4),dp(2));outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final Dialog[] dlg={null};String selected=selectedMissionMusic();
        TextView defaultHead=tv("حالت موسیقی",12,0xFF536785);defaultHead.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);defaultHead.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);outer.addView(defaultHead,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout tiles=new LinearLayout(this);tiles.setOrientation(LinearLayout.HORIZONTAL);tiles.setGravity(Gravity.CENTER);tiles.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);outer.addView(tiles,new LinearLayout.LayoutParams(-1,dp(112)));
        String[] glyph={"◉","✦","◈"};
        for(int i=0;i<defaultFocusMusic.length;i++){
            final int q=i;final boolean on=("d:"+i).equals(selected);
            LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(4),dp(6),dp(4),dp(6));
            GradientDrawable tg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{on?0xFFE9F7FF:0xFFF7F9FF,on?0xFFEFE8FF:0xFFF0F4FF});tg.setCornerRadius(dp(16));tg.setStroke(Math.max(1,dp(1)),on?0xFF4C8DFF:0x22466FA8);tile.setBackground(tg);tile.setElevation(on?dp(3):0);
            TextView art=tv(glyph[i%glyph.length],28,on?0xFF416DFF:0xFF6E7FA5);art.setGravity(Gravity.CENTER);tile.addView(art,new LinearLayout.LayoutParams(-1,dp(52)));
            TextView nm=tv(defaultFocusMusicNames[i],11,0xFF17345D);nm.setGravity(Gravity.CENTER);tile.addView(nm,new LinearLayout.LayoutParams(-1,dp(30)));
            tile.setOnClickListener(v->{playViewSound(v);missionAudioPrefs().edit().putString("selected","d:"+q).apply();playMissionDefault(q);if(dlg[0]!=null)dlg[0].dismiss();});
            LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,dp(100),1f);tlp.setMargins(dp(4),dp(4),dp(4),dp(4));tiles.addView(tile,tlp);
        }
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        TextView phoneHead=tv("My Music (From Phone)",12,0xFF536785);phoneHead.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);phoneHead.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);LinearLayout.LayoutParams ph=new LinearLayout.LayoutParams(-1,dp(34));ph.topMargin=dp(4);outer.addView(phoneHead,ph);
        if(tracks.isEmpty()){
            TextView none=tv("هنوز موسیقی‌ای از گوشی اضافه نشده",12,0xFF8190A8);none.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);none.setGravity(Gravity.CENTER);outer.addView(none,new LinearLayout.LayoutParams(-1,dp(48)));
        }else{
            for(String[] x:tracks){final String uri=x[0],name=x[1];addMusicPickerRow(outer,name,("u:"+uri).equals(selected),()->{missionAudioPrefs().edit().putString("selected","u:"+uri).putString("uri",uri).apply();playMissionMusic(android.net.Uri.parse(uri));if(dlg[0]!=null)dlg[0].dismiss();},()->{removeUserMusicTrack(uri);if(dlg[0]!=null)dlg[0].dismiss();showMissionMusicPicker();});}
        }
        TextView add=dialogButton("＋  Add Music",0xFF2FA8FF,0xFF7B61FF,false);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(50));alp.topMargin=dp(10);outer.addView(add,alp);add.setOnClickListener(v->{playViewSound(v);if(dlg[0]!=null)dlg[0].dismiss();chooseMissionMusicFromPhone();});
        ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);scroll.addView(outer,new ScrollView.LayoutParams(-1,-2));LinearLayout holder=new LinearLayout(this);holder.setOrientation(LinearLayout.VERTICAL);holder.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(480),getResources().getDisplayMetrics().heightPixels*2/3)));
        dlg[0]=buildPastelDialog("♫","انتخاب موسیقی","شاد • متعادل • آرام + موسیقی‌های گوشی",0xFF4D8EFF,holder,null,0,null,null,null);dlg[0].show();
    }
    private void addMusicPickerRow(LinearLayout outer,String name,boolean selected,Runnable choose,Runnable delete){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),0,dp(10),0);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        GradientDrawable rg=bg(selected?0xFFEAF4FF:0x00FFFFFF,dp(12));if(selected)rg.setStroke(1,0xFF2477E8);row.setBackground(rg);
        TextView label=tv((selected?"✓  ":"")+name,14,0xFF17345D);label.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        row.addView(label,new LinearLayout.LayoutParams(0,dp(46),1f));
        if(delete!=null){
            TextView del=tv("×",20,0xFFD84A55);del.setGravity(Gravity.CENTER);del.setContentDescription("حذف موسیقی");
            row.addView(del,new LinearLayout.LayoutParams(dp(42),dp(46)));
            del.setOnClickListener(v->{playViewSound(v);delete.run();});
        }
        row.setOnClickListener(v->{playViewSound(v);choose.run();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.bottomMargin=dp(4);outer.addView(row,lp);
    }
    private void chooseMissionMusicFromPhone(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_MISSION_MUSIC);
    }
    private void chooseMissionMusic(){showMissionMusicPicker();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_FULL_BACKUP_EXPORT&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            writeFullBackupAsync(data.getData());return;
        }
        if(requestCode==REQ_FULL_BACKUP_IMPORT&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            confirmFullBackupImport(data.getData());return;
        }
        if(requestCode==REQ_MISSION_MUSIC&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{
                android.net.Uri u=data.getData();
                int takeFlags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try{getContentResolver().takePersistableUriPermission(u,takeFlags&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                String uri=u.toString();
                addUserMusicTrack(uri,displayNameForUri(u));
                missionAudioPrefs().edit().putString("selected","u:"+uri).putString("uri",uri).apply();
                playMissionMusic(u);
                Toast.makeText(this,"به لیست موسیقی‌ها اضافه شد",Toast.LENGTH_SHORT).show();
            }catch(Exception ex){Toast.makeText(this,"موزیک قابل پخش نیست",Toast.LENGTH_SHORT).show();}
        }
        if(requestCode==REQ_DREAM_IMAGE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            android.net.Uri uri=data.getData();
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            if(pendingDreamSlot>=0)showDreamCropDialog(uri,pendingDreamSlot);
        }
    }
    private void playMissionDefault(int index){
        stopMissionMusic();
        try{
            int q=Math.max(0,Math.min(defaultFocusMusic.length-1,index));
            missionPlayer=android.media.MediaPlayer.create(this,defaultFocusMusic[q]);
            if(missionPlayer!=null){
                missionPlayer.setLooping(true);setMissionMusicOutput();missionPlayer.start();
            }
        }catch(Exception ignored){}
    }
    private void playMissionMusic(android.net.Uri u){
        stopMissionMusic();
        try{
            missionPlayer=android.media.MediaPlayer.create(this,u);
            if(missionPlayer!=null){missionPlayer.setLooping(true);setMissionMusicOutput();missionPlayer.start();}
        }catch(Exception ignored){}
    }
    private void playSavedMissionMusic(){
        if(missionPlayer!=null)return;
        String selected=selectedMissionMusic();
        try{
            if(selected.startsWith("d:")){
                int q=Integer.parseInt(selected.substring(2));playMissionDefault(q);
            }else if(selected.startsWith("u:")){
                playMissionMusic(android.net.Uri.parse(selected.substring(2)));
                if(missionPlayer==null){missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
            }else{missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
        }catch(Exception ex){missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
    }
    private void stopMissionMusic(){try{if(missionPlayer!=null){missionPlayer.stop();missionPlayer.release();missionPlayer=null;}}catch(Exception ignored){missionPlayer=null;}}

    private String subtaskDay(){return missionDay();}
    private void showSubtasksPopup(final int section,final int slot){
        final SharedPreferences sp=getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE);String day=subtaskDay();if(!isCurrentMissionDayKey(sp.getString("day","")))sp.edit().putString("day",day).putString("done_ids","").apply();
        final LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(2),0,dp(2),dp(2));outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);final LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));outer.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(420),getResources().getDisplayMetrics().heightPixels/2)));
        final Runnable[] render={null};render[0]=()->{
            list.removeAllViews();String raw=sp.getString("items","");java.util.LinkedHashSet<String> doneIds=new java.util.LinkedHashSet<>();for(String x:sp.getString("done_ids","").split("\\n"))if(x.trim().length()>0)doneIds.add(x.trim());java.util.ArrayList<String[]> active=new java.util.ArrayList<>(),done=new java.util.ArrayList<>();
            for(String line:raw.split("\n")){if(line.trim().length()==0)continue;String[] parts=line.split("\\|",2);if(parts.length<2)continue;(doneIds.contains(parts[0])?done:active).add(parts);}
            if(active.isEmpty()&&done.isEmpty()){TextView empty=tv("No subtasks yet",13,0xFF8290A6);empty.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(70)));}
            for(String[] x:active)addSubtaskRow(list,x[0],x[1],false,sp,render[0]);
            for(String[] x:done)addSubtaskRow(list,x[0],x[1],true,sp,render[0]);
        };
        TextView add=dialogButton("＋  Add Subtask",0xFF2FA8FF,0xFF7B61FF,false);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(50));alp.topMargin=dp(12);outer.addView(add,alp);
        add.setOnClickListener(v->{playViewSound(v);showPastelInputDialog("Add Subtask","",render[0],n->{String raw=sp.getString("items","");String id=System.currentTimeMillis()+"_"+Math.abs((n+System.nanoTime()).hashCode());sp.edit().putString("items",raw+(raw.length()>0?"\n":"")+id+"|"+n.replace("\n"," ")).apply();});});
        render[0].run();Dialog d=buildPastelDialog("☑","Subtasks","",0xFF587DFF,outer,null,0,null,null,null);d.show();
    }
    private void addSubtaskRow(LinearLayout list,String id,String text,boolean checked,SharedPreferences sp,Runnable render){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setPadding(dp(8),0,dp(4),0);GradientDrawable rg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{checked?0xFFF0F5F8:0xFFF9FBFF,checked?0xFFF3F0FA:0xFFF1F5FF});rg.setCornerRadius(dp(14));rg.setStroke(Math.max(1,dp(1)),checked?0x223F607F:0x334D8DFF);row.setBackground(rg);
        CheckBox c=new CheckBox(this);c.setText(text);c.setChecked(checked);c.setTextSize(14);c.setTextColor(checked?0xFF8792A4:0xFF17345D);c.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);c.setContentDescription("Subtask");try{c.setButtonTintList(ColorStateList.valueOf(0xFF4D8DFF));}catch(Exception ignored){}if(checked)c.setPaintFlags(c.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        TextView edit=tv("✎",17,0xFF2477E8);edit.setGravity(Gravity.CENTER);edit.setContentDescription("Edit");
        TextView del=tv("×",20,0xFFD84A55);del.setGravity(Gravity.CENTER);del.setContentDescription("Delete");
        row.addView(c,new LinearLayout.LayoutParams(0,dp(50),1f));row.addView(edit,new LinearLayout.LayoutParams(dp(40),dp(50)));row.addView(del,new LinearLayout.LayoutParams(dp(40),dp(50)));
        c.setOnCheckedChangeListener((b,on)->{playSfx(sfxSubtaskId,.62f);
            java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();
            for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0)set.add(x.trim());
            if(on)set.add(id);else set.remove(id);
            sp.edit().putString("done_ids",android.text.TextUtils.join("\n",set)).apply();
            b.post(render);
        });
        edit.setOnClickListener(v->{playViewSound(v);showPastelInputDialog("Edit Subtask",text,render,n->updateSubtaskText(sp,id,n));});
        del.setOnClickListener(v->{playViewSound(v);
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView msg=tv("Delete this subtask?",13,0xFF65748D);msg.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(msg,new LinearLayout.LayoutParams(-1,dp(44)));
            Dialog d=buildPastelDialog("×","Delete Subtask","",0xFFFF6078,body,"Delete",0xFFFF5268,()->{deleteSubtask(sp,id);render.run();},"Cancel",null);d.show();
        });
        LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(52));rlp.bottomMargin=dp(6);list.addView(row,rlp);
    }
    private void updateSubtaskText(SharedPreferences sp,String id,String newText){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);
            if(p.length==2&&id.equals(p[0]))out.add(id+"|"+newText.replace("\n"," "));
            else out.add(line);
        }
        sp.edit().putString("items",android.text.TextUtils.join("\n",out)).apply();
    }
    private void deleteSubtask(SharedPreferences sp,String id){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);if(p.length==2&&id.equals(p[0]))continue;out.add(line);
        }
        java.util.LinkedHashSet<String> done=new java.util.LinkedHashSet<>();
        for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0&&!id.equals(x.trim()))done.add(x.trim());
        sp.edit().putString("items",android.text.TextUtils.join("\n",out)).putString("done_ids",android.text.TextUtils.join("\n",done)).apply();
    }

    private void stopMissionTimer(){if(missionTick!=null){missionHandler.removeCallbacks(missionTick);missionTick=null;}}
    private void stopHomeActiveTicker(){if(homeActiveTick!=null){missionHandler.removeCallbacks(homeActiveTick);homeActiveTick=null;}}
    private void completeMission(boolean success){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        int section=progressPrefs.getInt("active_s",-1),slot=progressPrefs.getInt("active_k",-1);
        String title=progressPrefs.getString("active_title","");if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        stopMissionTimer();stopMissionMusic();expireComboIfNeeded();
        if(section>0&&slot>=0)saveMissionRewardSnapshot(section,slot);
        if(section>0&&slot>=0){setMissionState(section,slot,success?"done":"fail");refreshProgressMissionVisuals();}
        if(success){
            float mult=comboMultiplier();int earnedXp=Math.max(1,Math.round(baseXpForImportance(section,slot)*mult));int earnedCoins=Math.max(1,Math.round(baseCoinsForImportance(section,slot)*mult));int oldLevel=gameLevel,oldXp=gameXp,oldCoins=gameCoins,oldCombo=gameCombo;
            gameXp+=earnedXp;gameCoins+=earnedCoins;gameCombo++;lastSuccessAt=System.currentTimeMillis();
            while(gameXp>=xpNeeded(gameLevel)){gameXp-=xpNeeded(gameLevel);gameLevel++;}
            boolean leveled=gameLevel>oldLevel;int newLevel=gameLevel,newCombo=gameCombo;
            if(section>0&&slot>=0)recordMissionReward(section,slot,earnedXp,earnedCoins);
            saveGameState();showHudState(oldLevel,oldXp,oldCoins,oldCombo);clearActiveMissionState();animateRewardAndReturn(title,earnedXp,earnedCoins,newCombo,leveled,newLevel);
        }else{
            int previousCombo=gameCombo;if(section>0&&slot>=0)recordMissionReward(section,slot,0,0);
            gameCombo=0;lastSuccessAt=0;saveGameState();clearActiveMissionState();animateFailureAndReturn(title,previousCombo);
        }
    }
    private void showLaterConfirm(int section,int slot,String title){
        Dialog d=buildPastelDialog("⌛","Mission Paused",title,0xFF6E8FFF,null,"Restart",0xFF4B8DFF,()->laterMission(section,slot),"Cancel",null);d.show();
    }
    private void laterMission(int section,int slot){
        String title=progressPrefs==null?"":progressPrefs.getString("active_title","");if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        stopMissionTimer();stopMissionMusic();if(section>0&&slot>=0){setMissionState(section,slot,"ready");clearMissionRewardSnapshot(section,slot);refreshProgressMissionVisuals();}clearActiveMissionState();animateResetAndReturn(title);
    }
    private void clearActiveMissionState(){
        cancelMissionAlarm();cancelMissionNotification();removeActiveMissionBar();if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putBoolean("active",false).remove("active_s").remove("active_k").remove("active_title").remove("active_end").remove("active_total").remove("active_alerted").apply();
    }
    private void animateRewardAndReturn(String title,int xp,int coins,int combo,boolean leveled,int newLevel){
        missionHandler.postDelayed(()->playSfx(sfxRewardId,.42f),120);
        if(root==null){showProgressPath();showMissionSuccessDialog(title,xp,coins,combo,leveled,newLevel);return;}
        final java.util.ArrayList<View> fx=new java.util.ArrayList<>();int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);int cx=rw/2,cy=Math.round(rh*.57f);
        final TextView badge=tv("★",58,THEME_PRIMARY);badge.setShadowLayer(dp(12),0,0,0x8855C8FF);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(92),dp(92));bp.leftMargin=cx-dp(46);bp.topMargin=cy-dp(46);root.addView(badge,bp);fx.add(badge);badge.setAlpha(0f);badge.setScaleX(.35f);badge.setScaleY(.35f);
        AnimatorSet badgeA=new AnimatorSet();badgeA.playTogether(ObjectAnimator.ofFloat(badge,"alpha",0f,1f,1f),ObjectAnimator.ofFloat(badge,"scaleX",.35f,1.22f,.96f,1f),ObjectAnimator.ofFloat(badge,"scaleY",.35f,1.22f,.96f,1f),ObjectAnimator.ofFloat(badge,"rotation",-18f,8f,0f));badgeA.setDuration(1500);badgeA.setInterpolator(new android.view.animation.DecelerateInterpolator());badgeA.start();
        String[] labels={"+"+xp+" XP","+"+coins+" Coin","Combo +1"};int[] colors={0xFF17CFFF,0xFFFFC244,0xFFFF764D};float[] tx={rw*.38f,rw*.64f,rw*.82f};
        for(int i=0;i<3;i++){final TextView fly=tv(labels[i],15,colors[i]);fly.setShadowLayer(dp(5),0,0,0x66000000);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(118),dp(42));lp.leftMargin=cx-dp(59);lp.topMargin=cy+dp(45+i*14);root.addView(fly,lp);fx.add(fly);fly.setAlpha(0f);float dx=tx[i]-(cx),dy=dp(22)-(cy+dp(45+i*14));AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(fly,"alpha",0f,1f,1f,.05f),ObjectAnimator.ofFloat(fly,"translationX",0,dx),ObjectAnimator.ofFloat(fly,"translationY",0,dy),ObjectAnimator.ofFloat(fly,"scaleX",.75f,1.08f,1f),ObjectAnimator.ofFloat(fly,"scaleY",.75f,1.08f,1f));a.setStartDelay(350+i*220);a.setDuration(1750);a.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());a.start();}
        int[] dx={-150,-110,-70,-30,30,70,110,150,-130,-55,55,130};int[] dy={-150,-105,-170,-125,-155,-95,-165,-115,-45,-205,-210,-55};int[] pc={0xFF46CFFF,0xFF7B61FF,0xFF72C9FF,0xFFFF7AA8};
        for(int i=0;i<dx.length;i++){TextView p=tv(i%3==0?"✦":"•",20,pc[i%pc.length]);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(34),dp(34));lp.leftMargin=cx-dp(17);lp.topMargin=cy-dp(17);root.addView(p,lp);fx.add(p);p.setAlpha(0f);AnimatorSet pa=new AnimatorSet();pa.playTogether(ObjectAnimator.ofFloat(p,"alpha",0f,1f,0f),ObjectAnimator.ofFloat(p,"translationX",0,dp(dx[i])),ObjectAnimator.ofFloat(p,"translationY",0,dp(dy[i])),ObjectAnimator.ofFloat(p,"scaleX",.4f,1.25f,.7f),ObjectAnimator.ofFloat(p,"scaleY",.4f,1.25f,.7f),ObjectAnimator.ofFloat(p,"rotation",0f,180f));pa.setStartDelay(120+i*55);pa.setDuration(1850);pa.start();}
        missionHandler.postDelayed(()->{updateHud();pulseHudRewards();},1850);
        missionHandler.postDelayed(()->{for(View v:fx)try{if(v.getParent() instanceof ViewGroup)((ViewGroup)v.getParent()).removeView(v);}catch(Exception ignored){}showProgressPath();missionHandler.postDelayed(()->showMissionSuccessDialog(title,xp,coins,combo,leveled,newLevel),220);},2350);
    }
    private void animateFailureAndReturn(String title,int previousCombo){
        if(root==null){showProgressPath();showMissionFailDialog(title,previousCombo);return;}int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);TextView crystal=tv("◆",72,0xFFFF5B85);crystal.setShadowLayer(dp(14),0,0,0x88FF4A75);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(120),dp(120));lp.leftMargin=rw/2-dp(60);lp.topMargin=Math.round(rh*.52f)-dp(60);root.addView(crystal,lp);crystal.setAlpha(0f);AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(crystal,"alpha",0f,1f,1f,.15f),ObjectAnimator.ofFloat(crystal,"scaleX",.35f,1.18f,.96f,1f),ObjectAnimator.ofFloat(crystal,"scaleY",.35f,1.18f,.96f,1f),ObjectAnimator.ofFloat(crystal,"rotation",-10f,9f,-5f,0f));a.setDuration(1500);a.start();missionHandler.postDelayed(()->{try{root.removeView(crystal);}catch(Exception ignored){}showProgressPath();missionHandler.postDelayed(()->showMissionFailDialog(title,previousCombo),180);},1600);
    }
    private void animateResetAndReturn(String title){
        if(root==null){showProgressPath();return;}int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);TextView r=tv("↻",66,0xFF4D8DFF);r.setShadowLayer(dp(10),0,0,0x664D8DFF);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(110),dp(110));lp.leftMargin=rw/2-dp(55);lp.topMargin=Math.round(rh*.55f)-dp(55);root.addView(r,lp);r.setAlpha(0f);AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(r,"alpha",0f,1f,1f,0f),ObjectAnimator.ofFloat(r,"rotation",0f,360f),ObjectAnimator.ofFloat(r,"scaleX",.6f,1.12f,1f),ObjectAnimator.ofFloat(r,"scaleY",.6f,1.12f,1f));a.setDuration(1250);a.setInterpolator(new android.view.animation.DecelerateInterpolator());a.start();missionHandler.postDelayed(()->{try{root.removeView(r);}catch(Exception ignored){}showProgressPath();},1320);
    }
    private void animateRestoreFeedback(){
        if(root==null)return;final TextView v=tv("↻  Restored",16,0xFF287EDC);GradientDrawable g=bg(0xF2EFF8FF,dp(18));g.setStroke(Math.max(1,dp(1)),0x664A8DFF);v.setBackground(g);v.setElevation(dp(6));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(170),dp(48),Gravity.CENTER_HORIZONTAL|Gravity.TOP);lp.topMargin=dp(92);root.addView(v,lp);v.setAlpha(0f);v.setScaleX(.7f);v.setScaleY(.7f);AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(v,"alpha",0f,1f,1f,0f),ObjectAnimator.ofFloat(v,"translationY",dp(14),0,-dp(8)),ObjectAnimator.ofFloat(v,"scaleX",.7f,1.08f,1f),ObjectAnimator.ofFloat(v,"scaleY",.7f,1.08f,1f));a.setDuration(1500);a.start();missionHandler.postDelayed(()->{try{root.removeView(v);}catch(Exception ignored){}},1550);
    }
    private void showMissionSuccessDialog(String title,int xp,int coins,int combo,boolean leveled,int newLevel){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);body.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView a=rewardChip("★ +"+xp+" XP",0xFF0878D8,0xFFE9F8FF,0x5543B4FF),b=rewardChip("● +"+coins,0xFF2F78B8,0xFFEAF6FF,0x5554A9FF),c=rewardChip("🔥 "+combo,0xFFC84F2A,0xFFFFEEE9,0x55FF855F);row.addView(a,new LinearLayout.LayoutParams(0,dp(40),1f));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(0,dp(40),1f);blp.setMargins(dp(6),0,dp(6),0);row.addView(b,blp);row.addView(c,new LinearLayout.LayoutParams(0,dp(40),1f));
        
        Dialog d=buildPastelDialog("🏆","Mission Completed!",title,THEME_PRIMARY,body,"Continue",0xFF3F8CFF,()->{if(leveled)showLevelUpCard(newLevel);},null,null);d.show();
    }
    private void showMissionFailDialog(String title,int previousCombo){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);TextView chip=rewardChip(previousCombo>0?"🔥 Combo "+previousCombo+" → 0":"🔥 Combo Reset",0xFFC73A45,0xFFFFECEF,0x55FF5B72);body.addView(chip,new LinearLayout.LayoutParams(dp(170),dp(40)));
        Dialog d=buildPastelDialog("◆","Mission Failed",title,0xFFFF6078,body,"Continue",0xFF6B7EFF,null,null,null);d.show();
    }
    private void showMissionPausedInfoDialog(String title){
        Dialog d=buildPastelDialog("⌛","Mission Paused",title,0xFF708FFF,null,"Continue",0xFF4E8CFF,null,null,null);d.show();
    }
    private void showLevelUpCard(int level){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);TextView l=tv("Level "+level,24,0xFF234D9A);body.addView(l,new LinearLayout.LayoutParams(-1,dp(42)));TextView r=rewardChip("Rank: Explorer",0xFF4F5F7E,0xFFF0F4FF,0x445D7CFF);body.addView(r,new LinearLayout.LayoutParams(dp(190),dp(40)));Dialog d=buildPastelDialog("★","Level Up!","",THEME_PRIMARY,body,"Continue",0xFF3F8CFF,null,null,null);d.show();
    }
    private void consumePendingMissionFeedback(){
        SharedPreferences gp=getSharedPreferences("legacy_game",MODE_PRIVATE);int xp=gp.getInt("pending_reward_xp",0),coins=gp.getInt("pending_reward_coins",0),lvl=gp.getInt("pending_level_up",0),combo=gp.getInt("pending_combo",gameCombo),prevCombo=gp.getInt("pending_prev_combo",gameCombo);String title=gp.getString("pending_title","");String result=gp.getString("pending_result","");
        if(xp==0&&coins==0&&lvl==0&&result.length()==0)return;
        gp.edit().remove("pending_reward_xp").remove("pending_reward_coins").remove("pending_level_up").remove("pending_combo").remove("pending_prev_combo").remove("pending_title").remove("pending_result").apply();
        if("done".equals(result))showMissionSuccessDialog(title,xp,coins,combo,lvl>0,lvl);else if("fail".equals(result))showMissionFailDialog(title,prevCombo);else if("later".equals(result))showMissionPausedInfoDialog(title);else if(lvl>0)showLevelUpCard(lvl);
    }
    private void ensureNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            try{requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},4102);}catch(Exception ignored){}
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==4102&&grantResults!=null&&grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
            if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
            if(progressPrefs.getBoolean("active",false))MissionNotification.showRunning(this);
        }
    }

    private android.app.PendingIntent missionAlarmPendingIntent(){
        Intent i=new Intent(this,MissionAlarmReceiver.class);i.setAction("com.shahriar.legacy.MISSION_ALARM");
        return android.app.PendingIntent.getBroadcast(this,4101,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    }
    private android.app.PendingIntent missionActionPendingIntent(String action,int requestCode){
        Intent i=new Intent(this,MissionActionReceiver.class);i.setAction(action);
        return android.app.PendingIntent.getBroadcast(this,requestCode,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    }
    private void scheduleMissionAlarm(long endAt){
        try{
            android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);
            android.app.PendingIntent pi=missionAlarmPendingIntent();
            if(android.os.Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,endAt,pi);
            else am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,endAt,pi);
        }catch(Exception ignored){}
    }
    private void cancelMissionAlarm(){try{android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);am.cancel(missionAlarmPendingIntent());}catch(Exception ignored){}}
    private void cancelMissionNotification(){MissionNotification.cancel(this);}
    private void finishMissionTimerAlert(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressPrefs.getBoolean("active_alerted",false)){MissionNotification.showFinished(this);return;}
        progressPrefs.edit().putBoolean("active_alerted",true).apply();
        if(!isNotificationsEnabled())return;
        try{android.os.Vibrator vb=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);if(vb!=null){if(android.os.Build.VERSION.SDK_INT>=26)vb.vibrate(android.os.VibrationEffect.createOneShot(500,android.os.VibrationEffect.DEFAULT_AMPLITUDE));else vb.vibrate(500);}}catch(Exception ignored){}
        MissionNotification.showFinished(this);
    }

    private void removeActiveMissionBar(){
        stopHomeActiveTicker();
        try{if(activeBar!=null&&activeBar.getParent() instanceof ViewGroup)((ViewGroup)activeBar.getParent()).removeView(activeBar);}catch(Exception ignored){}
        activeBar=null;
    }
    private void addActiveMissionBar(){
        removeActiveMissionBar();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(!progressPrefs.getBoolean("active",false)||root==null||isRunningMissionScreen)return;
        final TextView bar=tv("",12,THEME_TEXT);activeBar=bar;bar.setGravity(Gravity.CENTER);bar.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xF4F9FCFF,0xEEF0F7FF});g.setCornerRadius(dp(20));g.setStroke(Math.max(1,Math.round(dp(.8f))),0x9964B5FF);bar.setBackground(g);
        bar.setPadding(dp(16),0,dp(16),0);bar.setElevation(dp(7));bar.setShadowLayer(dp(1.5f),0,dp(1),0x22004A85);bar.setContentDescription("Continue Mission");
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(258),dp(44),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=dp(18);root.addView(bar,bp);
        bar.setOnClickListener(v->resumeActiveMission());
        homeActiveTick=new Runnable(){public void run(){
            if(bar.getParent()==null||progressPrefs==null||!progressPrefs.getBoolean("active",false)){homeActiveTick=null;return;}
            long end=progressPrefs.getLong("active_end",0);long rem=Math.max(0,end-System.currentTimeMillis());long sec=(rem+999)/1000;
            String t=String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60);
            bar.setText(rem>0?"▶  Continue Mission   •   "+t:"▶  Continue Mission   •   00:00");
            missionHandler.postDelayed(this,1000);
        }};missionHandler.post(homeActiveTick);
    }

    // Progress Path rebuild: visual structure only. Mission logic will be added step by step.
    private ScrollView progressScroll;
    private LinearLayout progressPages;
    private int progressSectionCount=1;
    private SharedPreferences progressPrefs;

    private String progressTitle(int section,int slot){
        if(progressPrefs==null) progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        return progressPrefs.getString("title_"+section+"_"+slot,"");
    }
    private void askProgressTitle(final int section,final int slot,final TextView label){
        showPastelInputDialog("عنوان مأموریت",progressTitle(section,slot),null,title->{
            if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
            progressPrefs.edit().putString("title_"+section+"_"+slot,title).apply();label.setText(title);
        });
    }

    private void showProgressPath(){
        stopMissionTimer();
        stopHomeActiveTicker();removeHomeOnlyOverlays();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome=false;isRunningMissionScreen=false;isProgressPathScreen=true;isMissionEditorScreen=false;isPlaceholderScreen=false; ++homeGeneration; content.removeAllViews();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        progressMissionViews.clear();
        int savedSections=Math.max(1,progressPrefs.getInt("progress_section_count",1));
        progressSectionCount=1;
        progressScroll=new ScrollView(this);
        progressScroll.setFillViewport(true);
        progressScroll.setClipToPadding(false);
        progressScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        progressScroll.setBackgroundColor(Color.TRANSPARENT);
        progressPages=new LinearLayout(this);
        progressPages.setOrientation(LinearLayout.VERTICAL);
        progressPages.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        progressScroll.addView(progressPages,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1);
        lp.topMargin=0;
        content.addView(progressScroll,lp);
        addProgressSection(false);
        while(progressSectionCount<savedSections){progressSectionCount++;addProgressSection(false);}
        addActiveMissionBar();
        final int requestedSection=pendingProgressFocusSection,requestedSlot=pendingProgressFocusSlot;
        pendingProgressFocusSection=-1;pendingProgressFocusSlot=-1;
        progressScroll.post(()->{
            if(progressScroll==null)return;
            progressScroll.fullScroll(View.FOCUS_DOWN);
            progressScroll.postDelayed(()->{if(requestedSection>0&&requestedSlot>=0)scrollProgressToMission(requestedSection,requestedSlot,true);else scrollProgressToFirstPending(true);},70);
        });
    }

    private float[][] progressPointsForSection(int section){
        int h=activeHero();boolean first=(section%2)==1;
        if(h==1)return first?new float[][]{{0.358073f,0.201823f},{0.303385f,0.477214f},{0.416667f,0.737630f}}:new float[][]{{0.640156f,0.201172f},{0.698827f,0.479167f},{0.584094f,0.736328f}};
        if(h==2)return first?new float[][]{{0.381510f,0.216146f},{0.303385f,0.511068f},{0.415365f,0.766276f}}:new float[][]{{0.619296f,0.217448f},{0.693611f,0.511068f},{0.582790f,0.768229f}};
        return first?new float[][]{{0.378906f,0.209635f},{0.319010f,0.496745f},{0.412760f,0.762370f}}:new float[][]{{0.619296f,0.207682f},{0.677966f,0.496745f},{0.582790f,0.762370f}};
    }
    private float[] progressSizesForSection(int section){
        int h=activeHero();boolean first=(section%2)==1;
        if(h==1)return first?new float[]{0.333333f,0.330729f,0.328125f}:new float[]{0.333768f,0.325945f,0.328553f};
        if(h==2)return first?new float[]{0.312500f,0.315104f,0.320313f}:new float[]{0.311604f,0.315515f,0.315515f};
        return first?new float[]{0.312500f,0.338542f,0.322917f}:new float[]{0.320730f,0.338983f,0.323338f};
    }

    private void scrollProgressToMission(int targetSection,int targetSlot,boolean smooth){
        if(progressScroll==null||progressPages==null)return;
        int pageWidth=Math.max(progressPages.getWidth(),getResources().getDisplayMetrics().widthPixels);
        int pageHeight=Math.round(pageWidth*(1536f/768f));
        targetSection=Math.max(1,Math.min(Math.max(1,progressSectionCount),targetSection));targetSlot=Math.max(0,Math.min(2,targetSlot));
        final float[][] pts=progressPointsForSection(targetSection);
        int pageTop=(Math.max(1,progressSectionCount)-targetSection)*pageHeight;
        float cy=pts[targetSlot][1]*pageHeight;
        int viewport=Math.max(1,progressScroll.getHeight());int desired=Math.round(pageTop+cy-viewport*.52f);int maxScroll=Math.max(0,progressPages.getHeight()-viewport);desired=Math.max(0,Math.min(desired,maxScroll));
        if(smooth)progressScroll.smoothScrollTo(0,desired);else progressScroll.scrollTo(0,desired);
        TextView v=progressMissionViews.get(missionViewKey(targetSection,targetSlot));if(v!=null){v.animate().cancel();v.setScaleX(1f);v.setScaleY(1f);v.animate().scaleX(1.10f).scaleY(1.10f).setDuration(230).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(380).start()).start();}
    }

    private void scrollProgressToFirstPending(boolean smooth){
        if(progressScroll==null||progressPages==null)return;
        int pageWidth=Math.max(progressPages.getWidth(),getResources().getDisplayMetrics().widthPixels);
        int pageHeight=Math.round(pageWidth*(1536f/768f));
        int targetSection=1,targetSlot=2;
        boolean found=false;
        for(int s=1;s<=Math.max(1,progressSectionCount)&&!found;s++){
            for(int slot=2;slot>=0;slot--){
                String state=missionState(s,slot);
                if(!"done".equals(state) && !"fail".equals(state)){
                    targetSection=s;targetSlot=slot;found=true;break;
                }
            }
        }
        int pageTop=(Math.max(1,progressSectionCount)-targetSection)*pageHeight;
        float[][] pts=progressPointsForSection(targetSection);float cy=pts[targetSlot][1]*pageHeight;
        int viewport=Math.max(1,progressScroll.getHeight());
        int desired=Math.round(pageTop + cy - viewport*0.58f);
        int maxScroll=Math.max(0,progressPages.getHeight()-viewport);
        desired=Math.max(0,Math.min(desired,maxScroll));
        if(smooth)progressScroll.smoothScrollTo(0,desired); else progressScroll.scrollTo(0,desired);
    }

    private void refreshProgressArrows(){if(progressPages==null)return;for(int i=0;i<progressPages.getChildCount();i++){View p=progressPages.getChildAt(i);View u=p.findViewWithTag("progress_up"),d=p.findViewWithTag("progress_down");if(u!=null){u.setVisibility(i==0?View.VISIBLE:View.GONE);u.setEnabled(i==0);}if(d!=null)d.setVisibility(i==0&&progressSectionCount>1?View.VISIBLE:View.GONE);}}

    private void addProgressSection(boolean animateToNew){
        final int sectionNumber=progressSectionCount;
        final FrameLayout page=new FrameLayout(this);
        int w=getResources().getDisplayMetrics().widthPixels;
        int pageHeight=Math.round(w*(1536f/768f));

        ImageView art=new ImageView(this);
        art.setImageResource(sectionNumber%2==1?heroProgressFirstBackground():heroProgressSecondBackground());
        art.setScaleType(ImageView.ScaleType.FIT_XY);
        page.addView(art,new FrameLayout.LayoutParams(-1,-1));

        // Tiny naked up-arrow: top-left, no circle/square/background.
        TextView up=tv("⌃",19,0xFF245CCB);
        up.setContentDescription("ادامه مسیر"); up.setTag("progress_up");
        up.setBackgroundColor(Color.TRANSPARENT);
        up.setShadowLayer(dp(1.5f),0,dp(1),0x99FFFFFF);
        up.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.TOP|Gravity.LEFT);
        ap.leftMargin=dp(8);
        ap.topMargin=dp(52);
        page.addView(up,ap);
        up.setOnClickListener(v->{playViewSound(v);
            progressSectionCount++;
            if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
            progressPrefs.edit().putInt("progress_section_count",progressSectionCount).apply();
            addProgressSection(true);
        });

        // Hero-specific centers and inner diameters measured from every supplied 768x1536 progress artwork.
        // Odd sections use progress_first (circles left); even sections use progress_second (circles right).
        // Title, state fill and touch target all share this single MissionSlotView, so they cannot drift apart.
        final float[][] pts=progressPointsForSection(sectionNumber);
        final float[] sizes=progressSizesForSection(sectionNumber);

        for(int i=0;i<3;i++){
            final int slot=i;
            MissionSlotView mission=new MissionSlotView(this);mission.setText(progressTitle(sectionNumber,slot));mission.setTextSize(13);mission.setTextColor(0xFF162D54);mission.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            mission.setGravity(Gravity.CENTER);
            mission.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            mission.setMaxLines(2);
            enableAutoSize(mission,8,14);
            mission.setPadding(dp(10),dp(10),dp(10),dp(10));mission.setLineSpacing(0,1.06f);
            mission.setContentDescription("جایگاه مأموریت "+(slot+1));
            styleMissionSlot(mission,missionVisualState(sectionNumber,slot));
            progressMissionViews.put(missionViewKey(sectionNumber,slot),mission);
            int circleSize=Math.round(w*sizes[i]);
            int cx=Math.round(w*pts[i][0]);
            int cy=Math.round(pageHeight*pts[i][1]);
            FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(circleSize,circleSize);
            mp.leftMargin=cx-circleSize/2;
            mp.topMargin=cy-circleSize/2;
            page.addView(mission,mp);
            if(sectionNumber==progressNewMissionSection&&slot==progressNewMissionSlot){float endScale="active".equals(missionVisualState(sectionNumber,slot))?1.055f:1f;mission.setScaleX(.84f);mission.setScaleY(.84f);mission.setAlpha(.45f);mission.animate().scaleX(endScale).scaleY(endScale).alpha(1f).setDuration(220).setInterpolator(new android.view.animation.DecelerateInterpolator()).withEndAction(()->{progressNewMissionSection=-1;progressNewMissionSlot=-1;}).start();}
            if(sectionNumber==progressResultAnimSection&&slot==progressResultAnimSlot&&mission instanceof MissionSlotView){((MissionSlotView)mission).animateResultReveal();progressResultAnimSection=-1;progressResultAnimSlot=-1;}
            mission.setOnClickListener(v->{
                playViewSound(v);
                String state=missionState(sectionNumber,slot);
                if("active".equals(state)){resumeActiveMission();return;}
                if("done".equals(state)||"fail".equals(state)){showMissionSlotMenu(sectionNumber,slot);return;}
                showMissionEditor(sectionNumber,slot);
            });
            mission.setOnLongClickListener(v->{playUiClick();showMissionSlotMenu(sectionNumber,slot);return true;});
        }

        TextView down=tv("⌄",19,0xFF245CCB);down.setTag("progress_down");down.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams dl=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.BOTTOM|Gravity.LEFT);dl.leftMargin=dp(8);dl.bottomMargin=dp(8);page.addView(down,dl);
        down.setOnClickListener(v->{playViewSound(v);
            boolean empty=true;for(int k=0;k<3;k++)if(progressTitle(sectionNumber,k).trim().length()>0)empty=false;
            if(!empty){Toast.makeText(this,"برای حذف صفحه، دایره‌ها باید خالی باشند",Toast.LENGTH_SHORT).show();return;}
            if(sectionNumber==progressSectionCount&&progressSectionCount>1){
                progressPages.removeView(page);
                for(int k=0;k<3;k++)clearMissionSlot(sectionNumber,k);
                progressSectionCount--;
                if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
                progressPrefs.edit().putInt("progress_section_count",progressSectionCount).apply();
                refreshProgressArrows();
            }
        });
        progressPages.addView(page,0,new LinearLayout.LayoutParams(-1,pageHeight));refreshProgressArrows();
        if(animateToNew){
            progressScroll.post(()->progressScroll.smoothScrollTo(0,0));
        }
    }

    private void clearMissionSlot(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        SharedPreferences.Editor ed=progressPrefs.edit()
            .remove("title_"+section+"_"+slot)
            .remove(mf(section,slot,"importance"))
            .remove(mf(section,slot,"minutes"))
            .remove(mf(section,slot,"repeat"))
            .remove(mf(section,slot,"state"))
            .remove(mf(section,slot,"state_day"))
            .remove(mf(section,slot,"reward_snapshot"))
            .remove(mf(section,slot,"prev_level")).remove(mf(section,slot,"prev_xp")).remove(mf(section,slot,"prev_coins"))
            .remove(mf(section,slot,"prev_combo")).remove(mf(section,slot,"prev_last_success"))
            .remove(mf(section,slot,"reward_xp")).remove(mf(section,slot,"reward_coins")).remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at"))
            .remove(mf(section,slot,"defaults_v41"));
        ed.apply();
        getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE).edit().clear().apply();
    }

    private void showGameSettings(){
        final String[] opts={"10 دقیقه","15 دقیقه","20 دقیقه","30 دقیقه","45 دقیقه","60 دقیقه"};
        final int[] vals={10,15,20,30,45,60}; int checked=3; for(int i=0;i<vals.length;i++)if(vals[i]==comboWindowMinutes)checked=i;
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);final Dialog[] dlg={null};
        for(int i=0;i<opts.length;i++){final int idx=i;boolean selected=i==checked;TextView row=tv(opts[i]+(selected?"   ✓":""),14,selected?0xFF256FD1:0xFF17345D);row.setGravity(Gravity.CENTER);GradientDrawable rg=bg(selected?0xFFEAF4FF:0xFFF7F9FF,dp(13));rg.setStroke(Math.max(1,Math.round(dp(.7f))),selected?0x884E8CFF:0x224E8CFF);row.setBackground(rg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(44));lp.setMargins(0,dp(3),0,dp(3));body.addView(row,lp);row.setOnClickListener(v->{playViewSound(v);comboWindowMinutes=vals[idx];expireComboIfNeeded();saveGameState();dlg[0].dismiss();Toast.makeText(this,"مهلت Combo: "+comboWindowMinutes+" دقیقه",Toast.LENGTH_SHORT).show();});}
        dlg[0]=buildPastelDialog("⚡","مهلت ادامه Combo","",0xFF6B7EFF,body,null,0,null,"بستن",null);dlg[0].show();
    }
    private TextView settingsRow(String title,String value){
        TextView row=tv(title+"   "+value,14,0xFF17345D);row.setGravity(Gravity.CENTER);GradientDrawable rg=bg(0xFFF7F9FF,dp(13));rg.setStroke(Math.max(1,Math.round(dp(.7f))),0x224E8CFF);row.setBackground(rg);row.setPadding(dp(10),0,dp(10),0);return row;
    }
    private ImageView settingsHeaderIcon(int res,String description){
        ImageView v=new ImageView(this);v.setImageResource(res);v.setScaleType(ImageView.ScaleType.CENTER_INSIDE);v.setPadding(dp(7),dp(7),dp(7),dp(7));v.setContentDescription(description);
        GradientDrawable mask=new GradientDrawable();mask.setShape(GradientDrawable.OVAL);mask.setColor(0x0B4E8CFF);mask.setStroke(Math.max(1,dp(1)),0x224E8CFF);v.setBackground(mask);v.setClickable(true);v.setFocusable(true);return v;
    }

    private String backupFileName(){
        int[] j=jalaliForMillis(System.currentTimeMillis());
        return String.format(java.util.Locale.US,"Legacy-backup-%04d-%02d-%02d.zip",j[0],j[1],j[2]);
    }
    private void launchFullBackupExport(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,backupFileName());
        try{startActivityForResult(i,REQ_FULL_BACKUP_EXPORT);}catch(Exception e){Toast.makeText(this,"امکان ساخت فایل پشتیبان نیست",Toast.LENGTH_SHORT).show();}
    }
    private void launchFullBackupImport(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");
        try{startActivityForResult(i,REQ_FULL_BACKUP_IMPORT);}catch(Exception e){Toast.makeText(this,"امکان انتخاب فایل پشتیبان نیست",Toast.LENGTH_SHORT).show();}
    }
    private void confirmFullBackupImport(final android.net.Uri uri){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView note=tv("اطلاعات فعلی با محتوای فایل پشتیبان جایگزین می‌شود.",13,0xFF536785);note.setGravity(Gravity.CENTER);note.setPadding(dp(8),dp(4),dp(8),dp(4));body.addView(note,new LinearLayout.LayoutParams(-1,-2));
        Dialog d=buildPastelDialog("↻","بارگذاری پشتیبان","همه اطلاعات اپ بازیابی می‌شود",0xFF7B61FF,body,"بارگذاری",0xFF4E8CFF,()->restoreFullBackupAsync(uri),"لغو",null);d.show();
    }
    private java.util.ArrayList<String> sharedPreferenceNames(){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        try{
            java.io.File dir=new java.io.File(getApplicationInfo().dataDir,"shared_prefs");
            java.io.File[] fs=dir.listFiles((d,n)->n.endsWith(".xml"));
            if(fs!=null)for(java.io.File f:fs){String n=f.getName();n=n.substring(0,n.length()-4);if(!out.contains(n))out.add(n);}
        }catch(Exception ignored){}
        String[] known={"legacy_app_settings","legacy_progress_rebuild","legacy_game","legacy_mission_audio","legacy_tree_dynamic_v1","legacy_tree_graph_v2","legacy_tree_history_v1","legacy_dream_palace","legacy_timesheet_v2"};
        for(String n:known)if(!out.contains(n))out.add(n);
        java.util.Collections.sort(out);return out;
    }
    private org.json.JSONObject buildPreferencesBackup() throws Exception{
        org.json.JSONObject root=new org.json.JSONObject();org.json.JSONArray prefsArray=new org.json.JSONArray();
        for(String name:sharedPreferenceNames()){
            SharedPreferences sp=getSharedPreferences(name,MODE_PRIVATE);org.json.JSONObject po=new org.json.JSONObject();po.put("name",name);org.json.JSONArray values=new org.json.JSONArray();
            for(java.util.Map.Entry<String,?> it:sp.getAll().entrySet()){
                Object val=it.getValue();if(val==null)continue;org.json.JSONObject o=new org.json.JSONObject();o.put("key",it.getKey());
                if(val instanceof String){o.put("type","string");o.put("value",(String)val);}
                else if(val instanceof Integer){o.put("type","int");o.put("value",(Integer)val);}
                else if(val instanceof Long){o.put("type","long");o.put("value",(Long)val);}
                else if(val instanceof Float){o.put("type","float");o.put("value",Double.parseDouble(String.valueOf(val)));}
                else if(val instanceof Boolean){o.put("type","boolean");o.put("value",(Boolean)val);}
                else if(val instanceof java.util.Set){o.put("type","string_set");org.json.JSONArray a=new org.json.JSONArray();for(Object x:(java.util.Set<?>)val)a.put(String.valueOf(x));o.put("value",a);}
                else continue;
                values.put(o);
            }
            po.put("values",values);prefsArray.put(po);
        }
        root.put("preferences",prefsArray);return root;
    }
    private void restorePreferencesBackup(org.json.JSONObject root) throws Exception{
        java.util.HashSet<String> backupNames=new java.util.HashSet<>();
        org.json.JSONArray pa=root.getJSONArray("preferences");
        for(int i=0;i<pa.length();i++)backupNames.add(pa.getJSONObject(i).getString("name"));
        for(String existing:sharedPreferenceNames())getSharedPreferences(existing,MODE_PRIVATE).edit().clear().commit();
        for(int i=0;i<pa.length();i++){
            org.json.JSONObject po=pa.getJSONObject(i);String name=po.getString("name");SharedPreferences.Editor ed=getSharedPreferences(name,MODE_PRIVATE).edit().clear();
            org.json.JSONArray values=po.getJSONArray("values");
            for(int q=0;q<values.length();q++){
                org.json.JSONObject o=values.getJSONObject(q);String k=o.getString("key"),t=o.getString("type");
                if("string".equals(t))ed.putString(k,o.optString("value",""));
                else if("int".equals(t))ed.putInt(k,o.getInt("value"));
                else if("long".equals(t))ed.putLong(k,o.getLong("value"));
                else if("float".equals(t))ed.putFloat(k,(float)o.getDouble("value"));
                else if("boolean".equals(t))ed.putBoolean(k,o.getBoolean("value"));
                else if("string_set".equals(t)){org.json.JSONArray a=o.getJSONArray("value");java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();for(int z=0;z<a.length();z++)set.add(a.getString(z));ed.putStringSet(k,set);}
            }
            if(!ed.commit())throw new java.io.IOException("prefs");
        }
    }
    private void zipFileTree(java.util.zip.ZipOutputStream zos,java.io.File root,String prefix) throws Exception{
        if(root==null||!root.exists())return;java.io.File[] children=root.listFiles();if(children==null)return;
        byte[] buf=new byte[32768];
        for(java.io.File f:children){
            String entry=prefix+f.getName();
            if(f.isDirectory()){java.util.zip.ZipEntry ze=new java.util.zip.ZipEntry(entry+"/");zos.putNextEntry(ze);zos.closeEntry();zipFileTree(zos,f,entry+"/");}
            else{java.util.zip.ZipEntry ze=new java.util.zip.ZipEntry(entry);ze.setTime(f.lastModified());zos.putNextEntry(ze);try(java.io.FileInputStream in=new java.io.FileInputStream(f)){int n;while((n=in.read(buf))>0)zos.write(buf,0,n);}zos.closeEntry();}
        }
    }
    private void writeZipText(java.util.zip.ZipOutputStream zos,String name,String value) throws Exception{
        java.util.zip.ZipEntry e=new java.util.zip.ZipEntry(name);zos.putNextEntry(e);byte[] b=value.getBytes(java.nio.charset.StandardCharsets.UTF_8);zos.write(b);zos.closeEntry();
    }
    private void writeBackedUserMusic(java.util.zip.ZipOutputStream zos) throws Exception{
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();org.json.JSONArray meta=new org.json.JSONArray();String selected=selectedMissionMusic();byte[] buf=new byte[32768];int index=0;
        for(String[] tr:tracks){
            if(tr==null||tr.length<2)continue;android.net.Uri u=android.net.Uri.parse(tr[0]);
            try(java.io.InputStream in=getContentResolver().openInputStream(u)){
                if(in==null)continue;String entry="external_music/track_"+(index++);
                zos.putNextEntry(new java.util.zip.ZipEntry(entry));int n;while((n=in.read(buf))>0)zos.write(buf,0,n);zos.closeEntry();
                org.json.JSONObject o=new org.json.JSONObject();o.put("entry",entry);o.put("name",tr[1]==null?"موسیقی":tr[1]);o.put("selected",("u:"+tr[0]).equals(selected));meta.put(o);
            }catch(Exception ignored){}
        }
        writeZipText(zos,"external_music.json",meta.toString());
    }
    private void restoreBackedUserMusic(java.io.File stage,String metaText) throws Exception{
        if(metaText==null)return;org.json.JSONArray meta=new org.json.JSONArray(metaText);java.util.ArrayList<String[]> restored=new java.util.ArrayList<>();String selectedUri=null;
        java.io.File musicDir=new java.io.File(getFilesDir(),"restored_music");if(!musicDir.exists())musicDir.mkdirs();
        for(int i=0;i<meta.length();i++){
            org.json.JSONObject o=meta.getJSONObject(i);String entry=o.getString("entry");java.io.File src=new java.io.File(stage,entry);if(!src.exists())continue;
            java.io.File dst=new java.io.File(musicDir,"track_"+i+".audio");try(java.io.FileInputStream in=new java.io.FileInputStream(src);java.io.FileOutputStream out=new java.io.FileOutputStream(dst)){byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}
            String uri=android.net.Uri.fromFile(dst).toString();restored.add(new String[]{uri,o.optString("name","موسیقی")});if(o.optBoolean("selected",false))selectedUri=uri;
        }
        if(!restored.isEmpty()){saveUserMusicTracks(restored);SharedPreferences.Editor ed=missionAudioPrefs().edit();if(selectedUri!=null)ed.putString("selected","u:"+selectedUri).putString("uri",selectedUri);else ed.putString("selected","d:0").remove("uri");ed.apply();}
    }
    private void writeFullBackupAsync(final android.net.Uri uri){
        Toast.makeText(this,"در حال ساخت پشتیبان…",Toast.LENGTH_SHORT).show();
        new Thread(()->{
            String error=null;
            try(java.io.OutputStream raw=getContentResolver().openOutputStream(uri,"w");java.util.zip.ZipOutputStream zos=new java.util.zip.ZipOutputStream(new java.io.BufferedOutputStream(raw))){
                if(raw==null)throw new java.io.IOException("output");
                org.json.JSONObject manifest=new org.json.JSONObject();manifest.put("format",1);manifest.put("package",getPackageName());manifest.put("created_jalali",logicalJalaliDateKey());manifest.put("version_name",getPackageManager().getPackageInfo(getPackageName(),0).versionName);
                writeZipText(zos,"manifest.json",manifest.toString());
                writeZipText(zos,"preferences.json",buildPreferencesBackup().toString());
                zipFileTree(zos,getFilesDir(),"files/");
                writeBackedUserMusic(zos);
                java.io.File dbDir=getDatabasePath("_probe_").getParentFile();zipFileTree(zos,dbDir,"databases/");
                zos.finish();
            }catch(Exception e){error=e.getMessage()==null?"خطای ناشناخته":e.getMessage();}
            final String err=error;runOnUiThread(()->Toast.makeText(this,err==null?"پشتیبان کامل ساخته شد":"ساخت پشتیبان ناموفق بود: "+err,Toast.LENGTH_LONG).show());
        }).start();
    }
    private String readZipText(java.io.File zip,String name) throws Exception{
        try(java.util.zip.ZipFile zf=new java.util.zip.ZipFile(zip)){java.util.zip.ZipEntry e=zf.getEntry(name);if(e==null)return null;try(java.io.InputStream in=zf.getInputStream(e);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toString("UTF-8");}}
    }
    private void clearDirectory(java.io.File dir){
        if(dir==null||!dir.exists())return;java.io.File[] fs=dir.listFiles();if(fs==null)return;for(java.io.File f:fs){if(f.isDirectory())clearDirectory(f);try{f.delete();}catch(Exception ignored){}}
    }
    private void copyDirectory(java.io.File src,java.io.File dst) throws Exception{
        if(src==null||!src.exists())return;if(!dst.exists()&&!dst.mkdirs())throw new java.io.IOException("mkdir");
        java.io.File[] fs=src.listFiles();if(fs==null)return;byte[] buf=new byte[32768];
        for(java.io.File f:fs){java.io.File to=new java.io.File(dst,f.getName());if(f.isDirectory())copyDirectory(f,to);else{java.io.File par=to.getParentFile();if(par!=null&&!par.exists())par.mkdirs();try(java.io.FileInputStream in=new java.io.FileInputStream(f);java.io.FileOutputStream out=new java.io.FileOutputStream(to)){int n;while((n=in.read(buf))>0)out.write(buf,0,n);}}}
    }
    private void extractBackupData(java.io.File zip,java.io.File stage) throws Exception{
        String root=stage.getCanonicalPath()+java.io.File.separator;byte[] buf=new byte[32768];
        try(java.util.zip.ZipInputStream zin=new java.util.zip.ZipInputStream(new java.io.BufferedInputStream(new java.io.FileInputStream(zip)))){
            java.util.zip.ZipEntry e;while((e=zin.getNextEntry())!=null){
                String n=e.getName();if(!(n.startsWith("files/")||n.startsWith("databases/")||n.startsWith("external_music/"))){zin.closeEntry();continue;}
                java.io.File out=new java.io.File(stage,n);String canon=out.getCanonicalPath();if(!canon.startsWith(root))throw new java.io.IOException("unsafe backup");
                if(e.isDirectory()){out.mkdirs();}else{java.io.File par=out.getParentFile();if(par!=null&&!par.exists())par.mkdirs();try(java.io.FileOutputStream fos=new java.io.FileOutputStream(out)){int q;while((q=zin.read(buf))>0)fos.write(buf,0,q);}}
                zin.closeEntry();
            }
        }
    }
    private void restoreFullBackupAsync(final android.net.Uri uri){
        stopPresenceRewardLoop(true);
        Toast.makeText(this,"در حال بازیابی…",Toast.LENGTH_SHORT).show();
        new Thread(()->{
            String error=null;
            java.io.File tmp=new java.io.File(getCacheDir(),"legacy_restore_"+System.currentTimeMillis()+".zip");
            java.io.File stage=new java.io.File(getCacheDir(),"legacy_restore_stage_"+System.currentTimeMillis());
            try{
                try(java.io.InputStream in=getContentResolver().openInputStream(uri);java.io.FileOutputStream out=new java.io.FileOutputStream(tmp)){if(in==null)throw new java.io.IOException("input");byte[] b=new byte[32768];int n;while((n=in.read(b))>0)out.write(b,0,n);}
                String manifestText=readZipText(tmp,"manifest.json"),prefsText=readZipText(tmp,"preferences.json"),musicMeta=readZipText(tmp,"external_music.json");if(manifestText==null||prefsText==null)throw new java.io.IOException("فایل پشتیبان معتبر نیست");
                org.json.JSONObject manifest=new org.json.JSONObject(manifestText);if(manifest.optInt("format",-1)!=1||!getPackageName().equals(manifest.optString("package","")))throw new java.io.IOException("این پشتیبان مربوط به Legacy نیست");
                org.json.JSONObject prefsJson=new org.json.JSONObject(prefsText);extractBackupData(tmp,stage);
                cancelMissionAlarm();cancelMissionNotification();stopMissionMusic();stopMissionTimer();
                restorePreferencesBackup(prefsJson);
                java.io.File stagedFiles=new java.io.File(stage,"files");clearDirectory(getFilesDir());copyDirectory(stagedFiles,getFilesDir());
                restoreBackedUserMusic(stage,musicMeta);
                java.io.File dbDir=getDatabasePath("_probe_").getParentFile(),stagedDb=new java.io.File(stage,"databases");if(stagedDb.exists()){clearDirectory(dbDir);copyDirectory(stagedDb,dbDir);}
            }catch(Exception e){error=e.getMessage()==null?"خطای ناشناخته":e.getMessage();}
            try{clearDirectory(stage);stage.delete();tmp.delete();}catch(Exception ignored){}
            final String err=error;runOnUiThread(()->{
                if(err!=null){startPresenceRewardLoop();Toast.makeText(this,"بازیابی ناموفق بود: "+err,Toast.LENGTH_LONG).show();return;}
                progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);dreamPrefs=null;clearDreamThumbCache();loadGameState();
                if(progressPrefs.getBoolean("active",false)){long end=progressPrefs.getLong("active_end",0);if(end>System.currentTimeMillis()){scheduleMissionAlarm(end);MissionNotification.showRunning(this);}else MissionNotification.showFinished(this);}
                startPresenceRewardLoop();showHome();Toast.makeText(this,"پشتیبان با موفقیت بازیابی شد",Toast.LENGTH_LONG).show();
            });
        }).start();
    }
    private void showDayStartPicker(){
        int current=dayStartMinutes();final int[] hour={current/60},minute={current%60};
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final TextView value=tv(String.format(java.util.Locale.US,"%02d : %02d",hour[0],minute[0]),28,THEME_TEXT);value.setGravity(Gravity.CENTER);GradientDrawable vg=bg(0xFFEAF6FF,dp(18));vg.setStroke(Math.max(1,dp(1)),0x7754A9FF);value.setBackground(vg);body.addView(value,new LinearLayout.LayoutParams(-1,dp(64)));
        java.util.function.BiFunction<String,Runnable,TextView> ctl=(label,action)->{TextView b=dialogButton(label,0xFFF7FAFF,0xFFEAF3FF,true);GradientDrawable g=pastelButtonBg(0xFFF7FAFF,0xFFEAF3FF);g.setStroke(Math.max(1,dp(1)),0x6654A9FF);b.setBackground(g);b.setOnClickListener(v->{playViewSound(v);action.run();value.setText(String.format(java.util.Locale.US,"%02d : %02d",hour[0],minute[0]));});return b;};
        LinearLayout hr=new LinearLayout(this);hr.setOrientation(LinearLayout.HORIZONTAL);hr.setGravity(Gravity.CENTER);hr.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);TextView hl=tv("ساعت",13,THEME_MUTED);hl.setGravity(Gravity.CENTER);hr.addView(hl,new LinearLayout.LayoutParams(dp(64),dp(46)));TextView hp=ctl.apply("＋",()->hour[0]=(hour[0]+1)%24);TextView hm=ctl.apply("−",()->hour[0]=(hour[0]+23)%24);hr.addView(hp,new LinearLayout.LayoutParams(0,dp(44),1f));LinearLayout.LayoutParams hmlp=new LinearLayout.LayoutParams(0,dp(44),1f);hmlp.rightMargin=dp(8);hr.addView(hm,hmlp);LinearLayout.LayoutParams hrlp=new LinearLayout.LayoutParams(-1,dp(48));hrlp.topMargin=dp(10);body.addView(hr,hrlp);
        LinearLayout mr=new LinearLayout(this);mr.setOrientation(LinearLayout.HORIZONTAL);mr.setGravity(Gravity.CENTER);mr.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);TextView ml=tv("دقیقه",13,THEME_MUTED);ml.setGravity(Gravity.CENTER);mr.addView(ml,new LinearLayout.LayoutParams(dp(64),dp(46)));TextView mp=ctl.apply("＋",()->minute[0]=(minute[0]+1)%60);TextView mm=ctl.apply("−",()->minute[0]=(minute[0]+59)%60);mr.addView(mp,new LinearLayout.LayoutParams(0,dp(44),1f));LinearLayout.LayoutParams mmlp=new LinearLayout.LayoutParams(0,dp(44),1f);mmlp.rightMargin=dp(8);mr.addView(mm,mmlp);body.addView(mr,new LinearLayout.LayoutParams(-1,dp(48)));
        buildPastelDialog("◷","ساعت شروع روز","",THEME_PRIMARY,body,"ذخیره",THEME_PRIMARY,()->{appSettingsPrefs().edit().putInt("day_start_minutes",hour[0]*60+minute[0]).apply();lastObservedMissionDay=missionDay();applyDailyMissionResets();refreshProgressMissionVisuals();if(isTreeScreen){treeViewStateValid=true;showTreePage();}Toast.makeText(this,"شروع روز: "+formatDayStart(),Toast.LENGTH_SHORT).show();showAppSettings();},"لغو",()->showAppSettings()).show();
    }
    private void showAppSettings(){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);final Dialog[] dlg={null};
        TextView music=settingsRow("موسیقی",isMusicEnabled()?"روشن":"خاموش");
        TextView sfx=settingsRow("افکت صدا",isSfxEnabled()?"روشن":"خاموش");
        TextView notif=settingsRow("نوتیفیکیشن",isNotificationsEnabled()?"روشن":"خاموش");
        TextView combo=settingsRow("مهلت Combo",comboWindowMinutes+" دقیقه");
        TextView dayStart=settingsRow("شروع روز",formatDayStart());
        for(TextView row:new TextView[]{music,sfx,notif,combo,dayStart}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.setMargins(0,dp(4),0,dp(4));body.addView(row,lp);}
        music.setOnClickListener(v->{
            playViewSound(v);
            boolean next=!isMusicEnabled();
            appSettingsPrefs().edit().putBoolean("music_enabled",next).apply();
            if(missionPlayer==null && progressPrefs!=null && progressPrefs.getBoolean("active",false))playSavedMissionMusic();
            setMissionMusicOutput();
            Toast.makeText(this,next?"موسیقی روشن شد":"موسیقی خاموش شد",Toast.LENGTH_SHORT).show();
            dlg[0].dismiss();showAppSettings();
        });
        sfx.setOnClickListener(v->{boolean wasOn=isSfxEnabled();if(wasOn)playSfx(sfxToggleId,.72f);boolean next=!wasOn;appSettingsPrefs().edit().putBoolean("sfx_enabled",next).apply();if(next)playSfx(sfxToggleId,.72f);dlg[0].dismiss();showAppSettings();});
        notif.setOnClickListener(v->{playViewSound(v);boolean on=!isNotificationsEnabled();appSettingsPrefs().edit().putBoolean("notifications_enabled",on).apply();if(on){ensureNotificationPermission();if(progressPrefs!=null&&progressPrefs.getBoolean("active",false))MissionNotification.showRunning(this);}else cancelMissionNotification();dlg[0].dismiss();showAppSettings();});
        combo.setOnClickListener(v->{playViewSound(v);dlg[0].dismiss();showGameSettings();});
        dayStart.setOnClickListener(v->{playViewSound(v);dlg[0].dismiss();showDayStartPicker();});
        dlg[0]=buildPastelDialog("⚙","تنظیمات","",0xFF4E8CFF,body,null,0,null,"بستن",null);dlg[0].show();
    }

    private SharedPreferences legacyTreePrefs(){
        return getSharedPreferences("legacy_tree_dynamic_v1",MODE_PRIVATE);
    }
    private SharedPreferences treeGraphPrefs(){
        return getSharedPreferences("legacy_tree_graph_v2",MODE_PRIVATE);
    }
    private String treeNodePrefix(String id){return "node_"+id+"_";}
    private String treeNodeVal(String id,String field,String def){return treeGraphPrefs().getString(treeNodePrefix(id)+field,def);}
    private void treeNodePut(String id,String field,String value){treeGraphPrefs().edit().putString(treeNodePrefix(id)+field,value).apply();}
    private boolean treeNodeExpanded(String id){return treeGraphPrefs().getBoolean(treeNodePrefix(id)+"expanded",true);}
    private void setTreeNodeExpanded(String id,boolean value){treeGraphPrefs().edit().putBoolean(treeNodePrefix(id)+"expanded",value).apply();}
    private java.util.ArrayList<String> treeNodeIds(){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        String raw=treeGraphPrefs().getString("node_ids","root");
        for(String x:raw.split("\n"))if(x.trim().length()>0&&!out.contains(x.trim()))out.add(x.trim());
        if(!out.contains("root"))out.add(0,"root");
        return out;
    }
    private void saveTreeNodeIds(java.util.ArrayList<String> ids){treeGraphPrefs().edit().putString("node_ids",android.text.TextUtils.join("\n",ids)).apply();}
    private java.util.ArrayList<String> treeChildren(String parent){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String id:treeNodeIds())if(parent.equals(treeNodeVal(id,"parent","")))out.add(id);
        return out;
    }
    private String nextTreeNodeId(){
        SharedPreferences sp=treeGraphPrefs();int n=sp.getInt("next_id",1);sp.edit().putInt("next_id",n+1).apply();return "n"+n;
    }
    private void initTreeNodeDefaults(SharedPreferences.Editor ed,String id,String parent,String name){
        String p=treeNodePrefix(id);
        ed.putString(p+"parent",parent==null?"":parent).putString(p+"name",name).putString(p+"pv","0").putString(p+"gpv","0").putString(p+"count","0")
          .putString(p+"target_pv","0").putString(p+"target_gpv","0").putString(p+"target_count","0").putString(p+"stats_day","").putString(p+"todo","").putString(p+"todo_done","0").putString(p+"actions","").putString(p+"notes","").putBoolean(p+"expanded",true);
    }
    private void copyLegacyTreeFields(SharedPreferences old,String oldPrefix,SharedPreferences.Editor ed,String id){
        String p=treeNodePrefix(id);String[] fields={"name","pv","gpv","count","target_pv","target_gpv","target_count"};String[] defs={"بدون نام","0","0","0","0","0","0"};
        for(int i=0;i<fields.length;i++)ed.putString(p+fields[i],old.getString(oldPrefix+fields[i],defs[i]));
    }
    private void ensureTreeGraphV2(){
        SharedPreferences sp=treeGraphPrefs();if(sp.getBoolean("initialized",false))return;
        SharedPreferences old=legacyTreePrefs();SharedPreferences.Editor ed=sp.edit();java.util.ArrayList<String> ids=new java.util.ArrayList<>();ids.add("root");
        initTreeNodeDefaults(ed,"root","",old.getString("root_name","شهریار"));copyLegacyTreeFields(old,"root_",ed,"root");
        int next=1,direct=old.getInt("direct_count",0);
        for(int b=0;b<direct;b++){
            int depth=Math.max(1,old.getInt("branch_"+b+"_depth",1));String parent="root";
            for(int d=1;d<=depth;d++){
                String id="n"+(next++);ids.add(id);String oldPrefix="b"+b+"_d"+d+"_";String name=old.getString(oldPrefix+"name","بدون نام");
                initTreeNodeDefaults(ed,id,parent,name);copyLegacyTreeFields(old,oldPrefix,ed,id);ed.putBoolean(treeNodePrefix(id)+"expanded",old.getBoolean(oldPrefix+"expanded",true));parent=id;
            }
        }
        ed.putString("node_ids",android.text.TextUtils.join("\n",ids)).putInt("next_id",next).putBoolean("initialized",true).apply();
    }
    private SharedPreferences treeHistoryPrefs(){return getSharedPreferences("legacy_tree_history_v1",MODE_PRIVATE);}
    private void migrateTreeHistoryDateKeys(){
        SharedPreferences hp=treeHistoryPrefs();String rawDates=hp.getString("dates","");if(rawDates.length()==0)return;java.util.LinkedHashSet<String> normalized=new java.util.LinkedHashSet<>();SharedPreferences.Editor ed=hp.edit();boolean changed=false;
        for(String d:rawDates.split("\n")){d=d.trim();if(d.length()==0)continue;String n=normalizeDateStorageKey(d);normalized.add(n);if(!n.equals(d)){String old=hp.getString("snapshot_"+d,"");if(old.length()>0&&hp.getString("snapshot_"+n,"").length()==0)ed.putString("snapshot_"+n,old);ed.remove("snapshot_"+d);changed=true;}}
        if(changed)ed.putString("dates",android.text.TextUtils.join("\n",normalized)).apply();
    }
    private String treeDateKey(){return logicalJalaliDateKey();}
    private String treeEnc(String s){try{return android.util.Base64.encodeToString((s==null?"":s).getBytes("UTF-8"),android.util.Base64.NO_WRAP|android.util.Base64.URL_SAFE);}catch(Exception e){return "";}}
    private String treeDec(String s){try{return new String(android.util.Base64.decode(s,android.util.Base64.NO_WRAP|android.util.Base64.URL_SAFE),"UTF-8");}catch(Exception e){return "";}}
    private void saveTreeSnapshotToday(){
        if(treeHistoryViewDate!=null)return;
        migrateTreeHistoryDateKeys();ensureTreeGraphV2();String date=treeDateKey();StringBuilder out=new StringBuilder();
        String[] fields={"parent","name","pv","gpv","count","target_pv","target_gpv","target_count","stats_day","todo","todo_done","todos","actions","notes"};
        for(String id:treeNodeIds()){
            if(out.length()>0)out.append("\n");out.append(treeEnc(id));
            for(String f:fields)out.append('|').append(treeEnc(treeNodeVal(id,f,"")));
        }
        SharedPreferences hp=treeHistoryPrefs();java.util.LinkedHashSet<String> dates=new java.util.LinkedHashSet<>();
        for(String d:hp.getString("dates","").split("\n"))if(d.trim().length()>0)dates.add(d.trim());dates.add(date);
        hp.edit().putString("snapshot_"+date,out.toString()).putString("dates",android.text.TextUtils.join("\n",dates)).apply();
    }
    private boolean loadTreeHistory(String date){
        date=normalizeDateStorageKey(date);treeHistoryData.clear();String raw=treeHistoryPrefs().getString("snapshot_"+date,"");if(raw.length()==0)return false;
        String[] fieldsNewest2={"parent","name","pv","gpv","count","target_pv","target_gpv","target_count","stats_day","todo","todo_done","todos","actions","notes"};
        String[] fieldsNewest={"parent","name","pv","gpv","count","target_pv","target_gpv","target_count","stats_day","todo","todo_done","todos","actions"};
        String[] fieldsNew={"parent","name","pv","gpv","count","target_pv","target_gpv","target_count","todo","todo_done","todos","actions"};
        String[] fieldsOld={"parent","name","pv","gpv","count","target_pv","target_gpv","target_count","todo","todo_done","actions"};
        for(String line:raw.split("\n")){
            String[] a=line.split("\\|",-1);if(a.length<2)continue;String id=treeDec(a[0]);if(id.length()==0)continue;
            String[] use=a.length>=15?fieldsNewest2:(a.length>=14?fieldsNewest:(a.length>=13?fieldsNew:fieldsOld));
            java.util.HashMap<String,String> m=new java.util.HashMap<>();for(int i=0;i<use.length&&i+1<a.length;i++)m.put(use[i],treeDec(a[i+1]));treeHistoryData.put(id,m);
        }
        if(!treeHistoryData.containsKey("root"))return false;treeHistoryViewDate=date;return true;
    }
    private void leaveTreeHistory(){treeHistoryViewDate=null;treeHistoryData.clear();}
    private String treeDisplayVal(String id,String field,String def){
        if(treeHistoryViewDate!=null){java.util.HashMap<String,String> m=treeHistoryData.get(id);if(m!=null&&m.containsKey(field))return m.get(field);}return treeNodeVal(id,field,def);
    }
    private java.util.ArrayList<String> treeDisplayIds(){
        if(treeHistoryViewDate==null)return treeNodeIds();return new java.util.ArrayList<>(treeHistoryData.keySet());
    }
    private java.util.ArrayList<String> treeDisplayChildren(String parent){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();for(String id:treeDisplayIds())if(parent.equals(treeDisplayVal(id,"parent","")))out.add(id);return out;
    }
    private boolean treeDisplayExpanded(String id){return treeHistoryViewDate!=null||treeNodeExpanded(id);}
    private String normalizeTreeNumber(String raw){
        if(raw==null)return "0";String x=raw.trim().replace(",","").toUpperCase(java.util.Locale.ROOT);double mult=1d;
        try{if(x.endsWith("K")){mult=1000d;x=x.substring(0,x.length()-1);}else if(x.endsWith("M")){mult=1000000d;x=x.substring(0,x.length()-1);}double v=Double.parseDouble(x);if(v<0)v=0;return String.valueOf((long)Math.round(v*mult));}catch(Exception ignored){}
        String digits=x.replaceAll("[^0-9]","");return digits.length()==0?"0":digits;
    }
    private String formatTreeNumber(String raw){try{return String.format(java.util.Locale.US,"%,d",Long.parseLong(normalizeTreeNumber(raw)));}catch(Exception e){return "0";}}
    private EditText treeNumberField(String hint,String value){
        EditText e=(EditText)treeField(hint,normalizeTreeNumber(value));e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);e.setSelectAllOnFocus(false);return e;
    }
    private TextView treeField(String hint,String value){
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(value);e.setTextSize(14);e.setTextColor(0xFF17345D);e.setHintTextColor(0xFF8B98AA);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(12),0,dp(12),0);
        GradientDrawable g=bg(0xFFF6F9FF,dp(12));g.setStroke(Math.max(1,dp(1)),0x334D8DFF);e.setBackground(g);return e;
    }
    private TextView treeStatChip(String label,String value){
        TextView t=tv(value+"\n"+label,12,0xFF17345D);t.setGravity(Gravity.CENTER);t.setLineSpacing(0,1.02f);GradientDrawable g=bg(0xFFF7FAFF,dp(13));g.setStroke(Math.max(1,Math.round(dp(.7f))),0x224E8CFF);t.setBackground(g);t.setPadding(dp(6),dp(8),dp(6),dp(8));return t;
    }
    private class TreeIconView extends View{
        private final Paint ip=new Paint(Paint.ANTI_ALIAS_FLAG);private final int type;private boolean enabled=true,altState=false;
        TreeIconView(android.content.Context c,int t){super(c);type=t;setLayerType(View.LAYER_TYPE_SOFTWARE,null);setClickable(true);}
        void setIconEnabled(boolean e){enabled=e;setAlpha(e?1f:.35f);setEnabled(e);invalidate();}
        void setAltState(boolean v){altState=v;invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f,r=Math.min(w,h)*.39f;
            ip.setStyle(Paint.Style.FILL);ip.setColor(enabled?0xEE247FD8:0x884C6E8F);ip.setShadowLayer(dp(3.4f),0,0,0x6630A7FF);c.drawCircle(cx,cy,r,ip);ip.clearShadowLayer();
            ip.setStyle(Paint.Style.STROKE);ip.setStrokeCap(Paint.Cap.ROUND);ip.setStrokeJoin(Paint.Join.ROUND);ip.setStrokeWidth(Math.max(dp(1.8f),r*.12f));ip.setColor(Color.WHITE);
            if(type==0){c.drawLine(cx-r*.42f,cy,cx+r*.42f,cy,ip);c.drawLine(cx,cy-r*.42f,cx,cy+r*.42f,ip);} // add
            else if(type==1){ // todo checklist
                for(int i=-1;i<=1;i++){float yy=cy+i*r*.32f;c.drawLine(cx-r*.52f,yy,cx-r*.34f,yy+r*.12f,ip);c.drawLine(cx-r*.34f,yy+r*.12f,cx-r*.12f,yy-r*.13f,ip);c.drawLine(cx+r*.02f,yy,cx+r*.52f,yy,ip);}
            }else if(type==2){ // trash
                RectF b=new RectF(cx-r*.34f,cy-r*.18f,cx+r*.34f,cy+r*.48f);c.drawRoundRect(b,r*.08f,r*.08f,ip);c.drawLine(cx-r*.44f,cy-r*.34f,cx+r*.44f,cy-r*.34f,ip);c.drawLine(cx-r*.18f,cy-r*.48f,cx+r*.18f,cy-r*.48f,ip);c.drawLine(cx-r*.12f,cy-r*.48f,cx-r*.06f,cy-r*.64f,ip);c.drawLine(cx+r*.12f,cy-r*.48f,cx+r*.06f,cy-r*.64f,ip);
            }else if(type==3){ // search
                c.drawCircle(cx-r*.13f,cy-r*.12f,r*.34f,ip);c.drawLine(cx+r*.14f,cy+r*.14f,cx+r*.52f,cy+r*.52f,ip);
            }else if(type==4){ // history clock
                c.drawCircle(cx,cy,r*.52f,ip);c.drawLine(cx,cy,cx,cy-r*.31f,ip);c.drawLine(cx,cy,cx+r*.26f,cy+r*.12f,ip);c.drawArc(new RectF(cx-r*.72f,cy-r*.72f,cx+r*.72f,cy+r*.72f),205,70,false,ip);
            }else if(type==5){ // actions / activity log
                RectF card=new RectF(cx-r*.42f,cy-r*.50f,cx+r*.42f,cy+r*.48f);c.drawRoundRect(card,r*.08f,r*.08f,ip);
                c.drawLine(cx-r*.22f,cy-r*.18f,cx+r*.22f,cy-r*.18f,ip);c.drawLine(cx-r*.22f,cy+r*.04f,cx+r*.12f,cy+r*.04f,ip);
                c.drawLine(cx-r*.22f,cy+r*.26f,cx+r*.04f,cy+r*.26f,ip);c.drawLine(cx+r*.10f,cy+r*.25f,cx+r*.34f,cy+.02f*r,ip);
            }else if(type==6){ // expand / collapse whole tree
                float top=cy-r*.38f,bottom=cy+r*.33f;c.drawLine(cx,bottom,cx,cy-r*.02f,ip);c.drawLine(cx,cy-r*.02f,cx-r*.38f,top,ip);c.drawLine(cx,cy-r*.02f,cx+r*.38f,top,ip);
                c.drawCircle(cx,bottom,r*.12f,ip);c.drawCircle(cx-r*.38f,top,r*.12f,ip);c.drawCircle(cx+r*.38f,top,r*.12f,ip);
                if(altState)c.drawLine(cx-r*.18f,cy+r*.02f,cx+r*.18f,cy+r*.02f,ip);
                else{c.drawLine(cx-r*.18f,cy+r*.02f,cx+r*.18f,cy+r*.02f,ip);c.drawLine(cx,cy-r*.16f,cx,cy+r*.20f,ip);}
            }else if(type==7){ // note
                RectF paper=new RectF(cx-r*.43f,cy-r*.52f,cx+r*.36f,cy+r*.48f);c.drawRoundRect(paper,r*.07f,r*.07f,ip);
                c.drawLine(cx-r*.22f,cy-r*.22f,cx+r*.16f,cy-r*.22f,ip);c.drawLine(cx-r*.22f,cy,cx+r*.16f,cy,ip);c.drawLine(cx-r*.22f,cy+r*.22f,cx+r*.05f,cy+r*.22f,ip);
                c.drawLine(cx+r*.04f,cy+r*.42f,cx+r*.48f,cy-r*.02f,ip);c.drawLine(cx+r*.32f,cy-r*.18f,cx+r*.48f,cy-r*.02f,ip);
            }else if(type==8){ // quick random completion of incomplete tree stats
                // Three small member dots plus a pencil: same stroke language as the tree toolbar.
                c.drawCircle(cx-r*.34f,cy-r*.24f,r*.11f,ip);c.drawCircle(cx+r*.02f,cy-r*.24f,r*.11f,ip);c.drawCircle(cx-r*.16f,cy+r*.10f,r*.11f,ip);
                c.drawLine(cx-r*.43f,cy+r*.38f,cx+r*.33f,cy-r*.38f,ip);c.drawLine(cx+r*.22f,cy-r*.49f,cx+r*.43f,cy-r*.28f,ip);
                c.drawLine(cx-r*.45f,cy+r*.40f,cx-r*.31f,cy+r*.25f,ip);
            }
        }
    }
    private TreeIconView treeIcon(int type){return new TreeIconView(this,type);}
    private java.util.ArrayList<String[]> treeTodoItems(String id){
        java.util.ArrayList<String[]> out=new java.util.ArrayList<>();
        String raw=treeNodeVal(id,"todos","");
        for(String line:raw.split("\n")){
            if(line.trim().length()==0)continue;
            String[] a=line.split("\\|",3);if(a.length<3)continue;
            out.add(new String[]{a[0],treeDec(a[1]),"1".equals(a[2])?"1":"0"});
        }
        // One-time compatibility with the old single To Do field.
        if(out.isEmpty()){
            String old=treeNodeVal(id,"todo","").trim();
            if(old.length()>0)out.add(new String[]{"legacy",old,"1".equals(treeNodeVal(id,"todo_done","0"))?"1":"0"});
        }
        return out;
    }
    private java.util.ArrayList<String[]> treeDisplayTodoItems(String id){
        if(treeHistoryViewDate==null)return treeTodoItems(id);
        java.util.ArrayList<String[]> out=new java.util.ArrayList<>();String raw=treeDisplayVal(id,"todos","");
        for(String line:raw.split("\n")){if(line.trim().length()==0)continue;String[] a=line.split("\\|",3);if(a.length<3)continue;out.add(new String[]{a[0],treeDec(a[1]),"1".equals(a[2])?"1":"0"});}
        if(out.isEmpty()){
            String old=treeDisplayVal(id,"todo","").trim();if(old.length()>0)out.add(new String[]{"legacy",old,"1".equals(treeDisplayVal(id,"todo_done","0"))?"1":"0"});
        }
        return out;
    }
    private void saveTreeTodoItems(String id,java.util.ArrayList<String[]> items){
        java.util.ArrayList<String> lines=new java.util.ArrayList<>();
        for(String[] a:items)lines.add(a[0]+"|"+treeEnc(a[1])+"|"+("1".equals(a[2])?"1":"0"));
        treeGraphPrefs().edit().putString(treeNodePrefix(id)+"todos",android.text.TextUtils.join("\n",lines)).remove(treeNodePrefix(id)+"todo").remove(treeNodePrefix(id)+"todo_done").apply();
    }
    private long treeTimestamp(String id){try{return Long.parseLong(id);}catch(Exception e){return 0L;}}
    private void sortTreeTodoItems(java.util.ArrayList<String[]> items){
        java.util.Collections.sort(items,(a,b)->{
            boolean ad="1".equals(a[2]),bd="1".equals(b[2]);
            if(ad!=bd)return ad?1:-1;
            return Long.compare(treeTimestamp(b[0]),treeTimestamp(a[0]));
        });
    }
    private void deleteTreeTodoItem(String id,String itemId){
        java.util.ArrayList<String[]> items=treeTodoItems(id);java.util.Iterator<String[]> it=items.iterator();while(it.hasNext())if(it.next()[0].equals(itemId))it.remove();sortTreeTodoItems(items);saveTreeTodoItems(id,items);saveTreeSnapshotToday();
    }
    private void setTreeTodoChecked(String id,String itemId,boolean checked){java.util.ArrayList<String[]> items=treeTodoItems(id);for(String[] x:items)if(x[0].equals(itemId)){x[2]=checked?"1":"0";break;}sortTreeTodoItems(items);saveTreeTodoItems(id,items);saveTreeSnapshotToday();}
    private void addTreeTodoItem(String id,String text){if(id==null||text==null||text.trim().length()==0)return;java.util.ArrayList<String[]> items=treeTodoItems(id);items.add(0,new String[]{String.valueOf(System.currentTimeMillis()),text.trim(),"0"});sortTreeTodoItems(items);saveTreeTodoItems(id,items);saveTreeSnapshotToday();}
    private void renameTreeTodoItem(String id,String itemId,String text){if(text==null||text.trim().length()==0)return;java.util.ArrayList<String[]> items=treeTodoItems(id);for(String[] x:items)if(x[0].equals(itemId)){x[1]=text.trim();break;}saveTreeTodoItems(id,items);saveTreeSnapshotToday();}
    private void showTreeTodo(final String id){
        if(treeHistoryViewDate!=null)return;
        showTodoPanelForNode(id,false,false);
    }
    private java.util.ArrayList<String[]> treeNoteItems(String id){
        java.util.ArrayList<String[]> out=new java.util.ArrayList<>();String raw=treeNodeVal(id,"notes","");
        for(String line:raw.split("\n")){if(line.trim().length()==0)continue;String[] a=line.split("\\|",5);if(a.length<5)continue;String text=treeDec(a[1]);String done="1".equals(a[2])?"1":"0",checkable="1".equals(a[3])?"1":"0";int fs=14;try{fs=Math.max(10,Math.min(24,Integer.parseInt(a[4])));}catch(Exception ignored){}out.add(new String[]{a[0],text,done,checkable,String.valueOf(fs)});}
        return out;
    }
    private void saveTreeNoteItems(String id,java.util.ArrayList<String[]> items){java.util.ArrayList<String> lines=new java.util.ArrayList<>();for(String[] a:items){if(a==null||a.length<5||a[1].trim().length()==0)continue;lines.add(a[0]+"|"+treeEnc(a[1])+"|"+("1".equals(a[2])?"1":"0")+"|"+("1".equals(a[3])?"1":"0")+"|"+a[4]);}treeNodePut(id,"notes",android.text.TextUtils.join("\n",lines));}
    private void deleteTreeNote(String id,String noteId){java.util.ArrayList<String[]> items=treeNoteItems(id);java.util.Iterator<String[]> it=items.iterator();while(it.hasNext())if(it.next()[0].equals(noteId))it.remove();saveTreeNoteItems(id,items);saveTreeSnapshotToday();}
    private void setTreeNoteChecked(String id,String noteId,boolean checked){java.util.ArrayList<String[]> items=treeNoteItems(id);for(String[] a:items)if(a[0].equals(noteId)){a[2]=checked?"1":"0";break;}saveTreeNoteItems(id,items);saveTreeSnapshotToday();}
    private void showTreeNoteEditor(final String id,final String noteId,final String initialText,final boolean initialCheckable,final boolean initialDone,final int initialFont){
        if(treeHistoryViewDate!=null)return;LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        EditText input=new EditText(this);input.setText(initialText==null?"":initialText);input.setTextSize(initialFont);input.setTextColor(0xFF17345D);input.setGravity(Gravity.RIGHT|Gravity.TOP);input.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);input.setTextDirection(View.TEXT_DIRECTION_RTL);input.setMinLines(3);input.setMaxLines(8);input.setPadding(dp(12),dp(10),dp(12),dp(10));GradientDrawable ig=bg(0xFFF7FAFF,dp(14));ig.setStroke(Math.max(1,dp(1)),0x334D8DFF);input.setBackground(ig);body.addView(input,new LinearLayout.LayoutParams(-1,dp(118)));
        final int[] font={Math.max(10,Math.min(24,initialFont))};LinearLayout fontRow=new LinearLayout(this);fontRow.setOrientation(LinearLayout.HORIZONTAL);fontRow.setGravity(Gravity.CENTER);fontRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout.LayoutParams frp=new LinearLayout.LayoutParams(-1,dp(46));frp.topMargin=dp(8);body.addView(fontRow,frp);
        TextView plus=dialogButton("A+",0xFFF8FAFF,0xFFEFF3FB,true),size=tv(font[0]+"",13,0xFF17345D),minus=dialogButton("A−",0xFFF8FAFF,0xFFEFF3FB,true);size.setGravity(Gravity.CENTER);fontRow.addView(plus,new LinearLayout.LayoutParams(dp(64),dp(42)));fontRow.addView(size,new LinearLayout.LayoutParams(dp(64),dp(42)));fontRow.addView(minus,new LinearLayout.LayoutParams(dp(64),dp(42)));
        final boolean[] checkable={initialCheckable},done={initialDone};TextView mode=settingsRow("نوع خط",checkable[0]?"چک‌لیست":"متن ساده");LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(48));mp.topMargin=dp(6);body.addView(mode,mp);TextView checked=settingsRow("وضعیت تیک",done[0]?"تیک‌خورده":"بدون تیک");LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(48));cp.topMargin=dp(5);body.addView(checked,cp);checked.setVisibility(checkable[0]?View.VISIBLE:View.GONE);
        plus.setOnClickListener(v->{playUiClick();font[0]=Math.min(24,font[0]+1);input.setTextSize(font[0]);size.setText(String.valueOf(font[0]));});minus.setOnClickListener(v->{playUiClick();font[0]=Math.max(10,font[0]-1);input.setTextSize(font[0]);size.setText(String.valueOf(font[0]));});
        mode.setOnClickListener(v->{playSfx(sfxToggleId,.55f);checkable[0]=!checkable[0];if(!checkable[0])done[0]=false;mode.setText("نوع خط\n"+(checkable[0]?"چک‌لیست":"متن ساده"));checked.setVisibility(checkable[0]?View.VISIBLE:View.GONE);checked.setText("وضعیت تیک\n"+(done[0]?"تیک‌خورده":"بدون تیک"));});checked.setOnClickListener(v->{playSfx(sfxToggleId,.55f);done[0]=!done[0];checked.setText("وضعیت تیک\n"+(done[0]?"تیک‌خورده":"بدون تیک"));});
        Dialog d=buildPastelDialog("✎",noteId==null?"یادداشت جدید":"ویرایش یادداشت",treeNodeVal(id,"name",""),0xFF4D8EFF,body,"ذخیره",0xFF2F8DFF,()->{String text=input.getText().toString().trim();if(text.length()==0)return;java.util.ArrayList<String[]> items=treeNoteItems(id);String nid=noteId==null?String.valueOf(System.currentTimeMillis()):noteId;boolean found=false;for(String[] a:items)if(a[0].equals(nid)){a[1]=text;a[2]=done[0]?"1":"0";a[3]=checkable[0]?"1":"0";a[4]=String.valueOf(font[0]);found=true;break;}if(!found)items.add(0,new String[]{nid,text,done[0]?"1":"0",checkable[0]?"1":"0",String.valueOf(font[0])});saveTreeNoteItems(id,items);saveTreeSnapshotToday();showTreeNotes(id);},"لغو",null);d.show();
    }
    private void showTreeNotes(final String id){
        if(treeHistoryViewDate!=null)return;LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);final Dialog[] ref={null};java.util.ArrayList<String[]> items=treeNoteItems(id);
        if(items.isEmpty()){TextView none=tv("هنوز یادداشتی ثبت نشده",12,0xFF8794A7);none.setGravity(Gravity.CENTER);list.addView(none,new LinearLayout.LayoutParams(-1,dp(54)));}
        for(String[] a:items){final String nid=a[0],text=a[1];final boolean done="1".equals(a[2]),checkable="1".equals(a[3]);int fs=14;try{fs=Integer.parseInt(a[4]);}catch(Exception ignored){}final int font=fs;
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setPadding(dp(5),dp(3),dp(3),dp(3));GradientDrawable rg=bg(done?0xFFF1F4F7:0xFFF7FAFF,dp(12));rg.setStroke(Math.max(1,dp(1)),0x224D8DFF);row.setBackground(rg);
            View textView;if(checkable){CheckBox cb=new CheckBox(this);cb.setText(text);cb.setChecked(done);cb.setTextSize(font);cb.setTextColor(done?0xFF8792A4:0xFF17345D);cb.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);cb.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);cb.setTextDirection(View.TEXT_DIRECTION_RTL);try{cb.setButtonTintList(ColorStateList.valueOf(0xFF2F8DFF));}catch(Exception ignored){}if(done)cb.setPaintFlags(cb.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);cb.setOnCheckedChangeListener((b,on)->{setTreeNoteChecked(id,nid,on);b.setTextColor(on?0xFF8792A4:0xFF17345D);if(on)b.setPaintFlags(b.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);else b.setPaintFlags(b.getPaintFlags()&~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);});textView=cb;}else{TextView t=tv(text,font,0xFF17345D);t.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);t.setTextDirection(View.TEXT_DIRECTION_RTL);t.setMaxLines(5);textView=t;}
            row.addView(textView,new LinearLayout.LayoutParams(0,-1,1f));TextView edit=tv("✎",17,0xFF2477E8);edit.setGravity(Gravity.CENTER);TreeIconView del=treeIcon(2);row.addView(edit,new LinearLayout.LayoutParams(dp(38),dp(48)));row.addView(del,new LinearLayout.LayoutParams(dp(38),dp(38)));edit.setOnClickListener(v->{playUiClick();if(ref[0]!=null)ref[0].dismiss();showTreeNoteEditor(id,nid,text,checkable,done,font);});del.setOnClickListener(v->{playSfx(sfxFailId,.55f);deleteTreeNote(id,nid);if(ref[0]!=null)ref[0].dismiss();showTreeNotes(id);});LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,Math.max(dp(54),dp(30)+dp(font*2)));rp.bottomMargin=dp(6);list.addView(row,rp);
        }
        ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));outer.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(340),getResources().getDisplayMetrics().heightPixels/2)));TextView add=dialogButton("+ یادداشت",0xFF2FA8FF,0xFF7B61FF,false);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(48));alp.topMargin=dp(9);outer.addView(add,alp);add.setOnClickListener(v->{playSfx(sfxStartId,.65f);if(ref[0]!=null)ref[0].dismiss();showTreeNoteEditor(id,null,"",false,false,14);});ref[0]=buildPastelDialog("✎","یادداشت‌ها",treeNodeVal(id,"name",""),0xFF4D8EFF,outer,null,0,null,"بستن",null);ref[0].show();ref[0].setOnDismissListener(x->saveTreeSnapshotToday());
    }

    private final String[] treeActionChoices={"ارتباط سازی","پیش مشاوره","دعوت","معرفی کار","فالوآپ","ثبت سفارش اولیه","معرفی محصول","ثبت فروش"};
    private java.util.ArrayList<String[]> treeActionItems(String id){
        java.util.ArrayList<String[]> out=new java.util.ArrayList<>();String raw=treeNodeVal(id,"actions","");
        for(String line:raw.split("\n")){
            if(line.trim().length()==0)continue;String[] a=line.split("\\|",4);
            if(a.length>=4)out.add(new String[]{a[0],treeDec(a[1]),treeDec(a[2]),treeDec(a[3])});
            else if(a.length==3)out.add(new String[]{a[0],treeNodeVal(id,"name",""),treeDec(a[1]),treeDec(a[2])});
        }return out;
    }
    private void saveTreeActionItems(String id,java.util.ArrayList<String[]> items){
        java.util.ArrayList<String> lines=new java.util.ArrayList<>();for(String[] a:items)lines.add(a[0]+"|"+treeEnc(a[1])+"|"+treeEnc(a[2])+"|"+treeEnc(a[3]));treeNodePut(id,"actions",android.text.TextUtils.join("\n",lines));
    }
    private void sortTreeActionsNewest(java.util.ArrayList<String[]> items){java.util.Collections.sort(items,(a,b)->Long.compare(treeTimestamp(b[0]),treeTimestamp(a[0])));}
    private TextView treeSelectField(String hint,String value){
        TextView v=tv((value==null||value.trim().length()==0?hint:value)+"   ⌄",14,value==null||value.trim().length()==0?0xFF8794A7:0xFF17345D);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(dp(12),0,dp(12),0);GradientDrawable g=bg(0xFFF6F9FF,dp(12));g.setStroke(Math.max(1,dp(1)),0x334D8DFF);v.setBackground(g);v.setClickable(true);return v;
    }
    private void showTreeActionChoice(String title,String current,java.util.function.Consumer<String> choose){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);final Dialog[] ref={null};
        for(String opt:treeActionChoices){final String item=opt;TextView row=settingsRow(item,item.equals(current)?"✓":"");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.bottomMargin=dp(5);body.addView(row,lp);row.setOnClickListener(v->{playUiClick();choose.accept(item);if(ref[0]!=null)ref[0].dismiss();});}
        ref[0]=buildPastelDialog("⌄",title,"انتخاب کنید",0xFF4D8EFF,body,null,0,null,"بستن",null);ref[0].show();
    }
    private void showTreeActionEditor(final String id,final String actionId,final String targetText,final String doneText,final String nextText){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final EditText target=(EditText)treeField("نام فرد",targetText);body.addView(target,new LinearLayout.LayoutParams(-1,dp(50)));
        final String[] selectedDone={doneText==null?"":doneText},selectedNext={nextText==null?"":nextText};
        final TextView done=treeSelectField("انجام‌شده",selectedDone[0]),next=treeSelectField("اقدام بعدی",selectedNext[0]);
        LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,dp(50));dp1.topMargin=dp(8);body.addView(done,dp1);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(50));np.topMargin=dp(8);body.addView(next,np);
        done.setOnClickListener(v->showTreeActionChoice("انجام‌شده",selectedDone[0],choice->{selectedDone[0]=choice;done.setText(choice+"   ⌄");done.setTextColor(0xFF17345D);}));
        next.setOnClickListener(v->showTreeActionChoice("اقدام بعدی",selectedNext[0],choice->{selectedNext[0]=choice;next.setText(choice+"   ⌄");next.setTextColor(0xFF17345D);}));
        Dialog d=buildPastelDialog("✓","ثبت اقدام",treeNodeVal(id,"name",""),0xFF4D8EFF,body,"ذخیره",0xFF2F8DFF,()->{
            String targetName=target.getText().toString().trim();if(targetName.length()==0)targetName=treeNodeVal(id,"name","");
            java.util.ArrayList<String[]> items=treeActionItems(id);String aid=actionId==null?String.valueOf(System.currentTimeMillis()):actionId;boolean updated=false;
            for(String[] a:items)if(a[0].equals(aid)){a[1]=targetName;a[2]=selectedDone[0];a[3]=selectedNext[0];updated=true;break;}
            if(!updated)items.add(new String[]{aid,targetName,selectedDone[0],selectedNext[0]});saveTreeActionItems(id,items);saveTreeSnapshotToday();showTreeActions(id);
        },"لغو",null);d.show();
    }
    private void deleteTreeAction(String id,String actionId){java.util.ArrayList<String[]> items=treeActionItems(id);java.util.Iterator<String[]> it=items.iterator();while(it.hasNext())if(it.next()[0].equals(actionId))it.remove();saveTreeActionItems(id,items);saveTreeSnapshotToday();}
    private void showTreeActions(final String id){
        if(treeHistoryViewDate!=null)return;LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);java.util.ArrayList<String[]> items=treeActionItems(id);sortTreeActionsNewest(items);String person=treeNodeVal(id,"name","");final Dialog[] ref={null};
        if(items.isEmpty()){TextView none=tv("هنوز اقدامی ثبت نشده",12,0xFF8190A8);none.setGravity(Gravity.CENTER);list.addView(none,new LinearLayout.LayoutParams(-1,dp(54)));}
        for(String[] a:items){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setPadding(dp(8),0,dp(6),0);GradientDrawable rg=bg(0xFFF7FAFF,dp(12));rg.setStroke(Math.max(1,dp(1)),0x224D8DFF);row.setBackground(rg);
            String txt=(a[1].length()==0?person:a[1])+"   •   "+(a[2].length()==0?"—":a[2])+"   •   "+(a[3].length()==0?"—":a[3]);TextView label=tv(txt,11,0xFF17345D);label.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);enableAutoSize(label,8,11);row.addView(label,new LinearLayout.LayoutParams(0,dp(48),1f));
            TextView edit=tv("✎",16,0xFF2477E8),del=tv("×",19,0xFFD84A55);edit.setGravity(Gravity.CENTER);del.setGravity(Gravity.CENTER);row.addView(edit,new LinearLayout.LayoutParams(dp(40),dp(48)));row.addView(del,new LinearLayout.LayoutParams(dp(40),dp(48)));
            final String aid=a[0],target=a[1],done=a[2],next=a[3];edit.setOnClickListener(v->{playUiClick();if(ref[0]!=null)ref[0].dismiss();showTreeActionEditor(id,aid,target,done,next);});del.setOnClickListener(v->{playSfx(sfxFailId,.6f);deleteTreeAction(id,aid);if(ref[0]!=null)ref[0].dismiss();showTreeActions(id);});
            LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(50));rlp.bottomMargin=dp(6);list.addView(row,rlp);
        }
        ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));outer.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(330),getResources().getDisplayMetrics().heightPixels/2)));
        TextView add=dialogButton("ثبت اقدام",0xFF2FA8FF,0xFF7B61FF,false);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(48));alp.topMargin=dp(10);outer.addView(add,alp);add.setOnClickListener(v->{playSfx(sfxStartId,.7f);if(ref[0]!=null)ref[0].dismiss();showTreeActionEditor(id,null,"","","");});
        ref[0]=buildPastelDialog("✓","اقدامات",person,0xFF4D8EFF,outer,null,0,null,"بستن",null);ref[0].show();
    }
    private void collectTreeSubtree(String id,java.util.LinkedHashSet<String> out){out.add(id);for(String c:treeChildren(id))collectTreeSubtree(c,out);}
    private void deleteTreeNode(final String id){
        if("root".equals(id)||treeHistoryViewDate!=null)return;
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView note=tv("این فرد و تمام زیرشاخه‌های او حذف می‌شوند.",13,0xFF65748D);note.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(note,new LinearLayout.LayoutParams(-1,dp(48)));
        Dialog d=buildPastelDialog("⌫","حذف فرد",treeNodeVal(id,"name",""),0xFFFF6078,body,"حذف",0xFFFF5268,()->{
            java.util.LinkedHashSet<String> rm=new java.util.LinkedHashSet<>();collectTreeSubtree(id,rm);java.util.ArrayList<String> ids=treeNodeIds();ids.removeAll(rm);SharedPreferences.Editor ed=treeGraphPrefs().edit();String[] fs={"parent","name","pv","gpv","count","target_pv","target_gpv","target_count","stats_day","todo","todo_done","todos","actions","notes"};
            for(String n:rm){for(String f:fs)ed.remove(treeNodePrefix(n)+f);ed.remove(treeNodePrefix(n)+"expanded");}ed.apply();saveTreeNodeIds(ids);saveTreeSnapshotToday();treeAnimateNextLayout=true;showTreePage();
        },"لغو",null);d.show();
    }
    private void showTreeMemberCard(final String id){
        String name=treeDisplayVal(id,"name",id.equals("root")?"شهریار":"بدون نام"),pv=treeDisplayVal(id,"pv","0"),gpv=treeDisplayVal(id,"gpv","0"),count=treeDisplayVal(id,"count","0");
        String tpv=treeDisplayVal(id,"target_pv","0"),tgpv=treeDisplayVal(id,"target_gpv","0"),tcount=treeDisplayVal(id,"target_count","0");
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row1=new LinearLayout(this);row1.setOrientation(LinearLayout.HORIZONTAL);LinearLayout row2=new LinearLayout(this);row2.setOrientation(LinearLayout.HORIZONTAL);
        String[][] a={{"PV",formatTreeNumber(pv)},{"GPV",formatTreeNumber(gpv)},{"تعداد",formatTreeNumber(count)}}, b={{"هدف PV",formatTreeNumber(tpv)},{"هدف GPV",formatTreeNumber(tgpv)},{"هدف تعداد",formatTreeNumber(tcount)}};
        for(String[] x:a){TextView c=treeStatChip(x[0],x[1]);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(58),1f);lp.setMargins(dp(3),0,dp(3),0);row1.addView(c,lp);} 
        for(String[] x:b){TextView c=treeStatChip(x[0],x[1]);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(58),1f);lp.setMargins(dp(3),dp(8),dp(3),0);row2.addView(c,lp);} 
        body.addView(row1,new LinearLayout.LayoutParams(-1,-2));body.addView(row2,new LinearLayout.LayoutParams(-1,-2));
        java.util.ArrayList<String[]> todoItems=treeDisplayTodoItems(id);if(!todoItems.isEmpty()){
            LinearLayout todoBox=new LinearLayout(this);todoBox.setOrientation(LinearLayout.VERTICAL);todoBox.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            int shown=0;for(String[] ti:todoItems){if(shown++>=3)break;boolean tdDone="1".equals(ti[2]);TextView td=tv((tdDone?"☑  ":"☐  ")+ti[1],12,tdDone?0xFF7B8798:0xFF4D6381);td.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);td.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);td.setPadding(dp(10),dp(4),dp(10),dp(4));todoBox.addView(td,new LinearLayout.LayoutParams(-1,-2));}
            LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-1,-2);tlp.topMargin=dp(8);body.addView(todoBox,tlp);
        }
        final Dialog[] ref={null};
        if(treeHistoryViewDate==null){
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setGravity(Gravity.CENTER);actions.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            TreeIconView add=treeIcon(0),todoIcon=treeIcon(1),actionIcon=treeIcon(5),noteIcon=treeIcon(7),del=treeIcon(2);if("root".equals(id))del.setIconEnabled(false);
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(46),dp(46));ap.setMargins(dp(3),dp(10),dp(3),0);actions.addView(add,ap);actions.addView(todoIcon,new LinearLayout.LayoutParams(ap));actions.addView(actionIcon,new LinearLayout.LayoutParams(ap));actions.addView(noteIcon,new LinearLayout.LayoutParams(ap));actions.addView(del,new LinearLayout.LayoutParams(ap));body.addView(actions,new LinearLayout.LayoutParams(-1,dp(66)));
            add.setContentDescription("افزودن فرد");todoIcon.setContentDescription("To Do");actionIcon.setContentDescription("اقدامات");noteIcon.setContentDescription("یادداشت");del.setContentDescription("حذف فرد");
            add.setOnClickListener(v->{playSfx(sfxStartId,.72f);if(ref[0]!=null)ref[0].dismiss();addTreeChild(id);});
            todoIcon.setOnClickListener(v->{playUiClick();if(ref[0]!=null)ref[0].dismiss();showTreeTodo(id);});
            actionIcon.setOnClickListener(v->{playUiClick();if(ref[0]!=null)ref[0].dismiss();showTreeActions(id);});
            noteIcon.setOnClickListener(v->{playUiClick();if(ref[0]!=null)ref[0].dismiss();showTreeNotes(id);});
            del.setOnClickListener(v->{if(!"root".equals(id)){playSfx(sfxFailId,.65f);if(ref[0]!=null)ref[0].dismiss();deleteTreeNode(id);}});
            ref[0]=buildPastelDialog("◎",name,"نمایش کارت",0xFF37A8FF,body,"ویرایش",0xFF2F8DFF,()->showTreeMemberEditor(id),"بستن",null);
        }else{
            ref[0]=buildPastelDialog("◷",name,"تاریخ: "+formatPersianDateKey(treeHistoryViewDate),0xFF37A8FF,body,null,0,null,"بستن",null);
        }
        ref[0].show();
    }
    private void prepareTreeEditorField(final EditText e){
        e.setTag(e.getText().toString());
        e.setOnFocusChangeListener((v,has)->{
            EditText x=(EditText)v;
            if(has){x.setTag(x.getText().toString());x.setText("");}
            else if(x.getText().toString().trim().length()==0){Object old=x.getTag();x.setText(old==null?"":old.toString());}
        });
    }
    private void showTreeMemberEditor(final String id){showTreeMemberEditor(id,false);}
    private void showTreeMemberEditor(final String id,final boolean quickIncompleteFlow){
        if(treeHistoryViewDate!=null)return;
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // Name is intentionally read-only in the normal editing flow. It only becomes editable
        // after the small pencil button is pressed, because names do not change often.
        LinearLayout nameRow=new LinearLayout(this);nameRow.setOrientation(LinearLayout.HORIZONTAL);nameRow.setGravity(Gravity.CENTER_VERTICAL);nameRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView nameLabel=tv("نام فرد",12,0xFF536785);nameLabel.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);nameRow.addView(nameLabel,new LinearLayout.LayoutParams(dp(72),dp(46)));
        final EditText nameInput=(EditText)treeField("نام فرد",treeNodeVal(id,"name",id.equals("root")?"شهریار":"بدون نام"));
        nameInput.setEnabled(false);nameInput.setFocusable(false);nameInput.setAlpha(1f);nameRow.addView(nameInput,new LinearLayout.LayoutParams(0,dp(46),1f));
        TextView editName=tv("✎",19,0xFF2477E8);editName.setGravity(Gravity.CENTER);GradientDrawable eng=bg(0xFFEAF4FF,dp(12));eng.setStroke(Math.max(1,dp(1)),0x334D8DFF);editName.setBackground(eng);LinearLayout.LayoutParams enp=new LinearLayout.LayoutParams(dp(42),dp(42));enp.setMargins(dp(7),0,0,0);nameRow.addView(editName,enp);
        LinearLayout.LayoutParams nrp=new LinearLayout.LayoutParams(-1,dp(46));nrp.bottomMargin=dp(8);body.addView(nameRow,nrp);
        editName.setOnClickListener(v->{playUiClick();boolean on=!nameInput.isEnabled();nameInput.setEnabled(on);nameInput.setFocusable(on);nameInput.setFocusableInTouchMode(on);nameInput.setAlpha(1f);if(on){nameInput.requestFocus();nameInput.setSelection(nameInput.length());android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(im!=null)im.showSoftInput(nameInput,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);}});

        // Goals stay locked by default. A single edit control unlocks all three target values.
        LinearLayout goalHead=new LinearLayout(this);goalHead.setOrientation(LinearLayout.HORIZONTAL);goalHead.setGravity(Gravity.CENTER_VERTICAL);goalHead.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView gh=tv("هدف‌ها",12,0xFF536785);gh.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);goalHead.addView(gh,new LinearLayout.LayoutParams(0,dp(34),1f));
        TextView editGoals=tv("✎",18,0xFF2477E8);editGoals.setGravity(Gravity.CENTER);GradientDrawable egg=bg(0xFFEAF4FF,dp(11));egg.setStroke(Math.max(1,dp(1)),0x334D8DFF);editGoals.setBackground(egg);goalHead.addView(editGoals,new LinearLayout.LayoutParams(dp(40),dp(34)));body.addView(goalHead,new LinearLayout.LayoutParams(-1,dp(34)));

        final String[] fields={"pv","gpv","count"};final String[] targetFields={"target_pv","target_gpv","target_count"};final String[] labels={"PV","GPV","تعداد"};
        final EditText[] actualInputs=new EditText[3],targetInputs=new EditText[3];final boolean[] actualStatsTouched={false};
        for(int i=0;i<3;i++){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            TextView label=tv(labels[i],12,0xFF405D7F);label.setGravity(Gravity.CENTER);row.addView(label,new LinearLayout.LayoutParams(dp(50),dp(48)));
            actualInputs[i]=treeNumberField(labels[i],treeNodeVal(id,fields[i],"0"));prepareTreeEditorField(actualInputs[i]);
            actualInputs[i].setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN)actualStatsTouched[0]=true;return false;});
            row.addView(actualInputs[i],new LinearLayout.LayoutParams(0,dp(46),1.20f));
            TextView targetTag=tv("هدف",10,0xFF687B96);targetTag.setGravity(Gravity.CENTER);LinearLayout.LayoutParams ttp=new LinearLayout.LayoutParams(dp(42),dp(46));ttp.setMargins(dp(5),0,dp(5),0);row.addView(targetTag,ttp);
            targetInputs[i]=treeNumberField("هدف "+labels[i],treeNodeVal(id,targetFields[i],"0"));targetInputs[i].setEnabled(false);targetInputs[i].setFocusable(false);targetInputs[i].setAlpha(1f);row.addView(targetInputs[i],new LinearLayout.LayoutParams(0,dp(46),.90f));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(48));rp.bottomMargin=dp(7);body.addView(row,rp);
        }
        final boolean[] goalsUnlocked={false};
        editGoals.setOnClickListener(v->{playUiClick();goalsUnlocked[0]=!goalsUnlocked[0];for(EditText t:targetInputs){t.setEnabled(goalsUnlocked[0]);t.setFocusable(goalsUnlocked[0]);t.setFocusableInTouchMode(goalsUnlocked[0]);t.setAlpha(1f);}editGoals.setText(goalsUnlocked[0]?"✓":"✎");if(goalsUnlocked[0]){targetInputs[0].requestFocus();targetInputs[0].setSelection(targetInputs[0].length());}});

        String person=treeNodeVal(id,"name",id.equals("root")?"شهریار":"بدون نام");
        Dialog d=buildPastelDialog("✎","ویرایش اطلاعات",person,0xFF4D8EFF,body,"ذخیره",0xFF2F8DFF,()->{
            SharedPreferences.Editor ed=treeGraphPrefs().edit();boolean actualChanged=false;
            String newName=nameInput.getText().toString().trim();if(newName.length()==0)newName=treeNodeVal(id,"name",id.equals("root")?"شهریار":"بدون نام");ed.putString(treeNodePrefix(id)+"name",newName);
            for(int i=0;i<3;i++){
                String v=actualInputs[i].getText().toString().trim();if(v.length()==0){Object old=actualInputs[i].getTag();v=old==null?"0":old.toString();}v=normalizeTreeNumber(v);
                if(!v.equals(normalizeTreeNumber(treeNodeVal(id,fields[i],"0"))))actualChanged=true;ed.putString(treeNodePrefix(id)+fields[i],v);
                String target=targetInputs[i].getText().toString().trim();if(target.length()==0)target=treeNodeVal(id,targetFields[i],"0");target=normalizeTreeNumber(target);ed.putString(treeNodePrefix(id)+targetFields[i],target);
            }
            if(quickIncompleteFlow||actualStatsTouched[0]||actualChanged){ed.putString(treeNodePrefix(id)+"stats_day",treeDateKey());treeRecentStatsNodeId=id;}
            ed.apply();saveTreeSnapshotToday();treeAnimateNextLayout=true;showTreePage();
            if(quickIncompleteFlow)content.postDelayed(()->showRandomIncompleteTreeEditor(),180);
        },"لغو",null);d.show();
    }
    private void showRandomIncompleteTreeEditor(){
        if(treeHistoryViewDate!=null)return;ensureTreeGraphV2();java.util.ArrayList<String> incomplete=new java.util.ArrayList<>();
        for(String id:treeNodeIds())if(!treeStatsRecordedForDisplayDay(id))incomplete.add(id);
        if(incomplete.isEmpty()){Toast.makeText(this,"اطلاعات همه افراد تکمیل شده است",Toast.LENGTH_SHORT).show();return;}
        java.util.Collections.shuffle(incomplete,new java.util.Random(System.nanoTime()));String pick=incomplete.get(0);playUiClick();showTreeMemberEditor(pick,true);
    }
    private void addTreeChild(final String parentId){
        showPastelInputDialog("نام فرد","",null,name->{
            ensureTreeGraphV2();String id=nextTreeNodeId();java.util.ArrayList<String> ids=treeNodeIds();ids.add(id);SharedPreferences.Editor ed=treeGraphPrefs().edit();initTreeNodeDefaults(ed,id,parentId,name);ed.putBoolean(treeNodePrefix(parentId)+"expanded",true).apply();saveTreeNodeIds(ids);saveTreeSnapshotToday();treeAnimateNextLayout=true;showTreePage();
        });
    }
    private void expandTreeAncestors(String id){
        if(treeHistoryViewDate!=null)return;String p=treeNodeVal(id,"parent","");int guard=0;while(p.length()>0&&guard++<100){setTreeNodeExpanded(p,true);p=treeNodeVal(p,"parent","");}
    }
    private String normalizeTreeSearchText(String raw){
        if(raw==null)return "";
        String s=raw.trim().toLowerCase(java.util.Locale.ROOT)
            .replace('ي','ی').replace('ى','ی').replace('ك','ک')
            .replace('ۀ','ه').replace('ة','ه')
            .replace("‌","").replace("‏","").replace("‎","");
        try{
            s=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+","");
        }catch(Exception ignored){}
        return s.replaceAll("\\s+"," ");
    }
    private void showTreeSearch(){
        final EditText input=(EditText)treeField("نام فرد","");input.setSingleLine(true);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);body.addView(input,new LinearLayout.LayoutParams(-1,dp(50)));
        final LinearLayout suggestions=new LinearLayout(this);suggestions.setOrientation(LinearLayout.VERTICAL);suggestions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,-2);slp.topMargin=dp(8);body.addView(suggestions,slp);
        final Dialog[] ref={null};final String[] firstMatch={null};
        final Runnable render=()->{
            suggestions.removeAllViews();firstMatch[0]=null;String q=normalizeTreeSearchText(input.getText().toString());if(q.length()==0)return;int shown=0;
            for(String nodeId:treeDisplayIds()){
                String n=treeDisplayVal(nodeId,"name","");if(!normalizeTreeSearchText(n).contains(q))continue;if(firstMatch[0]==null)firstMatch[0]=nodeId;if(shown++>=8)break;final String pick=nodeId;
                TextView row=settingsRow(n,"");row.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.bottomMargin=dp(5);suggestions.addView(row,lp);
                row.setOnClickListener(v->{playUiClick();if(ref[0]!=null)ref[0].dismiss();expandTreeAncestors(pick);treeFocusNodeId=pick;treeViewStateValid=false;showTreePage();});
            }
            if(shown==0){TextView none=tv("فردی پیدا نشد",12,0xFF8794A7);none.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);none.setGravity(Gravity.CENTER);suggestions.addView(none,new LinearLayout.LayoutParams(-1,dp(44)));}
        };
        input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){render.run();}public void afterTextChanged(android.text.Editable e){}});
        input.setOnEditorActionListener((v,action,event)->{boolean enter=event!=null&&event.getKeyCode()==android.view.KeyEvent.KEYCODE_ENTER&&event.getAction()==android.view.KeyEvent.ACTION_DOWN;if(action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE||enter){if(firstMatch[0]!=null){String pick=firstMatch[0];if(ref[0]!=null)ref[0].dismiss();expandTreeAncestors(pick);treeFocusNodeId=pick;treeViewStateValid=false;showTreePage();}return true;}return false;});
        ref[0]=buildPastelDialog("⌕","جستجو","",0xFF4D8EFF,body,null,0,null,"بستن",null);ref[0].show();
    }
    private void showTreeHistoryDialog(){
        if(treeHistoryViewDate==null)saveTreeSnapshotToday();migrateTreeHistoryDateKeys();SharedPreferences hp=treeHistoryPrefs();java.util.ArrayList<String> dates=new java.util.ArrayList<>();
        for(String d:hp.getString("dates","").split("\\n"))if(d.trim().length()>0)dates.add(d.trim());java.util.Collections.sort(dates,(a,b)->normalizeDateStorageKey(b).compareTo(normalizeDateStorageKey(a)));
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);final Dialog[] ref={null};
        TextView current=settingsRow("درخت فعلی",treeHistoryViewDate==null?"✓":"");LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.bottomMargin=dp(5);body.addView(current,cp);current.setOnClickListener(v->{playUiClick();leaveTreeHistory();treeViewStateValid=false;if(ref[0]!=null)ref[0].dismiss();showTreePage();});
        for(int i=0;i<dates.size();i++){final String date=dates.get(i);TextView row=settingsRow(formatPersianDateKey(date),date.equals(treeHistoryViewDate)?"✓":"");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(44));lp.bottomMargin=dp(4);body.addView(row,lp);row.setOnClickListener(v->{playUiClick();if(loadTreeHistory(date)){treeViewStateValid=false;if(ref[0]!=null)ref[0].dismiss();showTreePage();}});}
        if(dates.isEmpty()){TextView none=tv("هنوز تاریخچه‌ای ثبت نشده",12,0xFF8190A8);none.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(none,new LinearLayout.LayoutParams(-1,dp(48)));}
        ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);scroll.addView(body,new ScrollView.LayoutParams(-1,-2));LinearLayout holder=new LinearLayout(this);holder.setOrientation(LinearLayout.VERTICAL);holder.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(420),getResources().getDisplayMetrics().heightPixels/2)));
        ref[0]=buildPastelDialog("◷","تاریخچه درختواره","",0xFF4D8EFF,holder,null,0,null,"بستن",null);ref[0].show();
    }

    private boolean allTreeBranchesExpanded(){
        if(treeHistoryViewDate!=null)return true;boolean any=false;
        for(String id:treeNodeIds()){if(treeChildren(id).isEmpty())continue;any=true;if(!treeNodeExpanded(id))return false;}return any;
    }
    private void setAllTreeBranches(boolean expanded){
        if(treeHistoryViewDate!=null)return;SharedPreferences.Editor ed=treeGraphPrefs().edit();
        for(String id:treeNodeIds())if(!treeChildren(id).isEmpty())ed.putBoolean(treeNodePrefix(id)+"expanded",expanded);ed.apply();
        treeAnimateNextLayout=true;treeViewStateValid=false;treeFocusNodeId=null;showTreePage();
    }
    private boolean treeStatsRecordedForDisplayDay(String id){
        // PV/GPV/count are cumulative. stats_day uses Jalali keys now; old Gregorian keys remain readable.
        String actual=treeDisplayVal(id,"stats_day","");
        if(treeHistoryViewDate!=null)return normalizeDateStorageKey(treeHistoryViewDate).equals(normalizeDateStorageKey(actual));
        return treeDateKey().equals(normalizeDateStorageKey(actual));
    }

    private class TreeNodeDraw{
        String id;int depth;float x,y,size;RectF nodeRect=new RectF(),orbRect=new RectF();java.util.ArrayList<String> children=new java.util.ArrayList<>();boolean expanded;
        boolean hasChildren(){return children!=null&&!children.isEmpty();}
    }
    private class TreeCanvasView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final java.util.ArrayList<TreeNodeDraw> draws=new java.util.ArrayList<>();
        private final java.util.HashMap<String,TreeNodeDraw> byId=new java.util.HashMap<>();
        private final android.view.ScaleGestureDetector scaleDetector;
        private final java.util.HashMap<String,float[]> animFrom=new java.util.HashMap<>();
        private float layoutAnim=1f,recentStatsFade=1f;
        private float scale=1f,panX=0f,panY=0f,lastX,lastY;
        private boolean dragging=false,scaleInProgress=false,postScaleAnchorNeeded=false;
        private long lastScaleEndAt=0L;
        private float worldW,worldH;
        private int maxDepth=0;
        private final float minScale=.42f,maxScale=2.80f;
        private final float statsScaleThreshold=1.85f;
        private final float nodeSize=dp(94);

        TreeCanvasView(android.content.Context c){
            super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);
            scaleDetector=new android.view.ScaleGestureDetector(c,new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){
                @Override public boolean onScaleBegin(android.view.ScaleGestureDetector d){scaleInProgress=true;dragging=true;return true;}
                @Override public boolean onScale(android.view.ScaleGestureDetector d){
                    float old=scale;
                    scale=Math.max(minScale,Math.min(maxScale,scale*d.getScaleFactor()));
                    float fx=d.getFocusX(),fy=d.getFocusY();
                    panX=fx-(fx-panX)*(scale/old);panY=fy-(fy-panY)*(scale/old);
                    clampPan();rememberViewState();invalidate();return true;
                }
                @Override public void onScaleEnd(android.view.ScaleGestureDetector d){scaleInProgress=false;lastScaleEndAt=android.os.SystemClock.uptimeMillis();postScaleAnchorNeeded=true;rememberViewState();invalidate();}
            });
        }
        private void rememberViewState(){treeSavedScale=scale;treeSavedPanX=panX;treeSavedPanY=panY;treeViewStateValid=true;}
        private void captureLayoutPositions(){treeLastPositions.clear();for(TreeNodeDraw d:draws)treeLastPositions.put(d.id,new float[]{animX(d),animY(d)});}
        private void startExternalLayoutAnimationIfNeeded(){
            if(!treeAnimateNextLayout||treeLastPositions.isEmpty()){treeAnimateNextLayout=false;return;}animFrom.clear();for(TreeNodeDraw d:draws){float[] o=treeLastPositions.get(d.id);if(o!=null)animFrom.put(d.id,o);}treeAnimateNextLayout=false;if(animFrom.isEmpty())return;layoutAnim=0f;
            post(()->{android.animation.ValueAnimator va=android.animation.ValueAnimator.ofFloat(0f,1f);va.setDuration(190);va.setInterpolator(new android.view.animation.DecelerateInterpolator());va.addUpdateListener(a->{layoutAnim=(Float)a.getAnimatedValue();invalidate();});va.start();});
        }
        private void startRecentStatsFadeIfNeeded(){
            if(treeRecentStatsNodeId==null||!byId.containsKey(treeRecentStatsNodeId)){recentStatsFade=1f;return;}recentStatsFade=0f;
            android.animation.ValueAnimator va=android.animation.ValueAnimator.ofFloat(0f,1f);va.setDuration(180);va.setInterpolator(new android.view.animation.DecelerateInterpolator());va.addUpdateListener(a->{recentStatsFade=(Float)a.getAnimatedValue();invalidate();});va.addListener(new android.animation.AnimatorListenerAdapter(){@Override public void onAnimationEnd(android.animation.Animator a){recentStatsFade=1f;treeRecentStatsNodeId=null;invalidate();}});va.start();
        }
        private float animX(TreeNodeDraw d){float[] o=animFrom.get(d.id);return o==null?d.x:o[0]+(d.x-o[0])*layoutAnim;}
        private float animY(TreeNodeDraw d){float[] o=animFrom.get(d.id);return o==null?d.y:o[1]+(d.y-o[1])*layoutAnim;}
        private float nodeSizeForDepth(int depth){return nodeSize;}
        private int visibleLeafCount(String id){
            java.util.ArrayList<String> ch=treeDisplayChildren(id);
            if(ch.isEmpty()||!treeDisplayExpanded(id))return 1;
            int n=0;for(String c:ch)n+=visibleLeafCount(c);return Math.max(1,n);
        }
        private int visibleMaxDepth(String id,int depth){
            int m=depth;java.util.ArrayList<String> ch=treeDisplayChildren(id);
            if(treeDisplayExpanded(id))for(String c:ch)m=Math.max(m,visibleMaxDepth(c,depth+1));
            return m;
        }
        private float layoutNode(String id,int depth,float left,float leafSpacing,float baseY,float levelGap){
            java.util.ArrayList<String> ch=treeDisplayChildren(id);boolean expanded=treeDisplayExpanded(id);float x;
            if(ch.isEmpty()||!expanded){x=left+leafSpacing*.5f;}
            else{
                float cursor=left,first=-1,last=-1;
                for(String c:ch){
                    int leaves=visibleLeafCount(c);
                    float cx=layoutNode(c,depth+1,cursor,leafSpacing,baseY,levelGap);
                    if(first<0)first=cx;last=cx;cursor+=leaves*leafSpacing;
                }
                x=(first+last)/2f;
            }
            TreeNodeDraw d=new TreeNodeDraw();d.id=id;d.depth=depth;d.x=x;d.y=baseY-depth*levelGap;d.size=nodeSizeForDepth(depth);d.expanded=expanded;d.children=ch;
            d.nodeRect.set(x-d.size/2f,d.y-d.size/2f,x+d.size/2f,d.y+d.size/2f);
            // A branch control exists ONLY for nodes that already have children. Leaf nodes stay clean;
            // adding a new person is done from the member card.
            if(!ch.isEmpty()){
                float orbS=dp(21),orbY=d.nodeRect.top-dp(24);
                d.orbRect.set(x-orbS/2f,orbY-orbS/2f,x+orbS/2f,orbY+orbS/2f);
            }else d.orbRect.setEmpty();
            draws.add(d);byId.put(id,d);return x;
        }
        private void buildLayout(){
            draws.clear();byId.clear();ensureTreeGraphV2();
            int leaves=visibleLeafCount("root");maxDepth=visibleMaxDepth("root",0);
            float leafSpacing=dp(124),side=dp(62),levelGap=dp(184);
            worldW=Math.max(getWidth(),leaves*leafSpacing+side*2);
            worldH=Math.max(getHeight(),dp(250)+maxDepth*levelGap+dp(250));
            // Root remains the visual anchor near the lower center.
            float baseY=worldH-dp(175),used=leaves*leafSpacing,left=(worldW-used)/2f;
            layoutNode("root",0,left,leafSpacing,baseY,levelGap);
        }
        private void fitInitial(){
            buildLayout();
            if(treeViewStateValid){scale=Math.max(minScale,Math.min(maxScale,treeSavedScale));panX=treeSavedPanX;panY=treeSavedPanY;}
            else{
                float widthFit=Math.min(1f,(getWidth()-dp(24))/Math.max(getWidth(),worldW));
                scale=Math.max(.58f,widthFit);TreeNodeDraw root=byId.get("root");
                if(root!=null){panX=getWidth()/2f-root.x*scale;panY=getHeight()*.79f-root.y*scale;}
            }
            clampPan();
            if(treeFocusNodeId!=null){
                TreeNodeDraw f=byId.get(treeFocusNodeId);
                if(f!=null){scale=Math.max(scale,Math.min(maxScale,2.12f));panX=getWidth()/2f-f.x*scale;panY=getHeight()*.48f-f.y*scale;clampPan();}
                treeFocusNodeId=null;
            }
            rememberViewState();startExternalLayoutAnimationIfNeeded();captureLayoutPositions();startRecentStatsFadeIfNeeded();
        }
        private void clampPan(){
            float scaledW=worldW*scale,scaledH=worldH*scale;
            if(scaledW<=getWidth())panX=(getWidth()-scaledW)/2f;else panX=Math.max(getWidth()-scaledW-dp(18),Math.min(dp(18),panX));
            if(scaledH<=getHeight())panY=(getHeight()-scaledH)/2f;else panY=Math.max(getHeight()-scaledH-dp(18),Math.min(dp(18),panY));
        }
        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);fitInitial();}
        private float fitNameSize(String name,float max,float avail){
            p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",Typeface.NORMAL));float s=max;p.setTextSize(s);
            while(s>dp(9.2f)&&p.measureText(name)>avail){s-=dp(.35f);p.setTextSize(s);}return s;
        }
        private void drawGlowLine(Canvas c,float x1,float y1,float x2,float y2){
            p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.BUTT);p.setStrokeJoin(Paint.Join.MITER);p.setStrokeMiter(10f);p.clearShadowLayer();
            // Crisp, thicker blue light: a solid saturated halo plus a sharp cyan core, without blur.
            p.setStrokeWidth(dp(7.4f));p.setColor(0x783087FF);c.drawLine(x1,y1,x2,y2,p);
            p.setStrokeWidth(dp(3.05f));p.setColor(0xFF19C8FF);c.drawLine(x1,y1,x2,y2,p);
        }
        private void drawBranch(Canvas c,TreeNodeDraw parent,TreeNodeDraw child){
            if(parent.orbRect.isEmpty())return;
            float px=animX(parent),py=animY(parent),cx=animX(child),cy=animY(child);
            float sx=px,sy=py+(parent.orbRect.centerY()-parent.y),ex=cx,ey=cy+child.size/2f;

            // Orthogonal tree connector: vertical -> horizontal -> vertical.
            // Siblings share the same middle Y, so their individual paths visually merge into
            // one clean trunk/bus with sharp 90-degree junctions (no Bezier curves or diagonals).
            float midY=sy+(ey-sy)*.5f;
            Path path=new Path();
            path.moveTo(sx,sy);
            path.lineTo(sx,midY);
            path.lineTo(ex,midY);
            path.lineTo(ex,ey);

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStrokeJoin(Paint.Join.MITER);
            p.setStrokeMiter(10f);

            // Crisp, saturated connection: thicker light with no blurred shadow.
            p.clearShadowLayer();p.setStrokeWidth(dp(7.4f));p.setColor(0x783087FF);c.drawPath(path,p);
            p.setStrokeWidth(dp(3.05f));p.setColor(0xFF19C8FF);c.drawPath(path,p);
        }
        private void drawTreeName(Canvas c,String name,float cx,float cy,float maxWidth,float maxSp,int color){
            android.text.TextPaint tp=new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);
            tp.setColor(color);tp.setTypeface(android.graphics.Typeface.create("sans-serif-medium",Typeface.NORMAL));
            float s=dp(maxSp);tp.setTextSize(s);
            while(s>dp(6.6f)&&tp.measureText(name)>maxWidth){s-=dp(.28f);tp.setTextSize(s);}
            float measured=Math.max(1f,tp.measureText(name));if(measured>maxWidth)tp.setTextScaleX(Math.max(.62f,maxWidth/measured));
            int width=Math.max(1,Math.round(maxWidth));
            android.text.StaticLayout layout=android.text.StaticLayout.Builder.obtain(name,0,name.length(),tp,width)
                    .setAlignment(android.text.Layout.Alignment.ALIGN_CENTER)
                    .setTextDirection(android.text.TextDirectionHeuristics.RTL)
                    .setIncludePad(false).setMaxLines(1).build();
            c.save();c.translate(cx-width/2f,cy-layout.getHeight()/2f);layout.draw(c);c.restore();
        }
        private void drawTreeStatText(Canvas c,String textValue,float x,float y,float sizeDp,int color){
            p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(android.graphics.Typeface.create("sans-serif",Typeface.NORMAL));p.setColor(color);p.clearShadowLayer();p.setTextSize(dp(sizeDp));c.drawText(textValue,x,y,p);
        }
        private float commonTreeStatsScale(String[] values,String[] labels,float cellW){
            float factor=1f;p.setTypeface(android.graphics.Typeface.create("sans-serif",Typeface.NORMAL));
            p.setTextSize(dp(8.1f));for(String v:values){float w=Math.max(1f,p.measureText(v));factor=Math.min(factor,cellW/w);}
            p.setTextSize(dp(6.3f));for(String v:labels){float w=Math.max(1f,p.measureText(v));factor=Math.min(factor,cellW/w);}
            return Math.max(.62f,Math.min(1f,factor));
        }
        private void drawNode(Canvas c,TreeNodeDraw d){
            float cx=animX(d),cy=animY(d),r=d.size*.47f;boolean statsVisible=scale>=statsScaleThreshold;
            boolean recorded=treeStatsRecordedForDisplayDay(d.id);
            // Incomplete = deep red, completed = deep green. Both use light text for strong contrast.
            int incompleteFill=0xFFA22E49,completedFill=0xFF176B4A;int fill=recorded?((treeRecentStatsNodeId!=null&&treeRecentStatsNodeId.equals(d.id))?mixColor(incompleteFill,completedFill,recentStatsFade):completedFill):incompleteFill;
            p.setStyle(Paint.Style.FILL);p.setColor(fill);p.setShadowLayer(dp(4.6f),0,0,recorded?0x663BCB91:0x66E14D6A);c.drawCircle(cx,cy,r,p);p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.65f));p.setColor(recorded?0xFF65E3B0:0xFFFF8298);c.drawCircle(cx,cy,r,p);

            final int mainText=0xFFF8FCFF,subText=0xFFDDEBFA;
            String name=treeDisplayVal(d.id,"name",d.id.equals("root")?"شهریار":"بدون نام");
            if(!statsVisible){drawTreeName(c,name,cx,cy,r*1.68f,14.7f,mainText);return;}

            drawTreeName(c,name,cx,cy-r*.42f,r*1.62f,11.6f,mainText);
            String[] values={formatTreeNumber(treeDisplayVal(d.id,"pv","0")),formatTreeNumber(treeDisplayVal(d.id,"gpv","0")),formatTreeNumber(treeDisplayVal(d.id,"count","0"))};
            String[] labels={"PV","GPV","تعداد"};float[] xs={cx-r*.56f,cx,cx+r*.56f};float cellW=r*.48f;
            // One common scale factor keeps every number the same size. Long values shrink the whole stats set together.
            float common=commonTreeStatsScale(values,labels,cellW);
            for(int i=0;i<3;i++)drawTreeStatText(c,values[i],xs[i],cy+dp(3),8.1f*common,mainText);
            for(int i=0;i<3;i++)drawTreeStatText(c,labels[i],xs[i],cy+dp(18),6.3f*common,subText);
        }
        private void drawOrb(Canvas c,TreeNodeDraw d){
            if(treeHistoryViewDate!=null||d.orbRect.isEmpty())return;
            float cx=animX(d),cy=animY(d)+(d.orbRect.centerY()-d.y),r=d.orbRect.width()/2f;
            // Only expand/collapse control; kept small and close to its parent.
            drawGlowLine(c,cx,animY(d)-d.size/2f,cx,cy);
            p.setStyle(Paint.Style.FILL);p.setColor(0xE91B78D6);p.setShadowLayer(dp(3.6f),0,0,0x8830A7FF);c.drawCircle(cx,cy,r,p);p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.9f));p.setColor(0xFFD5F5FF);c.drawCircle(cx,cy,r,p);
            String symbol=d.expanded?"−":"+";
            p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(r*1.28f);Paint.FontMetrics fm=p.getFontMetrics();c.drawText(symbol,cx,cy-(fm.ascent+fm.descent)/2f,p);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);c.save();c.translate(panX,panY);c.scale(scale,scale);
            for(TreeNodeDraw d:draws)if(d.expanded&&d.hasChildren())for(String id:d.children){TreeNodeDraw ch=byId.get(id);if(ch!=null)drawBranch(c,d,ch);}
            for(TreeNodeDraw d:draws){drawNode(c,d);drawOrb(c,d);}c.restore();
        }
        private float worldX(float x){return (x-panX)/scale;}private float worldY(float y){return (y-panY)/scale;}
        private TreeNodeDraw hitOrb(float wx,float wy){
            for(int i=draws.size()-1;i>=0;i--){TreeNodeDraw d=draws.get(i);if(d.orbRect.isEmpty())continue;RectF r=new RectF(d.orbRect);r.inset(-dp(8),-dp(8));if(r.contains(wx,wy))return d;}return null;
        }
        private TreeNodeDraw hitNode(float wx,float wy){for(int i=draws.size()-1;i>=0;i--){TreeNodeDraw d=draws.get(i);if(d.nodeRect.contains(wx,wy))return d;}return null;}
        private void handleOrb(TreeNodeDraw d){
            if(treeHistoryViewDate!=null||!d.hasChildren())return;
            float anchorScreenX=panX+d.x*scale,anchorScreenY=panY+d.y*scale;
            java.util.HashMap<String,float[]> oldPos=new java.util.HashMap<>();for(TreeNodeDraw q:draws)oldPos.put(q.id,new float[]{animX(q),animY(q)});
            boolean next=!d.expanded;setTreeNodeExpanded(d.id,next);playSfx(sfxToggleId,.72f);if(treeExpandAllButton!=null)treeExpandAllButton.setAltState(allTreeBranchesExpanded());
            buildLayout();TreeNodeDraw nd=byId.get(d.id);
            if(nd!=null){panX=anchorScreenX-nd.x*scale;panY=anchorScreenY-nd.y*scale;}
            clampPan();rememberViewState();animFrom.clear();for(TreeNodeDraw q:draws){float[] o=oldPos.get(q.id);if(o!=null)animFrom.put(q.id,o);}layoutAnim=0f;
            android.animation.ValueAnimator va=android.animation.ValueAnimator.ofFloat(0f,1f);va.setDuration(180);va.setInterpolator(new android.view.animation.DecelerateInterpolator());va.addUpdateListener(a->{layoutAnim=(Float)a.getAnimatedValue();invalidate();});va.start();
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            scaleDetector.onTouchEvent(e);long now=android.os.SystemClock.uptimeMillis();
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    lastX=e.getX();lastY=e.getY();dragging=false;return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    dragging=true;return true;
                case MotionEvent.ACTION_POINTER_UP:
                    lastScaleEndAt=now;postScaleAnchorNeeded=true;dragging=true;return true;
                case MotionEvent.ACTION_MOVE:
                    if(e.getPointerCount()==1&&!scaleInProgress&&!scaleDetector.isInProgress()){
                        if(now-lastScaleEndAt<90L)return true;
                        if(postScaleAnchorNeeded){lastX=e.getX();lastY=e.getY();postScaleAnchorNeeded=false;dragging=false;return true;}
                        float dx=e.getX()-lastX,dy=e.getY()-lastY;if(Math.abs(dx)+Math.abs(dy)>dp(3))dragging=true;
                        panX+=dx;panY+=dy;lastX=e.getX();lastY=e.getY();clampPan();rememberViewState();invalidate();
                    }return true;
                case MotionEvent.ACTION_UP:
                    if(now-lastScaleEndAt<90L){rememberViewState();return true;}
                    if(!dragging&&!scaleInProgress&&!scaleDetector.isInProgress()){
                        float wx=worldX(e.getX()),wy=worldY(e.getY());
                        TreeNodeDraw o=hitOrb(wx,wy);if(o!=null){handleOrb(o);return true;}
                        TreeNodeDraw n=hitNode(wx,wy);if(n!=null){rememberViewState();captureLayoutPositions();playUiClick();showTreeMemberCard(n.id);return true;}
                    }rememberViewState();return true;
                case MotionEvent.ACTION_CANCEL:rememberViewState();return true;
            }return true;
        }
    }
    private void showTreePage(){
        stopHomeActiveTicker();removeHomeOnlyOverlays();isHome=false;isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=true;isTreeScreen=true;++homeGeneration;content.removeAllViews();ensureTreeGraphV2();
        if(treeHistoryViewDate==null)saveTreeSnapshotToday();
        FrameLayout page=new FrameLayout(this);page.setBackgroundColor(THEME_FALLBACK);ImageView art=new ImageView(this);art.setImageResource(heroTreeBackground());art.setScaleType(ImageView.ScaleType.FIT_XY);page.addView(art,new FrameLayout.LayoutParams(-1,-1));
        TreeCanvasView canvas=new TreeCanvasView(this);page.addView(canvas,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);tools.setGravity(Gravity.CENTER);tools.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);GradientDrawable tg=bg(0xDDF7FAFF,dp(999));tg.setStroke(Math.max(1,dp(1)),0x554D8DFF);tools.setBackground(tg);tools.setElevation(dp(3));
        TreeIconView search=treeIcon(3),quickStats=treeIcon(8),expandAll=treeIcon(6),history=treeIcon(4);treeExpandAllButton=expandAll;search.setContentDescription("جستجو");quickStats.setContentDescription("تکمیل تصادفی اطلاعات ناقص");history.setContentDescription("تاریخچه");expandAll.setContentDescription("باز یا بسته کردن همه شاخه‌ها");expandAll.setAltState(allTreeBranchesExpanded());if(treeHistoryViewDate!=null){expandAll.setIconEnabled(false);quickStats.setIconEnabled(false);}
        tools.addView(search,new LinearLayout.LayoutParams(dp(42),dp(42)));tools.addView(quickStats,new LinearLayout.LayoutParams(dp(42),dp(42)));tools.addView(expandAll,new LinearLayout.LayoutParams(dp(42),dp(42)));tools.addView(history,new LinearLayout.LayoutParams(dp(42),dp(42)));
        search.setOnClickListener(v->{playUiClick();showTreeSearch();});quickStats.setOnClickListener(v->{if(treeHistoryViewDate==null)showRandomIncompleteTreeEditor();});expandAll.setOnClickListener(v->{playSfx(sfxToggleId,.72f);setAllTreeBranches(!allTreeBranchesExpanded());});history.setOnClickListener(v->{playUiClick();showTreeHistoryDialog();});
        FrameLayout.LayoutParams tlp=new FrameLayout.LayoutParams(dp(180),dp(48),Gravity.TOP|Gravity.RIGHT);tlp.topMargin=dp(64);tlp.rightMargin=dp(12);page.addView(tools,tlp);
        if(treeHistoryViewDate!=null){TextView badge=tv(formatPersianDateKey(treeHistoryViewDate),11,0xFF315B86);badge.setGravity(Gravity.CENTER);GradientDrawable bg=bg(0xEAF7FAFF,dp(999));bg.setStroke(Math.max(1,dp(1)),0x554D8DFF);badge.setBackground(bg);FrameLayout.LayoutParams blp=new FrameLayout.LayoutParams(dp(108),dp(30),Gravity.TOP|Gravity.LEFT);blp.topMargin=dp(72);blp.leftMargin=dp(12);page.addView(badge,blp);}
        content.addView(page,new FrameLayout.LayoutParams(-1,-1));addActiveMissionBar();
    }

    // ---------------- Dream Palace / Wish Palace ----------------
    // v80: persistent full-resolution originals, exact crop thumbnails, cached thumbs,
    // safe fit-center mapping, animated reorder, adjacent-page drag/drop and unified app theming.
    private android.content.SharedPreferences dreamPrefs(){
        if(dreamPrefs==null)dreamPrefs=getSharedPreferences("legacy_dream_palace",MODE_PRIVATE);
        return dreamPrefs;
    }
    private String dreamKey(int slot,String field){return "dream_"+slot+"_"+field;}
    private java.io.File dreamAssetFile(int slot,String kind){
        java.io.File dir=new java.io.File(getFilesDir(),"dream_palace");if(!dir.exists())dir.mkdirs();
        return new java.io.File(dir,"dream_"+slot+"_"+kind+"_"+System.currentTimeMillis()+("thumb".equals(kind)?".jpg":".img"));
    }
    private boolean hasDream(int slot){
        String path=dreamPrefs().getString(dreamKey(slot,"path"),"");
        if(path!=null&&path.length()>0&&new java.io.File(path).exists())return true;
        String original=dreamPrefs().getString(dreamKey(slot,"original"),"");
        return original!=null&&original.length()>0&&new java.io.File(original).exists();
    }
    private String dreamThumbPath(int slot){return dreamPrefs().getString(dreamKey(slot,"path"),"");}
    private String dreamOriginalPath(int slot){
        String p=dreamPrefs().getString(dreamKey(slot,"original"),"");
        if(p==null||p.length()==0||!new java.io.File(p).exists())p=dreamThumbPath(slot);
        return p==null?"":p;
    }
    private String dreamTitle(int slot){return dreamPrefs().getString(dreamKey(slot,"title"),"");}
    private String dreamYear(int slot){return dreamPrefs().getString(dreamKey(slot,"year"),String.valueOf(currentJalaliYear()));}
    private String dreamPrice(int slot){return dreamPrefs().getString(dreamKey(slot,"price"),"");}
    private int highestDreamSlot(){return Math.max(-1,dreamPrefs().getInt("highest_slot",-1));}
    private boolean anyDream(){int h=highestDreamSlot();for(int i=0;i<=h;i++)if(hasDream(i))return true;return false;}
    private java.util.ArrayList<Integer> dreamOrder(){java.util.ArrayList<Integer> out=new java.util.ArrayList<>();int h=highestDreamSlot();for(int i=0;i<=h;i++)if(hasDream(i))out.add(i);return out;}
    private void appendDreamOrderIfNeeded(int slot){
        java.util.ArrayList<Integer> order=dreamOrder();if(!order.contains(slot))order.add(slot);java.util.Collections.sort(order);StringBuilder b=new StringBuilder();
        for(int i=0;i<order.size();i++){if(i>0)b.append(',');b.append(order.get(i));}dreamPrefs().edit().putString("dream_order",b.toString()).apply();
    }
    private boolean isDreamPageComplete(int page){int start=page*20;for(int i=0;i<20;i++)if(!hasDream(start+i))return false;return true;}
    private int maxUnlockedDreamPage(){int page=0;while(page<50&&isDreamPageComplete(page))page++;return page;}
    private int currentJalaliYear(){return jalaliForMillis(System.currentTimeMillis())[0];}
    private String digitsOnly(String s){return s==null?"":s.replaceAll("[^0-9]","");}
    private String formatDreamPrice(String raw){String d=digitsOnly(raw);if(d.length()==0)return "";try{return String.format(java.util.Locale.US,"%,d",Long.parseLong(d));}catch(Exception e){return d;}}

    private final android.util.LruCache<String,android.graphics.Bitmap> dreamThumbCache=new android.util.LruCache<String,android.graphics.Bitmap>(12*1024){
        @Override protected int sizeOf(String key,android.graphics.Bitmap value){return Math.max(1,value.getByteCount()/1024);}
    };
    private FrameLayout dreamPagerRoot=null;
    private final java.util.HashMap<Integer,FrameLayout> dreamPagerPages=new java.util.HashMap<>();
    private int dreamDraggingSlot=-1;
    private boolean dreamDragPageShifted=false;
    private Runnable dreamEdgeSwitchRunnable=null;

    private void clearDreamThumbCache(){try{dreamThumbCache.evictAll();}catch(Exception ignored){}}
    private android.graphics.Bitmap rotateDreamBitmapForExif(android.graphics.Bitmap b,String path){
        if(b==null||path==null||path.length()==0)return b;int rot=0;
        try{android.media.ExifInterface ex=new android.media.ExifInterface(path);int or=ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,android.media.ExifInterface.ORIENTATION_NORMAL);
            if(or==android.media.ExifInterface.ORIENTATION_ROTATE_90)rot=90;else if(or==android.media.ExifInterface.ORIENTATION_ROTATE_180)rot=180;else if(or==android.media.ExifInterface.ORIENTATION_ROTATE_270)rot=270;
        }catch(Exception ignored){}
        if(rot==0)return b;try{android.graphics.Matrix m=new android.graphics.Matrix();m.postRotate(rot);android.graphics.Bitmap r=android.graphics.Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);if(r!=b)b.recycle();return r;}catch(Exception ignored){return b;}
    }
    private android.graphics.Bitmap decodeDreamFile(String path,int maxDim){
        if(path==null||path.length()==0||!new java.io.File(path).exists())return null;
        try{
            android.graphics.BitmapFactory.Options o=new android.graphics.BitmapFactory.Options();o.inJustDecodeBounds=true;android.graphics.BitmapFactory.decodeFile(path,o);
            int sample=1;while(Math.max(o.outWidth,o.outHeight)/sample>Math.max(200,maxDim)*2)sample*=2;
            o=new android.graphics.BitmapFactory.Options();o.inSampleSize=Math.max(1,sample);o.inPreferredConfig=maxDim>700?android.graphics.Bitmap.Config.ARGB_8888:android.graphics.Bitmap.Config.RGB_565;
            android.graphics.Bitmap b=android.graphics.BitmapFactory.decodeFile(path,o);return rotateDreamBitmapForExif(b,path);
        }catch(Exception e){return null;}
    }
    private android.graphics.Bitmap loadDreamThumbBitmap(int slot,int maxDim){
        String p=dreamThumbPath(slot);if(p==null||p.length()==0)p=dreamOriginalPath(slot);if(p==null||p.length()==0)return null;
        java.io.File f=new java.io.File(p);String key=p+"@"+maxDim+"@"+(f.exists()?f.lastModified():0);android.graphics.Bitmap c=dreamThumbCache.get(key);if(c!=null&&!c.isRecycled())return c;
        android.graphics.Bitmap b=decodeDreamFile(p,maxDim);if(b!=null)dreamThumbCache.put(key,b);return b;
    }
    private android.graphics.Bitmap loadDreamOriginalBitmap(int slot,int maxDim){return decodeDreamFile(dreamOriginalPath(slot),maxDim);}
    private void copyFile(java.io.File from,java.io.File to)throws java.io.IOException{
        java.io.File parent=to.getParentFile();if(parent!=null&&!parent.exists())parent.mkdirs();try(java.io.InputStream in=new java.io.FileInputStream(from);java.io.OutputStream out=new java.io.FileOutputStream(to)){byte[] buf=new byte[32768];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}
    }
    private void copyDreamUriRaw(android.net.Uri uri,java.io.File to)throws java.io.IOException{
        java.io.File parent=to.getParentFile();if(parent!=null&&!parent.exists())parent.mkdirs();try(java.io.InputStream in=getContentResolver().openInputStream(uri);java.io.OutputStream out=new java.io.FileOutputStream(to)){if(in==null)throw new java.io.IOException("no input");byte[] buf=new byte[32768];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}
    }
    private void saveBitmapJpeg(android.graphics.Bitmap b,java.io.File f,int quality)throws java.io.IOException{
        java.io.File parent=f.getParentFile();if(parent!=null&&!parent.exists())parent.mkdirs();try(java.io.FileOutputStream fos=new java.io.FileOutputStream(f)){if(!b.compress(android.graphics.Bitmap.CompressFormat.JPEG,quality,fos))throw new java.io.IOException("compress failed");}
    }
    private String[] readDreamRecord(int slot){if(!hasDream(slot))return null;return new String[]{dreamThumbPath(slot),dreamOriginalPath(slot),dreamTitle(slot),dreamYear(slot),dreamPrice(slot)};}
    private void writeDreamRecord(android.content.SharedPreferences.Editor ed,int slot,String[] r){String[] fields={"path","original","title","year","price"};if(r==null){for(String f:fields)ed.remove(dreamKey(slot,f));return;}for(int i=0;i<fields.length;i++)ed.putString(dreamKey(slot,fields[i]),r[i]==null?"":r[i]);}
    private void recomputeDreamHighest(){int old=Math.max(highestDreamSlot(),dreamPage*20+19),h=-1;for(int i=0;i<=old;i++)if(hasDream(i))h=i;dreamPrefs().edit().putInt("highest_slot",h).apply();}
    private boolean dreamPathStillReferenced(String path){if(path==null||path.length()==0)return false;int h=highestDreamSlot();for(int i=0;i<=h;i++){if(path.equals(dreamThumbPath(i))||path.equals(dreamOriginalPath(i)))return true;}return false;}
    private void deleteDreamFileIfUnused(String path){try{if(path!=null&&path.length()>0&&!dreamPathStillReferenced(path)){java.io.File f=new java.io.File(path);if(f.exists()&&f.getAbsolutePath().startsWith(getFilesDir().getAbsolutePath()))f.delete();}}catch(Exception ignored){}}

    private void moveDreamSlot(int from,int to){
        if(from==to||from<0||to<0||!hasDream(from))return;int lo=Math.min(from,to),hi=Math.max(from,to);java.util.HashMap<Integer,String[]> snap=new java.util.HashMap<>();for(int i=lo;i<=hi;i++)snap.put(i,readDreamRecord(i));String[] source=snap.get(from);
        android.content.SharedPreferences.Editor ed=dreamPrefs().edit();if(from>to){for(int i=from;i>to;i--)writeDreamRecord(ed,i,snap.get(i-1));writeDreamRecord(ed,to,source);}else{for(int i=from;i<to;i++)writeDreamRecord(ed,i,snap.get(i+1));writeDreamRecord(ed,to,source);}ed.apply();recomputeDreamHighest();clearDreamThumbCache();
        playSfx(sfxToggleId,.72f);showDreamPalaceInternal(to/20,from,to,true);
    }
    private int oldSlotForReorderedSlot(int newSlot,int from,int to){
        if(from<0||to<0||from==to)return newSlot;if(newSlot==to)return from;
        if(from<to&&newSlot>=from&&newSlot<to)return newSlot+1;if(from>to&&newSlot>to&&newSlot<=from)return newSlot-1;return newSlot;
    }
    private void deleteDreamAt(int slot,boolean returnViewer,boolean sequenceMode){
        if(!hasDream(slot))return;String[] removed=readDreamRecord(slot);int h=highestDreamSlot();java.util.ArrayList<String[]> snap=new java.util.ArrayList<>();for(int i=slot;i<=h;i++)snap.add(readDreamRecord(i));android.content.SharedPreferences.Editor ed=dreamPrefs().edit();
        for(int i=slot;i<h;i++)writeDreamRecord(ed,i,snap.get(i-slot+1));writeDreamRecord(ed,h,null);ed.putInt("highest_slot",Math.max(-1,h-1));ed.apply();clearDreamThumbCache();
        if(removed!=null){deleteDreamFileIfUnused(removed[0]);if(!java.util.Objects.equals(removed[1],removed[0]))deleteDreamFileIfUnused(removed[1]);}
        playSfx(sfxFailId,.68f);int nh=highestDreamSlot();if(returnViewer&&nh>=0){int next=Math.min(slot,nh);if(hasDream(next))showDreamViewer(next,sequenceMode);else showDreamPalace(Math.max(0,Math.min(slot/20,maxUnlockedDreamPage())));}else showDreamPalace(Math.max(0,Math.min(slot/20,maxUnlockedDreamPage())));
    }

    // Rectangles are normalized to the 768x1536 artwork. The art itself is FIT_CENTER,
    // and every hit/image rectangle is mapped through the same non-stretch transform.
    private static final float[][] DREAM_RECTS={
        {0.0352f,0.3053f,0.2292f,0.1113f},{0.2734f,0.3053f,0.2266f,0.1113f},{0.5091f,0.3053f,0.2227f,0.1113f},{0.7409f,0.3053f,0.2279f,0.1113f},
        {0.0352f,0.4238f,0.2292f,0.1107f},{0.2734f,0.4238f,0.2266f,0.1107f},{0.5091f,0.4238f,0.2227f,0.1107f},{0.7409f,0.4238f,0.2279f,0.1107f},
        {0.0352f,0.5410f,0.2292f,0.1113f},{0.2734f,0.5410f,0.2266f,0.1113f},{0.5091f,0.5410f,0.2227f,0.1113f},{0.7409f,0.5410f,0.2279f,0.1113f},
        {0.0352f,0.6589f,0.2292f,0.1100f},{0.2734f,0.6589f,0.2266f,0.1100f},{0.5091f,0.6589f,0.2227f,0.1100f},{0.7409f,0.6589f,0.2279f,0.1100f},
        {0.0352f,0.7754f,0.2292f,0.1120f},{0.2734f,0.7754f,0.2266f,0.1120f},{0.5091f,0.7754f,0.2227f,0.1120f},{0.7409f,0.7754f,0.2279f,0.1120f}
    };
    private android.graphics.RectF dreamArtRect(int w,int h){return fitCenterRect(w,h,768f,1536f);}
    private android.graphics.RectF dreamCellRect(int index,int w,int h){android.graphics.RectF a=dreamArtRect(w,h);float[] q=DREAM_RECTS[Math.max(0,Math.min(19,index))];return new android.graphics.RectF(a.left+a.width()*q[0],a.top+a.height()*q[1],a.left+a.width()*(q[0]+q[2]),a.top+a.height()*(q[1]+q[3]));}

    private class DreamThumbView extends ImageView{
        private final android.graphics.Path clip=new android.graphics.Path();private final Paint borderPaint=new Paint(Paint.ANTI_ALIAS_FLAG);private boolean showChosenBorder=true;
        DreamThumbView(android.content.Context c){super(c);setScaleType(ImageView.ScaleType.FIT_CENTER);setLayerType(View.LAYER_TYPE_SOFTWARE,null);setBackgroundColor(0x12000000);}
        void setChosenBorder(boolean b){showChosenBorder=b;invalidate();}
        @Override protected void onDraw(Canvas c){
            float r=Math.min(getWidth(),getHeight())*.105f;clip.reset();clip.addRoundRect(new RectF(0,0,getWidth(),getHeight()),r,r,android.graphics.Path.Direction.CW);int save=c.save();c.clipPath(clip);super.onDraw(c);c.restoreToCount(save);
            if(showChosenBorder){float sw=Math.max(dp(2),Math.min(getWidth(),getHeight())*.020f);borderPaint.setStyle(Paint.Style.STROKE);borderPaint.setStrokeWidth(sw);borderPaint.setColor(0xFFE7F7FF);borderPaint.setShadowLayer(dp(2),0,0,0x8855C8FF);float inset=sw*1.15f;c.drawRoundRect(new RectF(inset,inset,getWidth()-inset,getHeight()-inset),Math.max(1,r-inset*.25f),Math.max(1,r-inset*.25f),borderPaint);borderPaint.clearShadowLayer();}
        }
    }
    private class DreamPortalView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        DreamPortalView(android.content.Context c){super(c);setContentDescription("نمایش همه آرزوها");setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(getWidth(),getHeight())*.42f;
            // Static premium gallery asset: no pulse/glow animation, matched to the blue glass app theme.
            p.setStyle(Paint.Style.FILL);p.setColor(0xD9162A48);p.clearShadowLayer();c.drawCircle(cx,cy,r,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.4f));p.setColor(0xCC9DE6FF);c.drawCircle(cx,cy,r,p);
            float w=r*1.12f,h=r*.76f;for(int i=0;i<3;i++){float ox=(i-1)*r*.14f,oy=(1-i)*r*.09f;RectF rr=new RectF(cx-w/2+ox,cy-h/2+oy,cx+w/2+ox,cy+h/2+oy);p.setStyle(Paint.Style.FILL);p.setColor(i==2?0xD64D8EFF:0x9A315F9B);c.drawRoundRect(rr,r*.16f,r*.16f,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0xBFEAF7FF);c.drawRoundRect(rr,r*.16f,r*.16f,p);}
            p.setStyle(Paint.Style.FILL);p.setColor(0xFFEAF7FF);float sx=cx+r*.48f,sy=cy-r*.50f,sp=r*.13f;Path star=new Path();star.moveTo(sx,sy-sp);star.lineTo(sx+sp*.28f,sy-sp*.28f);star.lineTo(sx+sp,sy);star.lineTo(sx+sp*.28f,sy+sp*.28f);star.lineTo(sx,sy+sp);star.lineTo(sx-sp*.28f,sy+sp*.28f);star.lineTo(sx-sp,sy);star.lineTo(sx-sp*.28f,sy-sp*.28f);star.close();c.drawPath(star,p);
        }
    }
    private class DollarAssetView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);DollarAssetView(android.content.Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(getWidth(),getHeight())*.42f;android.graphics.LinearGradient lg=new android.graphics.LinearGradient(0,0,getWidth(),getHeight(),new int[]{0xFF55C8FF,0xFF7B61FF},null,android.graphics.Shader.TileMode.CLAMP);p.setShader(lg);p.setStyle(Paint.Style.FILL);p.setShadowLayer(dp(4),0,dp(1),0x66000000);c.drawCircle(cx,cy,r,p);p.clearShadowLayer();p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1,dp(1)));p.setColor(0xCCEAF7FF);c.drawCircle(cx,cy,r*.84f,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(r*1.03f);Paint.FontMetrics fm=p.getFontMetrics();c.drawText("$",cx,cy-(fm.ascent+fm.descent)/2f,p);}
    }

    private void showDreamPalace(int requestedPage){showDreamPalaceInternal(requestedPage,-1,-1,false);}
    private void showDreamPalaceInternal(int requestedPage,int reorderFrom,int reorderTo,boolean animateReorder){
        stopHomeActiveTicker();removeHomeOnlyOverlays();isHome=false;isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;isTreeScreen=false;isDreamViewerScreen=false;isDreamPalaceScreen=true;++homeGeneration;
        if(content==null){showHome();return;}isShopScreen=false;if(hudHeader!=null)hudHeader.setVisibility(View.VISIBLE);content.setTranslationX(0f);content.setTranslationY(0f);content.setAlpha(1f);content.removeAllViews();dreamPagerPages.clear();
        int max=maxUnlockedDreamPage();dreamPage=Math.max(0,Math.min(requestedPage,max));dreamPagerRoot=new FrameLayout(this);dreamPagerRoot.setClipChildren(true);dreamPagerRoot.setClipToPadding(true);dreamPagerRoot.setBackgroundColor(THEME_FALLBACK);content.addView(dreamPagerRoot,new FrameLayout.LayoutParams(-1,-1));
        final int pageAtBuild=dreamPage;dreamPagerRoot.post(()->{
            if(!isDreamPalaceScreen||dreamPagerRoot==null)return;int w=dreamPagerRoot.getWidth(),h=dreamPagerRoot.getHeight();if(w<=0||h<=0)return;int lo=Math.max(0,pageAtBuild-2),hi=Math.min(maxUnlockedDreamPage(),pageAtBuild+2);
            for(int p=lo;p<=hi;p++){FrameLayout pg=buildDreamPalacePage(p,w,h,reorderFrom,reorderTo,animateReorder);pg.setTranslationX((p-pageAtBuild)*w);dreamPagerPages.put(p,pg);dreamPagerRoot.addView(pg,new FrameLayout.LayoutParams(-1,-1));}
        });
        addActiveMissionBar();
    }
    private FrameLayout buildDreamPalacePage(final int pageIndex,final int w,final int h,final int reorderFrom,final int reorderTo,final boolean animateReorder){
        FrameLayout page=new FrameLayout(this);page.setBackgroundColor(THEME_FALLBACK);page.setTag(Integer.valueOf(pageIndex));
        ImageView art=new ImageView(this);art.setImageResource(heroDreamBackground());art.setScaleType(ImageView.ScaleType.FIT_CENTER);page.addView(art,new FrameLayout.LayoutParams(-1,-1));
        for(int i=0;i<20;i++){
            final int slot=pageIndex*20+i;android.graphics.RectF rr=dreamCellRect(i,w,h);int cover=Math.max(1,dp(1));int left=Math.round(rr.left)-cover,top=Math.round(rr.top)-cover,ww=Math.round(rr.width())+cover*2,hh=Math.round(rr.height())+cover*2;View cell;
            if(hasDream(slot)){DreamThumbView im=new DreamThumbView(this);android.graphics.Bitmap bm=loadDreamThumbBitmap(slot,420);if(bm!=null)im.setImageBitmap(bm);cell=im;}else cell=new View(this);
            cell.setContentDescription(hasDream(slot)?"آرزو "+(i+1):"افزودن آرزو "+(i+1));cell.setClickable(true);cell.setLongClickable(hasDream(slot));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,ww),Math.max(1,hh));lp.leftMargin=left;lp.topMargin=top;page.addView(cell,lp);
            if(hasDream(slot)&&!animateReorder){cell.setAlpha(0f);cell.setScaleX(.985f);cell.setScaleY(.985f);final View reveal=cell;reveal.postDelayed(()->reveal.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170).setInterpolator(new android.view.animation.DecelerateInterpolator()).start(),45L*i);}
            if(animateReorder&&hasDream(slot)&&slot>=Math.min(reorderFrom,reorderTo)&&slot<=Math.max(reorderFrom,reorderTo)){
                int oldSlot=oldSlotForReorderedSlot(slot,reorderFrom,reorderTo),oldPage=oldSlot/20,oldIndex=Math.floorMod(oldSlot,20);android.graphics.RectF oldR=dreamCellRect(oldIndex,w,h);float oldGlobalX=(oldPage-pageIndex)*w+oldR.left;cell.setTranslationX(oldGlobalX-rr.left);cell.setTranslationY(oldR.top-rr.top);cell.setAlpha(.74f);cell.animate().translationX(0f).translationY(0f).alpha(1f).setDuration(210).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            }
            final float[] down={0f,0f,0f,0f};final Runnable[] dragStart={null};
            cell.setOnDragListener((v,e)->{
                switch(e.getAction()){
                    case android.view.DragEvent.ACTION_DRAG_STARTED:return e.getClipDescription()!=null;
                    case android.view.DragEvent.ACTION_DRAG_ENTERED:v.animate().scaleX(1.035f).scaleY(1.035f).setDuration(180).start();return true;
                    case android.view.DragEvent.ACTION_DRAG_EXITED:v.animate().scaleX(1f).scaleY(1f).setDuration(180).start();return true;
                    case android.view.DragEvent.ACTION_DROP:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(160).start();int from=dreamDraggingSlot;Object ls=e.getLocalState();if(ls instanceof Integer)from=(Integer)ls;if(from<0&&e.getClipData()!=null&&e.getClipData().getItemCount()>0){try{from=Integer.parseInt(String.valueOf(e.getClipData().getItemAt(0).getText()));}catch(Exception ignored){}}final int f=from;dreamDraggingSlot=-1;if(f>=0)v.post(()->moveDreamSlot(f,slot));return true;
                    case android.view.DragEvent.ACTION_DRAG_ENDED:v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(150).start();v.setElevation(0f);if(!e.getResult()&&dreamDraggingSlot>=0){dreamDraggingSlot=-1;if(dreamDragPageShifted)showDreamPalace(dreamPage);}dreamDragPageShifted=false;return true;
                    default:return true;
                }
            });
            cell.setOnTouchListener((v,e)->handleDreamGridTouch(v,e,slot,down,dragStart));
        }
        if(anyDream()){
            DreamPortalView portal=new DreamPortalView(this);android.graphics.RectF ar=dreamArtRect(w,h);int pw=Math.max(dp(50),Math.round(ar.width()*.105f));FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(pw,pw);
            // New dream-gallery asset: visually integrated, and deliberately left of the old sun position.
            float cx=ar.left+ar.width()*.835f,cy=ar.top+ar.height()*.128f;pp.leftMargin=Math.round(cx-pw/2f);pp.topMargin=Math.round(cy-pw/2f);portal.setOnClickListener(v->{playUiClick();java.util.ArrayList<Integer> o=dreamOrder();if(!o.isEmpty())showDreamViewer(o.get(0),true);});page.addView(portal,pp);
        }
        View leftEdge=new View(this),rightEdge=new View(this);int ew=Math.max(dp(34),Math.round(w*.075f));FrameLayout.LayoutParams lep=new FrameLayout.LayoutParams(ew,-1,Gravity.LEFT),rep=new FrameLayout.LayoutParams(ew,-1,Gravity.RIGHT);page.addView(leftEdge,lep);page.addView(rightEdge,rep);installDreamDragEdge(leftEdge,-1);installDreamDragEdge(rightEdge,1);
        final float[] bgDown={0f,0f,0f,0f};final Runnable[] none={null};page.setClickable(true);page.setOnTouchListener((v,e)->handleDreamGridTouch(v,e,-1,bgDown,none));return page;
    }
    private void installDreamDragEdge(View edge,final int direction){
        edge.setClickable(false);edge.setOnDragListener((v,e)->{
            if(e.getAction()==android.view.DragEvent.ACTION_DRAG_STARTED)return true;
            if(e.getAction()==android.view.DragEvent.ACTION_DRAG_ENTERED){scheduleDreamEdgeSwitch(direction);return true;}
            if(e.getAction()==android.view.DragEvent.ACTION_DRAG_EXITED||e.getAction()==android.view.DragEvent.ACTION_DRAG_ENDED){cancelDreamEdgeSwitch();return true;}return true;
        });
    }
    private void cancelDreamEdgeSwitch(){if(dreamEdgeSwitchRunnable!=null&&dreamPagerRoot!=null)dreamPagerRoot.removeCallbacks(dreamEdgeSwitchRunnable);dreamEdgeSwitchRunnable=null;}
    private void scheduleDreamEdgeSwitch(final int direction){
        cancelDreamEdgeSwitch();if(dreamDraggingSlot<0||dreamPagerRoot==null)return;final int target=dreamPage+direction;if(target<0||target>maxUnlockedDreamPage()||!dreamPagerPages.containsKey(target))return;
        dreamEdgeSwitchRunnable=()->{if(dreamDraggingSlot<0||!isDreamPalaceScreen||dreamPagerRoot==null)return;dreamDragPageShifted=true;animateDreamPagerTo(target,980,false);};dreamPagerRoot.postDelayed(dreamEdgeSwitchRunnable,520);
    }
    private void animateDreamPagerTo(final int target,long duration,boolean rebuildAfter){
        if(dreamPagerRoot==null||target==dreamPage)return;int w=dreamPagerRoot.getWidth();if(w<=0)return;dreamPageAnimating=true;dreamPage=target;
        for(java.util.Map.Entry<Integer,FrameLayout> e:dreamPagerPages.entrySet()){int p=e.getKey();e.getValue().animate().translationX((p-target)*w).setDuration(duration).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();}
        dreamPagerRoot.postDelayed(()->{dreamPageAnimating=false;if(rebuildAfter&&dreamDraggingSlot<0)showDreamPalace(target);},duration+30);
    }
    private boolean handleDreamGridTouch(View v,MotionEvent e,int slot,float[] down,Runnable[] dragStart){
        if(e==null)return true;if(e.getActionMasked()==MotionEvent.ACTION_DOWN){down[0]=e.getX();down[1]=e.getY();down[2]=android.os.SystemClock.uptimeMillis();down[3]=0f;if(slot>=0&&hasDream(slot)){dragStart[0]=()->{if(down[3]==0f&&isDreamPalaceScreen){down[3]=1f;playUiClick();dreamDraggingSlot=slot;dreamDragPageShifted=false;v.animate().scaleX(1.06f).scaleY(1.06f).alpha(.94f).setDuration(140).start();v.setElevation(dp(9));try{android.content.ClipData clip=android.content.ClipData.newPlainText("dream_slot",String.valueOf(slot));v.startDragAndDrop(clip,new View.DragShadowBuilder(v),Integer.valueOf(slot),0);}catch(Exception ignored){dreamDraggingSlot=-1;v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).start();v.setElevation(0f);}}};v.postDelayed(dragStart[0],430);}return true;}
        if(e.getActionMasked()==MotionEvent.ACTION_MOVE){float dx=e.getX()-down[0],dy=e.getY()-down[1];if(down[3]==0f&&(Math.abs(dx)>dp(16)||Math.abs(dy)>dp(16))&&dragStart[0]!=null){v.removeCallbacks(dragStart[0]);dragStart[0]=null;}return true;}
        if(e.getActionMasked()==MotionEvent.ACTION_CANCEL){if(dragStart[0]!=null)v.removeCallbacks(dragStart[0]);dragStart[0]=null;return true;}
        if(e.getActionMasked()==MotionEvent.ACTION_UP){if(dragStart[0]!=null)v.removeCallbacks(dragStart[0]);dragStart[0]=null;if(down[3]==1f)return true;float dx=e.getX()-down[0],dy=e.getY()-down[1];long ms=android.os.SystemClock.uptimeMillis()-(long)down[2];if(Math.abs(dx)>dp(52)&&Math.abs(dx)>Math.abs(dy)*1.25f){if(dx<0&&dreamPage<maxUnlockedDreamPage())switchDreamPage(dreamPage+1,1);else if(dx>0&&dreamPage>0)switchDreamPage(dreamPage-1,-1);return true;}if(slot>=0&&Math.abs(dx)<dp(18)&&Math.abs(dy)<dp(18)&&ms<650){playUiClick();if(hasDream(slot))showDreamViewerFromGrid(v,slot,false);else beginAddDream(slot);return true;}return true;}return true;
    }
    private void switchDreamPage(int target,int direction){int max=maxUnlockedDreamPage();final int dest=Math.max(0,Math.min(target,max));if(dest==dreamPage||dreamPageAnimating)return;if(dreamPagerPages.containsKey(dest)){animateDreamPagerTo(dest,980,true);return;}showDreamPalace(dest);}

    private void beginAddDream(int slot){pendingDreamSlot=slot;pendingDreamEditing=false;pendingDreamReturnToViewer=false;pendingDreamSequenceMode=false;pendingDreamTempPath=null;pendingDreamOriginalTempPath=null;launchDreamImagePicker();}
    private void launchDreamImagePicker(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_DREAM_IMAGE);}catch(Exception e){Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");startActivityForResult(i,REQ_DREAM_IMAGE);}}
    private android.graphics.Bitmap decodeDreamUri(android.net.Uri uri,int maxDim){
        try{android.graphics.BitmapFactory.Options o=new android.graphics.BitmapFactory.Options();o.inJustDecodeBounds=true;try(java.io.InputStream in=getContentResolver().openInputStream(uri)){android.graphics.BitmapFactory.decodeStream(in,null,o);}int sample=1;while(o.outWidth/sample>maxDim*2||o.outHeight/sample>maxDim*2)sample*=2;o=new android.graphics.BitmapFactory.Options();o.inSampleSize=Math.max(1,sample);o.inPreferredConfig=android.graphics.Bitmap.Config.ARGB_8888;android.graphics.Bitmap b;try(java.io.InputStream in=getContentResolver().openInputStream(uri)){b=android.graphics.BitmapFactory.decodeStream(in,null,o);}if(b==null)return null;int rot=0;try(java.io.InputStream in=getContentResolver().openInputStream(uri)){android.media.ExifInterface ex=new android.media.ExifInterface(in);int or=ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,android.media.ExifInterface.ORIENTATION_NORMAL);if(or==android.media.ExifInterface.ORIENTATION_ROTATE_90)rot=90;else if(or==android.media.ExifInterface.ORIENTATION_ROTATE_180)rot=180;else if(or==android.media.ExifInterface.ORIENTATION_ROTATE_270)rot=270;}catch(Exception ignored){}if(rot!=0){android.graphics.Matrix m=new android.graphics.Matrix();m.postRotate(rot);android.graphics.Bitmap r=android.graphics.Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);if(r!=b)b.recycle();b=r;}return b;}catch(Exception e){return null;}
    }
    private void applyDialogSafeInsets(final View target){if(target==null)return;target.setOnApplyWindowInsetsListener((v,insets)->{int l=0,t=0,r=0,b=0;if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets q=insets.getInsets(android.view.WindowInsets.Type.systemBars());l=q.left;t=q.top;r=q.right;b=q.bottom;}else{l=insets.getSystemWindowInsetLeft();t=insets.getSystemWindowInsetTop();r=insets.getSystemWindowInsetRight();b=insets.getSystemWindowInsetBottom();}v.setPadding(l,t,r,b);return insets;});target.post(()->target.requestApplyInsets());}
    private void deleteTempDreamFile(String path){try{if(path!=null&&path.length()>0&&path.contains(getCacheDir().getAbsolutePath()))new java.io.File(path).delete();}catch(Exception ignored){}}
    private void showDreamCropDialog(android.net.Uri uri,int slot){
        android.graphics.Bitmap bm=decodeDreamUri(uri,2600);if(bm==null){Toast.makeText(this,"عکس باز نشد",Toast.LENGTH_SHORT).show();return;}
        try{java.io.File originalTmp=new java.io.File(getCacheDir(),"dream_original_pending_"+slot+"_"+System.currentTimeMillis()+".img");copyDreamUriRaw(uri,originalTmp);pendingDreamOriginalTempPath=originalTmp.getAbsolutePath();}catch(Exception ex){try{bm.recycle();}catch(Exception ignored){}Toast.makeText(this,"ذخیره عکس انجام نشد",Toast.LENGTH_SHORT).show();return;}
        final Dialog d=new Dialog(this,android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);FrameLayout rootCrop=new FrameLayout(this);rootCrop.setBackgroundColor(THEME_FALLBACK);applyDialogSafeInsets(rootCrop);DreamCropView crop=new DreamCropView(this,bm);rootCrop.addView(crop,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout cropTitle=new LinearLayout(this);cropTitle.setGravity(Gravity.CENTER);cropTitle.setPadding(dp(10),0,dp(10),0);GradientDrawable ctg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xEAF3F7FF,0xEAF8F4FF});ctg.setCornerRadius(dp(999));ctg.setStroke(Math.max(1,dp(1)),0x554D8DFF);cropTitle.setBackground(ctg);cropTitle.setElevation(dp(4));TextView cropAsset=tv("✦",22,0xFF4D8EFF);TextView cropName=tv("  تنظیم قاب آرزو",14,0xFF17345D);cropTitle.addView(cropAsset,new LinearLayout.LayoutParams(dp(34),dp(38)));cropTitle.addView(cropName,new LinearLayout.LayoutParams(-2,dp(38)));FrameLayout.LayoutParams ctlp=new FrameLayout.LayoutParams(-2,dp(42),Gravity.TOP|Gravity.CENTER_HORIZONTAL);ctlp.topMargin=dp(10);rootCrop.addView(cropTitle,ctlp);
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER);bar.setPadding(dp(14),dp(8),dp(14),dp(12));GradientDrawable cropBarBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xF3F8FCFF,0xEEF0F7FF});cropBarBg.setStroke(Math.max(1,dp(1)),0x554D8DFF);bar.setBackground(cropBarBg);TextView cancel=dreamGoldButton("لغو",false),save=dreamGoldButton("تأیید برش",true);bar.addView(cancel,new LinearLayout.LayoutParams(0,dp(48),1f));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(0,dp(48),1f);slp.leftMargin=dp(10);bar.addView(save,slp);FrameLayout.LayoutParams blp=new FrameLayout.LayoutParams(-1,dp(76),Gravity.BOTTOM);rootCrop.addView(bar,blp);
        cancel.setOnClickListener(v->{playUiClick();d.dismiss();deleteTempDreamFile(pendingDreamOriginalTempPath);pendingDreamOriginalTempPath=null;try{bm.recycle();}catch(Exception ignored){}});
        save.setOnClickListener(v->{playSfx(sfxConfirmId,.76f);android.graphics.Bitmap out=crop.croppedBitmap(1035,1000);if(out==null)return;try{java.io.File tmp=new java.io.File(getCacheDir(),"dream_pending_"+slot+"_"+System.currentTimeMillis()+".jpg");saveBitmapJpeg(out,tmp,96);out.recycle();pendingDreamTempPath=tmp.getAbsolutePath();d.dismiss();try{bm.recycle();}catch(Exception ignored){}showDreamMetaDialog(slot,pendingDreamEditing,pendingDreamTempPath,pendingDreamOriginalTempPath,pendingDreamReturnToViewer,pendingDreamSequenceMode);}catch(Exception ex){Toast.makeText(this,"ذخیره عکس انجام نشد",Toast.LENGTH_SHORT).show();}});
        d.setContentView(rootCrop);d.setOnCancelListener(x->{deleteTempDreamFile(pendingDreamOriginalTempPath);pendingDreamOriginalTempPath=null;try{bm.recycle();}catch(Exception ignored){}});d.show();
    }
    private TextView dreamGoldButton(String text,boolean primary){TextView b=dialogButton(text,primary?0xFF4E8CFF:0xFFF8FAFF,primary?0xFF7B61FF:0xFFEFF3FB,!primary);if(!primary){GradientDrawable g=pastelButtonBg(0xFFF8FAFF,0xFFEFF3FB);g.setStroke(Math.max(1,dp(1)),0x334D6B9A);b.setBackground(g);}return b;}
    private EditText dreamField(String hint,String text,boolean numeric){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(text==null?"":text);e.setTextSize(15);e.setTextColor(0xFF17345D);e.setHintTextColor(0x99677B9A);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(13),0,dp(13),0);GradientDrawable g=bg(0xFFF8FAFF,dp(13));g.setStroke(Math.max(1,dp(1)),0x334D6B9A);e.setBackground(g);if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER);return e;}
    private TextView dreamSelectField(String text){TextView v=tv(text==null?"":text,15,0xFF17345D);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(dp(13),0,dp(13),0);GradientDrawable g=bg(0xFFF8FAFF,dp(13));g.setStroke(Math.max(1,dp(1)),0x334D6B9A);v.setBackground(g);return v;}
    private void showDreamYearPicker(final TextView target,final java.util.ArrayList<String> years,final String[] selected){
        ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));final Dialog[] ref={null};
        for(String y:years){final String yy=y;TextView row=tv((yy.equals(selected[0])?"✓  ":"")+yy,14,0xFF17345D);row.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);row.setPadding(dp(14),0,dp(14),0);GradientDrawable rg=bg(yy.equals(selected[0])?0xFFEAF4FF:0xFFF8FAFF,dp(12));rg.setStroke(Math.max(1,dp(1)),yy.equals(selected[0])?0x664D8DFF:0x223B6DA8);row.setBackground(rg);LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(46));rlp.bottomMargin=dp(6);list.addView(row,rlp);row.setOnClickListener(v->{playUiClick();selected[0]=yy;target.setText(yy);if(ref[0]!=null)ref[0].dismiss();});}
        Dialog d=buildPastelDialog("✦","سال هدف",null,0xFF4D8EFF,scroll,null,0,null,null,null);ref[0]=d;Window w=d.getWindow();if(w!=null){WindowManager.LayoutParams a=w.getAttributes();a.height=Math.min(dp(480),getResources().getDisplayMetrics().heightPixels-dp(80));w.setAttributes(a);}d.show();
    }
    private void showDreamMetaDialog(int slot,boolean editing,String candidatePath,String candidateOriginalPath,boolean returnViewer,boolean sequenceMode){
        final Dialog d=new Dialog(this,R.style.InstantDialogTheme);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(18),dp(12),dp(18),dp(18));card.setBackground(pastelCardBg(0xFF4D8EFF));card.setElevation(dp(8));
        FrameLayout dreamTop=new FrameLayout(this);card.addView(dreamTop,new LinearLayout.LayoutParams(-1,dp(52)));TextView close=tv("×",22,0xFF29436E);close.setGravity(Gravity.CENTER);FrameLayout.LayoutParams xlp=new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.RIGHT|Gravity.TOP);dreamTop.addView(close,xlp);TextView asset=tv("✦",28,0xFF4D8EFF);asset.setGravity(Gravity.CENTER);GradientDrawable ag=bg(0xEAF3F7FF,dp(999));ag.setStroke(Math.max(1,dp(1)),0x443B7CFF);asset.setBackground(ag);FrameLayout.LayoutParams ailp=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.CENTER);dreamTop.addView(asset,ailp);TextView head=tv(editing?"ویرایش آرزو":"آرزوی جدید",20,0xFF142C54);head.setGravity(Gravity.CENTER);card.addView(head,new LinearLayout.LayoutParams(-1,dp(42)));
        if(candidatePath!=null||hasDream(slot)){FrameLayout previewWrap=new FrameLayout(this);LinearLayout.LayoutParams pwp=new LinearLayout.LayoutParams(-1,dp(218));pwp.setMargins(0,dp(4),0,dp(12));card.addView(previewWrap,pwp);DreamThumbView preview=new DreamThumbView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);android.graphics.Bitmap pb=decodeDreamFile(candidatePath!=null?candidatePath:dreamThumbPath(slot),700);if(pb!=null)preview.setImageBitmap(pb);FrameLayout.LayoutParams pvlp=new FrameLayout.LayoutParams(dp(208),dp(202),Gravity.CENTER);previewWrap.addView(preview,pvlp);}
        EditText title=dreamField("عنوان آرزو",editing?dreamTitle(slot):"",false);card.addView(title,new LinearLayout.LayoutParams(-1,dp(50)));TextView yearLabel=tv("سال هدف",12,0xFF536785);yearLabel.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams yll=new LinearLayout.LayoutParams(-1,dp(28));yll.topMargin=dp(8);card.addView(yearLabel,yll);
        java.util.ArrayList<String> yrs=new java.util.ArrayList<>();int cy=currentJalaliYear();for(int i=0;i<=10;i++)yrs.add(String.valueOf(cy+i));String sy=editing?dreamYear(slot):String.valueOf(cy);if(sy!=null&&sy.length()>0&&!yrs.contains(sy)){yrs.add(sy);java.util.Collections.sort(yrs,(a,b)->{try{return Integer.compare(Integer.parseInt(a),Integer.parseInt(b));}catch(Exception e){return a.compareTo(b);}});}final String[] selectedYear={sy==null||sy.length()==0?String.valueOf(cy):sy};TextView year=dreamSelectField(selectedYear[0]);year.setContentDescription("سال هدف");year.setOnClickListener(v->{playUiClick();showDreamYearPicker(year,yrs,selectedYear);});card.addView(year,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText price=dreamField("مبلغ دلاری",editing?formatDreamPrice(dreamPrice(slot)):"",true);LinearLayout.LayoutParams prp=new LinearLayout.LayoutParams(-1,dp(50));prp.topMargin=dp(9);card.addView(price,prp);final boolean[] guard={false};price.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){}public void afterTextChanged(android.text.Editable e){if(guard[0])return;String f=formatDreamPrice(e.toString());if(!f.equals(e.toString())){guard[0]=true;price.setText(f);price.setSelection(f.length());guard[0]=false;}}});
        if(editing){TextView change=dreamGoldButton("تغییر عکس",false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(44));cp.topMargin=dp(9);card.addView(change,cp);change.setOnClickListener(v->{playUiClick();d.dismiss();pendingDreamSlot=slot;pendingDreamEditing=true;pendingDreamReturnToViewer=returnViewer;pendingDreamSequenceMode=sequenceMode;pendingDreamTempPath=null;pendingDreamOriginalTempPath=null;launchDreamImagePicker();});TextView del=dreamGoldButton("حذف آرزو",false);del.setTextColor(0xFFB53C61);GradientDrawable dg=bg(0xFFFFF7FA,dp(14));dg.setStroke(Math.max(1,dp(1)),0x55D25A79);del.setBackground(dg);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,dp(42));dlp.topMargin=dp(8);card.addView(del,dlp);del.setOnClickListener(v->{playUiClick();Dialog confirm=buildPastelDialog("✦","حذف آرزو","",0xFF7B61FF,null,"حذف",0xFFD94B70,()->{d.dismiss();deleteDreamAt(slot,returnViewer,sequenceMode);},"لغو",null);confirm.show();});}
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setGravity(Gravity.CENTER);actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(50));alp.topMargin=dp(13);card.addView(actions,alp);TextView save=dreamGoldButton("ذخیره",true),cancel=dreamGoldButton("لغو",false);actions.addView(save,new LinearLayout.LayoutParams(0,-1,1f));LinearLayout.LayoutParams cvp=new LinearLayout.LayoutParams(0,-1,1f);cvp.leftMargin=dp(10);actions.addView(cancel,cvp);
        Runnable dreamCancel=()->{deleteTempDreamFile(candidatePath);deleteTempDreamFile(candidateOriginalPath);pendingDreamTempPath=null;pendingDreamOriginalTempPath=null;};cancel.setOnClickListener(v->{playUiClick();dreamCancel.run();d.dismiss();});close.setOnClickListener(v->{playUiClick();dreamCancel.run();d.dismiss();});
        save.setOnClickListener(v->{
            playSfx(sfxConfirmId,.78f);String t=title.getText().toString().trim(),y=selectedYear[0],p=digitsOnly(price.getText().toString());String oldThumb=dreamThumbPath(slot),oldOriginal=dreamOriginalPath(slot),finalThumb=oldThumb,finalOriginal=oldOriginal;
            try{if(candidatePath!=null&&candidatePath.length()>0){java.io.File dest=dreamAssetFile(slot,"thumb");copyFile(new java.io.File(candidatePath),dest);finalThumb=dest.getAbsolutePath();}if(candidateOriginalPath!=null&&candidateOriginalPath.length()>0){java.io.File dest=dreamAssetFile(slot,"original");copyFile(new java.io.File(candidateOriginalPath),dest);finalOriginal=dest.getAbsolutePath();}}catch(Exception ex){Toast.makeText(this,"ذخیره عکس انجام نشد",Toast.LENGTH_SHORT).show();return;}
            if(finalThumb==null||finalThumb.length()==0||!new java.io.File(finalThumb).exists()){Toast.makeText(this,"یک عکس انتخاب کن",Toast.LENGTH_SHORT).show();return;}if(finalOriginal==null||finalOriginal.length()==0||!new java.io.File(finalOriginal).exists())finalOriginal=finalThumb;
            boolean was=hasDream(slot);dreamPrefs().edit().putString(dreamKey(slot,"path"),finalThumb).putString(dreamKey(slot,"original"),finalOriginal).putString(dreamKey(slot,"title"),t).putString(dreamKey(slot,"year"),y).putString(dreamKey(slot,"price"),p).putInt("highest_slot",Math.max(highestDreamSlot(),slot)).apply();if(!was)appendDreamOrderIfNeeded(slot);clearDreamThumbCache();if(candidatePath!=null&&!java.util.Objects.equals(oldThumb,finalThumb))deleteDreamFileIfUnused(oldThumb);if(candidateOriginalPath!=null&&!java.util.Objects.equals(oldOriginal,finalOriginal)&&!java.util.Objects.equals(oldOriginal,oldThumb))deleteDreamFileIfUnused(oldOriginal);
            d.dismiss();deleteTempDreamFile(candidatePath);deleteTempDreamFile(candidateOriginalPath);pendingDreamTempPath=null;pendingDreamOriginalTempPath=null;if(returnViewer)showDreamViewer(slot,sequenceMode);else showDreamPalace(slot/20);
        });
        d.setContentView(card);d.setCanceledOnTouchOutside(true);d.setOnCancelListener(x->dreamCancel.run());Window w=d.getWindow();if(w!=null){w.setWindowAnimations(0);w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));WindowManager.LayoutParams a=w.getAttributes();a.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(390));a.height=WindowManager.LayoutParams.WRAP_CONTENT;a.gravity=Gravity.CENTER;a.dimAmount=.28f;w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setAttributes(a);}d.show();
    }

    private class DreamCropView extends View{
        private final android.graphics.Bitmap bitmap;private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);private final RectF crop=new RectF();private float scale=1f,minScale=1f,tx=0f,ty=0f,lastX,lastY;private boolean dragging=false;private final android.view.ScaleGestureDetector scaler;
        DreamCropView(android.content.Context c,android.graphics.Bitmap b){super(c);bitmap=b;setBackgroundColor(THEME_FALLBACK);scaler=new android.view.ScaleGestureDetector(c,new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(android.view.ScaleGestureDetector d){float old=scale;scale=Math.max(minScale,Math.min(minScale*6f,scale*d.getScaleFactor()));float ratio=scale/old,fx=d.getFocusX(),fy=d.getFocusY();tx=fx-(fx-tx)*ratio;ty=fy-(fy-ty)*ratio;clamp();invalidate();return true;}});}
        @Override protected void onSizeChanged(int w,int h,int ow,int oh){float maxW=w*.88f,maxH=(h-dp(122))*.74f,ratio=1.035f,cw=maxW,ch=cw/ratio;if(ch>maxH){ch=maxH;cw=ch*ratio;}crop.set((w-cw)/2f,(h-ch)/2f,(w+cw)/2f,(h+ch)/2f);minScale=Math.max(crop.width()/bitmap.getWidth(),crop.height()/bitmap.getHeight());scale=minScale;tx=crop.centerX()-bitmap.getWidth()*scale/2f;ty=crop.centerY()-bitmap.getHeight()*scale/2f;clamp();}
        private void clamp(){float bw=bitmap.getWidth()*scale,bh=bitmap.getHeight()*scale;if(tx>crop.left)tx=crop.left;if(ty>crop.top)ty=crop.top;if(tx+bw<crop.right)tx=crop.right-bw;if(ty+bh<crop.bottom)ty=crop.bottom-bh;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);android.graphics.Matrix m=new android.graphics.Matrix();m.postScale(scale,scale);m.postTranslate(tx,ty);c.drawBitmap(bitmap,m,p);p.setStyle(Paint.Style.FILL);p.setColor(0xAAEAF4FF);c.drawRect(0,0,getWidth(),crop.top,p);c.drawRect(0,crop.bottom,getWidth(),getHeight(),p);c.drawRect(0,crop.top,crop.left,crop.bottom,p);c.drawRect(crop.right,crop.top,getWidth(),crop.bottom,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));p.setColor(THEME_PRIMARY);p.setShadowLayer(dp(3),0,0,0x6655C8FF);c.drawRoundRect(crop,dp(20),dp(20),p);p.clearShadowLayer();}
        @Override public boolean onTouchEvent(MotionEvent e){scaler.onTouchEvent(e);switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:lastX=e.getX();lastY=e.getY();dragging=true;return true;case MotionEvent.ACTION_MOVE:if(e.getPointerCount()==1&&!scaler.isInProgress()&&dragging){float dx=e.getX()-lastX,dy=e.getY()-lastY;tx+=dx;ty+=dy;lastX=e.getX();lastY=e.getY();clamp();invalidate();}return true;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:dragging=false;return true;}return true;}
        android.graphics.Bitmap croppedBitmap(int outW,int outH){if(crop.width()<=0||crop.height()<=0)return null;android.graphics.Bitmap out=android.graphics.Bitmap.createBitmap(outW,outH,android.graphics.Bitmap.Config.ARGB_8888);Canvas c=new Canvas(out);float uniform=outW/crop.width();c.scale(uniform,uniform);c.translate(-crop.left,-crop.top);android.graphics.Matrix m=new android.graphics.Matrix();m.postScale(scale,scale);m.postTranslate(tx,ty);c.drawBitmap(bitmap,m,p);return out;}
    }

    private FrameLayout buildDreamViewer(final int slot,final boolean sequenceMode){
        FrameLayout viewer=new FrameLayout(this);viewer.setBackgroundColor(THEME_FALLBACK);android.graphics.Bitmap bm=loadDreamOriginalBitmap(slot,2400);
        ImageView backdrop=new ImageView(this);backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);if(bm!=null)backdrop.setImageBitmap(bm);backdrop.setAlpha(.34f);if(android.os.Build.VERSION.SDK_INT>=31){try{backdrop.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(16),dp(16),android.graphics.Shader.TileMode.CLAMP));}catch(Exception ignored){}}viewer.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);shade.setBackgroundColor(0x44F4F9FF);viewer.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        final int infoReserve=dp(112);ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setAdjustViewBounds(false);if(bm!=null)image.setImageBitmap(bm);FrameLayout.LayoutParams imageLp=new FrameLayout.LayoutParams(-1,-1);imageLp.setMargins(dp(10),dp(10),dp(10),infoReserve);viewer.addView(image,imageLp);

        String y=dreamYear(slot);TextView year=tv(y==null?"":y,16,THEME_TEXT);year.setGravity(Gravity.CENTER);GradientDrawable ybg=bg(0xEAF8FBFF,dp(15));ybg.setStroke(Math.max(1,dp(1)),0x7754A9FF);year.setBackground(ybg);year.setPadding(dp(13),0,dp(13),0);FrameLayout.LayoutParams ylp=new FrameLayout.LayoutParams(-2,dp(38),Gravity.TOP|Gravity.LEFT);ylp.leftMargin=dp(18);ylp.topMargin=dp(18);viewer.addView(year,ylp);

        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);info.setPadding(dp(10),0,dp(10),0);info.setBackground(pastelCardBg(THEME_PRIMARY));String t=dreamTitle(slot);TextView title=tv(t.length()>0?t:"آرزوی من",21,THEME_TEXT);title.setGravity(Gravity.CENTER);info.addView(title,new LinearLayout.LayoutParams(-1,dp(31)));String p=dreamPrice(slot);
        if(p!=null&&p.length()>0){LinearLayout money=new LinearLayout(this);money.setOrientation(LinearLayout.HORIZONTAL);money.setGravity(Gravity.CENTER);TextView amount=tv(formatDreamPrice(p),15,0xFF8FD9FF);amount.setGravity(Gravity.CENTER);money.addView(amount,new LinearLayout.LayoutParams(-2,dp(27)));DollarAssetView dollar=new DollarAssetView(this);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(dp(24),dp(24));dlp.leftMargin=dp(5);money.addView(dollar,dlp);info.addView(money,new LinearLayout.LayoutParams(-1,dp(27)));}
        FrameLayout.LayoutParams ilp=new FrameLayout.LayoutParams(-1,dp(62),Gravity.BOTTOM);ilp.leftMargin=dp(14);ilp.rightMargin=dp(14);ilp.bottomMargin=dp(8);viewer.addView(info,ilp);

        year.setAlpha(0f);year.setTranslationY(-dp(5));info.setAlpha(0f);info.setTranslationY(dp(7));
        viewer.postDelayed(()->{year.animate().alpha(1f).translationY(0f).setDuration(210).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();info.animate().alpha(1f).translationY(0f).setDuration(230).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();},55);

        if(bm!=null){final int bw=bm.getWidth(),bh=bm.getHeight();viewer.post(()->{int boxW=Math.max(1,viewer.getWidth()-dp(20)),boxH=Math.max(1,viewer.getHeight()-infoReserve-dp(20));android.graphics.RectF rr=fitCenterRect(boxW,boxH,bw,bh);float actualLeft=dp(10)+rr.left,actualTop=dp(10)+rr.top;FrameLayout.LayoutParams yp=(FrameLayout.LayoutParams)year.getLayoutParams();yp.leftMargin=Math.round(actualLeft)+dp(12);yp.topMargin=Math.round(actualTop)+dp(12);year.setLayoutParams(yp);FrameLayout.LayoutParams ip=(FrameLayout.LayoutParams)info.getLayoutParams();ip.gravity=Gravity.TOP|Gravity.LEFT;ip.width=Math.max(dp(220),Math.min(viewer.getWidth()-dp(28),Math.round(rr.width())));ip.height=dp(62);ip.leftMargin=Math.max(dp(14),Math.round(actualLeft+(rr.width()-ip.width)/2f));ip.topMargin=Math.min(viewer.getHeight()-dp(66),Math.round(actualTop+rr.height())+dp(3));ip.bottomMargin=0;info.setLayoutParams(ip);});}

        final android.view.GestureDetector gd=new android.view.GestureDetector(this,new android.view.GestureDetector.SimpleOnGestureListener(){@Override public boolean onDown(MotionEvent e){return true;}@Override public void onLongPress(MotionEvent e){playUiClick();showDreamMetaDialog(slot,true,null,null,true,sequenceMode);}});final float[] touch={0f,0f};viewer.setOnTouchListener((v,e)->{gd.onTouchEvent(e);if(e.getActionMasked()==MotionEvent.ACTION_DOWN){touch[0]=e.getX();touch[1]=e.getY();return true;}if(e.getActionMasked()==MotionEvent.ACTION_UP&&sequenceMode&&!dreamViewerAnimating){float dx=e.getX()-touch[0],dy=e.getY()-touch[1];if(Math.abs(dy)>=dp(58)&&Math.abs(dy)>Math.abs(dx)*1.15f){java.util.ArrayList<Integer> o=dreamOrder();int idx=o.indexOf(slot);if(dy<0&&idx>=0&&idx<o.size()-1)switchDreamViewer(o.get(idx+1),1);else if(dy>0&&idx>0)switchDreamViewer(o.get(idx-1),-1);}}return true;});return viewer;
    }

    private void showDreamViewerFromGrid(View source,int slot,boolean sequenceMode){
        if(source==null||root==null||content==null){showDreamViewer(slot,sequenceMode);return;}
        int[] sl={0,0},rl={0,0};source.getLocationInWindow(sl);root.getLocationInWindow(rl);int sw=Math.max(1,source.getWidth()),sh=Math.max(1,source.getHeight());android.graphics.Bitmap thumb=loadDreamThumbBitmap(slot,700);
        showDreamViewer(slot,sequenceMode);if(thumb==null||root==null)return;
        final DreamThumbView fly=new DreamThumbView(this);fly.setImageBitmap(thumb);fly.setChosenBorder(false);fly.setScaleType(ImageView.ScaleType.CENTER_CROP);FrameLayout.LayoutParams flp=new FrameLayout.LayoutParams(sw,sh);flp.leftMargin=sl[0]-rl[0];flp.topMargin=sl[1]-rl[1];root.addView(fly,flp);fly.setElevation(dp(20));
        View under=content.getChildCount()>0?content.getChildAt(content.getChildCount()-1):null;if(under!=null){under.setAlpha(.28f);under.animate().alpha(1f).setDuration(320).start();}
        android.graphics.Bitmap original=loadDreamOriginalBitmap(slot,1200);int bw=original!=null?original.getWidth():sw,bh=original!=null?original.getHeight():sh;int cw=Math.max(1,content.getWidth()),ch=Math.max(1,content.getHeight());android.graphics.RectF rr=fitCenterRect(Math.max(1,cw-dp(20)),Math.max(1,ch-dp(132)),bw,bh);int[] cl={0,0};content.getLocationInWindow(cl);float tx=(cl[0]-rl[0])+dp(10)+rr.left,ty=(cl[1]-rl[1])+dp(10)+rr.top,tsx=Math.max(.01f,rr.width()/sw),tsy=Math.max(.01f,rr.height()/sh);if(original!=null&&!original.isRecycled())original.recycle();
        fly.animate().x(tx).y(ty).scaleX(tsx).scaleY(tsy).alpha(.08f).setDuration(320).setInterpolator(new android.view.animation.DecelerateInterpolator()).withEndAction(()->{try{root.removeView(fly);}catch(Exception ignored){}}).start();
    }

    private void showDreamViewer(int slot,boolean sequenceMode){if(!hasDream(slot)){showDreamPalace(Math.max(0,slot/20));return;}stopHomeActiveTicker();removeHomeOnlyOverlays();isHome=false;isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;isTreeScreen=false;isDreamPalaceScreen=false;isDreamViewerScreen=true;isTimeTravelScreen=false;isShopScreen=false;dreamViewerSlot=slot;dreamViewerSequenceMode=sequenceMode;dreamViewerAnimating=false;++homeGeneration;if(hudHeader!=null)hudHeader.setVisibility(View.VISIBLE);removeActiveMissionBar();content.setTranslationX(0f);content.setTranslationY(0f);content.setAlpha(1f);content.removeAllViews();content.addView(buildDreamViewer(slot,sequenceMode),new FrameLayout.LayoutParams(-1,-1));if(hudHeader!=null)hudHeader.bringToFront();}
    private void switchDreamViewer(int newSlot,int direction){if(dreamViewerAnimating||!hasDream(newSlot)||content==null)return;dreamViewerAnimating=true;final View old=content.getChildCount()>0?content.getChildAt(content.getChildCount()-1):null;final FrameLayout next=buildDreamViewer(newSlot,true);int h=Math.max(content.getHeight(),getResources().getDisplayMetrics().heightPixels);float travel=Math.max(dp(240),h*.68f);next.setTranslationY(direction>0?travel:-travel);next.setAlpha(.66f);content.addView(next,new FrameLayout.LayoutParams(-1,-1));if(old!=null)old.animate().translationY(direction>0?-travel:travel).alpha(.48f).setDuration(360).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();next.animate().translationY(0f).alpha(1f).setDuration(360).setInterpolator(new android.view.animation.DecelerateInterpolator()).withEndAction(()->{if(old!=null)content.removeView(old);dreamViewerSlot=newSlot;dreamViewerSequenceMode=true;dreamViewerAnimating=false;}).start();}

    private SharedPreferences shopPrefs(){
        return getSharedPreferences("legacy_shop_v2",MODE_PRIVATE);
    }
    private java.util.ArrayList<ShopItem> defaultShopItems(){
        java.util.ArrayList<ShopItem> out=new java.util.ArrayList<>();
        out.add(new ShopItem("coffee","قهوه","استراحت و انرژی",2,0));
        out.add(new ShopItem("movie","فیلم","یک حال خوب کوتاه",5,1));
        out.add(new ShopItem("popcorn","پاپ‌کورن","میان‌وعده سینمایی",4,2));
        out.add(new ShopItem("dessert","دسر","جایزه شیرین",3,3));
        out.add(new ShopItem("discount","کد تخفیف خرید","پاداش خرید",8,5));
        out.add(new ShopItem("gift","هدیه ویژه","پاداش خاص",10,4));
        return out;
    }
    private String shopIconOf(int index){
        if(shopRewardIcons.length==0)return "✦";
        int idx=((index%shopRewardIcons.length)+shopRewardIcons.length)%shopRewardIcons.length;
        return shopRewardIcons[idx];
    }
    private String shopIconNameOf(int index){
        if(shopRewardIconNames.length==0)return "آیکن";
        int idx=((index%shopRewardIconNames.length)+shopRewardIconNames.length)%shopRewardIconNames.length;
        return shopRewardIconNames[idx];
    }
    private java.util.ArrayList<ShopItem> loadShopItems(){
        java.util.ArrayList<ShopItem> out=new java.util.ArrayList<>();
        String raw=shopPrefs().getString("items_json",null);
        if(raw==null||raw.trim().length()==0)return defaultShopItems();
        try{
            org.json.JSONArray arr=new org.json.JSONArray(raw);
            for(int i=0;i<arr.length();i++){
                org.json.JSONObject o=arr.getJSONObject(i);
                String id=o.optString("id","shop_"+i);
                String title=o.optString("title","پاداش");
                String subtitle=o.optString("subtitle","");
                int price=Math.max(0,o.optInt("price",0));
                int iconIndex=o.optInt("iconIndex",0);
                boolean oneTime=o.optBoolean("oneTime",false);
                out.add(new ShopItem(id,title,subtitle,price,iconIndex,oneTime));
            }
        }catch(Exception ignored){return defaultShopItems();}
        return out;
    }
    private void saveShopItems(java.util.ArrayList<ShopItem> items){
        org.json.JSONArray arr=new org.json.JSONArray();
        try{
            for(ShopItem item:items){
                if(item==null)continue;
                org.json.JSONObject o=new org.json.JSONObject();
                o.put("id",item.id==null?"shop_"+System.currentTimeMillis():item.id);
                o.put("title",item.title==null?"":item.title);
                o.put("subtitle",item.subtitle==null?"":item.subtitle);
                o.put("price",Math.max(0,item.price));
                o.put("iconIndex",item.iconIndex);
                o.put("oneTime",item.oneTime);
                arr.put(o);
            }
        }catch(Exception ignored){}
        shopPrefs().edit().putString("items_json",arr.toString()).apply();
    }
    private String selectedShopItemId(){
        return shopPrefs().getString("selected_item","");
    }
    private void setSelectedShopItemId(String id){
        shopPrefs().edit().putString("selected_item",id==null?"":id).apply();
    }
    private ShopItem findShopItem(java.util.ArrayList<ShopItem> items,String id){
        if(items==null||items.isEmpty())return null;
        for(ShopItem item:items)if(item!=null&&item.id!=null&&item.id.equals(id))return item;
        return null;
    }
    private int shopRedeemCount(String itemId){
        return shopPrefs().getInt("count_"+itemId,0);
    }
    private void setShopRedeemCount(String itemId,int count){
        shopPrefs().edit().putInt("count_"+itemId,Math.max(0,count)).apply();
    }
    private java.util.ArrayList<ShopPurchase> loadShopPurchases(){
        java.util.ArrayList<ShopPurchase> out=new java.util.ArrayList<>();String raw=shopPrefs().getString("purchases_json","[]");
        try{org.json.JSONArray arr=new org.json.JSONArray(raw);for(int i=0;i<arr.length();i++){org.json.JSONObject o=arr.getJSONObject(i);out.add(new ShopPurchase(o.optString("purchaseId","p_"+i),o.optString("itemId",""),o.optString("title","پاداش"),Math.max(0,o.optInt("price",0)),o.optInt("iconIndex",0),o.optBoolean("oneTime",false),o.optLong("boughtAt",0L)));}}catch(Exception ignored){}
        java.util.Collections.sort(out,(a,b)->Long.compare(b.boughtAt,a.boughtAt));return out;
    }
    private void saveShopPurchases(java.util.ArrayList<ShopPurchase> items){
        org.json.JSONArray arr=new org.json.JSONArray();try{for(ShopPurchase x:items){if(x==null)continue;org.json.JSONObject o=new org.json.JSONObject();o.put("purchaseId",x.purchaseId);o.put("itemId",x.itemId);o.put("title",x.title);o.put("price",x.price);o.put("iconIndex",x.iconIndex);o.put("oneTime",x.oneTime);o.put("boughtAt",x.boughtAt);arr.put(o);}}catch(Exception ignored){}shopPrefs().edit().putString("purchases_json",arr.toString()).apply();
    }
    private void addShopPurchase(ShopItem item){long now=System.currentTimeMillis();java.util.ArrayList<ShopPurchase> list=loadShopPurchases();list.add(0,new ShopPurchase("p_"+now+"_"+Math.abs((item.id+now).hashCode()),item.id,item.title,item.price,item.iconIndex,item.oneTime,now));saveShopPurchases(list);}
    private void removeShopPurchase(String purchaseId){java.util.ArrayList<ShopPurchase> list=loadShopPurchases();java.util.Iterator<ShopPurchase> it=list.iterator();while(it.hasNext())if(it.next().purchaseId.equals(purchaseId)){it.remove();break;}saveShopPurchases(list);}
    private void restoreOneTimeRewardIfNeeded(ShopPurchase p){if(p==null||!p.oneTime)return;java.util.ArrayList<ShopItem> items=loadShopItems();if(findShopItem(items,p.itemId)==null){items.add(new ShopItem(p.itemId,p.title,"",p.price,p.iconIndex,true));saveShopItems(items);}}
    private TextView shopHeaderButton(String text){
        TextView b=tv(text,12,Color.WHITE);b.setGravity(Gravity.CENTER);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xFF5AA8FF,0xFF7D84FF});g.setCornerRadius(dp(14));b.setBackground(g);b.setPadding(dp(10),0,dp(10),0);b.setElevation(dp(2));return b;
    }
    private TextView shopPrimaryButton(String text){
        TextView b=tv(text,14,Color.WHITE);b.setGravity(Gravity.CENTER);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xFF57A1FF,0xFF7088FF});g.setCornerRadius(dp(18));b.setBackground(g);b.setElevation(dp(3));b.setPadding(dp(10),0,dp(10),0);return b;
    }
    private TextView shopSecondaryButton(String text){
        TextView b=tv(text,13,0xFF17345D);b.setGravity(Gravity.CENTER);GradientDrawable g=bg(0xFFF7FAFF,dp(16));g.setStroke(Math.max(1,dp(1)),0x33588CFF);b.setBackground(g);b.setPadding(dp(10),0,dp(10),0);return b;
    }
    private GradientDrawable shopPanelBg(){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xF2182942,0xEC233758,0xF226426A});
        g.setCornerRadius(dp(28));g.setStroke(Math.max(1,dp(1)),0x77B8D9FF);return g;
    }
    private GradientDrawable shopCardBg(boolean selected){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{selected?0xFFF7FBFF:0xFFF5F9FF,selected?0xFFE5F1FF:0xFFEAF2FF});
        g.setCornerRadius(dp(22));g.setStroke(Math.max(1,dp(1)),selected?0xFF67A7FF:0x5594B6E8);return g;
    }
    private GradientDrawable shopSummaryBg(){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xE834527D,0xE72B446B});
        g.setCornerRadius(dp(24));g.setStroke(Math.max(1,dp(1)),0x7799C6FF);return g;
    }
    private GradientDrawable shopIconCircle(boolean selected){
        GradientDrawable g=bg(selected?0xFFE0ECFF:0xFFE6F0FF,dp(999));g.setStroke(Math.max(1,dp(1)),selected?0xAA6BA9FF:0x55A0B8E8);return g;
    }
    private void showDeleteShopItemConfirm(final ShopItem item,final Runnable onDelete){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView txt=tv("پاداش \""+(item==null?"":item.title)+"\" حذف شود؟",14,0xFF17345D);txt.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);body.addView(txt,new LinearLayout.LayoutParams(-1,-2));
        Dialog d=buildPastelDialog("⌫","حذف پاداش","",0xFFD84B6A,body,"حذف",0xFFD84B6A,()->{if(onDelete!=null)onDelete.run();},"لغو",null);d.show();
    }
    private void showShopIconPicker(final int[] selectedIcon,final java.util.function.Consumer<Integer> onPick){
        final Dialog[] ref={null};
        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
        for(int row=0;row<shopRewardIcons.length;row+=4){
            LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);line.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(-1,-2);if(row>0)llp.topMargin=dp(8);body.addView(line,llp);
            for(int col=0;col<4;col++){
                int idx=row+col;if(idx>=shopRewardIcons.length)break;final int pick=idx;
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);card.setPadding(dp(6),dp(8),dp(6),dp(8));card.setClickable(true);card.setFocusable(true);card.setBackground(shopCardBg(pick==selectedIcon[0]));
                LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(0,-2,1f);if(col<3)clp.leftMargin=dp(8);line.addView(card,clp);
                TextView icon=tv(shopIconOf(pick),24,0xFF16335C);icon.setGravity(Gravity.CENTER);icon.setBackground(shopIconCircle(pick==selectedIcon[0]));LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(dp(44),dp(44));card.addView(icon,ilp);
                TextView name=tv(shopIconNameOf(pick),11,0xFF17345D);name.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(-1,-2);nlp.topMargin=dp(6);card.addView(name,nlp);
                card.setOnClickListener(v->{playViewSound(v);selectedIcon[0]=pick;if(ref[0]!=null)ref[0].dismiss();if(onPick!=null)onPick.accept(pick);});
            }
        }
        ref[0]=buildPastelDialog("✦","انتخاب آیکن","",0xFF5AA8FF,scroll,null,0,null,"بستن",null);ref[0].show();
    }
    private TextView shopFieldLabel(String text){
        TextView v=tv(text,12,0xFF536785);v.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);return v;
    }
    private void moveShopItem(String id,int delta){
        java.util.ArrayList<ShopItem> items=loadShopItems();int at=-1;for(int i=0;i<items.size();i++)if(items.get(i).id.equals(id)){at=i;break;}if(at<0)return;int to=Math.max(0,Math.min(items.size()-1,at+delta));if(to==at)return;ShopItem item=items.remove(at);items.add(to,item);saveShopItems(items);
    }
    private String shopPageDots(int count,int active){
        if(count<=1)return "";StringBuilder b=new StringBuilder();active=Math.max(0,Math.min(count-1,active));for(int i=0;i<count;i++){if(i>0)b.append("  ");b.append(i==active?"●":"○");}return b.toString();
    }
    private void showShopItemEditor(final ShopItem existing,final java.util.function.Consumer<ShopItem> onSave,final Runnable onDelete){
        final boolean editing=existing!=null;
        final int[] selectedIcon={editing?existing.iconIndex:0};
        final boolean[] oneTime={editing&&existing.oneTime};
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        body.addView(shopFieldLabel("آیکن پاداش"),new LinearLayout.LayoutParams(-1,dp(24)));
        final TextView iconPicker=settingsRow("انتخاب آیکن",shopIconOf(selectedIcon[0])+"   "+shopIconNameOf(selectedIcon[0]));body.addView(iconPicker,new LinearLayout.LayoutParams(-1,dp(46)));
        LinearLayout.LayoutParams labLp=new LinearLayout.LayoutParams(-1,dp(24));labLp.topMargin=dp(6);body.addView(shopFieldLabel("نام پاداش"),labLp);
        final EditText title=dreamField("مثلاً قهوه",editing?existing.title:"",false);body.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout.LayoutParams lab3=new LinearLayout.LayoutParams(-1,dp(24));lab3.topMargin=dp(6);body.addView(shopFieldLabel("قیمت پاداش (سکه)"),lab3);
        LinearLayout priceRow=new LinearLayout(this);priceRow.setOrientation(LinearLayout.HORIZONTAL);priceRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);priceRow.setGravity(Gravity.CENTER_VERTICAL);body.addView(priceRow,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView unit=tv("سکه",13,THEME_TEXT);unit.setGravity(Gravity.CENTER);GradientDrawable ug=bg(0xFFEAF6FF,dp(12));ug.setStroke(Math.max(1,dp(1)),0x6654A9FF);unit.setBackground(ug);priceRow.addView(unit,new LinearLayout.LayoutParams(dp(64),-1));
        final EditText price=dreamField("عدد",editing?String.valueOf(existing.price):"",true);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,-1,1f);pp.rightMargin=dp(8);priceRow.addView(price,pp);

        LinearLayout.LayoutParams typeLab=new LinearLayout.LayoutParams(-1,dp(24));typeLab.topMargin=dp(8);body.addView(shopFieldLabel("نوع پاداش"),typeLab);
        LinearLayout typeRow=new LinearLayout(this);typeRow.setOrientation(LinearLayout.HORIZONTAL);typeRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);typeRow.setGravity(Gravity.CENTER);body.addView(typeRow,new LinearLayout.LayoutParams(-1,dp(42)));
        final TextView infinite=tv("بی‌نهایت",13,0xFF355270),single=tv("یک‌باره",13,0xFF355270);infinite.setGravity(Gravity.CENTER);single.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,-1,1f);ip.leftMargin=dp(4);typeRow.addView(infinite,ip);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-1,1f);sp.rightMargin=dp(4);typeRow.addView(single,sp);
        final Runnable updateType=()->{infinite.setBackground(homeTodoTabBg(!oneTime[0]));single.setBackground(homeTodoTabBg(oneTime[0]));infinite.setTextColor(!oneTime[0]?Color.WHITE:0xFF355270);single.setTextColor(oneTime[0]?Color.WHITE:0xFF355270);};updateType.run();
        infinite.setOnClickListener(v->{playViewSound(v);oneTime[0]=false;updateType.run();});single.setOnClickListener(v->{playViewSound(v);oneTime[0]=true;updateType.run();});

        final Dialog[] ref={null};
        iconPicker.setOnClickListener(v->{playViewSound(v);showShopIconPicker(selectedIcon,pick->iconPicker.setText("انتخاب آیکن   "+shopIconOf(pick)+"   "+shopIconNameOf(pick)));});
        if(editing){
            LinearLayout order=new LinearLayout(this);order.setOrientation(LinearLayout.HORIZONTAL);order.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);LinearLayout.LayoutParams olp=new LinearLayout.LayoutParams(-1,dp(44));olp.topMargin=dp(10);body.addView(order,olp);
            TextView earlier=shopSecondaryButton("انتقال به قبل");TextView later=shopSecondaryButton("انتقال به بعد");order.addView(earlier,new LinearLayout.LayoutParams(0,-1,1f));LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(0,-1,1f);llp.rightMargin=dp(8);order.addView(later,llp);
            earlier.setOnClickListener(v->{playViewSound(v);moveShopItem(existing.id,-1);if(ref[0]!=null)ref[0].dismiss();showShopCenter();});
            later.setOnClickListener(v->{playViewSound(v);moveShopItem(existing.id,1);if(ref[0]!=null)ref[0].dismiss();showShopCenter();});
        }
        if(editing&&onDelete!=null){
            TextView delete=shopSecondaryButton("حذف این پاداش");LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,dp(44));dlp.topMargin=dp(10);body.addView(delete,dlp);
            delete.setOnClickListener(v->{playViewSound(v);if(ref[0]!=null)ref[0].dismiss();showDeleteShopItemConfirm(existing,onDelete);});
        }
        ref[0]=buildPastelDialog(editing?"✎":"＋",editing?"ویرایش پاداش":"افزودن پاداش","",0xFF5AA8FF,body,"ذخیره",0xFF4E8CFF,()->{
            String ttl=title.getText().toString().trim();int pr=0;try{pr=Integer.parseInt(price.getText().toString().trim());}catch(Exception ignored){}
            if(ttl.length()==0){Toast.makeText(this,"نام پاداش را وارد کن",Toast.LENGTH_SHORT).show();return;}if(pr<=0){Toast.makeText(this,"قیمت باید بیشتر از صفر باشد",Toast.LENGTH_SHORT).show();return;}
            ShopItem out=new ShopItem(editing?existing.id:("shop_"+System.currentTimeMillis()),ttl,"",pr,selectedIcon[0],oneTime[0]);if(onSave!=null)onSave.accept(out);
        },"لغو",null);ref[0].show();
    }
    private void showShopRedeemDialog(final ShopItem item,final Runnable after){
        if(item==null)return;
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView t1=tv(item.title,15,0xFF17345D);t1.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);body.addView(t1,new LinearLayout.LayoutParams(-1,dp(30)));
        TextView type=tv(item.oneTime?"نوع: یک‌باره":"نوع: بی‌نهایت",12,0xFF536785);type.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);type.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);body.addView(type,new LinearLayout.LayoutParams(-1,dp(24)));
        TextView t2=tv("هزینه: "+item.price+" سکه",14,THEME_TEXT);t2.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);body.addView(t2,new LinearLayout.LayoutParams(-1,dp(28)));
        final int currentCount=shopRedeemCount(item.id);
        if(gameCoins<item.price){
            TextView warn=tv("سکه کافی نداری.",13,0xFFD9435B);warn.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);warn.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);warn.setPadding(0,dp(8),0,0);body.addView(warn,new LinearLayout.LayoutParams(-1,-2));
            Dialog d=buildPastelDialog(shopIconOf(item.iconIndex),"سکه کافی نیست",item.title,0xFFD9435B,body,"باشه",0xFF699BFF,null,null,null);d.show();return;
        }
        Dialog d=buildPastelDialog(shopIconOf(item.iconIndex),"تأیید خرید",item.title,0xFF5AA8FF,body,"خرید",0xFF4E8CFF,()->{
            if(gameCoins<item.price){Toast.makeText(this,"سکه کافی نیست",Toast.LENGTH_SHORT).show();return;}
            gameCoins=Math.max(0,gameCoins-item.price);saveGameState();setShopRedeemCount(item.id,currentCount+1);addShopPurchase(item);
            if(item.oneTime){java.util.ArrayList<ShopItem> items=loadShopItems();for(int i=items.size()-1;i>=0;i--)if(items.get(i).id.equals(item.id))items.remove(i);saveShopItems(items);setSelectedShopItemId(items.isEmpty()?"":items.get(0).id);}
            else setSelectedShopItemId(item.id);
            playSfx(sfxRewardId,.86f);Toast.makeText(this,item.title+" خریداری شد",Toast.LENGTH_SHORT).show();pulseHudRewards();if(after!=null)after.run();
        },"لغو",null);d.show();
    }

    private class ShopArchiveIconView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);ShopArchiveIconView(android.content.Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);setClickable(true);setFocusable(true);}
        @Override protected void onDraw(Canvas c){float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;p.setStyle(Paint.Style.FILL);p.setColor(0x823A73C6);p.setShadowLayer(dp(3),0,dp(1),0x44000000);c.drawRoundRect(new RectF(dp(2),dp(2),w-dp(2),h-dp(2)),dp(999),dp(999),p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.7f));p.setColor(0xFFEAF7FF);RectF box=new RectF(cx-dp(9),cy-dp(6),cx+dp(9),cy+dp(8));c.drawRoundRect(box,dp(2),dp(2),p);c.drawLine(cx-dp(11),cy-dp(8),cx+dp(11),cy-dp(8),p);c.drawLine(cx-dp(5),cy-dp(1),cx+dp(5),cy-dp(1),p);}
    }
    private void refundShopPurchase(final ShopPurchase purchase,final Runnable after){
        if(purchase==null)return;LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView t=tv("پاداش برگردد و "+purchase.price+" سکه کامل به حسابت برگردد؟",13,0xFF536785);t.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);body.addView(t,new LinearLayout.LayoutParams(-1,-2));
        Dialog d=buildPastelDialog(shopIconOf(purchase.iconIndex),"برگشت پاداش",purchase.title,0xFF5AA8FF,body,"برگشت سکه",0xFF4E8CFF,()->{gameCoins+=Math.max(0,purchase.price);saveGameState();setShopRedeemCount(purchase.itemId,Math.max(0,shopRedeemCount(purchase.itemId)-1));restoreOneTimeRewardIfNeeded(purchase);removeShopPurchase(purchase.purchaseId);playSfx(sfxRestoreId,.72f);Toast.makeText(this,"سکه برگشت داده شد",Toast.LENGTH_SHORT).show();if(after!=null)after.run();},"لغو",null);d.show();
    }
    private void showShopArchive(final Runnable after){
        final LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);final ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        final Dialog[] ref={null};final Runnable[] render={null};render[0]=()->{list.removeAllViews();java.util.ArrayList<ShopPurchase> purchases=loadShopPurchases();if(purchases.isEmpty()){TextView empty=tv("هنوز خریدی ثبت نشده",12,0xFF8794A7);empty.setGravity(Gravity.CENTER);empty.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));return;}for(ShopPurchase x:purchases){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setPadding(dp(7),dp(5),dp(7),dp(5));GradientDrawable rg=bg(0xFFF7FAFF,dp(14));rg.setStroke(Math.max(1,dp(1)),0x334D8DFF);row.setBackground(rg);TextView icon=tv(shopIconOf(x.iconIndex),22,0xFF17345D);icon.setGravity(Gravity.CENTER);row.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout texts=new LinearLayout(this);texts.setOrientation(LinearLayout.VERTICAL);texts.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);TextView title=tv(x.title,13,0xFF17345D);title.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);TextView meta=tv(x.price+" سکه • "+(x.oneTime?"یک‌باره":"بی‌نهایت"),10,0xFF70859E);meta.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);meta.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);texts.addView(title,new LinearLayout.LayoutParams(-1,dp(24)));texts.addView(meta,new LinearLayout.LayoutParams(-1,dp(18)));row.addView(texts,new LinearLayout.LayoutParams(0,-1,1f));TextView refund=shopSecondaryButton("برگشت");refund.setTextSize(11);row.addView(refund,new LinearLayout.LayoutParams(dp(66),dp(36)));refund.setOnClickListener(v->{playViewSound(v);refundShopPurchase(x,()->{render[0].run();if(after!=null)after.run();});});LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(58));rp.bottomMargin=dp(6);list.addView(row,rp);}};
        render[0].run();ref[0]=buildPastelDialog("▣","آرشیو خرید","خریدهای ثبت‌شده",0xFF5AA8FF,scroll,null,0,null,null,null);ref[0].show();
    }

    private void showShopCenter(){
        stopMissionTimer();
        stopHomeActiveTicker();removeHomeOnlyOverlays();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome=false;isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;isTreeScreen=false;isDreamPalaceScreen=false;isDreamViewerScreen=false;isTimeTravelScreen=false;isShopScreen=true;
        ++homeGeneration;if(hudHeader!=null)hudHeader.setVisibility(View.VISIBLE);removeActiveMissionBar();content.setTranslationX(0f);content.setTranslationY(0f);content.setAlpha(1f);content.removeAllViews();

        FrameLayout stage=new FrameLayout(this);content.addView(stage,new FrameLayout.LayoutParams(-1,-1));
        ImageView bgView=new ImageView(this);bgView.setImageResource(heroShopBackground());bgView.setScaleType(ImageView.ScaleType.CENTER_CROP);stage.addView(bgView,new FrameLayout.LayoutParams(-1,-1));
        View scrim=new View(this);scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x08FFFFFF,0x10FFFFFF,0x16EAF4FF,0x22DCEEFF}));stage.addView(scrim,new FrameLayout.LayoutParams(-1,-1));

        int screenW=getResources().getDisplayMetrics().widthPixels;int panelH=dp(430);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(14),dp(12),dp(14),dp(12));GradientDrawable panelBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xF4F9FCFF,0xEEF3FAFF,0xF2EEF9FF});panelBg.setCornerRadius(dp(30));panelBg.setStroke(Math.max(1,dp(2)),0xAA64B5FF);panel.setBackground(panelBg);panel.setElevation(dp(12));
        FrameLayout.LayoutParams plp=new FrameLayout.LayoutParams(-1,panelH,Gravity.BOTTOM);plp.leftMargin=dp(14);plp.rightMargin=dp(14);plp.bottomMargin=dp(14);stage.addView(panel,plp);

        final java.util.ArrayList<ShopItem>[] itemsRef=new java.util.ArrayList[]{loadShopItems()};
        final String[] selectedId={selectedShopItemId()};
        if(itemsRef[0]!=null&&!itemsRef[0].isEmpty()&&findShopItem(itemsRef[0],selectedId[0])==null){selectedId[0]=itemsRef[0].get(0).id;setSelectedShopItemId(selectedId[0]);}

        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.HORIZONTAL);header.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);header.setGravity(Gravity.CENTER_VERTICAL);panel.addView(header,new LinearLayout.LayoutParams(-1,dp(50)));
        LinearLayout titleWrap=new LinearLayout(this);titleWrap.setOrientation(LinearLayout.HORIZONTAL);titleWrap.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);titleWrap.setGravity(Gravity.CENTER_VERTICAL);header.addView(titleWrap,new LinearLayout.LayoutParams(0,-1,1f));
        TextView bag=tv("♧",25,THEME_PRIMARY);bag.setGravity(Gravity.CENTER);bag.setContentDescription("مرکز خرید");titleWrap.addView(bag,new LinearLayout.LayoutParams(dp(40),dp(40)));
        TextView title=tv("مرکز خرید",22,THEME_TEXT);title.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(-2,-1);titleLp.rightMargin=dp(5);titleWrap.addView(title,titleLp);

        final TextView coinChip=tv("●  "+presenceCoinText(),14,THEME_TEXT);shopCoinChip=coinChip;coinChip.setGravity(Gravity.CENTER);GradientDrawable coinBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xFFEAF6FF,0xFFE5EDFF});coinBg.setCornerRadius(dp(999));coinBg.setStroke(Math.max(1,dp(1)),0xAA64B5FF);coinChip.setBackground(coinBg);coinChip.setPadding(dp(10),0,dp(10),0);header.addView(coinChip,new LinearLayout.LayoutParams(-2,dp(38)));
        final ShopArchiveIconView archiveBtn=new ShopArchiveIconView(this);archiveBtn.setContentDescription("آرشیو خرید");LinearLayout.LayoutParams archiveLp=new LinearLayout.LayoutParams(dp(40),dp(40));archiveLp.leftMargin=dp(6);archiveLp.rightMargin=dp(6);header.addView(archiveBtn,archiveLp);
        final TextView addBtn=tv("＋ افزودن",12,THEME_PRIMARY);addBtn.setGravity(Gravity.CENTER);GradientDrawable addBg=bg(0xEAF4F9FF,dp(999));addBg.setStroke(Math.max(1,dp(1)),0x8864B5FF);addBtn.setBackground(addBg);addBtn.setContentDescription("افزودن پاداش");header.addView(addBtn,new LinearLayout.LayoutParams(dp(78),dp(38)));

        final HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.setOverScrollMode(View.OVER_SCROLL_NEVER);hsv.setFillViewport(true);LinearLayout.LayoutParams hsvLp=new LinearLayout.LayoutParams(-1,0,1f);hsvLp.topMargin=dp(4);panel.addView(hsv,hsvLp);
        final LinearLayout pages=new LinearLayout(this);pages.setOrientation(LinearLayout.HORIZONTAL);pages.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);pages.setGravity(Gravity.CENTER_VERTICAL);hsv.addView(pages,new HorizontalScrollView.LayoutParams(-2,-1));
        final TextView pageDots=tv("",12,THEME_PRIMARY);pageDots.setGravity(Gravity.CENTER);panel.addView(pageDots,new LinearLayout.LayoutParams(-1,dp(18)));

        final Runnable[] render={null};
        render[0]=()->{
            itemsRef[0]=loadShopItems();pages.removeAllViews();
            if(itemsRef[0]==null)itemsRef[0]=new java.util.ArrayList<>();
            if(itemsRef[0].isEmpty()){
                selectedId[0]="";setSelectedShopItemId("");LinearLayout emptyPage=new LinearLayout(this);emptyPage.setGravity(Gravity.CENTER);emptyPage.setOrientation(LinearLayout.VERTICAL);TextView empty=tv("فروشگاه خالی است",14,THEME_MUTED);empty.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);emptyPage.addView(empty,new LinearLayout.LayoutParams(Math.max(dp(300),screenW-dp(56)),dp(80)));pages.addView(emptyPage,new LinearLayout.LayoutParams(Math.max(dp(320),screenW-dp(56)),-1));coinChip.setText("●  "+presenceCoinText());pageDots.setText("");return;
            }
            if(findShopItem(itemsRef[0],selectedId[0])==null){selectedId[0]=itemsRef[0].get(0).id;setSelectedShopItemId(selectedId[0]);}
            int pageCount=(itemsRef[0].size()+5)/6;int pageW=Math.max(dp(320),screenW-dp(56));int gap=dp(7);int cardW=(pageW-gap*2)/3;
            for(int pg=0;pg<pageCount;pg++){
                LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams pageLp=new LinearLayout.LayoutParams(pageW,-1);if(pg<pageCount-1)pageLp.leftMargin=dp(12);pages.addView(page,pageLp);
                for(int row=0;row<2;row++){
                    LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);line.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);line.setGravity(Gravity.CENTER);LinearLayout.LayoutParams lineLp=new LinearLayout.LayoutParams(-1,0,1f);if(row==1)lineLp.topMargin=gap;page.addView(line,lineLp);
                    for(int col=0;col<3;col++){
                        int idx=pg*6+row*3+col;if(idx>=itemsRef[0].size()){View spacer=new View(this);LinearLayout.LayoutParams spLp=new LinearLayout.LayoutParams(cardW,-1);if(col<2)spLp.leftMargin=gap;line.addView(spacer,spLp);continue;}
                        final ShopItem item=itemsRef[0].get(idx);final boolean selected=item.id.equals(selectedId[0]);
                        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(6),dp(5),dp(6),dp(5));card.setClickable(true);card.setFocusable(true);GradientDrawable cardBg=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{selected?0xF5DCEEFF:0xECDAEBFF,selected?0xF2BFD9F7:0xE7BDD8F5});cardBg.setCornerRadius(dp(20));cardBg.setStroke(Math.max(1,dp(selected?2:1)),selected?0xFFF0FAFF:0xA6D7EDFF);card.setBackground(cardBg);card.setElevation(selected?dp(6):dp(3));LinearLayout.LayoutParams cardLp=new LinearLayout.LayoutParams(cardW,-1);if(col<2)cardLp.leftMargin=gap;line.addView(card,cardLp);
                        TextView icon=tv(shopIconOf(item.iconIndex),27,0xFF1A3964);icon.setGravity(Gravity.CENTER);icon.setBackground(shopIconCircle(selected));card.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
                        TextView itemTitle=tv(item.title,13,0xFF17345D);itemTitle.setGravity(Gravity.CENTER);itemTitle.setMaxLines(1);enableAutoSize(itemTitle,10,13);LinearLayout.LayoutParams itLp=new LinearLayout.LayoutParams(-1,dp(24));itLp.topMargin=dp(2);card.addView(itemTitle,itLp);
                        TextView mode=tv(item.oneTime?"یک‌باره":"بی‌نهایت",9,item.oneTime?0xFF934969:0xFF53718E);mode.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);mode.setGravity(Gravity.CENTER);card.addView(mode,new LinearLayout.LayoutParams(-1,dp(14)));
                        LinearLayout priceRow=new LinearLayout(this);priceRow.setOrientation(LinearLayout.HORIZONTAL);priceRow.setGravity(Gravity.CENTER);priceRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);card.addView(priceRow,new LinearLayout.LayoutParams(-1,dp(20)));TextView coinIcon=tv("●",11,THEME_PRIMARY);coinIcon.setGravity(Gravity.CENTER);priceRow.addView(coinIcon,new LinearLayout.LayoutParams(dp(16),-1));TextView price=tv(item.price+" سکه",11,THEME_TEXT);price.setGravity(Gravity.CENTER);priceRow.addView(price,new LinearLayout.LayoutParams(-2,-1));
                        boolean canBuy=gameCoins>=item.price;TextView buy=tv(canBuy?"خرید":"سکه کافی نیست",12,Color.WHITE);buy.setGravity(Gravity.CENTER);GradientDrawable buyBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,canBuy?new int[]{0xFF3F9DFF,0xFF6E79F1}:new int[]{0xAA8192AA,0xAA718199});buyBg.setCornerRadius(dp(999));buyBg.setStroke(Math.max(1,dp(1)),0xCCEDFAFF);buy.setBackground(buyBg);buy.setEnabled(canBuy);buy.setAlpha(canBuy?1f:.72f);LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,dp(34));blp.topMargin=dp(3);card.addView(buy,blp);
                        card.setOnClickListener(v->{playViewSound(v);selectedId[0]=item.id;setSelectedShopItemId(item.id);render[0].run();});
                        card.setOnLongClickListener(v->{playUiClick();showShopItemEditor(item,updated->{java.util.ArrayList<ShopItem> items=loadShopItems();for(int z=0;z<items.size();z++)if(items.get(z).id.equals(item.id)){items.set(z,updated);break;}saveShopItems(items);selectedId[0]=updated.id;setSelectedShopItemId(updated.id);render[0].run();},()->{java.util.ArrayList<ShopItem> items=loadShopItems();for(int z=items.size()-1;z>=0;z--)if(items.get(z).id.equals(item.id)){items.remove(z);break;}saveShopItems(items);selectedId[0]=items.isEmpty()?"":items.get(0).id;setSelectedShopItemId(selectedId[0]);render[0].run();});return true;});
                        buy.setOnClickListener(v->{playViewSound(v);selectedId[0]=item.id;setSelectedShopItemId(item.id);showShopRedeemDialog(item,render[0]);});
                    }
                }
            }
            coinChip.setText("●  "+presenceCoinText());pageDots.setText(shopPageDots(pageCount,0));final int pc=pageCount,step=pageW+dp(12);hsv.setOnScrollChangeListener((v,sx,sy,osx,osy)->{int active=step<=0?0:Math.min(pc-1,Math.max(0,Math.round(Math.abs(sx)/(float)step)));pageDots.setText(shopPageDots(pc,active));});
        };
        addBtn.setOnClickListener(v->{playViewSound(v);showShopItemEditor(null,created->{java.util.ArrayList<ShopItem> items=loadShopItems();items.add(created);saveShopItems(items);selectedId[0]=created.id;setSelectedShopItemId(created.id);render[0].run();hsv.post(()->hsv.fullScroll(View.FOCUS_LEFT));},null);});
        archiveBtn.setOnClickListener(v->{playUiClick();showShopArchive(render[0]);});
        render[0].run();addActiveMissionBar();
    }

    private void showTimeTravel(){
        stopMissionTimer();
        stopHomeActiveTicker();removeHomeOnlyOverlays();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome=false;isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;isTreeScreen=false;isDreamPalaceScreen=false;isDreamViewerScreen=false;isTimeTravelScreen=true;isShopScreen=false;isWorldCupScreen=false;
        ++homeGeneration;
        if(hudHeader!=null)hudHeader.setVisibility(View.VISIBLE);
        removeActiveMissionBar();
        content.setTranslationX(0f);content.setTranslationY(0f);content.setAlpha(1f);content.removeAllViews();
        ImageView bg=new ImageView(this);bg.setImageResource(heroTimeBackground());bg.setScaleType(ImageView.ScaleType.CENTER_CROP);content.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        TimeTravelView sheet=new TimeTravelView(this);content.addView(sheet,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
        if(hudHeader!=null)hudHeader.bringToFront();
    }

    private void showWorldCup(){
        stopMissionTimer();
        stopHomeActiveTicker();removeHomeOnlyOverlays();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome=false;isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;isTreeScreen=false;isDreamPalaceScreen=false;isDreamViewerScreen=false;isTimeTravelScreen=false;isShopScreen=false;isWorldCupScreen=true;
        ++homeGeneration;
        loadGameState();
        removeActiveMissionBar();
        if(hudHeader!=null)hudHeader.setVisibility(View.VISIBLE);
        content.setTranslationX(0f);content.setTranslationY(0f);content.setAlpha(1f);content.removeAllViews();
        ImageView bg=new ImageView(this);bg.setImageResource(heroWorldBackground());bg.setScaleType(ImageView.ScaleType.CENTER_CROP);content.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        WorldCupView world=new WorldCupView(this);world.setGameState(gameLevel,gameXp,xpNeeded(gameLevel));content.addView(world,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
        if(hudHeader!=null)hudHeader.bringToFront();
    }

    private void showPlaceholder(String title){
        stopHomeActiveTicker();removeHomeOnlyOverlays();
        isHome = false; isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=true;isTreeScreen=false;isTimeTravelScreen=false;isDreamPalaceScreen=false;isDreamViewerScreen=false;isShopScreen=false;isWorldCupScreen=false;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(THEME_FALLBACK);
        TextView t=tv(title,28,THEME_TEXT); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,THEME_MUTED); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
    }
    @Override public void onBackPressed(){
        // Exactly one sound and one navigation level per Back press. Dialogs consume Back themselves first.
        playUiClick();
        if(isMissionEditorScreen||isRunningMissionScreen){showProgressPath();return;}
        if(isTreeScreen&&treeHistoryViewDate!=null){leaveTreeHistory();treeViewStateValid=false;showTreePage();return;}
        if(isTreeScreen){leaveTreeHistory();showHome();return;}
        if(isDreamViewerScreen){showDreamPalace(Math.max(0,dreamViewerSlot/20));return;}
        if(isDreamPalaceScreen){showHome();return;}
        if(isTimeTravelScreen||isShopScreen||isWorldCupScreen){showHome();return;}
        if(isProgressPathScreen||isPlaceholderScreen){showHome();return;}
        if(isHome){long now=System.currentTimeMillis();if(now-lastHomeBackAt<=2000L){finish();}else lastHomeBackAt=now;return;}
        super.onBackPressed();
    }
    private int withAlpha(int color,int alpha){return (color & 0x00FFFFFF)|((alpha & 0xFF)<<24);}
    private int mixColor(int a,int b,float t){t=Math.max(0f,Math.min(1f,t));int aa=Color.alpha(a),ar=Color.red(a),ag=Color.green(a),ab=Color.blue(a);return Color.argb(Math.round(aa+(Color.alpha(b)-aa)*t),Math.round(ar+(Color.red(b)-ar)*t),Math.round(ag+(Color.green(b)-ag)*t),Math.round(ab+(Color.blue(b)-ab)*t));}
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
    private float dp(float x){ return x*getResources().getDisplayMetrics().density; }
}

package com.shahriar.legacy;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;

final class MissionNotification {
    static final int ID=4101;
    private MissionNotification(){}

    static void showRunning(Context context){ show(context,false); }
    static void showFinished(Context context){ show(context,true); }

    private static void show(Context context, boolean finished){
        SharedPreferences app=context.getSharedPreferences("legacy_app_settings",Context.MODE_PRIVATE);
        if(!app.getBoolean("notifications_enabled",true)){cancel(context);return;}
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        SharedPreferences progress=context.getSharedPreferences("legacy_progress_rebuild",Context.MODE_PRIVATE);
        if(!progress.getBoolean("active",false)){cancel(context);return;}
        long endAt=progress.getLong("active_end",0L);
        String title=progress.getString("active_title","Mission");
        if(title==null||title.trim().isEmpty())title="Mission";
        boolean muted=!app.getBoolean("sfx_enabled",true);
        String channel;
        int importance;
        if(finished){channel=muted?"mission_finish_silent_v51":"mission_finish_sound_v51";importance=NotificationManager.IMPORTANCE_HIGH;}
        else{channel="mission_running_v51";importance=NotificationManager.IMPORTANCE_LOW;}
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel nc=new NotificationChannel(channel,finished?"Mission timer":"Active mission",importance);
            if(!finished||muted){nc.setSound(null,null);nc.enableVibration(false);}
            nc.setShowBadge(false);
            nm.createNotificationChannel(nc);
        }
        Intent open=new Intent(context,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentPi=PendingIntent.getActivity(context,4101,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent donePi=actionPi(context,MissionActionReceiver.ACTION_DONE,4201);
        PendingIntent laterPi=actionPi(context,MissionActionReceiver.ACTION_LATER,4202);
        PendingIntent failPi=actionPi(context,MissionActionReceiver.ACTION_FAIL,4203);
        Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,channel):new Notification.Builder(context);
        nb.setSmallIcon(R.drawable.ic_notification_progress)
          .setContentTitle(title)
          .setContentIntent(contentPi)
          .setCategory(Notification.CATEGORY_PROGRESS)
          .setVisibility(Notification.VISIBILITY_PUBLIC)
          .setOngoing(true)
          .setOnlyAlertOnce(!finished)
          .addAction(0,"Done",donePi)
          .addAction(0,"Later",laterPi)
          .addAction(0,"Fail",failPi);
        if(finished){
            nb.setShowWhen(false).setContentText("00:00");
        }else{
            long safeEnd=Math.max(System.currentTimeMillis()+1000L,endAt);
            nb.setWhen(safeEnd).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true);
        }
        nm.notify(ID,nb.build());
    }

    static void cancel(Context context){
        try{NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.cancel(ID);}catch(Exception ignored){}
    }

    private static PendingIntent actionPi(Context context,String action,int requestCode){
        Intent i=new Intent(context,MissionActionReceiver.class);i.setAction(action);
        return PendingIntent.getBroadcast(context,requestCode,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
}

package com.shahriar.legacy;

import android.content.*;
import android.os.*;

public class MissionAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences sp=context.getSharedPreferences("legacy_progress_rebuild",Context.MODE_PRIVATE);
        if(!sp.getBoolean("active",false))return;
        long end=sp.getLong("active_end",0L);
        if(end>System.currentTimeMillis()+2000L)return;
        if(!context.getSharedPreferences("legacy_app_settings",Context.MODE_PRIVATE).getBoolean("notifications_enabled",true)){sp.edit().putBoolean("active_alerted",true).apply();MissionNotification.cancel(context);return;}
        if(sp.getBoolean("active_alerted",false)){MissionNotification.showFinished(context);return;}
        sp.edit().putBoolean("active_alerted",true).apply();
        try{
            android.os.Vibrator vb=(android.os.Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
            if(vb!=null){if(Build.VERSION.SDK_INT>=26)vb.vibrate(android.os.VibrationEffect.createOneShot(500,android.os.VibrationEffect.DEFAULT_AMPLITUDE));else vb.vibrate(500);}
        }catch(Exception ignored){}
        MissionNotification.showFinished(context);
    }
}

Legacy v79 – Dream Palace blue artwork + touch/theme alignment

Base: Legacy-v78-dream-palace-polish.zip

Dream Palace refinements:
- Replaced the Dream Palace background with the newly supplied blue 768×1536 artwork (stored as a high-quality 1536×3072 app asset).
- Re-measured all 20 slot hit/image rectangles against the new artwork so taps, image placement, and drag/drop targets line up with the visible cards.
- Dream Palace artwork now fills the safe app content area directly so touch coordinates stay aligned across devices.
- The Dream Viewer portal is repositioned over the sun and remains hidden until the first dream exists.
- Filled slots show the selected crop itself without an extra frame; crop aspect/output was tuned to the new near-square cards so the selected composition is preserved.
- Crop workflow uses the same blue/purple pastel visual language as Progress Path and Tree, including themed asset/title treatment, blue crop outline, and safe-area bottom actions.
- Add/Edit now uses the same shared pastel card/icon/button language; the target-year chooser is also a themed in-app dialog instead of a system spinner popup.
- Horizontal Dream Palace paging and vertical full-screen dream paging were slowed further for a calmer, smoother transition.
- Existing full uncropped viewer, blurred same-photo background, always-visible year/title/USD overlay, long-press edit, drag-to-reorder with shifting, page unlock rules, persistence, and safe-area behavior are preserved.

Legacy v78 – Dream Palace interaction polish

Base: Legacy-v77-dream-palace.zip (itself based on Legacy-v76-progress-tree-final.zip)

Dream Palace refinements:
- Crop editor now stays inside the phone safe area; bottom controls no longer sit under the Android navigation bar.
- Removed the extra crop instruction text.
- The selected crop is preserved exactly for the palace thumbnail and the add/edit preview.
- The original uncropped image is also stored separately and used in the full-screen viewer.
- Full-screen viewer uses the same original image as a large blurred/darkened background behind the complete uncropped photo.
- Year is always shown at the top-left of the actual displayed image in a dark glass rounded badge.
- Title is always centered near the bottom of the displayed image; the next line shows the numeric USD amount with a themed dollar asset.
- Add/Edit uses the app's existing blue/purple pastel dialog language and a dedicated numeric USD amount field.
- Long-press in full-screen still opens Edit; viewer metadata is now always visible instead of tap-to-toggle.
- Dream photos can be reordered by press-and-drag. Dropping at a new slot inserts there and shifts intervening slots instead of simple swapping; the order persists and drives full-screen sequence order.
- Horizontal page changes and vertical full-screen dream changes use deliberately slow, smooth transitions. Slow swipe gestures also advance one dream at a time in sequence mode.
- The next 20-slot page remains locked until all 20 slots on the current page are filled.
- Existing Progress Path, Tree, missions, settings, audio, notifications, and other Legacy behavior are preserved.

Legacy v77 – Dream Palace

Base: Legacy-v76-progress-tree-final.zip

Dream Palace added:
- New 4×5 Dream Palace screen using the supplied palace artwork (20 slots per page).
- Tap an empty slot to pick a photo, crop/zoom/pan it, then save title, Persian target year, and price/value.
- Filled slots show only the image; the baked gold placeholder frame is covered.
- Tap a filled slot for a clean full-screen viewer; tap toggles title/year/price.
- Long-press a full-screen dream to edit its metadata or replace/crop the image.
- The next 20-slot page unlocks only after the current page is completely filled; horizontal swipe moves between unlocked pages.
- A gold dream-viewer portal appears over the sun only after the first dream is saved.
- The portal opens dreams in saved order; each upward swipe snaps to exactly the next dream and downward swipe returns to the previous one.
- Dream data and images persist locally across app restarts.
- Existing Progress Path, Tree, missions, settings, audio, notifications, and other Legacy v76 behavior are preserved.

Legacy v76 – final progress/tree closure polish

Base: Legacy-v75-tree-daily-zoom-controls.zip

Final fixes:
- Back press now plays exactly one UI sound while still navigating exactly one level.
- Persian tree search is normalized for Arabic/Persian character variants (ی/ي/ى, ک/ك), ZWNJ/directional marks, diacritics, and repeated spaces.
- Tree History no longer has the previous 30-date display cap; all saved snapshot dates are shown in the scrollable history list.
- PV / GPV / count remain cumulative across the configurable logical-day boundary. At the new day, the values stay in place but stats_day no longer matches the new logical day, so the person is treated as not-yet-recorded until fresh actual stats are saved.
- Existing configurable day start (default 06:00), mission day boundaries, tree colors, zoom/search/history behavior, To Do, and Actions remain intact.

## v80 – Dream Palace completion pass
- Keeps the v79 blue Dream Palace artwork and maps all card hit targets through the same FIT_CENTER transform so the art/cards do not stretch on different phone ratios.
- Filled dream thumbnails show the exact saved crop without a second automatic crop/stretch and now have an inner rounded contrasting selection frame.
- Stores the selected source image byte-for-byte as the full-resolution original; the cropped thumbnail is stored separately.
- Fullscreen viewer uses the original image, the same image as a blurred/expanded backdrop, app-theme year badge, and places title + USD value compactly below the foreground image (not over it).
- Replaced the old sun/eye portal with a new blue/purple glass stacked-dream asset, shifted left from the previous position; it remains hidden until the first dream exists.
- Drag/drop reordering now animates the affected cards into their shifted positions. Adjacent pages are preloaded so a drag can cross page boundaries with a slow edge-triggered page slide.
- Added thumbnail LRU caching for large dream collections.
- Replacing an image cleans up obsolete private image files after a successful save.
- Existing target years outside the current +10-year picker window are preserved and remain selectable when editing.
- Added themed Delete Wish action; deletion shifts all later wishes one slot forward and updates page unlocking/order.
- Page and fullscreen transitions are deliberately slower/smoother and all Dream Palace dialogs use the app's blue/purple visual language.

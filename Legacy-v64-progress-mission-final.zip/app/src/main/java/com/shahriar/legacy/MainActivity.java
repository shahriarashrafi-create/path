package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.text.InputType;
import android.view.*;
import android.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content;
    private View activeBar;
    private boolean isRunningMissionScreen=false;
    private final java.util.HashMap<String,TextView> progressMissionViews=new java.util.HashMap<>();
    private TextView hudLevel, hudXpText, hudCoinText, hudComboText; private XpBarView hudXpBar;
    private boolean isProgressPathScreen=false, isMissionEditorScreen=false, isPlaceholderScreen=false;
    private android.media.SoundPool uiSoundPool;
    private int uiClickSoundId=0,sfxConfirmId=0,sfxFailId=0,sfxRestoreId=0,sfxSubtaskId=0,sfxMusicId=0,sfxToggleId=0,sfxResetId=0,sfxRewardId=0,sfxStartId=0,sfxTimerEndId=0;
    private final java.util.HashSet<Integer> readySfxIds=new java.util.HashSet<>();
    private Runnable homeActiveTick, dailyResetTick;
    private String lastObservedMissionDay="";
    private boolean isHome = true;
    private int homeGeneration = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","درخت تصاعد","سفر در زمان","مرکز خرید","جام جهانی"};
    // Touch centers measured against the current 768x1536 Home artwork.
    // Order matches names: Progress, Dream Palace, Growth Forest, Time Travel, Shop, World Cup.
    private final float[][] centers = {{0.198f,0.686f},{0.500f,0.686f},{0.802f,0.686f},{0.198f,0.852f},{0.500f,0.852f},{0.804f,0.852f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); initUiClickSound(); showHome(); }
    @Override protected void onResume(){
        super.onResume();
        loadGameState(); updateHud();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        if(isRunningMissionScreen&&!progressPrefs.getBoolean("active",false)){stopMissionTimer();stopMissionMusic();showProgressPath();consumePendingMissionFeedback();startDailyResetTicker();return;}
        refreshProgressMissionVisuals();
        if(!isRunningMissionScreen)addActiveMissionBar();
        consumePendingMissionFeedback();
        startDailyResetTicker();
    }
    @Override protected void onPause(){
        super.onPause();
        if(dailyResetTick!=null){missionHandler.removeCallbacks(dailyResetTick);dailyResetTick=null;}
    }
    @Override protected void onDestroy(){
        try{if(uiSoundPool!=null){uiSoundPool.release();uiSoundPool=null;}}catch(Exception ignored){}
        super.onDestroy();
    }
    private void initUiClickSound(){
        try{
            android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_GAME).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            uiSoundPool=new android.media.SoundPool.Builder().setMaxStreams(8).setAudioAttributes(aa).build();
            uiSoundPool.setOnLoadCompleteListener((sp,id,status)->{if(status==0)readySfxIds.add(id);});
            uiClickSoundId=uiSoundPool.load(this,R.raw.ui_click,1);
            sfxConfirmId=uiSoundPool.load(this,R.raw.sfx_confirm,1);
            sfxFailId=uiSoundPool.load(this,R.raw.sfx_fail,1);
            sfxRestoreId=uiSoundPool.load(this,R.raw.sfx_restore,1);
            sfxSubtaskId=uiSoundPool.load(this,R.raw.sfx_subtask,1);
            sfxMusicId=uiSoundPool.load(this,R.raw.sfx_music,1);
            sfxToggleId=uiSoundPool.load(this,R.raw.sfx_toggle,1);
            sfxResetId=uiSoundPool.load(this,R.raw.sfx_reset,1);
            sfxRewardId=uiSoundPool.load(this,R.raw.sfx_reward,1);
            sfxStartId=uiSoundPool.load(this,R.raw.sfx_start,1);
            sfxTimerEndId=uiSoundPool.load(this,R.raw.sfx_timer_end,1);
        }catch(Exception ignored){uiSoundPool=null;readySfxIds.clear();}
    }
    private SharedPreferences appSettingsPrefs(){
        return getSharedPreferences("legacy_app_settings",MODE_PRIVATE);
    }
    private boolean isSfxEnabled(){
        return appSettingsPrefs().getBoolean("sfx_enabled",true);
    }
    private boolean isMusicEnabled(){
        return appSettingsPrefs().getBoolean("music_enabled",true);
    }
    private boolean isNotificationsEnabled(){
        return appSettingsPrefs().getBoolean("notifications_enabled",true);
    }
    private void setMissionMusicOutput(){
        try{
            if(missionPlayer!=null){
                boolean on=isMusicEnabled();
                missionPlayer.setVolume(on?1f:0f,on?1f:0f);
            }
        }catch(Exception ignored){}
    }
    private void playSfx(int soundId,float volume){
        try{if(!isSfxEnabled())return;if(uiSoundPool!=null&&soundId!=0&&readySfxIds.contains(soundId))uiSoundPool.play(soundId,Math.max(.55f,volume),Math.max(.55f,volume),1,0,1f);}catch(Exception ignored){}
    }
    private void playUiClick(){playSfx(uiClickSoundId,.65f);}
    private int soundForView(View v){
        StringBuilder q=new StringBuilder();
        try{CharSequence cd=v.getContentDescription();if(cd!=null)q.append(cd).append(' ');}catch(Exception ignored){}
        if(v instanceof TextView){CharSequence tx=((TextView)v).getText();if(tx!=null)q.append(tx);}
        String x=q.toString().toLowerCase(java.util.Locale.ROOT);
        if(x.contains("restore")||x.contains("ریستور")||x.contains("بازیابی"))return sfxRestoreId;
        if(x.contains("fail")||x.contains("delete")||x.contains("حذف")||x.contains("انجام نشد"))return sfxFailId;
        if(x.contains("done")||x.contains("complete")||x.contains("انجام شد")||x.contains("تکمیل"))return sfxConfirmId;
        if(x.contains("subtask")||x.contains("ساب"))return sfxSubtaskId;
        if(x.contains("music")||x.contains("موسیقی")||x.contains("آهنگ"))return sfxMusicId;
        if(x.contains("sound")||x.contains("صدا")||x.contains("mute"))return sfxToggleId;
        if(x.contains("reset")||x.contains("restart")||x.contains("later")||x.contains("توقف")||x.contains("pause"))return sfxResetId;
        if(x.contains("start")||x.contains("continue")||x.contains("شروع")||x.contains("ادامه"))return sfxStartId;
        return uiClickSoundId;
    }
    private void playViewSound(View v){
        int id=soundForView(v);
        float vol=(id==sfxFailId?.82f:id==sfxRewardId?.86f:id==sfxStartId?.76f:id==sfxConfirmId?.78f:.68f);
        playSfx(id,vol);
    }
    private View clickableViewAt(View v,float rawX,float rawY){
        if(v==null||v.getVisibility()!=View.VISIBLE||v.getAlpha()<=0f)return null;
        int[] loc=new int[2];try{v.getLocationOnScreen(loc);}catch(Exception e){return null;}
        if(rawX<loc[0]||rawY<loc[1]||rawX>loc[0]+v.getWidth()||rawY>loc[1]+v.getHeight())return null;
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=g.getChildCount()-1;i>=0;i--){View hit=clickableViewAt(g.getChildAt(i),rawX,rawY);if(hit!=null)return hit;}}
        return v.isClickable()?v:null;
    }
    @Override public boolean dispatchTouchEvent(MotionEvent ev){
        return super.dispatchTouchEvent(ev);
    }
    private void enableAutoSize(TextView v,int minSp,int maxSp){
        if(v==null)return;
        if(android.os.Build.VERSION.SDK_INT>=26){
            try{v.setAutoSizeTextTypeUniformWithConfiguration(minSp,maxSp,1,android.util.TypedValue.COMPLEX_UNIT_SP);}catch(Exception ignored){}
        }
    }
    private android.graphics.RectF fitCenterRect(int boxW,int boxH,float srcW,float srcH){
        if(boxW<=0||boxH<=0||srcW<=0||srcH<=0)return new android.graphics.RectF(0,0,boxW,boxH);
        float scale=Math.min(boxW/srcW,boxH/srcH);
        float w=srcW*scale,h=srcH*scale;
        float left=(boxW-w)/2f,top=(boxH-h)/2f;
        return new android.graphics.RectF(left,top,left+w,top+h);
    }
    private void placeOnCanvas(FrameLayout.LayoutParams p,android.graphics.RectF canvas,float[] q){
        p.width=Math.round(canvas.width()*q[2]);p.height=Math.round(canvas.height()*q[3]);
        p.leftMargin=Math.round(canvas.left+canvas.width()*q[0]);p.topMargin=Math.round(canvas.top+canvas.height()*q[1]);
    }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    private android.graphics.drawable.Drawable pressRipple(int color){
        GradientDrawable mask=new GradientDrawable();mask.setShape(GradientDrawable.OVAL);mask.setColor(Color.WHITE);
        return new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(color),null,mask);
    }

    // Soft blue/purple dialog language used across mission popups.
    private GradientDrawable pastelCardBg(int accent){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFFFCFDFF,0xFFF3F7FF,0xFFF8F4FF});
        g.setCornerRadius(dp(24));g.setStroke(Math.max(1,Math.round(dp(.7f))),withAlpha(accent,0x66));return g;
    }
    private GradientDrawable pastelButtonBg(int c1,int c2){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{c1,c2});g.setCornerRadius(dp(14));return g;
    }
    private TextView dialogButton(String text,int c1,int c2,boolean light){
        TextView b=tv(text,14,light?0xFF17345D:Color.WHITE);b.setGravity(Gravity.CENTER);b.setBackground(pastelButtonBg(c1,c2));b.setElevation(dp(2));b.setPadding(dp(8),0,dp(8),0);return b;
    }
    private TextView rewardChip(String text,int textColor,int fill,int stroke){
        TextView v=tv(text,13,textColor);v.setGravity(Gravity.CENTER);GradientDrawable g=bg(fill,dp(13));g.setStroke(Math.max(1,dp(1)),stroke);v.setBackground(g);v.setPadding(dp(10),0,dp(10),0);return v;
    }
    private Dialog buildPastelDialog(String icon,String title,String subtitle,int accent,View body,String positive,int positiveColor,Runnable positiveAction,String negative,Runnable negativeAction){
        final Dialog d=new Dialog(this,R.style.InstantDialogTheme);d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(20),dp(14),dp(20),dp(20));card.setBackground(pastelCardBg(accent));card.setElevation(dp(6));
        FrameLayout top=new FrameLayout(this);card.addView(top,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView close=tv("×",22,0xFF29436E);close.setGravity(Gravity.CENTER);FrameLayout.LayoutParams xlp=new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.RIGHT|Gravity.TOP);top.addView(close,xlp);
        final TextView ico=tv(icon==null?"✦":icon,28,accent);ico.setGravity(Gravity.CENTER);GradientDrawable ig=bg(0xEAF3F7FF,dp(999));ig.setStroke(Math.max(1,dp(1)),0x443B7CFF);ico.setBackground(ig);FrameLayout.LayoutParams ilp=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.CENTER);top.addView(ico,ilp);
        TextView t=tv(title==null?"":title,19,0xFF142C54);t.setGravity(Gravity.CENTER);card.addView(t,new LinearLayout.LayoutParams(-1,dp(34)));
        if(subtitle!=null&&subtitle.trim().length()>0){TextView sub=tv(subtitle,13,0xFF536785);sub.setGravity(Gravity.CENTER);sub.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);sub.setPadding(dp(6),0,dp(6),0);card.addView(sub,new LinearLayout.LayoutParams(-1,-2));}
        if(body!=null){LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,-2);blp.topMargin=dp(12);card.addView(body,blp);}
        if((positive!=null&&positive.length()>0)||(negative!=null&&negative.length()>0)){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(52));rlp.topMargin=dp(14);card.addView(row,rlp);
            if(positive!=null&&positive.length()>0){TextView ok=dialogButton(positive,positiveColor,0xFF7B61FF,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1f);lp.setMargins(dp(5),0,0,0);row.addView(ok,lp);ok.setOnClickListener(v->{playViewSound(v);d.dismiss();if(positiveAction!=null)positiveAction.run();});}
            if(negative!=null&&negative.length()>0){TextView no=dialogButton(negative,0xFFF8FAFF,0xFFEFF3FB,true);GradientDrawable ng=pastelButtonBg(0xFFF8FAFF,0xFFEFF3FB);ng.setStroke(Math.max(1,dp(1)),0x334D6B9A);no.setBackground(ng);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1f);lp.setMargins(0,0,dp(5),0);row.addView(no,lp);no.setOnClickListener(v->{playViewSound(v);d.dismiss();if(negativeAction!=null)negativeAction.run();});}
        }
        close.setOnClickListener(v->{playViewSound(v);d.dismiss();});
        d.setContentView(card);d.setCanceledOnTouchOutside(true);
        // Configure the dialog window BEFORE show() so Android never gets a frame to run a slide-in transition.
        Window pre=d.getWindow();
        if(pre!=null){
            pre.setWindowAnimations(0);
            pre.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams a=pre.getAttributes();
            a.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(390));
            a.height=WindowManager.LayoutParams.WRAP_CONTENT;a.gravity=Gravity.CENTER;a.dimAmount=.26f;
            pre.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);pre.setAttributes(a);
        }
        d.setOnShowListener(x->{
            Window w=d.getWindow();if(w!=null){w.setWindowAnimations(0);WindowManager.LayoutParams a=w.getAttributes();a.gravity=Gravity.CENTER;w.setAttributes(a);}
            card.animate().cancel();card.setTranslationX(0f);card.setTranslationY(0f);card.setScaleX(1f);card.setScaleY(1f);card.setAlpha(1f);
            ico.animate().cancel();ico.setTranslationX(0f);ico.setTranslationY(0f);ico.setScaleX(1f);ico.setScaleY(1f);ico.setAlpha(1f);
        });
        return d;
    }
    private void showPastelInputDialog(String title,String initial,Runnable afterSave,java.util.function.Consumer<String> saver){
        EditText input=new EditText(this);input.setSingleLine(true);input.setText(initial==null?"":initial);input.setSelection(input.getText().length());input.setTextSize(15);input.setTextColor(0xFF17345D);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(12),0,dp(12),0);GradientDrawable ig=bg(0xFFF5F8FF,dp(14));ig.setStroke(Math.max(1,dp(1)),0x443B7CFF);input.setBackground(ig);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.addView(input,new LinearLayout.LayoutParams(-1,dp(50)));
        final Dialog[] ref={null};ref[0]=buildPastelDialog("✎",title,"",0xFF4E8CFF,body,"ذخیره",0xFF3F8CFF,()->{String n=input.getText().toString().trim();if(n.length()>0){saver.accept(n);if(afterSave!=null)afterSave.run();}},"لغو",null);ref[0].show();
    }

    private void showHome(){
        stopMissionTimer();
        stopHomeActiveTicker();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome = true; isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        activeBar=null;progressMissionViews.clear();
        setContentView(root);
        root.setFitsSystemWindows(true);

        ImageView home=new ImageView(this); home.setImageResource(R.drawable.home_background);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // Legacy HUD reference final polish: premium RPG HUD.
        FrameLayout header=new FrameLayout(this);
        header.setPadding(dp(7),0,dp(7),0);
        header.setBackground(new HudBackground());
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(52),Gravity.TOP);
        hp.setMargins(dp(10),dp(6),dp(10),0);
        root.addView(header,hp);

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(1),0,dp(1),0);
        header.addView(row,new FrameLayout.LayoutParams(-1,-1));

        ImageView avatar=new ImageView(this);
        avatar.setImageResource(R.drawable.avatar_legacy);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        avatar.setContentDescription("آواتار"); avatar.setElevation(dp(2));
        LinearLayout.LayoutParams avLp=new LinearLayout.LayoutParams(dp(40),dp(40));
        avLp.setMargins(dp(2),0,dp(6),0); row.addView(avatar,avLp);

        loadGameState();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        hudLevel=tv("LV "+gameLevel,12,0xFFFFE7A0); TextView level=hudLevel;
        level.setGravity(Gravity.CENTER);
        level.setShadowLayer(dp(1),0,0,0x665E3A00);
        LinearLayout.LayoutParams levelLp=new LinearLayout.LayoutParams(dp(38),dp(34));
        levelLp.setMargins(0,0,dp(1),0); row.addView(level,levelLp);

        LinearLayout xpGroup=new LinearLayout(this);
        xpGroup.setOrientation(LinearLayout.VERTICAL);
        xpGroup.setGravity(Gravity.CENTER_VERTICAL);
        XpBarView xp=new XpBarView(this); hudXpBar=xp;
        xp.setProgress(gameXp,xpNeeded(gameLevel));
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(9));
        xpLp.setMargins(0,dp(4),0,0); xpGroup.addView(xp,xpLp);
        hudXpText=tv(gameXp+" / "+xpNeeded(gameLevel)+" XP",8,0xFFE5F7FF); TextView xpTxt=hudXpText;
        xpTxt.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        xpGroup.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(14)));
        LinearLayout.LayoutParams xpgLp=new LinearLayout.LayoutParams(dp(112),dp(36));
        xpgLp.setMargins(0,0,dp(3),0); row.addView(xpGroup,xpgLp);

        LinearLayout coinBox=glassCapsule();
        ImageView coinIcon=new ImageView(this);
        coinIcon.setImageResource(R.drawable.hud_coin); coinIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        coinBox.addView(coinIcon,new LinearLayout.LayoutParams(dp(24),dp(24)));
        hudCoinText=tv(String.valueOf(gameCoins),13,0xFFFFF3CF); TextView coin=hudCoinText; coin.setPadding(dp(1),0,0,0);
        coinBox.addView(coin,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(25));
        coinLp.setMargins(0,0,dp(1),0); row.addView(coinBox,coinLp);

        LinearLayout comboBox=glassCapsule();
        comboBox.setClickable(true);
        comboBox.setContentDescription("Combo");
        comboBox.setOnClickListener(v->{playViewSound(v);showGameSettings();});
        ImageView flame=new ImageView(this); flame.setImageResource(R.drawable.hud_flame);
        flame.setScaleType(ImageView.ScaleType.FIT_CENTER);
        comboBox.addView(flame,new LinearLayout.LayoutParams(dp(22),dp(25)));
        hudComboText=tv(String.valueOf(gameCombo),13,Color.WHITE); TextView combo=hudComboText; comboBox.addView(combo,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(44),dp(25));
        comboLp.setMargins(0,0,dp(1),0); row.addView(comboBox,comboLp);

        ImageView gear=new ImageView(this); gear.setImageResource(R.drawable.hud_gear);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER); gear.setPadding(dp(4),dp(4),dp(4),dp(4));
        gear.setContentDescription("تنظیمات");
        gear.setOnClickListener(v->{playViewSound(v);showAppSettings();});
        row.addView(gear,new LinearLayout.LayoutParams(dp(34),dp(40)));

        // Hit targets follow the six labels baked into the selected 768x1536 Home artwork.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=768f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            // The touch zones sit on the signboards and slightly above their text,
            // matching the new 768x1536 fantasy Home artwork.
            int hitW=Math.max(dp(112), Math.round(205f*scale));
            int hitH=Math.max(dp(120), Math.round(220f*scale));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=Math.round(offsetX + srcW*centers[i][0]*scale);
                int cy=Math.round(offsetY + srcH*centers[i][1]*scale);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-hitW/2; lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==MotionEvent.ACTION_DOWN){ v.setAlpha(.55f); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->{ if(idx==0)playSfx(sfxStartId,.74f);else playUiClick(); if(idx==0) showProgressPath(); else showPlaceholder(names[idx]); }); content.addView(hit,lp);
            }
        });
        addActiveMissionBar();
        header.bringToFront();
    }

    private LinearLayout glassCapsule(){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0x3003080E,dp(13)); g.setStroke(Math.max(1,Math.round(dp(.7f))),0x335D7180); box.setBackground(g);
        return box;
    }

    private class XpBarView extends View {
        private final Paint p=new Paint(1); private int value=0,max=100;
        XpBarView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void setProgress(int v,int m){ value=Math.max(0,v); max=Math.max(1,m); invalidate(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float h=getHeight(), r=h/2f; RectF track=new RectF(dp(1),dp(1),getWidth()-dp(1),h-dp(1));
            p.setStyle(Paint.Style.FILL); p.setColor(0xAA071522); c.drawRoundRect(track,r,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xAA5EB8E8); c.drawRoundRect(track,r,r,p);
            float frac=Math.min(1f,value/(float)max);
            if(frac>0f){ RectF fill=new RectF(track.left,track.top,track.left+track.width()*frac,track.bottom);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF25E6FF); p.setShadowLayer(dp(4),0,0,0xCC19D9FF); c.drawRoundRect(fill,r,r,p); p.clearShadowLayer(); }
            else { p.setStyle(Paint.Style.FILL); p.setColor(0xFF36E8FF); p.setShadowLayer(dp(3),0,0,0xAA28DFFF); c.drawCircle(track.left+dp(2),h/2f,dp(1.3f),p); p.clearShadowLayer(); }
        }
    }

    private class HudBackground extends android.graphics.drawable.Drawable {
        private final Paint fill=new Paint(1), stroke=new Paint(1), bottomGlow=new Paint(1), topAccent=new Paint(1);
        HudBackground(){
            fill.setColor(0xED08131F); fill.setStyle(Paint.Style.FILL);
            stroke.setColor(0x3D8398A6); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            bottomGlow.setColor(0xA027D5FF); bottomGlow.setStyle(Paint.Style.STROKE); bottomGlow.setStrokeWidth(dp(1));
            topAccent.setColor(0xF0E8BD62); topAccent.setStyle(Paint.Style.STROKE); topAccent.setStrokeWidth(dp(1));
        }
        private Path shape(){
            RectF b=new RectF(getBounds()); float c=dp(7); Path p=new Path();
            p.moveTo(b.left+c,b.top); p.lineTo(b.right-c,b.top); p.lineTo(b.right,b.top+c);
            p.lineTo(b.right,b.bottom-c); p.lineTo(b.right-c,b.bottom); p.lineTo(b.left+c,b.bottom);
            p.lineTo(b.left,b.bottom-c); p.lineTo(b.left,b.top+c); p.close(); return p;
        }
        @Override public void draw(Canvas c){
            RectF b=new RectF(getBounds()); Path p=shape(); c.drawPath(p,fill); c.drawPath(p,stroke);
            c.drawLine(b.left+dp(11),b.bottom-dp(1),b.right-dp(11),b.bottom-dp(1),bottomGlow);
            c.drawLine(b.left+dp(12),b.top+dp(1),b.right-dp(12),b.top+dp(1),topAccent);
        }
        @Override public void setAlpha(int a){} @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){ return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private class CoinView extends View {
        Paint p=new Paint(1); CoinView(android.content.Context c){super(c);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float r=Math.min(getWidth(),getHeight())*.43f, x=getWidth()/2f,y=getHeight()/2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFB82E); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xFFFFF0A8); c.drawCircle(x,y,r-dp(1),p);
            p.setColor(0xFFD98A00); c.drawCircle(x,y,r-dp(3),p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF8C5A00); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(10));
            c.drawText("L",x,y-(p.ascent()+p.descent())/2,p);
        }
    }

    private int gameLevel=1, gameXp=0, gameCoins=0, gameCombo=0, comboWindowMinutes=30; private long lastSuccessAt=0;
    private SharedPreferences gamePrefs;
    private int xpNeeded(int level){ return 100+Math.max(0,level-1)*50; }
    private void loadGameState(){ gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gameLevel=gamePrefs.getInt("level",1);gameXp=gamePrefs.getInt("xp",0);gameCoins=gamePrefs.getInt("coins",0);gameCombo=gamePrefs.getInt("combo",0);lastSuccessAt=gamePrefs.getLong("lastSuccessAt",0);comboWindowMinutes=gamePrefs.getInt("comboWindowMinutes",30);expireComboIfNeeded(); }
    private void saveGameState(){ if(gamePrefs==null)gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gamePrefs.edit().putInt("level",gameLevel).putInt("xp",gameXp).putInt("coins",gameCoins).putInt("combo",gameCombo).putLong("lastSuccessAt",lastSuccessAt).putInt("comboWindowMinutes",comboWindowMinutes).apply();updateHud(); }
    private void updateHud(){ if(hudLevel!=null)hudLevel.setText("LV "+gameLevel);if(hudXpBar!=null)hudXpBar.setProgress(gameXp,xpNeeded(gameLevel));if(hudXpText!=null)hudXpText.setText(gameXp+" / "+xpNeeded(gameLevel)+" XP");if(hudCoinText!=null)hudCoinText.setText(String.valueOf(gameCoins));if(hudComboText!=null)hudComboText.setText(String.valueOf(gameCombo)); }
    private void showHudState(int level,int xp,int coins,int combo){if(hudLevel!=null)hudLevel.setText("LV "+level);if(hudXpBar!=null)hudXpBar.setProgress(xp,xpNeeded(level));if(hudXpText!=null)hudXpText.setText(xp+" / "+xpNeeded(level)+" XP");if(hudCoinText!=null)hudCoinText.setText(String.valueOf(coins));if(hudComboText!=null)hudComboText.setText(String.valueOf(combo));}
    private void pulseHudRewards(){View[] vs={hudXpText,hudCoinText,hudComboText,hudLevel};for(View v:vs)if(v!=null){v.setScaleX(1f);v.setScaleY(1f);v.animate().scaleX(1.18f).scaleY(1.18f).setDuration(260).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(360).start()).start();}if(hudXpBar!=null){hudXpBar.setScaleY(1f);hudXpBar.animate().scaleY(1.5f).setDuration(260).withEndAction(()->hudXpBar.animate().scaleY(1f).setDuration(360).start()).start();}}
    private float comboMultiplier(){return gameCombo>=10?3f:gameCombo>=7?2f:gameCombo>=3?1.5f:1f;}
    private int missionImportance(int section,int slot){
        try{return Math.max(0,Math.min(2,Integer.parseInt(mv(section,slot,"importance","0"))));}catch(Exception ignored){return 0;}
    }
    private int baseXpForImportance(int section,int slot){
        int importance=missionImportance(section,slot);
        return importance==2?35:importance==1?20:10;
    }
    private int baseCoinsForImportance(int section,int slot){
        int importance=missionImportance(section,slot);
        return importance==2?7:importance==1?4:2;
    }
    private void expireComboIfNeeded(){if(gameCombo>0&&lastSuccessAt>0&&System.currentTimeMillis()-lastSuccessAt>comboWindowMinutes*60000L){gameCombo=0;lastSuccessAt=0;if(gamePrefs!=null)gamePrefs.edit().putInt("combo",0).putLong("lastSuccessAt",0).apply();}}

    private int[] missionTimes={5,10,20,30,45};
    private String mf(int s,int k,String f){return "m_"+s+"_"+k+"_"+f;}
    private String mv(int s,int k,String f,String d){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);return progressPrefs.getString(mf(s,k,f),d);}
    private void ms(int s,int k,String f,String v){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);progressPrefs.edit().putString(mf(s,k,f),v).apply();}
    private GradientDrawable sel(boolean on){GradientDrawable g=bg(on?0x183B82F6:Color.TRANSPARENT,dp(999));if(on)g.setStroke(Math.max(2,Math.round(dp(1.8f))),0xFF2477E8);return g;}
    private TextView eh(String t,int z){TextView v=tv(t,z,0xFF17345D);v.setGravity(Gravity.CENTER);return v;}

    private String missionDay(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US);return f.format(new java.util.Date());}
    private void startDailyResetTicker(){
        if(dailyResetTick!=null)missionHandler.removeCallbacks(dailyResetTick);
        lastObservedMissionDay=missionDay();
        dailyResetTick=new Runnable(){public void run(){
            String nowDay=missionDay();
            if(!nowDay.equals(lastObservedMissionDay)){lastObservedMissionDay=nowDay;applyDailyMissionResets();refreshProgressMissionVisuals();}
            missionHandler.postDelayed(this,60000L);
        }};
        missionHandler.postDelayed(dailyResetTick,60000L);
    }
    private String missionState(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressTitle(section,slot).trim().length()==0)return "empty";
        if(progressPrefs.getBoolean("active",false)&&progressPrefs.getInt("active_s",-1)==section&&progressPrefs.getInt("active_k",-1)==slot)return "active";
        String state=mv(section,slot,"state","ready");
        if("active".equals(state))state="ready";
        return state;
    }
    private void setMissionState(int section,int slot,String state){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        SharedPreferences.Editor ed=progressPrefs.edit().putString(mf(section,slot,"state"),state);
        if("done".equals(state)||"fail".equals(state))ed.putString(mf(section,slot,"state_day"),missionDay());
        else ed.remove(mf(section,slot,"state_day"));
        ed.apply();
    }

    private void saveMissionRewardSnapshot(int section,int slot){
        if(section<1||slot<0)return;if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit()
            .putBoolean(mf(section,slot,"reward_snapshot"),true)
            .putInt(mf(section,slot,"prev_level"),gameLevel)
            .putInt(mf(section,slot,"prev_xp"),gameXp)
            .putInt(mf(section,slot,"prev_coins"),gameCoins)
            .putInt(mf(section,slot,"prev_combo"),gameCombo)
            .putLong(mf(section,slot,"prev_last_success"),lastSuccessAt)
            .putInt(mf(section,slot,"reward_xp"),0)
            .putInt(mf(section,slot,"reward_coins"),0)
            .remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at"))
            .apply();
    }
    private void recordMissionReward(int section,int slot,int xp,int coins){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putInt(mf(section,slot,"reward_xp"),xp).putInt(mf(section,slot,"reward_coins"),coins)
            .putString(mf(section,slot,"reward_outcome"),xp>0?"done":"fail").putLong(mf(section,slot,"reward_at"),System.currentTimeMillis()).apply();
    }
    private long lifetimeXp(){long total=gameXp;for(int l=1;l<gameLevel;l++)total+=xpNeeded(l);return total;}
    private void setLifetimeXp(long total){total=Math.max(0,total);int level=1;while(total>=xpNeeded(level)){total-=xpNeeded(level);level++;if(level>10000)break;}gameLevel=level;gameXp=(int)Math.max(0,total);}
    private void clearMissionRewardSnapshot(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit()
            .remove(mf(section,slot,"reward_snapshot")).remove(mf(section,slot,"prev_level")).remove(mf(section,slot,"prev_xp"))
            .remove(mf(section,slot,"prev_coins")).remove(mf(section,slot,"prev_combo")).remove(mf(section,slot,"prev_last_success"))
            .remove(mf(section,slot,"reward_xp")).remove(mf(section,slot,"reward_coins")).remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at")).apply();
    }
    private void restoreMissionAndRewards(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressPrefs.getBoolean(mf(section,slot,"reward_snapshot"),false)){
            int earnedXp=progressPrefs.getInt(mf(section,slot,"reward_xp"),0),earnedCoins=progressPrefs.getInt(mf(section,slot,"reward_coins"),0),prevCombo=progressPrefs.getInt(mf(section,slot,"prev_combo"),gameCombo);long prevLast=progressPrefs.getLong(mf(section,slot,"prev_last_success"),lastSuccessAt),rewardAt=progressPrefs.getLong(mf(section,slot,"reward_at"),0);String outcome=progressPrefs.getString(mf(section,slot,"reward_outcome"),earnedXp>0?"done":"fail");
            if(earnedXp>0)setLifetimeXp(lifetimeXp()-earnedXp);if(earnedCoins>0)gameCoins=Math.max(0,gameCoins-earnedCoins);
            if("done".equals(outcome)){
                if(rewardAt>0&&Math.abs(lastSuccessAt-rewardAt)<2500){gameCombo=prevCombo;lastSuccessAt=prevLast;}else if(gameCombo>0)gameCombo=Math.max(0,gameCombo-1);
            }else if("fail".equals(outcome)){
                if(lastSuccessAt==0||lastSuccessAt<=rewardAt){gameCombo=prevCombo;lastSuccessAt=prevLast;}
            }
            saveGameState();
        }
        clearMissionRewardSnapshot(section,slot);setMissionState(section,slot,"ready");refreshProgressMissionVisuals();showProgressPath();animateRestoreFeedback();
    }
    private LinearLayout restoreRewardBody(int section,int slot){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);
        TextView note=tv("همه اثرهای این نتیجه به حالت قبل برمی‌گردد.",13,0xFF60708B);note.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(note,new LinearLayout.LayoutParams(-1,dp(36)));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);body.addView(row,new LinearLayout.LayoutParams(-1,dp(46)));
        int xp=progressPrefs.getInt(mf(section,slot,"reward_xp"),0),coins=progressPrefs.getInt(mf(section,slot,"reward_coins"),0),prevCombo=progressPrefs.getInt(mf(section,slot,"prev_combo"),gameCombo);
        TextView a=rewardChip((xp>0?"−":"")+xp+" XP",0xFF0878D8,0xFFEAF7FF,0x553C9DFF);TextView b=rewardChip((coins>0?"−":"")+coins+" Coin",0xFFB57700,0xFFFFF7DF,0x55E5B42B);TextView c=rewardChip("Combo → "+prevCombo,0xFF9A4C17,0xFFFFF0E6,0x55FF9A53);
        row.addView(a,new LinearLayout.LayoutParams(0,dp(38),1f));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(0,dp(38),1f);blp.setMargins(dp(6),0,dp(6),0);row.addView(b,blp);row.addView(c,new LinearLayout.LayoutParams(0,dp(38),1f));return body;
    }
    private void showRestoreMissionDialog(int section,int slot){
        Dialog d=buildPastelDialog("↻","Restore Mission?",progressTitle(section,slot),0xFF26A8F2,restoreRewardBody(section,slot),"Restore",0xFF2D9DFF,()->restoreMissionAndRewards(section,slot),"Cancel",null);d.show();
    }
    private void showDeleteMissionDialog(int section,int slot){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView m=tv("این مأموریت و ساب‌تسک‌هایش از مسیر حذف می‌شود.",13,0xFF68758D);m.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(m,new LinearLayout.LayoutParams(-1,dp(42)));
        Dialog d=buildPastelDialog("⌫","Delete Mission?",progressTitle(section,slot),0xFFFF6078,body,"Delete",0xFFFF5268,()->{clearMissionSlot(section,slot);showProgressPath();},"Cancel",null);d.show();
    }
    private void showActiveMissionWarning(){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView m=tv("ابتدا مأموریت فعلی را تمام، Fail یا Later کنید.",13,0xFF5F6F89);m.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(m,new LinearLayout.LayoutParams(-1,dp(44)));
        Dialog d=buildPastelDialog("!","یک مأموریت در حال اجراست","همزمان فقط یک مأموریت می‌تواند فعال باشد.",0xFFFF6B82,body,"ادامه مأموریت",0xFF4E8CFF,()->resumeActiveMission(),"بستن",null);d.show();
    }
    private void showCompletedMissionLockedDialog(String title){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView m=tv("ویرایش اطلاعات آزاد است، اما برای اجرای دوباره ابتدا Restore را بزنید.",13,0xFF5F6F89);m.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(m,new LinearLayout.LayoutParams(-1,dp(48)));
        Dialog d=buildPastelDialog("✓","ماموریت قبلاً ثبت نتیجه شده",title,0xFF6B8FFF,body,"باشه",0xFF4E8CFF,null,null,null);d.show();
    }
    private void applyDailyMissionResets(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        String today=missionDay();
        int count=Math.max(1,progressPrefs.getInt("progress_section_count",1));
        for(int s=1;s<=count;s++)for(int k=0;k<3;k++){
            if(progressTitle(s,k).trim().length()==0)continue;
            if(!"1".equals(mv(s,k,"repeat","1")))continue;
            String state=missionState(s,k);
            if(!("done".equals(state)||"fail".equals(state)))continue;
            String day=mv(s,k,"state_day","");
            if(!today.equals(day)){
                setMissionState(s,k,"ready");
                clearMissionRewardSnapshot(s,k);
                SharedPreferences sub=getSharedPreferences("legacy_subtasks_"+s+"_"+k,MODE_PRIVATE);
                sub.edit().putString("day",today).putString("done_ids","").apply();
            }
        }
    }
    private String missionViewKey(int section,int slot){return section+":"+slot;}
    private class MissionSlotView extends TextView{
        private String visualState="";
        private final Paint stateFill=new Paint(Paint.ANTI_ALIAS_FLAG);
        MissionSlotView(android.content.Context c){super(c);setWillNotDraw(false);}
        void setVisualState(String s){visualState=s==null?"":s;invalidate();}
        @Override protected void onDraw(Canvas c){
            int fillColor=Color.TRANSPARENT;
            if("done".equals(visualState))fillColor=0xFF0B8F4D;
            else if("fail".equals(visualState))fillColor=0xFF8B1E32;
            else if("active".equals(visualState))fillColor=Color.TRANSPARENT;
            if(fillColor!=Color.TRANSPARENT){
                // Fill only the inside; the colored rim is part of the artwork and remains untouched.
                float r=Math.max(0f,Math.min(getWidth(),getHeight())*.5f-dp(4));
                stateFill.setStyle(Paint.Style.FILL);stateFill.setColor(fillColor);stateFill.clearShadowLayer();
                c.drawCircle(getWidth()/2f,getHeight()/2f,r,stateFill);
            }
            super.onDraw(c);
        }
    }
    private void styleMissionSlot(TextView mission,String state){
        if(mission instanceof MissionSlotView)((MissionSlotView)mission).setVisualState(state);
        mission.clearAnimation();
        mission.setAlpha(1f);
        mission.setBackgroundColor(Color.TRANSPARENT);
        mission.setShadowLayer(0,0,0,Color.TRANSPARENT);
        mission.setPaintFlags(mission.getPaintFlags()&~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        mission.setTypeface(Typeface.DEFAULT,Typeface.BOLD);

        if("done".equals(state)){
            mission.setTextColor(0xFFFFFFFF);
            mission.setShadowLayer(dp(1.2f),0,dp(.6f),0x55000000);
        }else if("fail".equals(state)){
            mission.setTextColor(0xFFFFFFFF);
            mission.setShadowLayer(dp(1.2f),0,dp(.6f),0x55000000);
        }else if("active".equals(state)){
            mission.setTextColor(0xFF162D54);
        }else{
            // Ready and empty slots: only the original artwork, with no gold/white overlay or animation.
            mission.setTextColor(0xFF162D54);
        }
    }
    private String missionVisualState(int section,int slot){
        return missionState(section,slot);
    }
    private void refreshProgressMissionVisuals(){
        if(progressMissionViews.isEmpty())return;
        for(java.util.Map.Entry<String,TextView> entry:progressMissionViews.entrySet()){
            try{
                String[] p=entry.getKey().split(":");
                int s=Integer.parseInt(p[0]),k=Integer.parseInt(p[1]);
                TextView v=entry.getValue();
                v.setText(progressTitle(s,k));
                styleMissionSlot(v,missionVisualState(s,k));
            }catch(Exception ignored){}
        }
    }
    private void showMissionSlotMenu(final int section,final int slot){
        String title=progressTitle(section,slot);if(title.trim().length()==0){showMissionEditor(section,slot);return;}
        String state=missionState(section,slot);
        if("active".equals(state)){resumeActiveMission();return;}
        java.util.ArrayList<String> items=new java.util.ArrayList<>();
        if("done".equals(state)||"fail".equals(state))items.add("Restore");
        items.add("ویرایش مأموریت");items.add("حذف مأموریت");
        final String[] arr=items.toArray(new String[0]);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(0,dp(2),0,0);
        final Dialog[] menu={null};
        for(String item:arr){
            boolean danger="حذف مأموریت".equals(item);
            TextView choice=tv(item,14,danger?0xFFD9435B:0xFF17345D);choice.setGravity(Gravity.CENTER);
            GradientDrawable cg=bg(danger?0xFFFFF3F5:0xFFF5F8FF,dp(14));cg.setStroke(Math.max(1,Math.round(dp(.7f))),danger?0x44FF6078:0x334E8CFF);choice.setBackground(cg);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.setMargins(0,dp(4),0,dp(4));body.addView(choice,cp);
            choice.setOnClickListener(v->{playViewSound(v);menu[0].dismiss();String chosen=((TextView)v).getText().toString();if("Restore".equals(chosen))showRestoreMissionDialog(section,slot);else if("ویرایش مأموریت".equals(chosen))showMissionEditor(section,slot);else if("حذف مأموریت".equals(chosen))showDeleteMissionDialog(section,slot);});
        }
        menu[0]=buildPastelDialog("✦",title,"مدیریت مأموریت",0xFF4E8CFF,body,null,0,null,"بستن",null);menu[0].show();
    }
    private void confirmDeleteMission(final int section,final int slot){showDeleteMissionDialog(section,slot);}

    private void showMissionEditor(final int section,final int slot){
        stopHomeActiveTicker();
        isHome=false;isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=true;isPlaceholderScreen=false;++homeGeneration;getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);content.removeAllViews();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);applyDailyMissionResets();
        FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(R.drawable.mission_editor_reference);art.setScaleType(ImageView.ScaleType.FIT_CENTER);
        e.addView(art,new FrameLayout.LayoutParams(-1,-1));

        final String old=progressTitle(section,slot);
        final String entryState=missionState(section,slot);
        final boolean resultLocked="done".equals(entryState)||"fail".equals(entryState);
        final EditText title=new EditText(this);title.setSingleLine(true);title.setText(old.length()==0?"عنوان":old);
        title.setTextSize(14);title.setTextColor(0xFF17345D);title.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        title.setPadding(dp(8),0,dp(8),0);title.setBackgroundColor(Color.TRANSPARENT);title.setLongClickable(false);title.setTextIsSelectable(false);enableAutoSize(title,10,14);title.setOnClickListener(v->playUiClick());
        if(android.os.Build.VERSION.SDK_INT>=29){
            try{
                title.setTextCursorDrawable(getDrawable(R.drawable.editor_cursor));
                title.setTextSelectHandle(getDrawable(R.drawable.editor_handle_invisible));
                title.setTextSelectHandleLeft(getDrawable(R.drawable.editor_handle_invisible));
                title.setTextSelectHandleRight(getDrawable(R.drawable.editor_handle_invisible));
            }catch(Exception ignored){}
        }
        FrameLayout.LayoutParams tl=new FrameLayout.LayoutParams(0,0);e.addView(title,tl);

        final TextView circleTitle=eh(old,15);circleTitle.setTextColor(0xFF17345D);circleTitle.setTranslationX(dp(2.5f));circleTitle.setTranslationY(-dp(1.5f));
        FrameLayout.LayoutParams cl=new FrameLayout.LayoutParams(0,0);e.addView(circleTitle,cl);

        // Every truly new/empty mission starts from the agreed defaults.
        if(old.trim().length()==0){
            progressPrefs.edit()
                .putString(mf(section,slot,"importance"),"0")
                .putString(mf(section,slot,"minutes"),"10")
                .putString(mf(section,slot,"repeat"),"1")
                .putString(mf(section,slot,"state"),"ready")
                .remove(mf(section,slot,"state_day"))
                .apply();
        }
        final int[] imp={Integer.parseInt(mv(section,slot,"importance","0"))};
        final TextView[] iv={eh("",1),eh("",1),eh("",1)};
        for(TextView v:iv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        int saved=Integer.parseInt(mv(section,slot,"minutes","10"));final int[] ti={1};
        for(int i=0;i<missionTimes.length;i++)if(missionTimes[i]==saved)ti[0]=i;
        final TextView minus=eh("",1),time=eh(missionTimes[ti[0]]+" دقیقه",14),plus=eh("",1);time.setTranslationY(0f);
        e.addView(minus,new FrameLayout.LayoutParams(0,0));e.addView(time,new FrameLayout.LayoutParams(0,0));e.addView(plus,new FrameLayout.LayoutParams(0,0));

        final int[] rp={Integer.parseInt(mv(section,slot,"repeat","1"))};
        final TextView[] rv={eh("",1),eh("",1)};
        for(TextView v:rv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        final TextView start=eh("Start Mission",1);start.setTextColor(Color.TRANSPARENT);start.setBackgroundColor(Color.TRANSPARENT);
        e.addView(start,new FrameLayout.LayoutParams(0,0));

        // Exact responsive hit areas from the approved 768x1536 artwork.
        e.addOnLayoutChangeListener((v,l,t,r,bt,ol,ot,or,ob)->{
            android.graphics.RectF canvas=fitCenterRect(e.getWidth(),e.getHeight(),768f,1536f);
            java.util.function.BiConsumer<View,float[]> place=(view,q)->{
                FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();
                placeOnCanvas(p,canvas,q);view.setLayoutParams(p);
            };
            // Pixel-calibrated from the actual 768x1536 editor artwork.
            place.accept(title,new float[]{.403646f,.419922f,.419271f,.041667f});
            // No separate title circle exists in this artwork.
            place.accept(circleTitle,new float[]{0f,0f,0f,0f});
            place.accept(iv[0],new float[]{.402344f,.505859f,.162760f,.047526f});
            place.accept(iv[1],new float[]{.575521f,.503906f,.180990f,.055339f});
            place.accept(iv[2],new float[]{.769531f,.505208f,.169271f,.048828f});
            place.accept(minus,new float[]{.402344f,.598307f,.106771f,.049479f});
            place.accept(time,new float[]{.510417f,.598307f,.194010f,.049479f});
            place.accept(plus,new float[]{.705729f,.598307f,.104167f,.049479f});
            place.accept(rv[0],new float[]{.402344f,.684896f,.256510f,.052083f});
            place.accept(rv[1],new float[]{.675781f,.684896f,.260417f,.052083f});
            place.accept(start,new float[]{.132812f,.798828f,.735677f,.074219f});
        });

        // Defaults are visible immediately.
        for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));
        for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));
        time.setText(missionTimes[ti[0]]+" دقیقه");

        title.setOnFocusChangeListener((v,has)->{
            if(has&&"عنوان".contentEquals(title.getText()))title.setText("");
            if(!has){String x=title.getText().toString().trim();
                if(x.length()==0){
                    if(resultLocked){title.setText(old);circleTitle.setText(old);}
                    else{title.setText("عنوان");circleTitle.setText("");progressPrefs.edit().remove("title_"+section+"_"+slot).putString(mf(section,slot,"state"),"ready").remove(mf(section,slot,"state_day")).apply();}
                }else{progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();if(!resultLocked&&"empty".equals(missionState(section,slot)))setMissionState(section,slot,"ready");circleTitle.setText(x);}
            }
        });
        title.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence x,int a,int b,int c){}
            public void onTextChanged(CharSequence x,int a,int b,int c){String q=x.toString().trim();circleTitle.setText("عنوان".equals(q)?"":q);}
            public void afterTextChanged(android.text.Editable x){}
        });
        for(int i=0;i<3;i++){final int q=i;iv[i].setClickable(true);iv[i].setOnClickListener(v->{playViewSound(v);imp[0]=q;ms(section,slot,"importance",""+q);for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));});}
        minus.setClickable(true);plus.setClickable(true);
        minus.setOnClickListener(v->{playViewSound(v);if(ti[0]>0)ti[0]--;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        plus.setOnClickListener(v->{playViewSound(v);if(ti[0]<missionTimes.length-1)ti[0]++;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        for(int i=0;i<2;i++){final int q=i;rv[i].setClickable(true);rv[i].setOnClickListener(v->{playViewSound(v);rp[0]=q;ms(section,slot,"repeat",""+q);for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));});}
        start.setClickable(true);start.setOnClickListener(v->{playViewSound(v);
            String x=title.getText().toString().trim();
            if(x.length()==0||"عنوان".equals(x)){Toast.makeText(this,"عنوان مأموریت را وارد کنید",Toast.LENGTH_SHORT).show();return;}
            progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();
            if("empty".equals(missionState(section,slot)))setMissionState(section,slot,"ready");
            hideKeyboard(title);
            if(resultLocked){showCompletedMissionLockedDialog(x);return;}
            if(progressPrefs.getBoolean("active",false)){
                int as=progressPrefs.getInt("active_s",-1),ak=progressPrefs.getInt("active_k",-1);
                if(as==section&&ak==slot){resumeActiveMission();return;}
                showActiveMissionWarning();return;
            }
            clearMissionRewardSnapshot(section,slot);
            startRunningMission(section,slot,x,missionTimes[ti[0]]);
        });
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
    }

    private void hideKeyboard(View v){
        try{((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}
    }

    private android.os.Handler missionHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable missionTick;
    private android.media.MediaPlayer missionPlayer; private boolean missionMuted=false; private static final int REQ_MISSION_MUSIC=9042;

    private class MissionProgressView extends View {
        private final Paint p=new Paint(1); private float fraction=0f;
        MissionProgressView(android.content.Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setFraction(float f){fraction=Math.max(0f,Math.min(1f,f));invalidate();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float sw=dp(8.5f),pad=sw/2f+dp(1.2f);
            RectF r=new RectF(pad,pad,getWidth()-pad,getHeight()-pad);
            p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(sw);p.setColor(0xECF8FBFF);c.drawArc(r,-90,360,false,p);
            if(fraction>0f){p.setColor(0xFF2A8FFF);p.setShadowLayer(dp(2.8f),0,0,0x552A8FFF);c.drawArc(r,-90,360f*fraction,false,p);p.clearShadowLayer();}
        }
    }

    private void startRunningMission(final int section,final int slot,final String title,final int minutes){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressPrefs.getBoolean("active",false)){
            int as=progressPrefs.getInt("active_s",-1),ak=progressPrefs.getInt("active_k",-1);
            if(as==section&&ak==slot){resumeActiveMission();return;}
            showActiveMissionWarning();
            return;
        }
        setMissionState(section,slot,"ready");
        final long total=minutes*60000L;
        final long endAt=System.currentTimeMillis()+total;
        progressPrefs.edit()
            .putBoolean("active",true)
            .putInt("active_s",section)
            .putInt("active_k",slot)
            .putString("active_title",title)
            .putLong("active_end",endAt)
            .putLong("active_total",total)
            .putBoolean("active_alerted",false)
            .apply();
        ensureNotificationPermission();
        cancelMissionNotification();
        scheduleMissionAlarm(endAt);
        showRunningMissionScreen(section,slot,title,endAt,total);
    }

    private void resumeActiveMission(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(!progressPrefs.getBoolean("active",false)){Toast.makeText(this,"ماموریت فعالی وجود ندارد",Toast.LENGTH_SHORT).show();showProgressPath();return;}
        int section=progressPrefs.getInt("active_s",-1),slot=progressPrefs.getInt("active_k",-1);
        long endAt=progressPrefs.getLong("active_end",0),total=progressPrefs.getLong("active_total",0);
        String title=progressPrefs.getString("active_title","");
        if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        if(section<1||slot<0||endAt<=0||total<=0){clearActiveMissionState();Toast.makeText(this,"اطلاعات مأموریت فعال ناقص بود",Toast.LENGTH_SHORT).show();showProgressPath();return;}
        showRunningMissionScreen(section,slot,title,endAt,total);
    }

    private int[] subtaskStats(int section,int slot){
        SharedPreferences sp=getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE);
        int totalCount=0,doneCount=0;
        java.util.HashSet<String> doneIds=new java.util.HashSet<>();
        if(subtaskDay().equals(sp.getString("day",""))){
            for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0)doneIds.add(x.trim());
        }
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);if(p.length<2)continue;
            totalCount++;if(doneIds.contains(p[0]))doneCount++;
        }
        return new int[]{doneCount,totalCount};
    }

    private void showRunningMissionScreen(final int section,final int slot,final String title,final long endAt,final long total){
        stopHomeActiveTicker();
        removeActiveMissionBar();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        isHome=false;isRunningMissionScreen=true;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=false;++homeGeneration;content.removeAllViews();
        final FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(R.drawable.mission_running_reference);art.setScaleType(ImageView.ScaleType.FIT_CENTER);e.addView(art,new FrameLayout.LayoutParams(-1,-1));
        final TextView missionTitle=eh(title,14);missionTitle.setTextColor(0xFF355883);missionTitle.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);missionTitle.setMaxLines(2);missionTitle.setLineSpacing(0,1.02f);missionTitle.setGravity(Gravity.CENTER);missionTitle.setIncludeFontPadding(false);enableAutoSize(missionTitle,8,14);e.addView(missionTitle,new FrameLayout.LayoutParams(0,0));
        final MissionProgressView ring=new MissionProgressView(this);e.addView(ring,new FrameLayout.LayoutParams(0,0));
        final TextView timer=eh("",38);timer.setTextColor(0xFF071A4A);timer.setTypeface(android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL));timer.setLetterSpacing(.045f);timer.setShadowLayer(dp(1.4f),0,dp(1),0x44FFFFFF);e.addView(timer,new FrameLayout.LayoutParams(0,0));
        float rewardMult=comboMultiplier();int previewXp=Math.max(1,Math.round(baseXpForImportance(section,slot)*rewardMult)),previewCoins=Math.max(1,Math.round(baseCoinsForImportance(section,slot)*rewardMult));
        final TextView rewardPreview=eh("★ +"+previewXp+" XP     ● +"+previewCoins+" Coin",12);rewardPreview.setTextColor(0xFF285A8F);rewardPreview.setTypeface(android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL));rewardPreview.setBackground(bg(0xA8F4F8FF,dp(999)));rewardPreview.setPadding(dp(10),0,dp(10),0);e.addView(rewardPreview,new FrameLayout.LayoutParams(0,0));
        final TextView subtaskBadge=eh("",10);subtaskBadge.setTextColor(Color.WHITE);subtaskBadge.setBackground(bg(0xE84267A6,dp(999)));subtaskBadge.setPadding(dp(5),0,dp(5),0);e.addView(subtaskBadge,new FrameLayout.LayoutParams(0,0));
        final View done=new View(this),fail=new View(this),music=new View(this),sound=new View(this),reset=new View(this),subtasks=new View(this);
        done.setContentDescription("Done");fail.setContentDescription("Fail");music.setContentDescription("Choose music");sound.setContentDescription("Sound on/off");reset.setContentDescription("Reset mission");subtasks.setContentDescription("Subtasks");
        done.setBackground(pressRipple(0x4400D878));fail.setBackground(pressRipple(0x44FF355C));music.setBackground(pressRipple(0x334D8EFF));sound.setBackground(pressRipple(0x334D8EFF));reset.setBackground(pressRipple(0x334D8EFF));subtasks.setBackground(pressRipple(0x334D8EFF));
        e.addView(done,new FrameLayout.LayoutParams(0,0));e.addView(fail,new FrameLayout.LayoutParams(0,0));e.addView(music,new FrameLayout.LayoutParams(0,0));e.addView(sound,new FrameLayout.LayoutParams(0,0));e.addView(reset,new FrameLayout.LayoutParams(0,0));e.addView(subtasks,new FrameLayout.LayoutParams(0,0));
        e.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{android.graphics.RectF canvas=fitCenterRect(e.getWidth(),e.getHeight(),768f,1536f);java.util.function.BiConsumer<View,float[]> place=(view,q)->{FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();placeOnCanvas(p,canvas,q);view.setLayoutParams(p);};
            // Pixel-calibrated from the actual 768x1536 running-mission artwork.
            place.accept(missionTitle,new float[]{.315104f,.474609f,.367188f,.043620f});
            place.accept(ring,new float[]{.255208f,.447266f,.486979f,.243490f});
            place.accept(timer,new float[]{.332031f,.533854f,.333333f,.058594f});
            place.accept(rewardPreview,new float[]{.312500f,.603516f,.372396f,.029297f});
            place.accept(done,new float[]{.166667f,.681641f,.216146f,.108073f});place.accept(fail,new float[]{.623698f,.681641f,.216146f,.108073f});
            place.accept(music,new float[]{.128906f,.839193f,.131510f,.065104f});place.accept(sound,new float[]{.324219f,.839193f,.131510f,.065104f});place.accept(reset,new float[]{.544271f,.839193f,.131510f,.065104f});place.accept(subtasks,new float[]{.747396f,.839193f,.131510f,.065104f});
            place.accept(subtaskBadge,new float[]{.800781f,.825521f,.104167f,.022786f});
        });
        missionMuted=false;
        missionAudioPrefs().edit().remove("muted").apply();
        if(isMusicEnabled())playSavedMissionMusic(); else stopMissionMusic();
        if(missionTick!=null)missionHandler.removeCallbacks(missionTick);
        missionTick=new Runnable(){public void run(){
            long rem=Math.max(0,endAt-System.currentTimeMillis());
            long elapsed=Math.min(total,Math.max(0,total-rem));
            ring.setFraction(total<=0?1f:elapsed/(float)total);
            long sec=(rem+999)/1000;
            timer.setText(String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60));
            if(sec<=10)timer.setTextColor(0xFFC62845);else if(sec<=60)timer.setTextColor(0xFFC17A18);else timer.setTextColor(0xFF071A4A);
            int[] ss=subtaskStats(section,slot);subtaskBadge.setText(ss[1]>0?(ss[0]+"/"+ss[1]):"0");
            if(rem>0)missionHandler.postDelayed(this,250);
            else{
                timer.setText("00:00");
                timer.setTextColor(0xFFC62845);
                ring.setFraction(1f);
                stopMissionMusic();
                playSfx(sfxTimerEndId,.38f);
                if(progressPrefs!=null&&!progressPrefs.getBoolean("active_alerted",false))finishMissionTimerAlert();
            }
        }};missionHandler.post(missionTick);
        done.setOnClickListener(v->{playViewSound(v);completeMission(true);});fail.setOnClickListener(v->{playViewSound(v);completeMission(false);});
        music.setOnClickListener(v->{playViewSound(v);chooseMissionMusic();});
        sound.setOnClickListener(v->{
            boolean wasOn=isSfxEnabled();
            if(wasOn)playSfx(sfxToggleId,.72f);
            boolean next=!wasOn;
            appSettingsPrefs().edit().putBoolean("sfx_enabled",next).apply();
            if(next)playSfx(sfxToggleId,.72f);
            Toast.makeText(this,next?"افکت صدا روشن شد":"افکت صدا خاموش شد",Toast.LENGTH_SHORT).show();
        });
        reset.setOnClickListener(v->{playViewSound(v);showLaterConfirm(section,slot,title);});
        subtasks.setOnClickListener(v->{playViewSound(v);showSubtasksPopup(section,slot);});
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
    }

    private SharedPreferences missionAudioPrefs(){
        return getSharedPreferences("legacy_mission_audio",MODE_PRIVATE);
    }
    // Keep the three-mode structure, but temporarily point every mode at one tiny focus loop.
    private final int[] defaultFocusMusic={R.raw.focus_calm,R.raw.focus_calm,R.raw.focus_calm};
    private final String[] defaultFocusMusicNames={"شاد","متعادل","آرام"};

    private String selectedMissionMusic(){
        SharedPreferences sp=missionAudioPrefs();
        String selected=sp.getString("selected","");
        if(selected.length()==0){
            // One-time migration from the v43 single-URI setting.
            String old=sp.getString("uri","");
            if(old.length()>0){
                selected="u:"+old;
                addUserMusicTrack(old,displayNameForUri(android.net.Uri.parse(old)));
            }else selected="d:0";
            sp.edit().putString("selected",selected).apply();
        }
        return selected;
    }
    private java.util.ArrayList<String[]> loadUserMusicTracks(){
        java.util.ArrayList<String[]> out=new java.util.ArrayList<>();
        String raw=missionAudioPrefs().getString("user_tracks","");
        for(String line:raw.split("\n")){
            if(line.trim().length()==0)continue;
            String[] parts=line.split("\t",2);
            if(parts.length<2)continue;
            try{
                out.add(new String[]{android.net.Uri.decode(parts[0]),android.net.Uri.decode(parts[1])});
            }catch(Exception ignored){}
        }
        return out;
    }
    private void saveUserMusicTracks(java.util.ArrayList<String[]> tracks){
        java.util.ArrayList<String> lines=new java.util.ArrayList<>();
        for(String[] x:tracks){
            if(x==null||x.length<2||x[0]==null||x[0].trim().length()==0)continue;
            lines.add(android.net.Uri.encode(x[0])+"\t"+android.net.Uri.encode(x[1]==null?"موسیقی":x[1]));
        }
        missionAudioPrefs().edit().putString("user_tracks",android.text.TextUtils.join("\n",lines)).apply();
    }
    private void addUserMusicTrack(String uri,String name){
        if(uri==null||uri.trim().length()==0)return;
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        for(String[] x:tracks)if(uri.equals(x[0]))return;
        tracks.add(new String[]{uri,(name==null||name.trim().length()==0)?"موسیقی گوشی":name.trim()});
        saveUserMusicTracks(tracks);
    }
    private void removeUserMusicTrack(String uri){
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        java.util.ArrayList<String[]> keep=new java.util.ArrayList<>();
        for(String[] x:tracks)if(!uri.equals(x[0]))keep.add(x);
        saveUserMusicTracks(keep);
        if(("u:"+uri).equals(selectedMissionMusic())){
            missionAudioPrefs().edit().putString("selected","d:0").apply();
            playMissionDefault(0);
        }
    }
    private String displayNameForUri(android.net.Uri uri){
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);
            if(c!=null&&c.moveToFirst()){
                int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if(i>=0){String n=c.getString(i);if(n!=null&&n.trim().length()>0)return n;}
            }
        }catch(Exception ignored){}finally{try{if(c!=null)c.close();}catch(Exception ignored){}}
        String last=uri==null?null:uri.getLastPathSegment();
        return last==null?"موسیقی گوشی":last;
    }

    private void showMissionMusicPicker(){
        final LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(4),0,dp(4),dp(2));outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final Dialog[] dlg={null};String selected=selectedMissionMusic();
        TextView defaultHead=tv("حالت موسیقی",12,0xFF536785);defaultHead.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);defaultHead.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);outer.addView(defaultHead,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout tiles=new LinearLayout(this);tiles.setOrientation(LinearLayout.HORIZONTAL);tiles.setGravity(Gravity.CENTER);tiles.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);outer.addView(tiles,new LinearLayout.LayoutParams(-1,dp(112)));
        String[] glyph={"◉","✦","◈"};
        for(int i=0;i<defaultFocusMusic.length;i++){
            final int q=i;final boolean on=("d:"+i).equals(selected);
            LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(4),dp(6),dp(4),dp(6));
            GradientDrawable tg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{on?0xFFE9F7FF:0xFFF7F9FF,on?0xFFEFE8FF:0xFFF0F4FF});tg.setCornerRadius(dp(16));tg.setStroke(Math.max(1,dp(1)),on?0xFF4C8DFF:0x22466FA8);tile.setBackground(tg);tile.setElevation(on?dp(3):0);
            TextView art=tv(glyph[i%glyph.length],28,on?0xFF416DFF:0xFF6E7FA5);art.setGravity(Gravity.CENTER);tile.addView(art,new LinearLayout.LayoutParams(-1,dp(52)));
            TextView nm=tv(defaultFocusMusicNames[i],11,0xFF17345D);nm.setGravity(Gravity.CENTER);tile.addView(nm,new LinearLayout.LayoutParams(-1,dp(30)));
            tile.setOnClickListener(v->{playViewSound(v);missionAudioPrefs().edit().putString("selected","d:"+q).apply();playMissionDefault(q);if(dlg[0]!=null)dlg[0].dismiss();});
            LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,dp(100),1f);tlp.setMargins(dp(4),dp(4),dp(4),dp(4));tiles.addView(tile,tlp);
        }
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        TextView phoneHead=tv("My Music (From Phone)",12,0xFF536785);phoneHead.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);phoneHead.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);LinearLayout.LayoutParams ph=new LinearLayout.LayoutParams(-1,dp(34));ph.topMargin=dp(4);outer.addView(phoneHead,ph);
        if(tracks.isEmpty()){
            TextView none=tv("هنوز موسیقی‌ای از گوشی اضافه نشده",12,0xFF8190A8);none.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);none.setGravity(Gravity.CENTER);outer.addView(none,new LinearLayout.LayoutParams(-1,dp(48)));
        }else{
            for(String[] x:tracks){final String uri=x[0],name=x[1];addMusicPickerRow(outer,name,("u:"+uri).equals(selected),()->{missionAudioPrefs().edit().putString("selected","u:"+uri).putString("uri",uri).apply();playMissionMusic(android.net.Uri.parse(uri));if(dlg[0]!=null)dlg[0].dismiss();},()->{removeUserMusicTrack(uri);if(dlg[0]!=null)dlg[0].dismiss();showMissionMusicPicker();});}
        }
        TextView add=dialogButton("＋  Add Music",0xFF2FA8FF,0xFF7B61FF,false);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(50));alp.topMargin=dp(10);outer.addView(add,alp);add.setOnClickListener(v->{playViewSound(v);if(dlg[0]!=null)dlg[0].dismiss();chooseMissionMusicFromPhone();});
        ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);scroll.addView(outer,new ScrollView.LayoutParams(-1,-2));LinearLayout holder=new LinearLayout(this);holder.setOrientation(LinearLayout.VERTICAL);holder.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(480),getResources().getDisplayMetrics().heightPixels*2/3)));
        dlg[0]=buildPastelDialog("♫","انتخاب موسیقی","شاد • متعادل • آرام + موسیقی‌های گوشی",0xFF4D8EFF,holder,null,0,null,null,null);dlg[0].show();
    }
    private void addMusicPickerRow(LinearLayout outer,String name,boolean selected,Runnable choose,Runnable delete){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),0,dp(10),0);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        GradientDrawable rg=bg(selected?0xFFEAF4FF:0x00FFFFFF,dp(12));if(selected)rg.setStroke(1,0xFF2477E8);row.setBackground(rg);
        TextView label=tv((selected?"✓  ":"")+name,14,0xFF17345D);label.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        row.addView(label,new LinearLayout.LayoutParams(0,dp(46),1f));
        if(delete!=null){
            TextView del=tv("×",20,0xFFD84A55);del.setGravity(Gravity.CENTER);del.setContentDescription("حذف موسیقی");
            row.addView(del,new LinearLayout.LayoutParams(dp(42),dp(46)));
            del.setOnClickListener(v->{playViewSound(v);delete.run();});
        }
        row.setOnClickListener(v->{playViewSound(v);choose.run();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.bottomMargin=dp(4);outer.addView(row,lp);
    }
    private void chooseMissionMusicFromPhone(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_MISSION_MUSIC);
    }
    private void chooseMissionMusic(){showMissionMusicPicker();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_MISSION_MUSIC&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{
                android.net.Uri u=data.getData();
                int takeFlags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try{getContentResolver().takePersistableUriPermission(u,takeFlags&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                String uri=u.toString();
                addUserMusicTrack(uri,displayNameForUri(u));
                missionAudioPrefs().edit().putString("selected","u:"+uri).putString("uri",uri).apply();
                playMissionMusic(u);
                Toast.makeText(this,"به لیست موسیقی‌ها اضافه شد",Toast.LENGTH_SHORT).show();
            }catch(Exception ex){Toast.makeText(this,"موزیک قابل پخش نیست",Toast.LENGTH_SHORT).show();}
        }
    }
    private void playMissionDefault(int index){
        stopMissionMusic();
        try{
            int q=Math.max(0,Math.min(defaultFocusMusic.length-1,index));
            missionPlayer=android.media.MediaPlayer.create(this,defaultFocusMusic[q]);
            if(missionPlayer!=null){
                missionPlayer.setLooping(true);setMissionMusicOutput();missionPlayer.start();
            }
        }catch(Exception ignored){}
    }
    private void playMissionMusic(android.net.Uri u){
        stopMissionMusic();
        try{
            missionPlayer=android.media.MediaPlayer.create(this,u);
            if(missionPlayer!=null){missionPlayer.setLooping(true);setMissionMusicOutput();missionPlayer.start();}
        }catch(Exception ignored){}
    }
    private void playSavedMissionMusic(){
        if(missionPlayer!=null)return;
        String selected=selectedMissionMusic();
        try{
            if(selected.startsWith("d:")){
                int q=Integer.parseInt(selected.substring(2));playMissionDefault(q);
            }else if(selected.startsWith("u:")){
                playMissionMusic(android.net.Uri.parse(selected.substring(2)));
                if(missionPlayer==null){missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
            }else{missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
        }catch(Exception ex){missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
    }
    private void stopMissionMusic(){try{if(missionPlayer!=null){missionPlayer.stop();missionPlayer.release();missionPlayer=null;}}catch(Exception ignored){missionPlayer=null;}}

    private String subtaskDay(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US);return f.format(new java.util.Date());}
    private void showSubtasksPopup(final int section,final int slot){
        final SharedPreferences sp=getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE);String day=subtaskDay();if(!day.equals(sp.getString("day","")))sp.edit().putString("day",day).putString("done_ids","").apply();
        final LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(2),0,dp(2),dp(2));outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);final LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));outer.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(420),getResources().getDisplayMetrics().heightPixels/2)));
        final Runnable[] render={null};render[0]=()->{
            list.removeAllViews();String raw=sp.getString("items","");java.util.LinkedHashSet<String> doneIds=new java.util.LinkedHashSet<>();for(String x:sp.getString("done_ids","").split("\\n"))if(x.trim().length()>0)doneIds.add(x.trim());java.util.ArrayList<String[]> active=new java.util.ArrayList<>(),done=new java.util.ArrayList<>();
            for(String line:raw.split("\\n")){if(line.trim().length()==0)continue;String[] parts=line.split("\\|",2);if(parts.length<2)continue;(doneIds.contains(parts[0])?done:active).add(parts);}
            if(active.isEmpty()&&done.isEmpty()){TextView empty=tv("No subtasks yet",13,0xFF8290A6);empty.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(70)));}
            for(String[] x:active)addSubtaskRow(list,x[0],x[1],false,sp,render[0]);
            for(String[] x:done)addSubtaskRow(list,x[0],x[1],true,sp,render[0]);
        };
        TextView add=dialogButton("＋  Add Subtask",0xFF2FA8FF,0xFF7B61FF,false);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(50));alp.topMargin=dp(12);outer.addView(add,alp);
        add.setOnClickListener(v->{playViewSound(v);showPastelInputDialog("Add Subtask","",render[0],n->{String raw=sp.getString("items","");String id=System.currentTimeMillis()+"_"+Math.abs((n+System.nanoTime()).hashCode());sp.edit().putString("items",raw+(raw.length()>0?"\n":"")+id+"|"+n.replace("\n"," ")).apply();});});
        render[0].run();Dialog d=buildPastelDialog("☑","Subtasks","",0xFF587DFF,outer,null,0,null,null,null);d.show();
    }
    private void addSubtaskRow(LinearLayout list,String id,String text,boolean checked,SharedPreferences sp,Runnable render){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setPadding(dp(8),0,dp(4),0);GradientDrawable rg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{checked?0xFFF0F5F8:0xFFF9FBFF,checked?0xFFF3F0FA:0xFFF1F5FF});rg.setCornerRadius(dp(14));rg.setStroke(Math.max(1,dp(1)),checked?0x223F607F:0x334D8DFF);row.setBackground(rg);
        CheckBox c=new CheckBox(this);c.setText(text);c.setChecked(checked);c.setTextSize(14);c.setTextColor(checked?0xFF8792A4:0xFF17345D);c.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);c.setContentDescription("Subtask");try{c.setButtonTintList(ColorStateList.valueOf(0xFF4D8DFF));}catch(Exception ignored){}if(checked)c.setPaintFlags(c.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        TextView edit=tv("✎",17,0xFF2477E8);edit.setGravity(Gravity.CENTER);edit.setContentDescription("Edit");
        TextView del=tv("×",20,0xFFD84A55);del.setGravity(Gravity.CENTER);del.setContentDescription("Delete");
        row.addView(c,new LinearLayout.LayoutParams(0,dp(50),1f));row.addView(edit,new LinearLayout.LayoutParams(dp(40),dp(50)));row.addView(del,new LinearLayout.LayoutParams(dp(40),dp(50)));
        c.setOnCheckedChangeListener((b,on)->{playSfx(sfxSubtaskId,.62f);
            java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();
            for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0)set.add(x.trim());
            if(on)set.add(id);else set.remove(id);
            sp.edit().putString("done_ids",android.text.TextUtils.join("\n",set)).apply();
            b.post(render);
        });
        edit.setOnClickListener(v->{playViewSound(v);showPastelInputDialog("Edit Subtask",text,render,n->updateSubtaskText(sp,id,n));});
        del.setOnClickListener(v->{playViewSound(v);
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView msg=tv("Delete this subtask?",13,0xFF65748D);msg.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(msg,new LinearLayout.LayoutParams(-1,dp(44)));
            Dialog d=buildPastelDialog("×","Delete Subtask","",0xFFFF6078,body,"Delete",0xFFFF5268,()->{deleteSubtask(sp,id);render.run();},"Cancel",null);d.show();
        });
        LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(52));rlp.bottomMargin=dp(6);list.addView(row,rlp);
    }
    private void updateSubtaskText(SharedPreferences sp,String id,String newText){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);
            if(p.length==2&&id.equals(p[0]))out.add(id+"|"+newText.replace("\n"," "));
            else out.add(line);
        }
        sp.edit().putString("items",android.text.TextUtils.join("\n",out)).apply();
    }
    private void deleteSubtask(SharedPreferences sp,String id){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);if(p.length==2&&id.equals(p[0]))continue;out.add(line);
        }
        java.util.LinkedHashSet<String> done=new java.util.LinkedHashSet<>();
        for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0&&!id.equals(x.trim()))done.add(x.trim());
        sp.edit().putString("items",android.text.TextUtils.join("\n",out)).putString("done_ids",android.text.TextUtils.join("\n",done)).apply();
    }

    private void stopMissionTimer(){if(missionTick!=null){missionHandler.removeCallbacks(missionTick);missionTick=null;}}
    private void stopHomeActiveTicker(){if(homeActiveTick!=null){missionHandler.removeCallbacks(homeActiveTick);homeActiveTick=null;}}
    private void completeMission(boolean success){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        int section=progressPrefs.getInt("active_s",-1),slot=progressPrefs.getInt("active_k",-1);
        String title=progressPrefs.getString("active_title","");if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        stopMissionTimer();stopMissionMusic();expireComboIfNeeded();
        if(section>0&&slot>=0)saveMissionRewardSnapshot(section,slot);
        if(section>0&&slot>=0){setMissionState(section,slot,success?"done":"fail");refreshProgressMissionVisuals();}
        if(success){
            float mult=comboMultiplier();int earnedXp=Math.max(1,Math.round(baseXpForImportance(section,slot)*mult));int earnedCoins=Math.max(1,Math.round(baseCoinsForImportance(section,slot)*mult));int oldLevel=gameLevel,oldXp=gameXp,oldCoins=gameCoins,oldCombo=gameCombo;
            gameXp+=earnedXp;gameCoins+=earnedCoins;gameCombo++;lastSuccessAt=System.currentTimeMillis();
            while(gameXp>=xpNeeded(gameLevel)){gameXp-=xpNeeded(gameLevel);gameLevel++;}
            boolean leveled=gameLevel>oldLevel;int newLevel=gameLevel,newCombo=gameCombo;
            if(section>0&&slot>=0)recordMissionReward(section,slot,earnedXp,earnedCoins);
            saveGameState();showHudState(oldLevel,oldXp,oldCoins,oldCombo);clearActiveMissionState();animateRewardAndReturn(title,earnedXp,earnedCoins,newCombo,leveled,newLevel);
        }else{
            int previousCombo=gameCombo;if(section>0&&slot>=0)recordMissionReward(section,slot,0,0);
            gameCombo=0;lastSuccessAt=0;saveGameState();clearActiveMissionState();animateFailureAndReturn(title,previousCombo);
        }
    }
    private void showLaterConfirm(int section,int slot,String title){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);
        TextView note=tv("تایمر متوقف می‌شود و اجرای بعدی از زمان کامل شروع خواهد شد.",13,0xFF60708B);note.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);note.setGravity(Gravity.CENTER);body.addView(note,new LinearLayout.LayoutParams(-1,dp(50)));
        Dialog d=buildPastelDialog("⌛","Mission Paused",title,0xFF6E8FFF,body,"Restart",0xFF4B8DFF,()->laterMission(section,slot),"Cancel",null);d.show();
    }
    private void laterMission(int section,int slot){
        String title=progressPrefs==null?"":progressPrefs.getString("active_title","");if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        stopMissionTimer();stopMissionMusic();if(section>0&&slot>=0){setMissionState(section,slot,"ready");clearMissionRewardSnapshot(section,slot);refreshProgressMissionVisuals();}clearActiveMissionState();animateResetAndReturn(title);
    }
    private void clearActiveMissionState(){
        cancelMissionAlarm();cancelMissionNotification();removeActiveMissionBar();if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putBoolean("active",false).remove("active_s").remove("active_k").remove("active_title").remove("active_end").remove("active_total").remove("active_alerted").apply();
    }
    private void animateRewardAndReturn(String title,int xp,int coins,int combo,boolean leveled,int newLevel){
        missionHandler.postDelayed(()->playSfx(sfxRewardId,.42f),120);
        if(root==null){showProgressPath();showMissionSuccessDialog(title,xp,coins,combo,leveled,newLevel);return;}
        final java.util.ArrayList<View> fx=new java.util.ArrayList<>();int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);int cx=rw/2,cy=Math.round(rh*.57f);
        final TextView badge=tv("★",58,0xFFFFC84A);badge.setShadowLayer(dp(12),0,0,0x99FFD85A);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(92),dp(92));bp.leftMargin=cx-dp(46);bp.topMargin=cy-dp(46);root.addView(badge,bp);fx.add(badge);badge.setAlpha(0f);badge.setScaleX(.35f);badge.setScaleY(.35f);
        AnimatorSet badgeA=new AnimatorSet();badgeA.playTogether(ObjectAnimator.ofFloat(badge,"alpha",0f,1f,1f),ObjectAnimator.ofFloat(badge,"scaleX",.35f,1.22f,.96f,1f),ObjectAnimator.ofFloat(badge,"scaleY",.35f,1.22f,.96f,1f),ObjectAnimator.ofFloat(badge,"rotation",-18f,8f,0f));badgeA.setDuration(1500);badgeA.setInterpolator(new android.view.animation.DecelerateInterpolator());badgeA.start();
        String[] labels={"+"+xp+" XP","+"+coins+" Coin","Combo +1"};int[] colors={0xFF17CFFF,0xFFFFC244,0xFFFF764D};float[] tx={rw*.38f,rw*.64f,rw*.82f};
        for(int i=0;i<3;i++){final TextView fly=tv(labels[i],15,colors[i]);fly.setShadowLayer(dp(5),0,0,0x66000000);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(118),dp(42));lp.leftMargin=cx-dp(59);lp.topMargin=cy+dp(45+i*14);root.addView(fly,lp);fx.add(fly);fly.setAlpha(0f);float dx=tx[i]-(cx),dy=dp(22)-(cy+dp(45+i*14));AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(fly,"alpha",0f,1f,1f,.05f),ObjectAnimator.ofFloat(fly,"translationX",0,dx),ObjectAnimator.ofFloat(fly,"translationY",0,dy),ObjectAnimator.ofFloat(fly,"scaleX",.75f,1.08f,1f),ObjectAnimator.ofFloat(fly,"scaleY",.75f,1.08f,1f));a.setStartDelay(350+i*220);a.setDuration(1750);a.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());a.start();}
        int[] dx={-150,-110,-70,-30,30,70,110,150,-130,-55,55,130};int[] dy={-150,-105,-170,-125,-155,-95,-165,-115,-45,-205,-210,-55};int[] pc={0xFF46CFFF,0xFF7B61FF,0xFFFFC84A,0xFFFF7AA8};
        for(int i=0;i<dx.length;i++){TextView p=tv(i%3==0?"✦":"•",20,pc[i%pc.length]);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(34),dp(34));lp.leftMargin=cx-dp(17);lp.topMargin=cy-dp(17);root.addView(p,lp);fx.add(p);p.setAlpha(0f);AnimatorSet pa=new AnimatorSet();pa.playTogether(ObjectAnimator.ofFloat(p,"alpha",0f,1f,0f),ObjectAnimator.ofFloat(p,"translationX",0,dp(dx[i])),ObjectAnimator.ofFloat(p,"translationY",0,dp(dy[i])),ObjectAnimator.ofFloat(p,"scaleX",.4f,1.25f,.7f),ObjectAnimator.ofFloat(p,"scaleY",.4f,1.25f,.7f),ObjectAnimator.ofFloat(p,"rotation",0f,180f));pa.setStartDelay(120+i*55);pa.setDuration(1850);pa.start();}
        missionHandler.postDelayed(()->{updateHud();pulseHudRewards();},1850);
        missionHandler.postDelayed(()->{for(View v:fx)try{if(v.getParent() instanceof ViewGroup)((ViewGroup)v.getParent()).removeView(v);}catch(Exception ignored){}showProgressPath();missionHandler.postDelayed(()->showMissionSuccessDialog(title,xp,coins,combo,leveled,newLevel),220);},2350);
    }
    private void animateFailureAndReturn(String title,int previousCombo){
        if(root==null){showProgressPath();showMissionFailDialog(title,previousCombo);return;}int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);TextView crystal=tv("◆",72,0xFFFF5B85);crystal.setShadowLayer(dp(14),0,0,0x88FF4A75);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(120),dp(120));lp.leftMargin=rw/2-dp(60);lp.topMargin=Math.round(rh*.52f)-dp(60);root.addView(crystal,lp);crystal.setAlpha(0f);AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(crystal,"alpha",0f,1f,1f,.15f),ObjectAnimator.ofFloat(crystal,"scaleX",.35f,1.18f,.96f,1f),ObjectAnimator.ofFloat(crystal,"scaleY",.35f,1.18f,.96f,1f),ObjectAnimator.ofFloat(crystal,"rotation",-10f,9f,-5f,0f));a.setDuration(1500);a.start();missionHandler.postDelayed(()->{try{root.removeView(crystal);}catch(Exception ignored){}showProgressPath();missionHandler.postDelayed(()->showMissionFailDialog(title,previousCombo),180);},1600);
    }
    private void animateResetAndReturn(String title){
        if(root==null){showProgressPath();return;}int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);TextView r=tv("↻",66,0xFF4D8DFF);r.setShadowLayer(dp(10),0,0,0x664D8DFF);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(110),dp(110));lp.leftMargin=rw/2-dp(55);lp.topMargin=Math.round(rh*.55f)-dp(55);root.addView(r,lp);r.setAlpha(0f);AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(r,"alpha",0f,1f,1f,0f),ObjectAnimator.ofFloat(r,"rotation",0f,360f),ObjectAnimator.ofFloat(r,"scaleX",.6f,1.12f,1f),ObjectAnimator.ofFloat(r,"scaleY",.6f,1.12f,1f));a.setDuration(1250);a.setInterpolator(new android.view.animation.DecelerateInterpolator());a.start();missionHandler.postDelayed(()->{try{root.removeView(r);}catch(Exception ignored){}showProgressPath();},1320);
    }
    private void animateRestoreFeedback(){
        if(root==null)return;final TextView v=tv("↻  Restored",16,0xFF287EDC);GradientDrawable g=bg(0xF2EFF8FF,dp(18));g.setStroke(Math.max(1,dp(1)),0x664A8DFF);v.setBackground(g);v.setElevation(dp(6));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(170),dp(48),Gravity.CENTER_HORIZONTAL|Gravity.TOP);lp.topMargin=dp(92);root.addView(v,lp);v.setAlpha(0f);v.setScaleX(.7f);v.setScaleY(.7f);AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(v,"alpha",0f,1f,1f,0f),ObjectAnimator.ofFloat(v,"translationY",dp(14),0,-dp(8)),ObjectAnimator.ofFloat(v,"scaleX",.7f,1.08f,1f),ObjectAnimator.ofFloat(v,"scaleY",.7f,1.08f,1f));a.setDuration(1500);a.start();missionHandler.postDelayed(()->{try{root.removeView(v);}catch(Exception ignored){}},1550);
    }
    private void showMissionSuccessDialog(String title,int xp,int coins,int combo,boolean leveled,int newLevel){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);body.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView a=rewardChip("★ +"+xp+" XP",0xFF0878D8,0xFFE9F8FF,0x5543B4FF),b=rewardChip("● +"+coins,0xFFB77700,0xFFFFF7DD,0x55E9B63B),c=rewardChip("🔥 "+combo,0xFFC84F2A,0xFFFFEEE9,0x55FF855F);row.addView(a,new LinearLayout.LayoutParams(0,dp(40),1f));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(0,dp(40),1f);blp.setMargins(dp(6),0,dp(6),0);row.addView(b,blp);row.addView(c,new LinearLayout.LayoutParams(0,dp(40),1f));
        TextView msg=tv("آفرین! یک قدم دیگر در مسیرت جلو رفتی.",13,0xFF5D6F88);msg.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(msg,new LinearLayout.LayoutParams(-1,dp(38)));
        Dialog d=buildPastelDialog("🏆","Mission Completed!",title,0xFFFFC84A,body,"Continue",0xFF3F8CFF,()->{if(leveled)showLevelUpCard(newLevel);},null,null);d.show();
    }
    private void showMissionFailDialog(String title,int previousCombo){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);TextView chip=rewardChip(previousCombo>0?"🔥 Combo "+previousCombo+" → 0":"🔥 Combo Reset",0xFFC73A45,0xFFFFECEF,0x55FF5B72);body.addView(chip,new LinearLayout.LayoutParams(dp(170),dp(40)));TextView msg=tv("این مرحله تمام شد؛ مسیر هنوز ادامه دارد. دوباره قوی‌تر برگرد.",13,0xFF62718A);msg.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);msg.setGravity(Gravity.CENTER);LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,dp(54));mlp.topMargin=dp(6);body.addView(msg,mlp);
        Dialog d=buildPastelDialog("◆","Mission Failed",title,0xFFFF6078,body,"Continue",0xFF6B7EFF,null,null,null);d.show();
    }
    private void showMissionPausedInfoDialog(String title){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView msg=tv("مأموریت برای اجرای بعدی از زمان کامل آماده شده است.",13,0xFF62718A);msg.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(msg,new LinearLayout.LayoutParams(-1,dp(48)));Dialog d=buildPastelDialog("⌛","Mission Paused",title,0xFF708FFF,body,"Continue",0xFF4E8CFF,null,null,null);d.show();
    }
    private void showLevelUpCard(int level){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);TextView l=tv("Level "+level,24,0xFF234D9A);body.addView(l,new LinearLayout.LayoutParams(-1,dp(42)));TextView r=rewardChip("Rank: Explorer",0xFF4F5F7E,0xFFF0F4FF,0x445D7CFF);body.addView(r,new LinearLayout.LayoutParams(dp(190),dp(40)));TextView msg=tv("سطح جدیدت باز شد؛ ادامه بده.",13,0xFF65748D);msg.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(msg,new LinearLayout.LayoutParams(-1,dp(42)));Dialog d=buildPastelDialog("★","Level Up!","سطح جدید شما",0xFFFFC84A,body,"Continue",0xFF3F8CFF,null,null,null);d.show();
    }
    private void consumePendingMissionFeedback(){
        SharedPreferences gp=getSharedPreferences("legacy_game",MODE_PRIVATE);int xp=gp.getInt("pending_reward_xp",0),coins=gp.getInt("pending_reward_coins",0),lvl=gp.getInt("pending_level_up",0),combo=gp.getInt("pending_combo",gameCombo),prevCombo=gp.getInt("pending_prev_combo",gameCombo);String title=gp.getString("pending_title","");String result=gp.getString("pending_result","");
        if(xp==0&&coins==0&&lvl==0&&result.length()==0)return;
        gp.edit().remove("pending_reward_xp").remove("pending_reward_coins").remove("pending_level_up").remove("pending_combo").remove("pending_prev_combo").remove("pending_title").remove("pending_result").apply();
        if("done".equals(result))showMissionSuccessDialog(title,xp,coins,combo,lvl>0,lvl);else if("fail".equals(result))showMissionFailDialog(title,prevCombo);else if("later".equals(result))showMissionPausedInfoDialog(title);else if(lvl>0)showLevelUpCard(lvl);
    }
    private void ensureNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            try{requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},4102);}catch(Exception ignored){}
        }
    }
    private android.app.PendingIntent missionAlarmPendingIntent(){
        Intent i=new Intent(this,MissionAlarmReceiver.class);i.setAction("com.shahriar.legacy.MISSION_ALARM");
        return android.app.PendingIntent.getBroadcast(this,4101,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    }
    private android.app.PendingIntent missionActionPendingIntent(String action,int requestCode){
        Intent i=new Intent(this,MissionActionReceiver.class);i.setAction(action);
        return android.app.PendingIntent.getBroadcast(this,requestCode,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    }
    private void scheduleMissionAlarm(long endAt){
        try{
            android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);
            android.app.PendingIntent pi=missionAlarmPendingIntent();
            if(android.os.Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,endAt,pi);
            else am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,endAt,pi);
        }catch(Exception ignored){}
    }
    private void cancelMissionAlarm(){try{android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);am.cancel(missionAlarmPendingIntent());}catch(Exception ignored){}}
    private void cancelMissionNotification(){try{android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.cancel(4101);}catch(Exception ignored){}}
    private void finishMissionTimerAlert(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putBoolean("active_alerted",true).apply();
        if(!isNotificationsEnabled())return;
        try{android.os.Vibrator vb=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);if(vb!=null){if(android.os.Build.VERSION.SDK_INT>=26)vb.vibrate(android.os.VibrationEffect.createOneShot(500,android.os.VibrationEffect.DEFAULT_AMPLITUDE));else vb.vibrate(500);}}catch(Exception ignored){}
        try{
            if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            boolean muted=!isSfxEnabled();
            String ch=muted?"mission_timer_silent_v44":"mission_timer_sound_v44";
            android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if(android.os.Build.VERSION.SDK_INT>=26){
                android.app.NotificationChannel nc=new android.app.NotificationChannel(ch,muted?"Mission Timer (Silent)":"Mission Timer",android.app.NotificationManager.IMPORTANCE_HIGH);
                if(muted)nc.setSound(null,null);
                nm.createNotificationChannel(nc);
            }
            Intent open=new Intent(this,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            android.app.PendingIntent contentPi=android.app.PendingIntent.getActivity(this,4101,open,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder nb=android.os.Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,ch):new android.app.Notification.Builder(this);
            android.app.PendingIntent donePi=missionActionPendingIntent(MissionActionReceiver.ACTION_DONE,4201),laterPi=missionActionPendingIntent(MissionActionReceiver.ACTION_LATER,4202),failPi=missionActionPendingIntent(MissionActionReceiver.ACTION_FAIL,4203);
            android.widget.RemoteViews rv=new android.widget.RemoteViews(getPackageName(),R.layout.notification_mission_complete);long notifMin=Math.max(1,progressPrefs.getLong("active_total",60000L)/60000L);rv.setTextViewText(R.id.notif_title,"Mission Completed!");rv.setTextViewText(R.id.notif_mission,progressPrefs.getString("active_title","Mission")+"  •  "+notifMin+" min");rv.setOnClickPendingIntent(R.id.notif_done,donePi);rv.setOnClickPendingIntent(R.id.notif_later,laterPi);rv.setOnClickPendingIntent(R.id.notif_fail,failPi);
            nb.setSmallIcon(R.drawable.ic_launcher_legacy).setContentTitle("Mission Completed!").setContentText(progressPrefs.getString("active_title","Mission")).setContentIntent(contentPi).setAutoCancel(true).setCustomContentView(rv).setCustomBigContentView(rv)
              .addAction(0,"Done",donePi).addAction(0,"Later",laterPi).addAction(0,"Fail",failPi);
            if(android.os.Build.VERSION.SDK_INT>=24)nb.setStyle(new android.app.Notification.DecoratedCustomViewStyle());
            if(android.os.Build.VERSION.SDK_INT<26)nb.setSound(muted?null:android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION));
            nm.notify(4101,nb.build());
        }catch(Exception ignored){}
    }

    private void removeActiveMissionBar(){
        stopHomeActiveTicker();
        try{if(activeBar!=null&&activeBar.getParent() instanceof ViewGroup)((ViewGroup)activeBar.getParent()).removeView(activeBar);}catch(Exception ignored){}
        activeBar=null;
    }
    private void addActiveMissionBar(){
        removeActiveMissionBar();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(!progressPrefs.getBoolean("active",false)||root==null||isRunningMissionScreen)return;
        final TextView bar=tv("",12,0xFFF5FAFF);activeBar=bar;bar.setGravity(Gravity.CENTER);bar.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        GradientDrawable g=bg(0xEE10233B,dp(20));g.setStroke(Math.max(1,Math.round(dp(.8f))),0x88F0C75E);bar.setBackground(g);
        bar.setPadding(dp(16),0,dp(16),0);bar.setElevation(dp(7));bar.setShadowLayer(dp(2),0,dp(1),0x55000000);bar.setContentDescription("Continue Mission");
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(258),dp(44),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=dp(18);root.addView(bar,bp);
        bar.setOnClickListener(v->resumeActiveMission());
        homeActiveTick=new Runnable(){public void run(){
            if(bar.getParent()==null||progressPrefs==null||!progressPrefs.getBoolean("active",false)){homeActiveTick=null;return;}
            long end=progressPrefs.getLong("active_end",0);long rem=Math.max(0,end-System.currentTimeMillis());long sec=(rem+999)/1000;
            String t=String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60);
            bar.setText(rem>0?"▶  Continue Mission   •   "+t:"▶  Continue Mission   •   00:00");
            missionHandler.postDelayed(this,1000);
        }};missionHandler.post(homeActiveTick);
    }

    // Progress Path rebuild: visual structure only. Mission logic will be added step by step.
    private ScrollView progressScroll;
    private LinearLayout progressPages;
    private int progressSectionCount=1;
    private SharedPreferences progressPrefs;

    private String progressTitle(int section,int slot){
        if(progressPrefs==null) progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        return progressPrefs.getString("title_"+section+"_"+slot,"");
    }
    private void askProgressTitle(final int section,final int slot,final TextView label){
        showPastelInputDialog("عنوان مأموریت",progressTitle(section,slot),null,title->{
            if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
            progressPrefs.edit().putString("title_"+section+"_"+slot,title).apply();label.setText(title);
        });
    }

    private void showProgressPath(){
        stopMissionTimer();
        stopHomeActiveTicker();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome=false;isRunningMissionScreen=false;isProgressPathScreen=true;isMissionEditorScreen=false;isPlaceholderScreen=false; ++homeGeneration; content.removeAllViews();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        progressMissionViews.clear();
        int savedSections=Math.max(1,progressPrefs.getInt("progress_section_count",1));
        progressSectionCount=1;
        progressScroll=new ScrollView(this);
        progressScroll.setFillViewport(true);
        progressScroll.setClipToPadding(false);
        progressScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        progressScroll.setBackgroundColor(Color.TRANSPARENT);
        progressPages=new LinearLayout(this);
        progressPages.setOrientation(LinearLayout.VERTICAL);
        progressPages.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        progressScroll.addView(progressPages,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1);
        lp.topMargin=0;
        content.addView(progressScroll,lp);
        addProgressSection(false);
        while(progressSectionCount<savedSections){progressSectionCount++;addProgressSection(false);}
        addActiveMissionBar();
        progressScroll.post(()->{
            if(progressScroll==null)return;
            progressScroll.fullScroll(View.FOCUS_DOWN);
            progressScroll.postDelayed(()->scrollProgressToFirstPending(true),70);
        });
    }

    private void scrollProgressToFirstPending(boolean smooth){
        if(progressScroll==null||progressPages==null)return;
        int pageWidth=Math.max(progressPages.getWidth(),getResources().getDisplayMetrics().widthPixels);
        int pageHeight=Math.round(pageWidth*(1536f/768f));
        final float[][] odd={{0.602214f,0.227865f},{0.735026f,0.488607f},{0.573568f,0.751628f}};
        final float[][] even={{0.412109f,0.227865f},{0.297526f,0.485677f},{0.425130f,0.749349f}};
        int targetSection=1,targetSlot=2;
        boolean found=false;
        for(int s=1;s<=Math.max(1,progressSectionCount)&&!found;s++){
            for(int slot=2;slot>=0;slot--){
                String state=missionState(s,slot);
                if(!"done".equals(state) && !"fail".equals(state)){
                    targetSection=s;targetSlot=slot;found=true;break;
                }
            }
        }
        int pageTop=(Math.max(1,progressSectionCount)-targetSection)*pageHeight;
        float cy=((targetSection%2)==1?odd[targetSlot][1]:even[targetSlot][1])*pageHeight;
        int viewport=Math.max(1,progressScroll.getHeight());
        int desired=Math.round(pageTop + cy - viewport*0.58f);
        int maxScroll=Math.max(0,progressPages.getHeight()-viewport);
        desired=Math.max(0,Math.min(desired,maxScroll));
        if(smooth)progressScroll.smoothScrollTo(0,desired); else progressScroll.scrollTo(0,desired);
    }

    private void refreshProgressArrows(){if(progressPages==null)return;for(int i=0;i<progressPages.getChildCount();i++){View p=progressPages.getChildAt(i);View u=p.findViewWithTag("progress_up"),d=p.findViewWithTag("progress_down");if(u!=null){u.setVisibility(i==0?View.VISIBLE:View.GONE);u.setEnabled(i==0);}if(d!=null)d.setVisibility(i==0&&progressSectionCount>1?View.VISIBLE:View.GONE);}}

    private void addProgressSection(boolean animateToNew){
        final int sectionNumber=progressSectionCount;
        final FrameLayout page=new FrameLayout(this);
        int w=getResources().getDisplayMetrics().widthPixels;
        int pageHeight=Math.round(w*(1536f/768f));

        ImageView art=new ImageView(this);
        art.setImageResource(sectionNumber%2==1?R.drawable.progress_path_first:R.drawable.progress_path_second);
        art.setScaleType(ImageView.ScaleType.FIT_XY);
        page.addView(art,new FrameLayout.LayoutParams(-1,-1));

        ImageView topOrb=new ImageView(this);topOrb.setImageResource(R.drawable.progress_orb);topOrb.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams topOrbLp=new FrameLayout.LayoutParams(dp(26),dp(26),Gravity.TOP|Gravity.CENTER_HORIZONTAL);page.addView(topOrb,topOrbLp);topOrb.setTranslationY(-dp(10));
        ImageView bottomOrb=new ImageView(this);bottomOrb.setImageResource(R.drawable.progress_orb);bottomOrb.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams bottomOrbLp=new FrameLayout.LayoutParams(dp(26),dp(26),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);page.addView(bottomOrb,bottomOrbLp);bottomOrb.setTranslationY(dp(10));

        // Tiny naked up-arrow: top-left, no circle/square/background.
        TextView up=tv("⌃",19,0xFF245CCB);
        up.setContentDescription("ادامه مسیر"); up.setTag("progress_up");
        up.setBackgroundColor(Color.TRANSPARENT);
        up.setShadowLayer(dp(1.5f),0,dp(1),0x99FFFFFF);
        up.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.TOP|Gravity.LEFT);
        ap.leftMargin=dp(8);
        ap.topMargin=dp(52);
        page.addView(up,ap);
        up.setOnClickListener(v->{playViewSound(v);
            progressSectionCount++;
            if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
            progressPrefs.edit().putInt("progress_section_count",progressSectionCount).apply();
            addProgressSection(true);
        });

        // Exact circle centers measured from the current 768x1536 progress artworks.
        // Odd sections: hero on the left / circles on the right.
        // Even sections: hero on the right / circles on the left.
        // Title, state fill and touch target all share this single MissionSlotView, so they cannot drift apart.
        final float[][] odd={{0.602214f,0.227865f},{0.735026f,0.488607f},{0.573568f,0.751628f}};
        final float[][] even={{0.412109f,0.227865f},{0.297526f,0.485677f},{0.425130f,0.749349f}};
        final float[][] pts=(sectionNumber%2==1)?odd:even;
        // Sized to the white inner field plus a small touch allowance while keeping Done/Fail fills inside the blue rim.
        final float[] oddSizes={0.3260f,0.3400f,0.3280f};
        final float[] evenSizes={0.3140f,0.3170f,0.3140f};
        final float[] sizes=(sectionNumber%2==1)?oddSizes:evenSizes;

        for(int i=0;i<3;i++){
            final int slot=i;
            MissionSlotView mission=new MissionSlotView(this);mission.setText(progressTitle(sectionNumber,slot));mission.setTextSize(13);mission.setTextColor(0xFF162D54);mission.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            mission.setGravity(Gravity.CENTER);
            mission.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            mission.setMaxLines(2);
            enableAutoSize(mission,8,14);
            mission.setPadding(dp(10),dp(10),dp(10),dp(10));mission.setLineSpacing(0,1.06f);
            mission.setContentDescription("جایگاه مأموریت "+(slot+1));
            styleMissionSlot(mission,missionVisualState(sectionNumber,slot));
            progressMissionViews.put(missionViewKey(sectionNumber,slot),mission);
            int circleSize=Math.round(w*sizes[i]);
            int cx=Math.round(w*pts[i][0]);
            int cy=Math.round(pageHeight*pts[i][1]);
            FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(circleSize,circleSize);
            mp.leftMargin=cx-circleSize/2;
            mp.topMargin=cy-circleSize/2;
            page.addView(mission,mp);
            mission.setOnClickListener(v->{
                playViewSound(v);
                String state=missionState(sectionNumber,slot);
                if("active".equals(state)){resumeActiveMission();return;}
                if("done".equals(state)||"fail".equals(state)){showMissionSlotMenu(sectionNumber,slot);return;}
                showMissionEditor(sectionNumber,slot);
            });
            mission.setOnLongClickListener(v->{playUiClick();showMissionSlotMenu(sectionNumber,slot);return true;});
        }

        TextView down=tv("⌄",19,0xFF245CCB);down.setTag("progress_down");down.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams dl=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.BOTTOM|Gravity.LEFT);dl.leftMargin=dp(8);dl.bottomMargin=dp(8);page.addView(down,dl);
        down.setOnClickListener(v->{playViewSound(v);
            boolean empty=true;for(int k=0;k<3;k++)if(progressTitle(sectionNumber,k).trim().length()>0)empty=false;
            if(!empty){Toast.makeText(this,"برای حذف صفحه، دایره‌ها باید خالی باشند",Toast.LENGTH_SHORT).show();return;}
            if(sectionNumber==progressSectionCount&&progressSectionCount>1){
                progressPages.removeView(page);
                for(int k=0;k<3;k++)clearMissionSlot(sectionNumber,k);
                progressSectionCount--;
                if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
                progressPrefs.edit().putInt("progress_section_count",progressSectionCount).apply();
                refreshProgressArrows();
            }
        });
        progressPages.addView(page,0,new LinearLayout.LayoutParams(-1,pageHeight));refreshProgressArrows();
        if(animateToNew){
            progressScroll.post(()->progressScroll.smoothScrollTo(0,0));
        }
    }

    private void clearMissionSlot(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        SharedPreferences.Editor ed=progressPrefs.edit()
            .remove("title_"+section+"_"+slot)
            .remove(mf(section,slot,"importance"))
            .remove(mf(section,slot,"minutes"))
            .remove(mf(section,slot,"repeat"))
            .remove(mf(section,slot,"state"))
            .remove(mf(section,slot,"state_day"))
            .remove(mf(section,slot,"reward_snapshot"))
            .remove(mf(section,slot,"prev_level")).remove(mf(section,slot,"prev_xp")).remove(mf(section,slot,"prev_coins"))
            .remove(mf(section,slot,"prev_combo")).remove(mf(section,slot,"prev_last_success"))
            .remove(mf(section,slot,"reward_xp")).remove(mf(section,slot,"reward_coins")).remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at"))
            .remove(mf(section,slot,"defaults_v41"));
        ed.apply();
        getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE).edit().clear().apply();
    }

    private void showGameSettings(){
        final String[] opts={"10 دقیقه","15 دقیقه","20 دقیقه","30 دقیقه","45 دقیقه","60 دقیقه"};
        final int[] vals={10,15,20,30,45,60}; int checked=3; for(int i=0;i<vals.length;i++)if(vals[i]==comboWindowMinutes)checked=i;
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);final Dialog[] dlg={null};
        for(int i=0;i<opts.length;i++){final int idx=i;boolean selected=i==checked;TextView row=tv(opts[i]+(selected?"   ✓":""),14,selected?0xFF256FD1:0xFF17345D);row.setGravity(Gravity.CENTER);GradientDrawable rg=bg(selected?0xFFEAF4FF:0xFFF7F9FF,dp(13));rg.setStroke(Math.max(1,Math.round(dp(.7f))),selected?0x884E8CFF:0x224E8CFF);row.setBackground(rg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(44));lp.setMargins(0,dp(3),0,dp(3));body.addView(row,lp);row.setOnClickListener(v->{playViewSound(v);comboWindowMinutes=vals[idx];expireComboIfNeeded();saveGameState();dlg[0].dismiss();Toast.makeText(this,"مهلت Combo: "+comboWindowMinutes+" دقیقه",Toast.LENGTH_SHORT).show();});}
        dlg[0]=buildPastelDialog("⚡","مهلت ادامه Combo","زمان مجاز برای حفظ زنجیره موفقیت",0xFF6B7EFF,body,null,0,null,"بستن",null);dlg[0].show();
    }
    private TextView settingsRow(String title,String value){
        TextView row=tv(title+"   "+value,14,0xFF17345D);row.setGravity(Gravity.CENTER);GradientDrawable rg=bg(0xFFF7F9FF,dp(13));rg.setStroke(Math.max(1,Math.round(dp(.7f))),0x224E8CFF);row.setBackground(rg);row.setPadding(dp(10),0,dp(10),0);return row;
    }
    private void showAppSettings(){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);final Dialog[] dlg={null};
        TextView music=settingsRow("موسیقی",isMusicEnabled()?"روشن":"خاموش");
        TextView sfx=settingsRow("افکت صدا",isSfxEnabled()?"روشن":"خاموش");
        TextView notif=settingsRow("نوتیفیکیشن",isNotificationsEnabled()?"روشن":"خاموش");
        TextView combo=settingsRow("مهلت Combo",comboWindowMinutes+" دقیقه");
        for(TextView row:new TextView[]{music,sfx,notif,combo}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.setMargins(0,dp(4),0,dp(4));body.addView(row,lp);}
        music.setOnClickListener(v->{playViewSound(v);boolean next=!isMusicEnabled();appSettingsPrefs().edit().putBoolean("music_enabled",next).apply();if(next){if(isRunningMissionScreen)playSavedMissionMusic();}else stopMissionMusic();Toast.makeText(this,next?"موسیقی روشن شد":"موسیقی خاموش شد",Toast.LENGTH_SHORT).show();dlg[0].dismiss();showAppSettings();});
        sfx.setOnClickListener(v->{boolean wasOn=isSfxEnabled();if(wasOn)playSfx(sfxToggleId,.72f);boolean next=!wasOn;appSettingsPrefs().edit().putBoolean("sfx_enabled",next).apply();if(next)playSfx(sfxToggleId,.72f);dlg[0].dismiss();showAppSettings();});
        notif.setOnClickListener(v->{playViewSound(v);appSettingsPrefs().edit().putBoolean("notifications_enabled",!isNotificationsEnabled()).apply();dlg[0].dismiss();showAppSettings();});
        combo.setOnClickListener(v->{playViewSound(v);dlg[0].dismiss();showGameSettings();});
        dlg[0]=buildPastelDialog("⚙","تنظیمات","کنترل موسیقی، افکت‌ها و اعلان‌ها",0xFF4E8CFF,body,null,0,null,"بستن",null);dlg[0].show();
    }

    private void showPlaceholder(String title){
        stopHomeActiveTicker();
        isHome = false; isRunningMissionScreen=false;isProgressPathScreen=false;isMissionEditorScreen=false;isPlaceholderScreen=true;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(Color.rgb(10,31,51));
        TextView t=tv(title,28,Color.WHITE); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,0xFFBFD4E6); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
    }
    @Override public void onBackPressed(){
        playUiClick();
        // Exactly one navigation level per Back press. Dialogs consume Back themselves first.
        if(isMissionEditorScreen||isRunningMissionScreen){showProgressPath();return;}
        if(isProgressPathScreen||isPlaceholderScreen){showHome();return;}
        super.onBackPressed();
    }
    private int withAlpha(int color,int alpha){return (color & 0x00FFFFFF)|((alpha & 0xFF)<<24);}
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
    private float dp(float x){ return x*getResources().getDisplayMetrics().density; }
}

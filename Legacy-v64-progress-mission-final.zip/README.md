Legacy v64 – Progress Path / Mission flow final

Final checks and fixes:
- Editor and Running Mission preserve the 1:2 reference-art ratio with touch overlays mapped to that same canvas.
- Running Mission: FOCUS removed; auto-sizing mission title is inside the timer circle.
- Running Mission: progress arc is thicker and the blue fill covers the white elapsed track.
- Progress Path: orb assets replace blue bars; top orb is higher and bottom orb lower.
- Progress Path auto-scrolls smoothly to the first circle from the bottom that is not Done/Fail on entry, Back, Done and Fail.
- Done circles use strong green fill with high-contrast text; Fail circles use dark red fill with high-contrast text; no code-drawn rim.
- Long mission titles auto-size in Progress Path and Running Mission.
- Importance rewards preserved: Low 10 XP / 2 Coin, Medium 20 XP / 4 Coin, High 35 XP / 7 Coin.
- SFX routed through game/media audio so click and event sounds are audible; key interactions have explicit event SFX.
- Music and SFX are independent settings.
- Gear opens real Settings: Music, SFX, Notifications and Combo Window.
- Combo flame opens Combo Window only.
- Subtask UI remains clean and English-only, with interaction sounds.
- Legacy music-muted flag is migrated away so it cannot silently disable the new Music setting.
- Popup animations remain disabled for direct centered opening.
- Back moves one navigation level at a time.
- High-quality WebP artwork retained to keep ZIP size low.

Build note: local Gradle build cannot run in this environment because the Gradle distribution host is unreachable. The archive and project structure were validated locally.

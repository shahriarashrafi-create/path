package com.shahriar.legacy;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.SystemClock;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Time Travel / weekly time-sheet.
 * Only the supplied page background is a bitmap. The timetable, glass surface,
 * sticky axes, cards and controls are rendered in code.
 */
public class TimeTravelView extends View {
    private final MainActivity activity;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final android.content.SharedPreferences prefs;
    private final android.view.ScaleGestureDetector scaleDetector;

    private final RectF panel = new RectF();
    private final RectF titleBar = new RectF();
    private final RectF headerViewport = new RectF();
    private final RectF hourViewport = new RectF();
    private final RectF gridViewport = new RectF();
    private final RectF topPrev = new RectF(), topNext = new RectF(), titleTouch = new RectF();
    private final HashMap<String,RectF> eventRects = new HashMap<>(); // content coordinates

    private final String[] dayNames={"شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"};
    private float zoom=1f,panX=0f,panY=0f,lastX,lastY,downX,downY;
    private boolean moved=false, scaling=false;
    private long lastScaleEnd=0L, downTime=0L;
    private int weekOffset=0;
    private Drawable arrowLeftAsset,arrowRightAsset;

    private static final int START_MIN=7*60, END_MIN=24*60;
    private static final String PREF_NAME="legacy_timesheet_v2";
    private static final long PAN_AFTER_PINCH_DELAY_MS=72L;

    static class Entry {
        String id,title,weekKey; int day,start,end; boolean fixed;
        Entry(String id){this.id=id;}
    }

    public TimeTravelView(MainActivity a){
        super(a); activity=a; prefs=a.getSharedPreferences(PREF_NAME,Context.MODE_PRIVATE);
        setFocusable(true);setClickable(true);setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        text.setTypeface(Typeface.create("sans",Typeface.NORMAL));
        try{arrowLeftAsset=a.getDrawable(R.drawable.ic_time_arrow_left);arrowRightAsset=a.getDrawable(R.drawable.ic_time_arrow_right);}catch(Exception ignored){}
        scaleDetector=new android.view.ScaleGestureDetector(a,new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScaleBegin(android.view.ScaleGestureDetector d){scaling=true;moved=true;return true;}
            @Override public boolean onScale(android.view.ScaleGestureDetector d){
                float old=zoom;
                float next=Math.max(.70f,Math.min(2.00f,old*d.getScaleFactor()));
                if(Math.abs(next-old)<.0005f)return true;
                float fx=d.getFocusX(),fy=d.getFocusY();
                float cw=contentWidth(),ch=contentHeight();
                float contentX=cw/2f+(fx-gridViewport.centerX()-panX)/old;
                float contentY=ch/2f+(fy-gridViewport.centerY()-panY)/old;
                zoom=next;
                panX=fx-gridViewport.centerX()-(contentX-cw/2f)*zoom;
                panY=fy-gridViewport.centerY()-(contentY-ch/2f)*zoom;
                clampPan();invalidate();return true;
            }
            @Override public void onScaleEnd(android.view.ScaleGestureDetector d){scaling=false;lastScaleEnd=SystemClock.uptimeMillis();clampPan();invalidate();}
        });
    }

    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    private float sp(float v){return v*getResources().getDisplayMetrics().scaledDensity;}
    private int clamp(int v,int lo,int hi){return Math.max(lo,Math.min(hi,v));}
    private float clampf(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){
        float side=Math.max(dp(10),w*.030f);
        float top=Math.max(dp(176),h*.255f);
        float bottom=h-dp(14); // footer removed: the timetable gets the space
        if(bottom-top<dp(470)){top=Math.max(dp(150),h*.225f);bottom=h-dp(10);}
        panel.set(side,top,w-side,bottom);
        float titleH=Math.min(dp(44),Math.max(dp(38),panel.height()*.055f));
        titleBar.set(panel.left,panel.top,panel.right,panel.top+titleH);

        float innerL=panel.left+dp(9),innerR=panel.right-dp(9);
        float headerH=Math.min(dp(48),Math.max(dp(42),panel.height()*.060f));
        float gap=dp(3);
        float hourW=Math.min(dp(44),Math.max(dp(36),(innerR-innerL)*.082f));
        float headerTop=titleBar.bottom+dp(2);
        float gridTop=headerTop+headerH+gap;
        float gridBottom=panel.bottom-dp(9);
        headerViewport.set(innerL+hourW,headerTop,innerR,headerTop+headerH);
        hourViewport.set(innerL,gridTop,innerL+hourW,gridBottom);
        gridViewport.set(innerL+hourW,gridTop,innerR,gridBottom);

        float b=dp(32),cy=titleBar.centerY();
        topPrev.set(panel.left+dp(14),cy-b/2,panel.left+dp(14)+b,cy+b/2);
        topNext.set(panel.right-dp(14)-b,cy-b/2,panel.right-dp(14),cy+b/2);
        titleTouch.set(topPrev.right+dp(8),titleBar.top,topNext.left-dp(8),titleBar.bottom);
        clampPan();
    }

    private float contentWidth(){return Math.max(gridViewport.width()*1.28f,dp(340));}
    private float contentHeight(){return gridViewport.height()*1.12f;}
    private float baseDayW(){return contentWidth()/7f;}
    private float baseRowH(){return contentHeight()/17f;}
    private float mapX(float contentX){return gridViewport.centerX()+panX+(contentX-contentWidth()/2f)*zoom;}
    private float mapY(float contentY){return gridViewport.centerY()+panY+(contentY-contentHeight()/2f)*zoom;}
    private float unmapX(float screenX){return contentWidth()/2f+(screenX-gridViewport.centerX()-panX)/zoom;}
    private float unmapY(float screenY){return contentHeight()/2f+(screenY-gridViewport.centerY()-panY)/zoom;}

    private void clampPan(){
        if(gridViewport.width()<=0||gridViewport.height()<=0)return;
        float sw=contentWidth()*zoom,sh=contentHeight()*zoom;
        float naturalX=Math.abs(sw-gridViewport.width())/2f;
        float naturalY=Math.abs(sh-gridViewport.height())/2f;
        float limX=Math.max(dp(24),naturalX);
        float limY=Math.max(dp(24),naturalY);
        panX=clampf(panX,-limX,limX);panY=clampf(panY,-limY,limY);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        drawGlassPanel(c);
        drawTitle(c);
        drawGridBody(c);
        drawStickyHeader(c);
        drawStickyHours(c);
        drawScheduleFrame(c);
    }

    private void drawGlassPanel(Canvas c){
        // Darker, calmer glass: keep the background present but make the schedule dominant.
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(panel.left,panel.top,panel.right,panel.bottom,
                new int[]{0xC32D6E9F,0xBD1D5688,0xC0133E70},new float[]{0f,.50f,1f},Shader.TileMode.CLAMP));
        p.setShadowLayer(dp(5),0,dp(2),0x44258FD0);c.drawRoundRect(panel,dp(20),dp(20),p);p.clearShadowLayer();p.setShader(null);
        p.setColor(0x14FFFFFF);RectF wash=new RectF(panel);wash.inset(dp(2),dp(2));c.drawRoundRect(wash,dp(19),dp(19),p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.72f));p.setColor(0x91BDE7FF);c.drawRoundRect(panel,dp(20),dp(20),p);
        p.setStyle(Paint.Style.FILL);p.setColor(0x13FFFFFF);RectF shine=new RectF(panel.left+dp(8),panel.top+dp(5),panel.right-dp(8),panel.top+dp(18));c.drawRoundRect(shine,dp(11),dp(11),p);
    }

    private void drawTitle(Canvas c){
        drawGlassButton(c,topPrev);drawGlassButton(c,topNext);
        drawArrowAsset(c,topPrev,true);drawArrowAsset(c,topNext,false);
        text.setTextAlign(Paint.Align.CENTER);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextSize(sp(16.5f));text.setColor(0xFFF1FBFF);text.setShadowLayer(dp(2.2f),0,0,0x7141B8FF);
        drawCentered(c,weekTitle(),panel.centerX(),titleBar.centerY(),text);text.clearShadowLayer();
    }

    private String weekTitle(){
        if(weekOffset==0)return "هفته جاری";
        if(weekOffset==1)return "یک هفته بعد";
        if(weekOffset==-1)return "یک هفته قبل";
        int n=Math.abs(weekOffset);
        return faDigits(String.valueOf(n))+" هفته "+(weekOffset>0?"بعد":"قبل");
    }

    private void drawGlassButton(Canvas c,RectF r){
        p.setStyle(Paint.Style.FILL);p.setColor(0x24145A8C);c.drawRoundRect(r,dp(9),dp(9),p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.65f));p.setColor(0x87A8E7FF);c.drawRoundRect(r,dp(9),dp(9),p);
    }

    private void drawArrowAsset(Canvas c,RectF r,boolean left){
        Drawable d=left?arrowLeftAsset:arrowRightAsset;
        if(d!=null){int pad=Math.round(dp(7));d.setBounds(Math.round(r.left)+pad,Math.round(r.top)+pad,Math.round(r.right)-pad,Math.round(r.bottom)-pad);d.draw(c);return;}
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2f));p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Color.WHITE);float cx=r.centerX(),cy=r.centerY(),s=r.width()*.18f;Path q=new Path();if(left){q.moveTo(cx+s,cy-s);q.lineTo(cx-s,cy);q.lineTo(cx+s,cy+s);}else{q.moveTo(cx-s,cy-s);q.lineTo(cx+s,cy);q.lineTo(cx-s,cy+s);}c.drawPath(q,p);p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawGridBody(Canvas c){
        c.save();c.clipRect(gridViewport);
        // grid backdrop first
        p.setStyle(Paint.Style.FILL);p.setColor(0x32102A4B);c.drawRoundRect(gridViewport,dp(12),dp(12),p);

        float dayW=baseDayW(),rowH=baseRowH();
        int today=currentDayIndex();
        // current-day column on top of backdrop so the highlight stays visible
        if(weekOffset==0&&today>=0){
            float l=mapX(today*dayW),r=mapX((today+1)*dayW);
            p.setStyle(Paint.Style.FILL);p.setColor(0x3421A9FF);p.setShadowLayer(dp(7),0,0,0x7033B6FF);c.drawRect(l,gridViewport.top,r,gridViewport.bottom,p);p.clearShadowLayer();
        }

        // Quieter grid: vertical separators stay subtle; hourly guides remain slightly clearer.
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.42f));p.setColor(0x4D52C6FF);
        for(int d=0;d<=7;d++){float x=mapX(d*dayW);if(x>=gridViewport.left-dp(2)&&x<=gridViewport.right+dp(2))c.drawLine(x,gridViewport.top,x,gridViewport.bottom,p);}
        p.setStrokeWidth(dp(.58f));p.setColor(0x6D68D0FF);
        for(int r=0;r<=17;r++){float y=mapY(r*rowH);if(y>=gridViewport.top-dp(2)&&y<=gridViewport.bottom+dp(2))c.drawLine(gridViewport.left,y,gridViewport.right,y,p);}

        eventRects.clear();
        ArrayList<Entry> list=entriesForWeek();Collections.sort(list,(a,b)->a.day!=b.day?a.day-b.day:a.start-b.start);
        for(Entry e:list){
            float cl=e.day*dayW+dp(2.5f)/Math.max(.70f,zoom),cr=(e.day+1)*dayW-dp(2.5f)/Math.max(.70f,zoom);
            float ct=((e.start-START_MIN)/60f)*rowH+dp(1.5f)/Math.max(.70f,zoom),cb=((e.end-START_MIN)/60f)*rowH-dp(1.5f)/Math.max(.70f,zoom);
            cb=Math.max(ct+dp(19)/Math.max(.70f,zoom),Math.min(contentHeight(),cb));
            RectF contentRect=new RectF(cl,ct,cr,cb);eventRects.put(e.id,contentRect);
            RectF er=new RectF(mapX(cl),mapY(ct),mapX(cr),mapY(cb));
            if(er.right<gridViewport.left||er.left>gridViewport.right||er.bottom<gridViewport.top||er.top>gridViewport.bottom)continue;
            int st=statusFor(e.id);
            // Done/Fail colors intentionally keep their existing intensity; neutral blocks become more legible.
            int fill=st==1?0xA94AAE8D:st==2?0xA9C15B77:0xBC2F78B9;
            int stroke=st==1?0xD4B8F6DF:st==2?0xD4FFB7C7:0xE8C7EEFF;
            float rad=dp(7)*clampf(zoom,.70f,1.18f);
            p.setStyle(Paint.Style.FILL);p.setColor(fill);p.setShadowLayer(dp(2.4f),0,dp(1.1f),0x55102138);c.drawRoundRect(er,rad,rad,p);p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.0f));p.setColor(stroke);c.drawRoundRect(er,rad,rad,p);
            drawEventText(c,e,er);
        }
        c.restore();
    }

    private void drawEventText(Canvas c,Entry e,RectF er){
        float maxW=Math.max(dp(14),er.width()-dp(8));
        float z=clampf(zoom,.70f,1.18f);
        float size=8.0f*z;
        text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setTextAlign(Paint.Align.CENTER);text.setColor(0xFFF6FCFF);
        // Only the title lives inside a filled time block. The block itself communicates the duration.
        size=fitTextSp(e.title,maxW,size,5.3f);text.setTextSize(sp(size));
        String title=ellipsizeToWidth(e.title,maxW,text);
        drawCentered(c,title,er.centerX(),er.centerY(),text);
    }

    private void drawStickyHeader(Canvas c){
        c.save();c.clipRect(headerViewport);
        float dayW=baseDayW();int today=currentDayIndex();
        for(int d=0;d<7;d++){
            float l=mapX(d*dayW)+dp(2),r=mapX((d+1)*dayW)-dp(2);
            if(r<headerViewport.left||l>headerViewport.right)continue;
            RectF dr=new RectF(l,headerViewport.top+dp(2),r,headerViewport.bottom-dp(2));
            boolean current=weekOffset==0&&d==today;
            p.setStyle(Paint.Style.FILL);p.setColor(current?0xA93C98E9:0x443B7DB5);c.drawRoundRect(dr,dp(8),dp(8),p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(current?dp(1.35f):dp(.62f));p.setColor(current?0xE5DDF7FF:0x6F5CBFFF);if(current){p.setShadowLayer(dp(7),0,0,0x8834B4FF);}c.drawRoundRect(dr,dp(8),dp(8),p);p.clearShadowLayer();
            long dm=weekStartMillis()+d*86400000L;int[] j=jalaliForMillis(dm);
            float scale=clampf(zoom,.70f,1.08f);
            text.setTextAlign(Paint.Align.CENTER);text.setTypeface(Typeface.create("sans",Typeface.BOLD));text.setColor(0xFFF1FAFF);text.setTextSize(sp(8.8f*scale));
            String dn=ellipsizeToWidth(dayNames[d],Math.max(dp(10),dr.width()-dp(6)),text);c.drawText(dn,dr.centerX(),dr.top+dr.height()*.42f,text);
            text.setTextSize(sp(10.3f*scale));text.setTypeface(Typeface.create("sans",Typeface.NORMAL));c.drawText(faDigits(String.valueOf(j[2])),dr.centerX(),dr.top+dr.height()*.76f,text);
        }
        c.restore();
    }

    private void drawStickyHours(Canvas c){
        c.save();c.clipRect(hourViewport);
        p.setStyle(Paint.Style.FILL);p.setColor(0x35113355);c.drawRoundRect(hourViewport,dp(8),dp(8),p);
        float rowH=baseRowH();float scale=clampf(zoom,.70f,1.08f);
        text.setTextAlign(Paint.Align.CENTER);text.setTypeface(Typeface.create("sans",Typeface.NORMAL));text.setTextSize(sp(8.1f*scale));text.setColor(0xFFE9F7FF);
        for(int h=7;h<=24;h++){
            float y=(h==24)?mapY(17f*rowH)-dp(5):mapY((h-7+.5f)*rowH);
            if(y<hourViewport.top-dp(8)||y>hourViewport.bottom+dp(8))continue;
            drawCentered(c,String.format(Locale.US,"%02d:00",h),hourViewport.centerX(),y,text);
        }
        c.restore();
    }

    private void drawScheduleFrame(Canvas c){
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.72f));p.setColor(0x8FAEE7FF);
        RectF all=new RectF(hourViewport.left,headerViewport.top,gridViewport.right,gridViewport.bottom);c.drawRoundRect(all,dp(11),dp(11),p);
        p.setColor(0x4267D3FF);p.setStrokeWidth(dp(.48f));c.drawLine(hourViewport.right,headerViewport.top,hourViewport.right,gridViewport.bottom,p);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        scaleDetector.onTouchEvent(e);
        float x=e.getX(),y=e.getY();
        if(e.getActionMasked()==MotionEvent.ACTION_POINTER_UP&&e.getPointerCount()>1){
            int keep=e.getActionIndex()==0?1:0;
            if(keep<e.getPointerCount()){lastX=e.getX(keep);lastY=e.getY(keep);}
            moved=true;lastScaleEnd=SystemClock.uptimeMillis();return true;
        }
        if(e.getPointerCount()>1){lastX=e.getX(0);lastY=e.getY(0);moved=true;return true;}
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                downX=lastX=x;downY=lastY=y;downTime=SystemClock.uptimeMillis();moved=false;return true;
            case MotionEvent.ACTION_MOVE:
                float dx=x-lastX,dy=y-lastY;if(Math.hypot(x-downX,y-downY)>dp(7))moved=true;
                boolean inTable=gridViewport.contains(downX,downY)||headerViewport.contains(downX,downY)||hourViewport.contains(downX,downY);
                if(moved&&inTable&&!scaling&&SystemClock.uptimeMillis()-lastScaleEnd>PAN_AFTER_PINCH_DELAY_MS){panX+=dx;panY+=dy;clampPan();invalidate();}
                lastX=x;lastY=y;return true;
            case MotionEvent.ACTION_UP:
                long held=SystemClock.uptimeMillis()-downTime;
                if(!moved&&!scaling){performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);handleTap(x,y,held);}
                scaling=false;return true;
            case MotionEvent.ACTION_CANCEL:scaling=false;return true;
        }
        return true;
    }

    private void handleTap(float x,float y,long held){
        if(topPrev.contains(x,y)){feedback(null);changeWeek(-1);return;}
        if(topNext.contains(x,y)){feedback(null);changeWeek(1);return;}
        if(titleTouch.contains(x,y)){feedback(null);if(held>=480)showOverview();else showWeekPicker();return;}
        if(!gridViewport.contains(x,y))return;
        float lx=unmapX(x),ly=unmapY(y);
        for(Entry en:entriesForWeek()){RectF rr=eventRects.get(en.id);if(rr!=null&&rr.contains(lx,ly)){feedback(null);showEntryEditor(en,en.day,en.start,en.end);return;}}
        float dayW=baseDayW(),rowH=baseRowH();int day=(int)(lx/dayW);if(day<0||day>6)return;
        int row=(int)Math.floor(ly/rowH);row=clamp(row,0,16);
        int start=START_MIN+row*60;int end=Math.min(END_MIN,start+60);
        feedback(null);showEntryEditor(null,day,start,end);
    }

    private void feedback(View v){
        try{if(v!=null)v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);else performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);}catch(Exception ignored){}
        try{activity.playTimeTravelUiSound(v);}catch(Exception ignored){}
    }

    private void changeWeek(int delta){int n=clamp(weekOffset+delta,-10,10);if(n==weekOffset){Toast.makeText(activity,"تاریخچه تا ۱۰ هفته در دسترس است",Toast.LENGTH_SHORT).show();return;}weekOffset=n;zoom=1f;panX=panY=0;invalidate();}

    private long weekStartMillis(){return weekStartMillis(weekOffset);}
    private long weekStartMillis(int off){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);int dow=c.get(Calendar.DAY_OF_WEEK);int delta=(dow-Calendar.SATURDAY+7)%7;c.add(Calendar.DAY_OF_MONTH,-delta+off*7);return c.getTimeInMillis();}
    private String weekKey(){return weekKeyFor(weekStartMillis());}
    private String weekKeyFor(long ms){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date(ms));}
    private int currentDayIndex(){Calendar c=Calendar.getInstance();return (c.get(Calendar.DAY_OF_WEEK)-Calendar.SATURDAY+7)%7;}

    private ArrayList<String> ids(){String raw=prefs.getString("ids","");ArrayList<String> out=new ArrayList<>();if(raw!=null&&!raw.trim().isEmpty())for(String s:raw.split(","))if(!s.trim().isEmpty())out.add(s.trim());return out;}
    private void saveIds(ArrayList<String> ids){StringBuilder b=new StringBuilder();for(String id:ids){if(b.length()>0)b.append(',');b.append(id);}prefs.edit().putString("ids",b.toString()).apply();}
    private Entry read(String id){if(!prefs.contains("e_"+id+"_title"))return null;Entry e=new Entry(id);e.title=prefs.getString("e_"+id+"_title","");e.day=prefs.getInt("e_"+id+"_day",0);e.start=prefs.getInt("e_"+id+"_start",START_MIN);e.end=prefs.getInt("e_"+id+"_end",Math.min(END_MIN,e.start+60));e.fixed=prefs.getBoolean("e_"+id+"_fixed",true);e.weekKey=prefs.getString("e_"+id+"_week",weekKey());return e;}
    private void write(Entry e){prefs.edit().putString("e_"+e.id+"_title",e.title).putInt("e_"+e.id+"_day",e.day).putInt("e_"+e.id+"_start",e.start).putInt("e_"+e.id+"_end",e.end).putBoolean("e_"+e.id+"_fixed",e.fixed).putString("e_"+e.id+"_week",e.weekKey).apply();ArrayList<String> a=ids();if(!a.contains(e.id)){a.add(e.id);saveIds(a);}}
    private void delete(Entry e){ArrayList<String> a=ids();a.remove(e.id);saveIds(a);android.content.SharedPreferences.Editor ed=prefs.edit();String pre="e_"+e.id+"_";ed.remove(pre+"title").remove(pre+"day").remove(pre+"start").remove(pre+"end").remove(pre+"fixed").remove(pre+"week");for(int i=-10;i<=10;i++)ed.remove("st_"+weekKeyFor(weekStartMillis(i))+"_"+e.id);ed.apply();invalidate();}
    private ArrayList<Entry> entriesForWeek(){String wk=weekKey();ArrayList<Entry> out=new ArrayList<>();for(String id:ids()){Entry e=read(id);if(e!=null&&(e.fixed||wk.equals(e.weekKey)))out.add(e);}return out;}
    private int statusFor(String id){return prefs.getInt("st_"+weekKey()+"_"+id,0);}
    private void setStatus(String id,int st){android.content.SharedPreferences.Editor ed=prefs.edit();String k="st_"+weekKey()+"_"+id;if(st==0)ed.remove(k);else ed.putInt(k,st);ed.apply();invalidate();}

    private boolean sameMergeGroup(Entry a,Entry b){return a.day==b.day&&a.fixed==b.fixed&&safe(a.title).equalsIgnoreCase(safe(b.title))&&(a.fixed||safe(a.weekKey).equals(safe(b.weekKey)));}
    private Entry findConflict(Entry e){for(Entry q:entriesForWeek()){if(q.id.equals(e.id)||q.day!=e.day)continue;boolean overlap=e.start<q.end&&e.end>q.start;if(overlap)return q;}return null;}
    private void saveMerged(Entry e){ArrayList<Entry> all=entriesForWeek();for(Entry q:all){if(q.id.equals(e.id))continue;if(sameMergeGroup(e,q)&&q.end>=e.start&&e.end>=q.start){e.start=Math.min(e.start,q.start);e.end=Math.max(e.end,q.end);delete(q);}}write(e);invalidate();}
    private String safe(String s){return s==null?"":s.trim();}

    private GradientDrawable fieldBg(int fill,int stroke,float radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(Math.max(1,Math.round(dp(1))),stroke);return g;}
    private GradientDrawable pastelButtonBg(int c1,int c2){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{c1,c2});g.setCornerRadius(dp(14));return g;}
    private TextView label(String s,float size,int color){TextView v=new TextView(activity);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.CENTER);v.setTypeface(Typeface.create("sans",Typeface.BOLD));return v;}
    private TextView button(String s,boolean primary){TextView v=label(s,14,primary?Color.WHITE:0xFF17345D);v.setBackground(primary?pastelButtonBg(0xFF4E8CFF,0xFF7B61FF):fieldBg(0xFFF7FAFF,0x334D8DFF,14));v.setPadding((int)dp(10),0,(int)dp(10),0);v.setClickable(true);v.setElevation(dp(1));return v;}
    private TextView softButton(String s,int accentFill,int textColor){TextView v=label(s,14,textColor);v.setBackground(fieldBg(accentFill,0x334D8DFF,14));v.setPadding((int)dp(10),0,(int)dp(10),0);v.setClickable(true);return v;}

    private LinearLayout dialogCard(String icon,String title,String subtitle){
        LinearLayout card=new LinearLayout(activity);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding((int)dp(20),(int)dp(14),(int)dp(20),(int)dp(20));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFFFCFDFF,0xFFF3F7FF,0xFFF8F4FF});bg.setCornerRadius(dp(24));bg.setStroke(Math.max(1,Math.round(dp(.7f))),0x664E8CFF);card.setBackground(bg);card.setElevation(dp(7));
        TextView ico=label(icon==null?"✦":icon,25,0xFF4E8CFF);GradientDrawable ig=fieldBg(0xEAF3F7FF,0x443B7CFF,999);ico.setBackground(ig);LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams((int)dp(46),(int)dp(46));ilp.bottomMargin=(int)dp(7);card.addView(ico,ilp);
        TextView h=label(title,20,0xFF142C54);card.addView(h,new LinearLayout.LayoutParams(-1,(int)dp(36)));
        if(subtitle!=null&&!subtitle.trim().isEmpty()){TextView sub=label(subtitle,12.5f,0xFF536785);sub.setTypeface(Typeface.create("sans",Typeface.NORMAL));sub.setPadding((int)dp(6),0,(int)dp(6),0);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,-2);slp.bottomMargin=(int)dp(8);card.addView(sub,slp);}
        return card;
    }

    private Dialog baseDialog(View body){
        Dialog d=new Dialog(activity);d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        FrameLayout safe=new FrameLayout(activity);safe.setPadding((int)dp(14),(int)dp(26),(int)dp(14),(int)dp(28));
        int maxW=Math.min(getResources().getDisplayMetrics().widthPixels-(int)dp(28),(int)dp(390));
        FrameLayout.LayoutParams blp=new FrameLayout.LayoutParams(maxW,-2,Gravity.CENTER);safe.addView(body,blp);d.setContentView(safe);d.setCanceledOnTouchOutside(true);
        Window w=d.getWindow();if(w!=null){w.setWindowAnimations(0);w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams lp=w.getAttributes();lp.width=WindowManager.LayoutParams.MATCH_PARENT;lp.height=WindowManager.LayoutParams.MATCH_PARENT;lp.gravity=Gravity.CENTER;lp.dimAmount=.28f;w.setAttributes(lp);}
        return d;
    }

    private EditText inputField(String hint,String value){EditText e=new EditText(activity);e.setSingleLine(true);e.setHint(hint);e.setText(value==null?"":value);e.setTextSize(15);e.setTextColor(0xFF17345D);e.setHintTextColor(0x99677B9A);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding((int)dp(13),0,(int)dp(13),0);e.setBackground(fieldBg(0xFFF8FAFF,0x334D6B9A,13));return e;}

    private void showEntryEditor(Entry src,int day,int start,int end){
        final Entry e=src==null?new Entry(String.valueOf(System.currentTimeMillis())):read(src.id);boolean creating=src==null;if(creating){e.day=day;e.start=start;e.end=end;e.fixed=true;e.weekKey=weekKey();e.title="";}
        LinearLayout card=dialogCard("✦",creating?"برنامه جدید":"ویرایش برنامه",creating?"بازه‌ی پیش‌فرض یک ساعت است":"زمان و تکرار برنامه را تنظیم کن");
        EditText title=inputField("عنوان برنامه",e.title);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-1,(int)dp(50));tlp.bottomMargin=(int)dp(9);card.addView(title,tlp);
        final int[] dd={e.day},ss={e.start},ee={e.end};final boolean[] ff={e.fixed};
        TextView dayField=softButton(dayNames[dd[0]],0xFFF7FAFF,0xFF17345D),startField=softButton(timeText(ss[0]),0xFFF7FAFF,0xFF17345D),endField=softButton(timeText(ee[0]),0xFFF7FAFF,0xFF17345D);
        LinearLayout row=new LinearLayout(activity);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.addView(dayField,new LinearLayout.LayoutParams(0,(int)dp(46),1));View g1=new View(activity);row.addView(g1,new LinearLayout.LayoutParams((int)dp(7),1));row.addView(startField,new LinearLayout.LayoutParams(0,(int)dp(46),1));View g2=new View(activity);row.addView(g2,new LinearLayout.LayoutParams((int)dp(7),1));row.addView(endField,new LinearLayout.LayoutParams(0,(int)dp(46),1));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,(int)dp(46));rlp.bottomMargin=(int)dp(9);card.addView(row,rlp);
        TextView fixed=softButton(ff[0]?"تکرار هفتگی  ✓":"فقط همین هفته",ff[0]?0xFFEAF4FF:0xFFF7FAFF,0xFF17345D);card.addView(fixed,new LinearLayout.LayoutParams(-1,(int)dp(46)));
        dayField.setOnClickListener(v->{feedback(v);showDayPicker(dd[0],n->{dd[0]=n;dayField.setText(dayNames[n]);});});
        startField.setOnClickListener(v->{feedback(v);showTimePicker(ss[0],n->{ss[0]=n;if(ee[0]<=ss[0])ee[0]=Math.min(END_MIN,ss[0]+60);startField.setText(timeText(ss[0]));endField.setText(timeText(ee[0]));},false);});
        endField.setOnClickListener(v->{feedback(v);showTimePicker(ee[0],n->{ee[0]=Math.max(ss[0]+30,n);endField.setText(timeText(ee[0]));},true);});
        fixed.setOnClickListener(v->{feedback(v);ff[0]=!ff[0];fixed.setText(ff[0]?"تکرار هفتگی  ✓":"فقط همین هفته");fixed.setBackground(fieldBg(ff[0]?0xFFEAF4FF:0xFFF7FAFF,0x334D8DFF,14));});

        if(!creating){
            // Keep the existing status/delete controls, but place them directly in Edit so no intermediate menu is needed.
            TextView done=softButton("انجام شد",0xFFEAF8F2,0xFF287454),fail=softButton("انجام نشد",0xFFFFF0F4,0xFFAD3F5F),neutral=softButton("بدون وضعیت",0xFFF7FAFF,0xFF52667F),del=softButton("حذف",0xFFFFF7FA,0xFFB53C61);
            TextView[] stateButtons={done,fail,neutral,del};for(TextView b:stateButtons){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(40));lp.topMargin=(int)dp(5);card.addView(b,lp);}
            done.setOnClickListener(v->{feedback(v);setStatus(e.id,1);});
            fail.setOnClickListener(v->{feedback(v);setStatus(e.id,2);});
            neutral.setOnClickListener(v->{feedback(v);setStatus(e.id,0);});
            del.setOnClickListener(v->{feedback(v);Dialog parent=(Dialog)card.getTag();if(parent!=null)parent.dismiss();confirmDelete(e);});
        }

        LinearLayout actions=new LinearLayout(activity);actions.setOrientation(LinearLayout.HORIZONTAL);TextView cancel=button("لغو",false),save=button("ذخیره",true);actions.addView(cancel,new LinearLayout.LayoutParams(0,(int)dp(48),1));View ag=new View(activity);actions.addView(ag,new LinearLayout.LayoutParams((int)dp(8),1));actions.addView(save,new LinearLayout.LayoutParams(0,(int)dp(48),1));LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,(int)dp(48));alp.topMargin=(int)dp(12);card.addView(actions,alp);
        Dialog d=baseDialog(card);card.setTag(d);cancel.setOnClickListener(v->{feedback(v);d.dismiss();});
        save.setOnClickListener(v->{feedback(v);String t=title.getText().toString().trim();if(t.isEmpty()){title.setError("عنوان را وارد کن");return;}e.title=t;e.day=dd[0];e.start=clamp(ss[0],START_MIN,END_MIN-30);e.end=clamp(Math.max(e.start+30,ee[0]),e.start+30,END_MIN);e.fixed=ff[0];if(!e.fixed)e.weekKey=weekKey();Entry conflict=findConflict(e);if(conflict!=null){showConflictDialog(conflict);return;}saveMerged(e);d.dismiss();});d.show();
    }

    interface IntPick{void onPick(int n);}
    private void showDayPicker(int selected,IntPick cb){ArrayList<String> a=new ArrayList<>();for(String s:dayNames)a.add(s);showChoice("روز",a,selected,n->cb.onPick(n));}
    private void showTimePicker(int selected,IntPick cb,boolean allow24){ArrayList<String>a=new ArrayList<>();ArrayList<Integer> vals=new ArrayList<>();for(int m=START_MIN;m<=END_MIN;m+=30){if(!allow24&&m==END_MIN)continue;a.add(timeText(m));vals.add(m);}int sel=0;for(int i=0;i<vals.size();i++)if(vals.get(i)==selected)sel=i;final ArrayList<Integer> f=vals;showChoice("زمان",a,sel,n->cb.onPick(f.get(n)));}
    private void showChoice(String title,ArrayList<String> options,int selected,IntPick cb){
        LinearLayout card=dialogCard("✦",title,"");ScrollView sc=new ScrollView(activity);sc.setFillViewport(false);LinearLayout list=new LinearLayout(activity);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);
        for(int i=0;i<options.size();i++){final int idx=i;TextView r=softButton((i==selected?"✓  ":"")+options.get(i),i==selected?0xFFEAF4FF:0xFFF8FAFF,0xFF17345D);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(42));lp.bottomMargin=(int)dp(5);list.addView(r,lp);r.setOnClickListener(v->{feedback(v);cb.onPick(idx);Dialog dd=(Dialog)sc.getTag();if(dd!=null)dd.dismiss();});}
        int screenH=getResources().getDisplayMetrics().heightPixels;card.addView(sc,new LinearLayout.LayoutParams(-1,Math.min((int)dp(420),Math.max((int)dp(120),screenH-(int)dp(280)))));Dialog d=baseDialog(card);sc.setTag(d);d.show();
    }

    private void showEntryActions(Entry e){
        LinearLayout card=dialogCard("✦",e.title,dayNames[e.day]+"   "+timeText(e.start)+" – "+timeText(e.end)+(e.fixed?"   • هفتگی":""));
        TextView edit=softButton("ویرایش",0xFFEAF4FF,0xFF245E99),done=softButton("انجام شد",0xFFEAF8F2,0xFF287454),fail=softButton("انجام نشد",0xFFFFF0F4,0xFFAD3F5F),neutral=softButton("بدون وضعیت",0xFFF7FAFF,0xFF52667F),del=softButton("حذف",0xFFFFF7FA,0xFFB53C61);
        TextView[] bs={edit,done,fail,neutral,del};for(TextView b:bs){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(44));lp.bottomMargin=(int)dp(6);card.addView(b,lp);}Dialog d=baseDialog(card);
        edit.setOnClickListener(v->{feedback(v);d.dismiss();showEntryEditor(e,e.day,e.start,e.end);});done.setOnClickListener(v->{feedback(v);setStatus(e.id,1);d.dismiss();});fail.setOnClickListener(v->{feedback(v);setStatus(e.id,2);d.dismiss();});neutral.setOnClickListener(v->{feedback(v);setStatus(e.id,0);d.dismiss();});del.setOnClickListener(v->{feedback(v);d.dismiss();confirmDelete(e);});d.show();
    }

    private void confirmDelete(Entry e){
        LinearLayout card=dialogCard("✦","حذف برنامه؟","این برنامه از جدول حذف می‌شود.");LinearLayout a=new LinearLayout(activity);TextView no=button("لغو",false),yes=softButton("حذف",0xFFFFEAF0,0xFFB53C61);a.addView(no,new LinearLayout.LayoutParams(0,(int)dp(46),1));View gap=new View(activity);a.addView(gap,new LinearLayout.LayoutParams((int)dp(8),1));a.addView(yes,new LinearLayout.LayoutParams(0,(int)dp(46),1));card.addView(a,new LinearLayout.LayoutParams(-1,(int)dp(46)));Dialog d=baseDialog(card);no.setOnClickListener(v->{feedback(v);d.dismiss();});yes.setOnClickListener(v->{feedback(v);delete(e);d.dismiss();});d.show();
    }

    private void showConflictDialog(Entry conflict){
        String sub=dayNames[conflict.day]+"، "+timeText(conflict.start)+" تا "+timeText(conflict.end)+" با «"+conflict.title+"» تداخل دارد. بازه را در همین ویرایش تغییر بده.";
        LinearLayout card=dialogCard("!","تداخل زمانی",sub);TextView back=button("بازگشت به ویرایش",true);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,(int)dp(48));bp.topMargin=(int)dp(8);card.addView(back,bp);Dialog d=baseDialog(card);back.setOnClickListener(v->{feedback(v);d.dismiss();});d.show();
    }

    private void showWeekPicker(){
        LinearLayout card=dialogCard("✦","انتخاب هفته","تاریخ‌ها بر اساس تقویم شمسی هستند");ScrollView sc=new ScrollView(activity);LinearLayout list=new LinearLayout(activity);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);
        for(int o=-10;o<=10;o++){final int off=o;long s=weekStartMillis(off),e=s+6*86400000L;int[] a=jalaliForMillis(s),b=jalaliForMillis(e);String cap=faDigits(a[0]+"/"+two(a[1])+"/"+two(a[2]))+"  تا  "+faDigits(b[0]+"/"+two(b[1])+"/"+two(b[2]));TextView row=softButton((off==weekOffset?"✓  ":"")+cap,off==weekOffset?0xFFEAF4FF:0xFFF8FAFF,0xFF17345D);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(44));lp.bottomMargin=(int)dp(5);list.addView(row,lp);row.setOnClickListener(v->{feedback(v);weekOffset=off;zoom=1;panX=panY=0;invalidate();Dialog dd=(Dialog)sc.getTag();if(dd!=null)dd.dismiss();});}
        card.addView(sc,new LinearLayout.LayoutParams(-1,(int)Math.min(dp(420),getResources().getDisplayMetrics().heightPixels-dp(300))));Dialog d=baseDialog(card);sc.setTag(d);d.show();
    }

    private void showOverview(){
        LinearLayout card=dialogCard("✦","نمای کلی هفته","لمس هر برنامه، تنظیمات همان برنامه را باز می‌کند");ArrayList<Entry> es=entriesForWeek();Collections.sort(es,(a,b)->a.day!=b.day?a.day-b.day:a.start-b.start);ScrollView sc=new ScrollView(activity);LinearLayout list=new LinearLayout(activity);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);
        if(es.isEmpty()){TextView empty=label("هنوز برنامه‌ای ثبت نشده",13,0xFF647895);list.addView(empty,new LinearLayout.LayoutParams(-1,(int)dp(60)));}else for(Entry e:es){int st=statusFor(e.id);String mark=st==1?"✓  ":st==2?"×  ":"";TextView row=softButton(mark+dayNames[e.day]+"  •  "+timeText(e.start)+"  •  "+e.title,st==1?0xFFEAF8F2:st==2?0xFFFFF0F4:0xFFF8FAFF,st==1?0xFF287454:st==2?0xFFAD3F5F:0xFF17345D);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)dp(44));lp.bottomMargin=(int)dp(5);list.addView(row,lp);row.setOnClickListener(v->{feedback(v);Dialog dd=(Dialog)sc.getTag();if(dd!=null)dd.dismiss();showEntryEditor(e,e.day,e.start,e.end);});}
        int h=(int)Math.min(dp(320),Math.max(dp(80),es.size()*dp(49)));card.addView(sc,new LinearLayout.LayoutParams(-1,h));TextView reset=softButton("ریست این هفته (حفظ برنامه‌های ثابت)",0xFFF5F0F7,0xFF80516D);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,(int)dp(46));rp.topMargin=(int)dp(9);card.addView(reset,rp);Dialog d=baseDialog(card);sc.setTag(d);reset.setOnClickListener(v->{feedback(v);d.dismiss();confirmResetWeek();});d.show();
    }

    private void confirmResetWeek(){LinearLayout card=dialogCard("↻","ریست هفته","برنامه‌های یک‌باره پاک می‌شوند؛ برنامه‌های ثابت باقی می‌مانند.");LinearLayout a=new LinearLayout(activity);TextView no=button("لغو",false),yes=softButton("ریست",0xFFFFEEF3,0xFF9A4967);a.addView(no,new LinearLayout.LayoutParams(0,(int)dp(46),1));View gap=new View(activity);a.addView(gap,new LinearLayout.LayoutParams((int)dp(8),1));a.addView(yes,new LinearLayout.LayoutParams(0,(int)dp(46),1));card.addView(a,new LinearLayout.LayoutParams(-1,(int)dp(46)));Dialog d=baseDialog(card);no.setOnClickListener(v->{feedback(v);d.dismiss();});yes.setOnClickListener(v->{feedback(v);resetWeek();d.dismiss();});d.show();}
    private void resetWeek(){String wk=weekKey();ArrayList<String> all=ids();for(String id:new ArrayList<>(all)){Entry e=read(id);if(e==null)continue;if(!e.fixed&&wk.equals(e.weekKey))delete(e);else prefs.edit().remove("st_"+wk+"_"+id).apply();}invalidate();}

    private float fitTextSp(String s,float maxWidth,float startSp,float minSp){float size=startSp;text.setTextSize(sp(size));while(size>minSp&&text.measureText(s)>maxWidth){size-=.4f;text.setTextSize(sp(size));}return Math.max(minSp,size);}
    private String ellipsizeToWidth(String s,float maxWidth,Paint pt){if(s==null)return "";if(pt.measureText(s)<=maxWidth)return s;String ell="…";int n=s.length();while(n>1&&pt.measureText(s.substring(0,n)+ell)>maxWidth)n--;return s.substring(0,Math.max(1,n))+ell;}
    private String timeText(int min){if(min>=END_MIN)return "24:00";return String.format(Locale.US,"%02d:%02d",min/60,min%60);}
    private String two(int n){return n<10?"0"+n:String.valueOf(n);}
    private void drawCentered(Canvas c,String s,float x,float y,Paint pt){Paint.FontMetrics fm=pt.getFontMetrics();c.drawText(s,x,y-(fm.ascent+fm.descent)/2f,pt);}
    private String faDigits(String s){String en="0123456789",fa="۰۱۲۳۴۵۶۷۸۹";StringBuilder b=new StringBuilder();for(char ch:s.toCharArray()){int i=en.indexOf(ch);b.append(i>=0?fa.charAt(i):ch);}return b.toString();}

    private int[] jalaliForMillis(long millis){Calendar c=Calendar.getInstance();c.setTimeInMillis(millis);return gregorianToJalali(c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}
    private int[] gregorianToJalali(int gy,int gm,int gd){int[] gdm={0,31,59,90,120,151,181,212,243,273,304,334};int gy2=(gm>2)?(gy+1):gy;long days=355666L+365L*gy+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400+gd+gdm[gm-1];int jy=-1595+33*(int)(days/12053);days%=12053;jy+=4*(int)(days/1461);days%=1461;if(days>365){jy+=(int)((days-1)/365);days=(days-1)%365;}int jm,jd;if(days<186){jm=1+(int)(days/31);jd=1+(int)(days%31);}else{jm=7+(int)((days-186)/30);jd=1+(int)((days-186)%30);}return new int[]{jy,jm,jd};}
}

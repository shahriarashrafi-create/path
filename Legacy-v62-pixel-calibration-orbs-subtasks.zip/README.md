Legacy v62

Changes:
- Removed full-width blue bars from the top/bottom of each Progress Path artwork.
- Added a small glowing blue orb centered at the very top and bottom of each Progress Path page.
- Simplified Subtasks: removed Persian section labels/subtitles and switched auxiliary edit/delete UI to concise English.
- Pixel-calibrated Mission Editor against the actual 768x1536 artwork: title, edit icon, importance pills, time controls, repeat controls, Start button.
- Added a dedicated touch zone for the pencil/edit icon that focuses the title field.
- Improved selected-state outline for editor choices.
- Pixel-calibrated Running Mission against the actual 768x1536 artwork: title, ring, timer, reward, Done/Fail, Music/Sound/Reset/Subtasks.
- Reduced and aligned the progress ring stroke to sit on the artwork's timer circle.
- Synced the Home code label to «درخت تصاعد».

Journey v41 - Stage editor polish

Changes from v40:
- Persian stage title input is now right-aligned inside the title field.
- Selected values for Time, Importance, Repeat, and Reminder are separated from their fixed labels and aligned in a consistent value column.
- Dynamic values use a smaller, softer gray-blue style to avoid visual collision with the labels.
- Time continues to show the selected value as 5 / 10 / 20 / 30 with a smaller "min" suffix.
- Back from a stage editor now returns to the exact previous scroll position in Progress Path instead of jumping back to the bottom.
- The existing 7 progress images, 21 stage touch targets, touch feedback, persistent titles/settings, Header, Bottom Bar, and Start Mission flow are preserved.

package com.shahriar.legacy;

import android.app.*;
import android.content.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MissionActionReceiver extends BroadcastReceiver {
    public static final String ACTION_DONE="com.shahriar.legacy.MISSION_DONE";
    public static final String ACTION_LATER="com.shahriar.legacy.MISSION_LATER";
    public static final String ACTION_FAIL="com.shahriar.legacy.MISSION_FAIL";

    @Override public void onReceive(Context context, Intent intent){
        if(intent==null)return;
        String action=intent.getAction();
        if(!ACTION_DONE.equals(action)&&!ACTION_LATER.equals(action)&&!ACTION_FAIL.equals(action))return;
        SharedPreferences progress=context.getSharedPreferences("legacy_progress_rebuild",Context.MODE_PRIVATE);
        if(!progress.getBoolean("active",false)){cancelNotification(context);return;}
        int section=progress.getInt("active_s",-1),slot=progress.getInt("active_k",-1);
        if(section<1||slot<0){clearActive(context,progress);return;}
        String title=progress.getString("active_title","");

        SharedPreferences game=context.getSharedPreferences("legacy_game",Context.MODE_PRIVATE);
        int level=game.getInt("level",1),xp=game.getInt("xp",0),coins=game.getInt("coins",0),combo=game.getInt("combo",0);
        long last=game.getLong("lastSuccessAt",0);int window=game.getInt("comboWindowMinutes",30);long now=System.currentTimeMillis();
        if(combo>0&&last>0&&now-last>window*60000L){combo=0;last=0;game.edit().putInt("combo",0).putLong("lastSuccessAt",0).apply();}

        boolean finalResult=ACTION_DONE.equals(action)||ACTION_FAIL.equals(action);
        if(finalResult){
            progress.edit()
                .putBoolean(mf(section,slot,"reward_snapshot"),true)
                .putInt(mf(section,slot,"prev_level"),level)
                .putInt(mf(section,slot,"prev_xp"),xp)
                .putInt(mf(section,slot,"prev_coins"),coins)
                .putInt(mf(section,slot,"prev_combo"),combo)
                .putLong(mf(section,slot,"prev_last_success"),last)
                .putInt(mf(section,slot,"reward_xp"),0)
                .putInt(mf(section,slot,"reward_coins"),0)
                .remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at"))
                .apply();
        }

        String state=ACTION_DONE.equals(action)?"done":ACTION_FAIL.equals(action)?"fail":"ready";
        SharedPreferences.Editor pe=progress.edit().putString(mf(section,slot,"state"),state);
        if("done".equals(state)||"fail".equals(state))pe.putString(mf(section,slot,"state_day"),today());else pe.remove(mf(section,slot,"state_day"));pe.apply();

        if(ACTION_DONE.equals(action)){
            float mult=combo>=10?3f:combo>=7?2f:combo>=3?1.5f:1f;
            int importance=0;try{importance=Math.max(0,Math.min(2,Integer.parseInt(progress.getString(mf(section,slot,"importance"),"0"))));}catch(Exception ignored){}
            int baseXp=importance==2?35:importance==1?20:10;
            int baseCoins=importance==2?7:importance==1?4:2;
            int earnedXp=Math.max(1,Math.round(baseXp*mult)),earnedCoins=Math.max(1,Math.round(baseCoins*mult));int oldLevel=level;
            xp+=earnedXp;coins+=earnedCoins;combo++;last=now;while(xp>=xpNeeded(level)){xp-=xpNeeded(level);level++;}
            progress.edit().putInt(mf(section,slot,"reward_xp"),earnedXp).putInt(mf(section,slot,"reward_coins"),earnedCoins).putString(mf(section,slot,"reward_outcome"),"done").putLong(mf(section,slot,"reward_at"),last).apply();
            game.edit().putInt("level",level).putInt("xp",xp).putInt("coins",coins).putInt("combo",combo).putLong("lastSuccessAt",last)
                .putInt("pending_reward_xp",earnedXp).putInt("pending_reward_coins",earnedCoins).putInt("pending_level_up",level>oldLevel?level:0)
                .putInt("pending_combo",combo).putInt("pending_prev_combo",Math.max(0,combo-1)).putString("pending_title",title).putString("pending_result","done").apply();
        }else if(ACTION_FAIL.equals(action)){
            int prevCombo=combo;
            progress.edit().putInt(mf(section,slot,"reward_xp"),0).putInt(mf(section,slot,"reward_coins"),0).putString(mf(section,slot,"reward_outcome"),"fail").putLong(mf(section,slot,"reward_at"),now).apply();
            game.edit().putInt("combo",0).putLong("lastSuccessAt",0).putInt("pending_prev_combo",prevCombo).putInt("pending_combo",0).putString("pending_title",title).putString("pending_result","fail").apply();
        }else{
            game.edit().putString("pending_title",title).putString("pending_result","later").apply();
        }
        clearActive(context,progress);
    }
    private static int xpNeeded(int level){return 100+Math.max(0,level-1)*50;}
    private static String mf(int s,int k,String f){return "m_"+s+"_"+k+"_"+f;}
    private static String today(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
    private static void clearActive(Context context,SharedPreferences progress){
        progress.edit().putBoolean("active",false).remove("active_s").remove("active_k").remove("active_title").remove("active_end").remove("active_total").remove("active_alerted").apply();
        try{AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);Intent i=new Intent(context,MissionAlarmReceiver.class);i.setAction("com.shahriar.legacy.MISSION_ALARM");PendingIntent pi=PendingIntent.getBroadcast(context,4101,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}catch(Exception ignored){}
        cancelNotification(context);
    }
    private static void cancelNotification(Context context){try{NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);nm.cancel(4101);}catch(Exception ignored){}}
}

Legacy v76 – final progress/tree closure polish

Base: Legacy-v75-tree-daily-zoom-controls.zip

Final fixes:
- Back press now plays exactly one UI sound while still navigating exactly one level.
- Persian tree search is normalized for Arabic/Persian character variants (ی/ي/ى, ک/ك), ZWNJ/directional marks, diacritics, and repeated spaces.
- Tree History no longer has the previous 30-date display cap; all saved snapshot dates are shown in the scrollable history list.
- PV / GPV / count remain cumulative across the configurable logical-day boundary. At the new day, the values stay in place but stats_day no longer matches the new logical day, so the person is treated as not-yet-recorded until fresh actual stats are saved.
- Existing configurable day start (default 06:00), mission day boundaries, tree colors, zoom/search/history behavior, To Do, and Actions remain intact.

# Legacy v49

Gaming polish pass built on v48.

- Replaced Home/Progress pulse guides with animated coin-rain using the real HUD coin asset.
- Next unfinished Progress circle receives coin rain; the latest completed circle gets a tiny 3-frame moving hero marker.
- Start Mission button has coin-rain attraction animation.
- Added 3 built-in 2-minute focus tracks: energetic, calm, balanced.
- Added global UI tap/click sound.
- Added slower page enter/exit and dialog enter/exit transitions.
- Added custom pastel popup icon assets for music, subtasks, success, failure, pause, restore, delete, level-up, alert and edit.
- Reduced nonessential explanatory copy across pages and popups.
- Extended mission launch/reward/fail/reset/restore animation timing and added coin-asset bursts.
- App version: 1.34 (38).

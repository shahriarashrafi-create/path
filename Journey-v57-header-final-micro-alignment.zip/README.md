Journey v54

Changes in this version:
- Replaced the previous header with a new compact blue HUD-style header similar to the approved mockup.
- Added the business anime avatar as the header profile image.
- Replaced the launcher icon with the same avatar image.
- Kept the current home background/touch calibration from v53.
- Settings backup actions remain available (Export / Import).

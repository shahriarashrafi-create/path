Journey-v49-progress-path-final

Final closure of the Journey Progress Path / Mission flow.

Included:
- 7 stacked Progress Path artworks with 21 stages.
- Persistent mission timer based on a saved end timestamp; closing or killing the app does not reset a running mission.
- Paused missions reopen paused with their exact saved remaining time.
- If the timer expires while the app is closed, reopening shows 00:00 and ? until the user chooses Done or Fail.
- Only one active mission is allowed. Re-entering the same active stage resumes it instead of restarting its timer.
- Done = green path circle + struck-through title; Fail = red circle + struck-through title; Active = blue state.
- NEW final path interaction: a single tap on a Done/Fail circle opens that stage page for review/edit.
- NEW final path interaction: a double tap on a Done/Fail circle within 300 ms resets only that stage result.
- Reset preserves title/settings, removes Done/Fail styling, returns that stage's recorded XP/coins, and recalculates combo from remaining results.
- Result submission remains locked against duplicate rewards.
- Timer and Pause/Resume visual calibration from v48 retained.
- No Android notification/reminder scheduling in this version, per current requirement.
- Journey safe-area Header/Bottom Bar behavior remains unchanged.
- App version: 1.7 (versionCode 11).


## v51 — Home touch recalibration
- Removed the legacy global `-36dp` Home hotspot offset.
- Rebuilt all six Home touch zones from the current `journey_background` artwork.
- Applied the same final fine-tune used on Progress Path touch targets: `+1dp` downward.
- Home destinations remain: جام جهانی، مرکز خرید، کاخ آرزوها، سفر در زمان، جنگل شکوفایی، مسیر پیشرفت.
- No visual assets or Mission/Progress logic changed in this version.

## v52 – Avatar, launcher icon and data backup
- Launcher icon replaced with the supplied two-character anime artwork.
- Header avatar replaced with the supplied business-style male anime portrait.
- Center Journey logo removed from the header while keeping the rest of the header shell intact.
- Settings now includes Data & Backup actions for Export and Import.
- Export writes all Journey SharedPreferences to a JSON backup using Android's document picker.
- Import restores the saved preferences so progress can be carried between builds/reinstalls.
- Existing Home background, calibrated touch zones, Progress Path, mission timer, rewards and all other logic are unchanged.


## v53 – Home background + touch recalibration
- Replaced only the Home background with the new high-quality 1:2 anime artwork.
- Recalibrated all six Home touch zones to the six visible cards in the new artwork.
- Kept the final Progress Path-style touch correction: +1dp downward.
- Header, Bottom Bar, avatar, app icon, backup/import-export, Progress Path, Mission logic, and all other screens remain unchanged.

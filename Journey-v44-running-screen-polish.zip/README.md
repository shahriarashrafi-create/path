Journey-v44-running-screen-polish

Changes from v43:
1. Replaced the mission-running background with the approved clean 1:2 artwork.
2. Kept Header and Bottom Bar as app UI on the top layer; they are not baked into the background image.
3. Subtask rows remain blank in the artwork. The app renders editable text and adds a checkbox only through code.
4. Subtask checkboxes were reduced and realigned for a cleaner fit inside each row.
5. Checked subtasks remain stored and the subtask text is struck through.
6. Timer is positioned ~1 mm to the right and ~2 mm lower, as requested, to sit closer to the circle center.
7. Pause/Resume touch target and dynamic icon use the same calibration (~1 mm right, ~2 mm down).
8. Pause/Resume icon is larger. Running state shows Pause (Ⅱ); paused state shows Play (▶).
9. Timer still uses the duration selected on the previous stage-settings screen.
10. Timer continues while navigating away and resumes from the correct remaining time when returning.
11. Done/Fail buttons, reward logic, 21 stage touch areas, seven progress artworks, saved titles/settings/subtasks, and permanent Header/Bottom Bar remain intact.

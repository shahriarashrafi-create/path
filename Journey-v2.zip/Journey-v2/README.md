# Journey v2

Android application project for Journey.

This revision simplifies startup code for maximum compatibility and keeps the bundled 1080x2040 WebP background in `drawable-nodpi`.

App display name: Journey (including Persian locale resources).

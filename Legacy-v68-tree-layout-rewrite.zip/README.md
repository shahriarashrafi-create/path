Legacy v68 – Tree Layout Engine Rewrite

Changes in "درخت تصاعد":
- Replaced the old one-column-per-branch layout with a true dynamic hierarchical tree.
- Tree grows from bottom to top and keeps each generation on a consistent horizontal level.
- Children are distributed symmetrically around their parent/subtree; large organizations no longer get pushed into a single right-side column.
- Every person in every level can add a new child.
- A leaf node always shows a + orb above it; tapping it adds a child.
- A node with visible children shows −; tapping it collapses that branch.
- A collapsed node shows +; tapping it expands the existing branch.
- Member card includes an explicit "افزودن فرد" action, so nodes that already have children can still add more children.
- Existing v67 tree data is migrated automatically into the new v2 graph format on first open.
- Existing names, PV, GPV, count, target PV, target GPV, and target count are preserved during migration.
- Names auto-fit inside the circles instead of overlapping.
- Root is largest, first generation is medium, later generations are progressively smaller.
- At normal/close zoom, PV / GPV / count are shown; at zoomed-out levels higher generations simplify to the name for readability.
- Added one-finger pan and two-finger pinch zoom for large trees.
- Opening/closing a branch preserves the clicked node's screen position to prevent sudden whole-tree jumps.
- Adding a new person recenters toward the newly created node.
- Background remains the selected clean palace image; all nodes, lines, glows and control orbs are code-rendered.

Base: Legacy-v67-dynamic-tree.zip

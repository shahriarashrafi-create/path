package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.view.*;
import android.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content;
    private long lastBackAt = 0;
    private boolean isHome = true;
    private int homeGeneration = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","جنگل شکوفایی","سفر در زمان","مرکز خرید","جام جهانی"};
    // Touch centers measured against the current 768x1536 Home artwork.
    // Order matches names: Progress, Dream Palace, Growth Forest, Time Travel, Shop, World Cup.
    private final float[][] centers = {{0.510f,0.773f},{0.195f,0.542f},{0.715f,0.606f},{0.842f,0.426f},{0.320f,0.325f},{0.845f,0.217f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void showHome(){
        isHome = true;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        setContentView(root);
        root.setFitsSystemWindows(true);

        ImageView home=new ImageView(this); home.setImageResource(R.drawable.home_background);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // New Legacy HUD, rebuilt from scratch. It floats inside the safe area.
        FrameLayout header=new FrameLayout(this);
        header.setPadding(dp(7),dp(3),dp(7),dp(3));
        header.setBackground(new HudBackground());
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(64),Gravity.TOP);
        hp.setMargins(dp(8),dp(4),dp(8),0);
        root.addView(header,hp);

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(5),0,dp(4),0);
        header.addView(row,new FrameLayout.LayoutParams(-1,-1));

        ImageView avatar=new ImageView(this);
        avatar.setImageResource(R.drawable.avatar_legacy);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        avatar.setContentDescription("آواتار");
        row.addView(avatar,new LinearLayout.LayoutParams(dp(50),dp(50)));

        LinearLayout stats=new LinearLayout(this);
        stats.setOrientation(LinearLayout.VERTICAL);
        stats.setGravity(Gravity.CENTER_VERTICAL);
        stats.setPadding(dp(7),0,dp(6),0);
        TextView level=tv("LV 1",13,0xFFF7F9FC);
        level.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        stats.addView(level,new LinearLayout.LayoutParams(-1,dp(18)));

        ProgressBar xp=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        xp.setMax(100); xp.setProgress(0);
        xp.setProgressTintList(ColorStateList.valueOf(0xFF22C7FF));
        xp.setProgressBackgroundTintList(ColorStateList.valueOf(0xAA35526B));
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(8));
        xpLp.setMargins(0,dp(1),0,dp(1)); stats.addView(xp,xpLp);
        TextView xpTxt=tv("0 / 100 XP",9,0xFFEAF7FF);
        xpTxt.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        stats.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(15)));
        row.addView(stats,new LinearLayout.LayoutParams(0,dp(50),1f));

        LinearLayout coinBox=glassCapsule();
        CoinView coinIcon=new CoinView(this);
        coinBox.addView(coinIcon,new LinearLayout.LayoutParams(dp(19),dp(19)));
        TextView coin=tv("0",12,0xFFFFE5A0); coin.setPadding(dp(4),0,0,0);
        coinBox.addView(coin,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(29));
        coinLp.setMargins(0,0,dp(4),0); row.addView(coinBox,coinLp);

        LinearLayout comboBox=glassCapsule();
        TextView flame=tv("🔥",13,Color.WHITE); comboBox.addView(flame,new LinearLayout.LayoutParams(dp(23),-1));
        TextView combo=tv("0",12,Color.WHITE); comboBox.addView(combo,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(47),dp(29));
        comboLp.setMargins(0,0,dp(3),0); row.addView(comboBox,comboLp);

        TextView gear=tv("⚙",17,0xFFE8EEF3);
        gear.setGravity(Gravity.CENTER); gear.setContentDescription("تنظیمات");
        gear.setOnClickListener(v->showPlaceholder("تنظیمات"));
        row.addView(gear,new LinearLayout.LayoutParams(dp(36),dp(44)));

        // Hit targets follow the six labels baked into the selected 768x1536 Home artwork.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=768f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            int hitW=Math.max(dp(118), Math.round(245f*scale));
            int hitH=Math.max(dp(48), Math.round(72f*scale));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=Math.round(offsetX + srcW*centers[i][0]*scale);
                int cy=Math.round(offsetY + srcH*centers[i][1]*scale);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-hitW/2; lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==MotionEvent.ACTION_DOWN){ v.setAlpha(.55f); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->showPlaceholder(names[idx])); content.addView(hit,lp);
            }
        });
        header.bringToFront();
    }

    private LinearLayout glassCapsule(){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0x8A132536,dp(15)); g.setStroke(dp(1),0x553E789B); box.setBackground(g);
        return box;
    }

    private class HudBackground extends android.graphics.drawable.Drawable {
        private final Paint fill=new Paint(1), stroke=new Paint(1), glow=new Paint(1);
        HudBackground(){
            fill.setColor(0xC8172738); fill.setStyle(Paint.Style.FILL);
            stroke.setColor(0xAA8FB7CF); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            glow.setColor(0x5522C7FF); glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(dp(2));
        }
        private Path shape(){
            RectF b=new RectF(getBounds()); float c=dp(10); Path p=new Path();
            p.moveTo(b.left+c,b.top); p.lineTo(b.right-c,b.top); p.lineTo(b.right,b.top+c);
            p.lineTo(b.right,b.bottom-c); p.lineTo(b.right-c,b.bottom); p.lineTo(b.left+c,b.bottom);
            p.lineTo(b.left,b.bottom-c); p.lineTo(b.left,b.top+c); p.close(); return p;
        }
        @Override public void draw(Canvas c){ Path p=shape(); c.drawPath(p,fill); c.drawPath(p,glow); c.drawPath(p,stroke); }
        @Override public void setAlpha(int a){} @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){ return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private class CoinView extends View {
        Paint p=new Paint(1); CoinView(android.content.Context c){super(c);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float r=Math.min(getWidth(),getHeight())*.43f, x=getWidth()/2f,y=getHeight()/2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFC43D); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xFFFFE9A3); c.drawCircle(x,y,r-dp(1),p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF8C5A00); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(10));
            c.drawText("L",x,y-(p.ascent()+p.descent())/2,p);
        }
    }

    private void showPlaceholder(String title){
        isHome = false;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(Color.rgb(10,31,51));
        TextView t=tv(title,28,Color.WHITE); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,0xFFBFD4E6); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
    }
    @Override public void onBackPressed(){
        // On a section, Back returns Home. On Home, double Back exits.
        if(!isHome){ showHome(); return; }
        long now=System.currentTimeMillis();
        if(now-lastBackAt<1800){ super.onBackPressed(); }
        else { lastBackAt=now; Toast.makeText(this,"برای خروج دوباره بزنید",Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
}

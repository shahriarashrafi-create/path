# Legacy v13 — HUD Polish

- Compact floating HUD with reduced height and dead space
- Smaller avatar while preserving the selected artwork
- Tighter LV/XP grouping with clearer bright-blue XP track
- Smaller coin, combo and settings controls
- Current Home artwork and six touch targets preserved
- Android system status/navigation bars remain outside app content

# Journey v3
Android app project for Journey.

- App name: Journey
- Background: 1080x2040 WebP (9:17)
- Background is fit to screen width without center-crop side loss.
- Edge-to-edge system bars remain transparent.

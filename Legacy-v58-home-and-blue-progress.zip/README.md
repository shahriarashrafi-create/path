Legacy v58
Changes:
- Replaced home background with new uploaded image.
- Replaced progress path images: odd sections use right-circle artwork, even sections use left-circle artwork.
- Recalibrated mission circle centers/sizes for the new 768x1536 progress images.
- Updated page aspect ratio to 768x1536 and kept touch/title/state fill aligned.
- Adjusted home touch centers for the new home artwork.

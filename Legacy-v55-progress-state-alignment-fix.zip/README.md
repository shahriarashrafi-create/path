# Legacy v55

Progress Path state + alignment correction based on v54.

- Removed the special gold next-mission overlay and all of its coin/sparkle/pulse animation code.
- Removed the special white empty-slot overlay and the animated `.`, `..`, `...` prompt.
- Completed missions now fill only the inside of the artwork circle with a strong green and use high-contrast white text.
- Failed missions now fill only the inside with dark red and use high-contrast white text.
- No code-drawn outline/stroke is added around mission circles; the original artwork rim stays visible.
- Recalibrated circle/title/touch geometry independently for both progress artworks using measured centers from the actual 768x1536 images.
- Fixed upper/alternate progress pages where mirrored coordinates caused the text/touch circle to drift away from the visible artwork circle.
- Retains v54 Home artwork/touch zones, direct popup behavior, one-step Back navigation, UI click SFX, and compact focus audio placeholders.

Version: 1.35 (39).

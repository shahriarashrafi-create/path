package com.shahriar.legacy;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;

public class MissionAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        android.content.SharedPreferences sp=context.getSharedPreferences("legacy_progress_rebuild",Context.MODE_PRIVATE);
        if(!sp.getBoolean("active",false)) return;
        long end=sp.getLong("active_end",0);
        if(end>System.currentTimeMillis()+2000) return;
        sp.edit().putBoolean("active_alerted",true).apply();
        try{
            android.os.Vibrator vb=(android.os.Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
            if(vb!=null){
                if(Build.VERSION.SDK_INT>=26)vb.vibrate(android.os.VibrationEffect.createOneShot(500,android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                else vb.vibrate(500);
            }
        }catch(Exception ignored){}
        try{
            if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return;
            boolean muted=context.getSharedPreferences("legacy_mission_audio",Context.MODE_PRIVATE).getBoolean("muted",false);
            String ch=muted?"mission_timer_silent_v44":"mission_timer_sound_v44";
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(Build.VERSION.SDK_INT>=26){
                NotificationChannel nc=new NotificationChannel(ch,muted?"Mission Timer (Silent)":"Mission Timer",NotificationManager.IMPORTANCE_HIGH);
                if(muted)nc.setSound(null,null);
                nm.createNotificationChannel(nc);
            }
            Intent open=new Intent(context,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent contentPi=PendingIntent.getActivity(context,4101,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,ch):new Notification.Builder(context);
            PendingIntent donePi=actionPi(context,MissionActionReceiver.ACTION_DONE,4201),laterPi=actionPi(context,MissionActionReceiver.ACTION_LATER,4202),failPi=actionPi(context,MissionActionReceiver.ACTION_FAIL,4203);
            android.widget.RemoteViews rv=new android.widget.RemoteViews(context.getPackageName(),R.layout.notification_mission_complete);long min=Math.max(1,sp.getLong("active_total",60000L)/60000L);rv.setTextViewText(R.id.notif_title,"Mission Completed!");rv.setTextViewText(R.id.notif_mission,sp.getString("active_title","Mission")+"  •  "+min+" min");rv.setOnClickPendingIntent(R.id.notif_done,donePi);rv.setOnClickPendingIntent(R.id.notif_later,laterPi);rv.setOnClickPendingIntent(R.id.notif_fail,failPi);
            nb.setSmallIcon(R.drawable.ic_launcher_legacy).setContentTitle("Mission Completed!").setContentText(sp.getString("active_title","Mission")).setContentIntent(contentPi).setAutoCancel(true).setCustomContentView(rv).setCustomBigContentView(rv)
              .addAction(0,"Done",donePi).addAction(0,"Later",laterPi).addAction(0,"Fail",failPi);
            if(Build.VERSION.SDK_INT>=24)nb.setStyle(new Notification.DecoratedCustomViewStyle());
            if(Build.VERSION.SDK_INT<26)nb.setSound(muted?null:android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION));
            nm.notify(4101,nb.build());
        }catch(Exception ignored){}
    }
    private static PendingIntent actionPi(Context context,String action,int requestCode){
        Intent i=new Intent(context,MissionActionReceiver.class);i.setAction(action);
        return PendingIntent.getBroadcast(context,requestCode,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
}

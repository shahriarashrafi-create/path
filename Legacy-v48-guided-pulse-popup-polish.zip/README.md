Legacy v48 — Guided Progress Pulse & Popup Polish

Changes in this build:
- Replaced the remaining raw Android mission-details popup with the pastel blue/purple Legacy UI.
- Removed remaining raw AlertDialog styling for progress-title and Combo settings; all app dialogs now use the same custom popup language.
- Home: the Progress Path sign now has a soft cyan/blue breathing glow and sparkles to guide the next action.
- Progress Path: the active mission, or otherwise the lowest unfinished circle, receives a pulsing guide ring; Done/Fail circles are skipped.
- Tapping a mission circle now gives immediate pulse feedback before opening/resuming it.
- Starting a mission adds a slower MISSION START pulse, expanding ring and sparkle animation before the timer screen opens.
- Success animation is slower and more readable, with motivational text, particles and delayed XP/Coin/Combo flight into the HUD.
- Fail, Reset and Restore feedback animations are slower and clearer while keeping the tone encouraging.
- All custom popup entrances, icons and primary buttons have slower game-like motion and the same pastel blue/purple theme.
- Existing v47 fixes remain: real reward rollback on Restore and Done/Fail missions cannot be rerun through Edit until Restore.

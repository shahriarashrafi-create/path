# Legacy v5 — Professional Home Header

- Keeps the 709x1536 Home artwork at its original aspect ratio with CENTER_CROP; no stretching.
- Compact 68dp coded header, separate from the artwork.
- Avatar is cropped from the same anime character used on Home.
- Cleaner Level / XP hierarchy and visible XP track.
- Coin and Settings controls aligned consistently.
- Preserves safe-area behavior between Android status/navigation bars.
- Keeps crop-aware touch targets for all six Home destinations.
- Package remains `com.shahriar.legacy` so this updates Legacy, not the older Gamification app.

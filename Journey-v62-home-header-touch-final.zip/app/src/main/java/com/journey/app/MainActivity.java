package com.journey.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.os.Build;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.text.style.ForegroundColorSpan;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT_BACKUP = 7101;
    private static final int REQ_IMPORT_BACKUP = 7102;
    private FrameLayout root;
    private boolean onHome = true;
    private boolean onProgressPath = false;
    private boolean onProgressStage = false;
    private SharedPreferences prefs;
    private ScrollView currentProgressScroll;
    private int savedProgressScrollY = -1;
    private final Handler missionHandler = new Handler();
    private Runnable missionTick;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        prefs = getSharedPreferences("journey_progress", MODE_PRIVATE);
        if (!prefs.contains("level")) prefs.edit().putInt("level",1).putInt("xp",0).putInt("coins",0).putInt("combo",0).apply();
        // A running/paused mission survives Activity/app restarts. Its end timestamp is persisted,
        // so reopening Journey resumes the same mission instead of resetting the countdown.
        int activeNode = prefs.getInt("active_progress_node", 0);
        if (activeNode >= 1 && activeNode <= 21) {
            showRunningStage(activeNode);
        } else {
            if (activeNode != 0) {
                prefs.edit()
                    .remove("active_progress_node")
                    .remove("active_progress_end")
                    .remove("active_progress_remaining")
                    .remove("active_progress_paused")
                    .remove("active_progress_awaiting_result")
                    .commit();
            }
            showHome();
        }
    }

    private void configureWindow() {
        Window w = getWindow();
        // Keep app content strictly between Android system bars.
        // Do not draw the background underneath the status/navigation bars.
        w.setStatusBarColor(Color.rgb(2, 15, 38));
        w.setNavigationBarColor(Color.rgb(2, 15, 38));
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    private void showHome() {
        if (missionTick != null) missionHandler.removeCallbacks(missionTick);
        onHome = true;
        onProgressPath = false;
        onProgressStage = false;
        refreshComboTimeout();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 15, 38));
        // Permanent Journey rule: all app UI stays strictly inside Android system bars.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(0, top, 0, bottom);
                return insets;
            });
        }

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.journey_background);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bg.setAdjustViewBounds(false);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        // Home touch zones calibrated directly to the six wide cards in the final 1:2 artwork.
        // The zones cover each complete card (image + Persian label); addHotspot keeps the requested +1dp downward calibration.
        // v61: recalibrated upward from the real-device screenshot so the touch rectangles sit on the artwork, not below it.
        // Map touches through the actual CENTER_CROP image matrix. This keeps every hitbox
        // attached to its visible card on different phone aspect ratios instead of drifting vertically.
        addImageHotspot(bg, "جام جهانی", .035f, .108f, .965f, .231f);
        addImageHotspot(bg, "مرکز خرید", .035f, .235f, .965f, .358f);
        addImageHotspot(bg, "کاخ آرزوها", .035f, .362f, .965f, .486f);
        addImageHotspot(bg, "سفر در زمان", .035f, .490f, .965f, .613f);
        addImageHotspot(bg, "جنگل شکوفایی", .035f, .617f, .965f, .744f);
        addImageHotspot(bg, "مسیر پیشرفت", .035f, .748f, .965f, .878f);

        // Keep Journey chrome above the background and every touch layer.
        addTopBar();
        addBottomBar();

        setContentView(root);
    }


    private void addTopBar() {
        int level = prefs.getInt("level", 1);
        int xp = prefs.getInt("xp", 0);
        int combo = prefs.getInt("combo", 0);

        FrameLayout shell = new FrameLayout(this);
        shell.setClipChildren(false);
        shell.setClipToPadding(false);

        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(45), dp(4), dp(6), dp(4));
        GradientDrawable pillBg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.argb(196, 50, 78, 182), Color.argb(190, 35, 57, 141)});
        pillBg.setCornerRadius(dp(22));
        pillBg.setStroke(dp(1), Color.argb(170, 197, 214, 255));
        pill.setBackground(pillBg);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);

        TextView lvBadge = new TextView(this);
        lvBadge.setText("Lv\n" + level);
        lvBadge.setGravity(Gravity.CENTER);
        lvBadge.setTextColor(Color.WHITE);
        lvBadge.setTypeface(Typeface.DEFAULT_BOLD);
        lvBadge.setTextSize(11.5f);
        lvBadge.setLineSpacing(0f, 0.90f);
        GradientDrawable lvBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(82, 107, 228), Color.rgb(42, 56, 154)});
        lvBg.setShape(GradientDrawable.OVAL);
        lvBg.setStroke(dp(2), Color.rgb(239, 193, 74));
        lvBadge.setBackground(lvBg);
        LinearLayout.LayoutParams lvLp = new LinearLayout.LayoutParams(dp(32), dp(32));
        lvLp.rightMargin = dp(4);
        content.addView(lvBadge, lvLp);

        LinearLayout rankBox = new LinearLayout(this);
        rankBox.setOrientation(LinearLayout.VERTICAL);
        rankBox.setGravity(Gravity.CENTER_VERTICAL);
        rankBox.setPadding(0, 0, dp(4), 0);

        TextView rankText = new TextView(this);
        rankText.setText("Explorer");
        rankText.setTextColor(Color.WHITE);
        rankText.setTypeface(Typeface.DEFAULT_BOLD);
        rankText.setTextSize(12f);
        rankBox.addView(rankText, new LinearLayout.LayoutParams(-2, -2));

        ProgressBar xpBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        xpBar.setMax(Math.max(level * 100, 100));
        xpBar.setProgress(Math.min(xp, xpBar.getMax()));
        GradientDrawable track = new GradientDrawable();
        track.setColor(Color.argb(185, 7, 13, 35));
        track.setCornerRadius(dp(5));
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(255, 183, 42), Color.rgb(255, 220, 97)});
        fill.setCornerRadius(dp(5));
        android.graphics.drawable.ClipDrawable clip = new android.graphics.drawable.ClipDrawable(
                fill, Gravity.LEFT, android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable layers = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{track, clip});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        xpBar.setProgressDrawable(layers);
        LinearLayout.LayoutParams xpLp = new LinearLayout.LayoutParams(dp(56), dp(5));
        xpLp.topMargin = dp(3);
        rankBox.addView(xpBar, xpLp);
        LinearLayout.LayoutParams rankLp = new LinearLayout.LayoutParams(-2, -2);
        rankLp.rightMargin = dp(5);
        content.addView(rankBox, rankLp);

        LinearLayout comboChip = new LinearLayout(this);
        comboChip.setOrientation(LinearLayout.HORIZONTAL);
        comboChip.setGravity(Gravity.CENTER_VERTICAL);
        comboChip.setPadding(dp(7), 0, dp(8), 0);
        GradientDrawable comboBg = new GradientDrawable();
        comboBg.setColor(Color.argb(120, 23, 17, 40));
        comboBg.setCornerRadius(dp(14));
        comboBg.setStroke(dp(1), Color.argb(145, 176, 195, 255));
        comboChip.setBackground(comboBg);

        TextView flame = new TextView(this);
        flame.setText("🔥");
        flame.setTextSize(15f);
        comboChip.addView(flame, new LinearLayout.LayoutParams(-2, -2));

        TextView comboValue = new TextView(this);
        comboValue.setText(String.valueOf(combo));
        comboValue.setTextColor(Color.WHITE);
        comboValue.setTypeface(Typeface.DEFAULT_BOLD);
        comboValue.setTextSize(11.5f);
        comboValue.setPadding(dp(4), 0, 0, 0);
        comboChip.addView(comboValue, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout.LayoutParams comboLp = new LinearLayout.LayoutParams(-2, dp(28));
        comboLp.rightMargin = dp(3);
        content.addView(comboChip, comboLp);

        content.addView(createHeaderCounterChip("⭐", xp));
        content.addView(createHeaderCounterChip("🪙", prefs.getInt("coins", 0)));

        TextView gear = new TextView(this);
        gear.setText("⚙");
        gear.setGravity(Gravity.CENTER);
        gear.setTextColor(Color.WHITE);
        gear.setTextSize(10.5f);
        GradientDrawable gearBg = new GradientDrawable();
        gearBg.setShape(GradientDrawable.OVAL);
        gearBg.setColor(Color.argb(105, 20, 26, 60));
        gearBg.setStroke(dp(1), Color.argb(150, 176, 198, 255));
        gear.setBackground(gearBg);
        gear.setOnClickListener(v -> showSettings());
        LinearLayout.LayoutParams gearLp = new LinearLayout.LayoutParams(dp(20), dp(20));
        content.addView(gear, gearLp);

        pill.addView(content, new LinearLayout.LayoutParams(-1, -1));

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(-1, dp(42));
        pillLp.gravity = Gravity.TOP;
        pillLp.leftMargin = dp(16);
        pillLp.rightMargin = dp(6);
        pillLp.topMargin = dp(14);
        shell.addView(pill, pillLp);

        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.journey_avatar);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams avatarLp = new FrameLayout.LayoutParams(dp(40), dp(40));
        avatarLp.gravity = Gravity.START | Gravity.TOP;
        avatarLp.leftMargin = dp(4);
        avatarLp.topMargin = dp(10);
        shell.addView(avatar, avatarLp);

        FrameLayout.LayoutParams shellLp = new FrameLayout.LayoutParams(-1, dp(62));
        shellLp.gravity = Gravity.TOP;
        shellLp.leftMargin = dp(4);
        shellLp.rightMargin = dp(4);
        root.addView(shell, shellLp);
    }

    private LinearLayout createHeaderCounterChip(String icon, int value) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setPadding(dp(8), 0, dp(9), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(120, 23, 17, 40));
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.argb(145, 176, 195, 255));
        chip.setBackground(bg);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(13f);
        chip.addView(iconView, new LinearLayout.LayoutParams(-2, -2));

        TextView valueView = new TextView(this);
        valueView.setText(String.valueOf(value));
        valueView.setTextColor(Color.WHITE);
        valueView.setTypeface(Typeface.DEFAULT_BOLD);
        valueView.setTextSize(10.5f);
        valueView.setPadding(dp(4), 0, 0, 0);
        chip.addView(valueView, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(28));
        lp.setMargins(0, 0, dp(4), 0);
        chip.setLayoutParams(lp);
        return chip;
    }

    private String formatHeaderCountdown(long millis) {
        long totalSec = Math.max(0L, millis / 1000L);
        long min = totalSec / 60L;
        long sec = totalSec % 60L;
        return String.format(java.util.Locale.US, "%02d:%02d", min, sec);
    }

    // Bottom navigation is 100% native code: no bitmap/image asset is used.
    // The center Home control floats above the panel and is deliberately not clipped.
    private void addBottomBar() {
        FrameLayout navRoot = new FrameLayout(this);
        navRoot.setClipChildren(false);
        navRoot.setClipToPadding(false);

        View panelView = new View(this);
        GradientDrawable panel = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.argb(210, 30, 19, 13), Color.argb(226, 2, 10, 24)});
        panel.setStroke(1, Color.argb(165, 165, 119, 38));
        panel.setCornerRadii(new float[]{dp(24),dp(24),dp(24),dp(24),0,0,0,0});
        panelView.setBackground(panel);
        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(-1, dp(31), Gravity.BOTTOM);
        navRoot.addView(panelView, panelLp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        row.setPadding(dp(18), 0, dp(18), 0);
        row.setClipChildren(false);
        row.setClipToPadding(false);

        LinearLayout notifications = bottomItem(NavIconView.BELL, "اعلان‌ها", false, true);
        notifications.setOnClickListener(v -> showSection("اعلان‌ها"));
        LinearLayout.LayoutParams sideLp = new LinearLayout.LayoutParams(0, dp(31), 1f);
        row.addView(notifications, sideLp);

        LinearLayout home = bottomItem(NavIconView.HOME, "خانه", true, false);
        home.setOnClickListener(v -> showHome());
        LinearLayout.LayoutParams homeLp = new LinearLayout.LayoutParams(0, dp(47), 1f);
        row.addView(home, homeLp);

        LinearLayout settings = bottomItem(NavIconView.GEAR, "تنظیمات", false, false);
        settings.setOnClickListener(v -> showSection("تنظیمات"));
        row.addView(settings, new LinearLayout.LayoutParams(0, dp(31), 1f));

        FrameLayout.LayoutParams rowLp = new FrameLayout.LayoutParams(-1, dp(47), Gravity.BOTTOM);
        navRoot.addView(row, rowLp);

        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-1, dp(47));
        np.gravity = Gravity.BOTTOM;
        root.addView(navRoot, np);
    }

    private LinearLayout bottomItem(int iconType, String label, boolean selected, boolean notificationDot) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        box.setClickable(true);
        box.setClipChildren(false);
        box.setClipToPadding(false);

        FrameLayout iconHolder = new FrameLayout(this);
        iconHolder.setClipChildren(false);
        int holder = selected ? dp(42) : dp(25);
        if (selected) {
            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            circle.setColor(Color.rgb(12, 13, 19));
            circle.setStroke(dp(2), Color.rgb(244, 169, 35));
            iconHolder.setBackground(circle);
        }
        NavIconView icon = new NavIconView(iconType, selected);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(selected ? dp(27) : dp(20), selected ? dp(27) : dp(20), Gravity.CENTER);
        iconHolder.addView(icon, ip);

        if (notificationDot && hasUnreadNotifications()) {
            View dot = new View(this);
            GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(Color.rgb(255,55,45));
            d.setStroke(dp(1), Color.rgb(255,180,120)); dot.setBackground(d);
            FrameLayout.LayoutParams dpv = new FrameLayout.LayoutParams(dp(7), dp(7), Gravity.TOP | Gravity.RIGHT);
            dpv.setMargins(0, 0, 0, 0); iconHolder.addView(dot, dpv);
        }
        box.addView(iconHolder, new LinearLayout.LayoutParams(holder, holder));

        return box;
    }

    private boolean hasUnreadNotifications() {
        return prefs.getBoolean("has_unread_notifications", false);
    }

    private class NavIconView extends View {
        static final int BELL=1, HOME=2, GEAR=3;
        private final int type; private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        NavIconView(int type, boolean selected) {
            super(MainActivity.this); this.type=type;
            paint.setColor(selected ? Color.rgb(255,184,35) : Color.rgb(255,222,142));
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2));
            paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
            if(type==HOME){
                paint.setColor(Color.rgb(255,184,35)); paint.setStyle(Paint.Style.FILL);
                Path homePath=new Path();
                homePath.moveTo(w*.10f,h*.48f); homePath.lineTo(cx,h*.10f); homePath.lineTo(w*.90f,h*.48f);
                homePath.lineTo(w*.78f,h*.48f); homePath.lineTo(w*.78f,h*.88f); homePath.lineTo(w*.22f,h*.88f);
                homePath.lineTo(w*.22f,h*.48f); homePath.close(); c.drawPath(homePath,paint);
                paint.setColor(Color.rgb(12,13,19)); c.drawRoundRect(new RectF(w*.44f,h*.63f,w*.59f,h*.88f),dp(1),dp(1),paint);
            } else if(type==BELL){
                paint.setStyle(Paint.Style.STROKE);
                Path p=new Path(); p.moveTo(w*.25f,h*.68f); p.quadTo(w*.32f,h*.60f,w*.32f,h*.42f); p.quadTo(w*.32f,h*.20f,cx,h*.20f); p.quadTo(w*.68f,h*.20f,w*.68f,h*.42f); p.quadTo(w*.68f,h*.60f,w*.75f,h*.68f); p.lineTo(w*.25f,h*.68f); c.drawPath(p,paint);
                c.drawLine(w*.22f,h*.72f,w*.78f,h*.72f,paint); c.drawArc(new RectF(w*.42f,h*.70f,w*.58f,h*.86f),0,180,false,paint);
            } else {
                paint.setStyle(Paint.Style.STROKE); c.drawCircle(cx,cy,Math.min(w,h)*.25f,paint); c.drawCircle(cx,cy,Math.min(w,h)*.09f,paint);
                for(int i=0;i<8;i++){ double a=i*Math.PI/4; float x1=cx+(float)Math.cos(a)*w*.31f, y1=cy+(float)Math.sin(a)*h*.31f; float x2=cx+(float)Math.cos(a)*w*.42f, y2=cy+(float)Math.sin(a)*h*.42f; c.drawLine(x1,y1,x2,y2,paint); }
            }
        }
    }

    private TextView statCapsule(String icon, int value) {
        TextView v = headerText(icon + " " + value, 12, Gravity.CENTER);
        v.setSingleLine(true); v.setPadding(dp(5),0,dp(5),0); v.setMinWidth(dp(44));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.argb(185, 5, 10, 20));
        bg.setStroke(1, Color.argb(150, 150, 109, 39)); bg.setCornerRadius(dp(13)); v.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(24)); p.setMargins(dp(1),0,dp(1),0); v.setLayoutParams(p);
        return v;
    }

    private TextView headerText(String text, float size, int gravity) {
        TextView v = new TextView(this); v.setText(text); v.setTextColor(Color.WHITE); v.setTextSize(size); v.setGravity(gravity | Gravity.CENTER_VERTICAL); v.setMaxLines(2); return v;
    }

    // Reward rules reserved for mission completion: low 10XP/5 coins, medium 20XP/10 coins, high 30XP/15 coins.
    // Combo: consecutive successful missions; 30-minute default window. Fail/timeout resets to zero.
    // Combo 3+ => x1.5 rewards, Combo 7+ => x2 rewards.
    private void awardMission(int baseXp, int baseCoins, boolean success) {
        if (!success) { prefs.edit().putInt("combo",0).putLong("combo_deadline",0).apply(); return; }
        int combo = prefs.getInt("combo",0) + 1;
        float mult = combo >= 7 ? 2f : (combo >= 3 ? 1.5f : 1f);
        int level = prefs.getInt("level",1);
        int xp = prefs.getInt("xp",0) + Math.round(baseXp * mult);
        int coins = prefs.getInt("coins",0) + Math.round(baseCoins * mult);
        while (xp >= level * 100) { xp -= level * 100; level++; }
        prefs.edit().putInt("level",level).putInt("xp",xp).putInt("coins",coins).putInt("combo",combo)
            .putLong("combo_deadline", System.currentTimeMillis() + 30L*60L*1000L).apply();
    }

    // Persist a mission result exactly once. Reward deltas are stored per node so a later
    // reset can subtract only this mission's XP/coins without disturbing other completed missions.
    private boolean finalizeMissionResult(int node, boolean success) {
        if (prefs.getInt("active_progress_node", 0) != node) return false;
        if (prefs.getBoolean("progress_node_result_locked_" + node, false)) return false;

        SharedPreferences.Editor lock = prefs.edit();
        lock.putBoolean("progress_node_result_locked_" + node, true).apply();

        int awardedXp = 0;
        int awardedCoins = 0;
        int comboBefore = prefs.getInt("combo", 0);
        long comboDeadlineBefore = prefs.getLong("combo_deadline", 0);

        if (success) {
            String importance = prefs.getString("progress_node_importance_" + node, "متوسط");
            int baseXp = "زیاد".equals(importance) ? 30 : ("کم".equals(importance) ? 10 : 20);
            int baseCoins = "زیاد".equals(importance) ? 15 : ("کم".equals(importance) ? 5 : 10);
            int nextCombo = comboBefore + 1;
            float mult = nextCombo >= 7 ? 2f : (nextCombo >= 3 ? 1.5f : 1f);
            awardedXp = Math.round(baseXp * mult);
            awardedCoins = Math.round(baseCoins * mult);
            awardMission(baseXp, baseCoins, true);
        } else {
            awardMission(0, 0, false);
        }

        prefs.edit()
            .putBoolean("progress_node_done_" + node, success)
            .putBoolean("progress_node_failed_" + node, !success)
            .putString("progress_node_result_" + node, success ? "done" : "failed")
            .putLong("progress_node_result_time_" + node, System.currentTimeMillis())
            .putInt("progress_node_awarded_xp_" + node, awardedXp)
            .putInt("progress_node_awarded_coins_" + node, awardedCoins)
            .putInt("progress_node_combo_before_" + node, comboBefore)
            .putLong("progress_node_combo_deadline_before_" + node, comboDeadlineBefore)
            .remove("active_progress_node")
            .remove("active_progress_end")
            .remove("active_progress_remaining")
            .remove("active_progress_paused")
            .remove("active_progress_awaiting_result")
            .commit();
        return true;
    }


    // Convert the current level/xp pair to cumulative XP so a completed node can return
    // exactly the reward it granted, even when that reward crossed a level boundary.
    private int cumulativeXp(int level, int xp) {
        int completedLevels = Math.max(0, level - 1);
        return 50 * completedLevels * (completedLevels + 1) + Math.max(0, xp);
    }

    private int[] levelAndXpFromCumulative(int totalXp) {
        int remaining = Math.max(0, totalXp);
        int level = 1;
        while (remaining >= level * 100) {
            remaining -= level * 100;
            level++;
        }
        return new int[]{level, remaining};
    }

    // Rebuild only the live combo state from the remaining recorded results.
    // Reward deltas already granted to other nodes are intentionally left untouched.
    private void recalculateComboFromResults() {
        java.util.ArrayList<Integer> nodes = new java.util.ArrayList<>();
        for (int i = 1; i <= 21; i++) {
            if (prefs.getLong("progress_node_result_time_" + i, 0) > 0) nodes.add(i);
        }
        java.util.Collections.sort(nodes, (a, b) -> Long.compare(
            prefs.getLong("progress_node_result_time_" + a, 0),
            prefs.getLong("progress_node_result_time_" + b, 0)));

        int combo = 0;
        long deadline = 0;
        for (int node : nodes) {
            long time = prefs.getLong("progress_node_result_time_" + node, 0);
            boolean done = prefs.getBoolean("progress_node_done_" + node, false);
            if (!done) {
                combo = 0;
                deadline = 0;
                continue;
            }
            if (combo > 0 && deadline > 0 && time <= deadline) combo++;
            else combo = 1;
            deadline = time + 30L * 60L * 1000L;
        }
        if (deadline > 0 && System.currentTimeMillis() > deadline) {
            combo = 0;
            deadline = 0;
        }
        prefs.edit().putInt("combo", combo).putLong("combo_deadline", deadline).apply();
    }

    // Reset a Done/Fail node back to its normal state while preserving its title/settings.
    // Exact XP/coin rewards granted by that node are returned.
    private boolean resetProgressNodeResult(int node) {
        boolean done = prefs.getBoolean("progress_node_done_" + node, false);
        boolean failed = prefs.getBoolean("progress_node_failed_" + node, false);
        if (!done && !failed) return false;

        int awardedXp = prefs.getInt("progress_node_awarded_xp_" + node, 0);
        int awardedCoins = prefs.getInt("progress_node_awarded_coins_" + node, 0);

        int currentLevel = prefs.getInt("level", 1);
        int currentXp = prefs.getInt("xp", 0);
        int currentTotalXp = cumulativeXp(currentLevel, currentXp);
        int[] levelXp = levelAndXpFromCumulative(Math.max(0, currentTotalXp - awardedXp));
        int newCoins = Math.max(0, prefs.getInt("coins", 0) - awardedCoins);

        prefs.edit()
            .putInt("level", levelXp[0])
            .putInt("xp", levelXp[1])
            .putInt("coins", newCoins)
            .remove("progress_node_done_" + node)
            .remove("progress_node_failed_" + node)
            .remove("progress_node_result_" + node)
            .remove("progress_node_result_time_" + node)
            .remove("progress_node_awarded_xp_" + node)
            .remove("progress_node_awarded_coins_" + node)
            .remove("progress_node_combo_before_" + node)
            .remove("progress_node_combo_deadline_before_" + node)
            .remove("progress_node_result_locked_" + node)
            .commit();

        recalculateComboFromResults();
        return true;
    }

    private void refreshComboTimeout() {
        long deadline = prefs.getLong("combo_deadline",0);
        if (prefs.getInt("combo",0) > 0 && deadline > 0 && System.currentTimeMillis() > deadline)
            prefs.edit().putInt("combo",0).putLong("combo_deadline",0).apply();
    }

    private void addImageHotspot(ImageView image, String title, float l, float t, float r, float b) {
        View v = new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setClickable(true);
        v.setOnClickListener(view -> {
            GradientDrawable glow = new GradientDrawable();
            glow.setColor(Color.argb(42, 255, 193, 7));
            glow.setStroke(dp(2), Color.argb(180, 255, 193, 7));
            glow.setCornerRadius(dp(28));
            view.setBackground(glow);
            new Handler().postDelayed(() -> {
                view.setBackgroundColor(Color.TRANSPARENT);
                showSection(title);
            }, 110);
        });
        image.post(() -> {
            if (image.getDrawable() == null) return;
            float dw = image.getDrawable().getIntrinsicWidth();
            float dh = image.getDrawable().getIntrinsicHeight();
            android.graphics.Matrix m = image.getImageMatrix();
            float[] pts = new float[]{l * dw, t * dh, r * dw, b * dh};
            m.mapPoints(pts);
            int[] imageLoc = new int[2];
            int[] rootLoc = new int[2];
            image.getLocationOnScreen(imageLoc);
            root.getLocationOnScreen(rootLoc);
            int left = Math.round(pts[0]) + imageLoc[0] - rootLoc[0];
            int top = Math.round(pts[1]) + imageLoc[1] - rootLoc[1] + dp(1);
            int right = Math.round(pts[2]) + imageLoc[0] - rootLoc[0];
            int bottom = Math.round(pts[3]) + imageLoc[1] - rootLoc[1] + dp(1);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    Math.max(1, right - left), Math.max(1, bottom - top));
            lp.leftMargin = left;
            lp.topMargin = top;
            v.setLayoutParams(lp);
        });
        root.addView(v, new FrameLayout.LayoutParams(1, 1));
    }

    private void addHotspot(String title, float l, float t, float r, float b) {
        View v = new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setClickable(true);
        v.setOnClickListener(view -> {
            GradientDrawable glow = new GradientDrawable();
            glow.setColor(Color.argb(42, 255, 193, 7));
            glow.setStroke(dp(2), Color.argb(180, 255, 193, 7));
            glow.setCornerRadius(dp(28));
            view.setBackground(glow);
            new Handler().postDelayed(() -> {
                view.setBackgroundColor(Color.TRANSPARENT);
                showSection(title);
            }, 110);
        });
        root.post(() -> {
            int w = root.getWidth(), h = root.getHeight();
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                Math.round((r-l)*w), Math.round((b-t)*h));
            p.leftMargin = Math.round(l*w);
            // Match the final Progress Path touch calibration: only ~1dp downward.
            p.topMargin = Math.max(0, Math.round(t*h) + dp(1));
            v.setLayoutParams(p);
        });
        root.addView(v, new FrameLayout.LayoutParams(1,1));
    }

    private void showSection(String title) {
        if ("مسیر پیشرفت".equals(title)) { showProgressPath(); return; }
        if ("تنظیمات".equals(title)) { showSettings(); return; }
        onHome = false;
        onProgressPath = false;
        onProgressStage = false;
        refreshComboTimeout();

        // Every Journey page uses the same permanent shell: safe-area + Header + Bottom Bar.
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 15, 38));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(0, top, 0, bottom);
                return insets;
            });
        }

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        heading.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        FrameLayout.LayoutParams contentLp = new FrameLayout.LayoutParams(-1, -1);
        contentLp.topMargin = dp(44);
        contentLp.bottomMargin = dp(31);
        root.addView(heading, contentLp);

        addTopBar();
        addBottomBar();
        setContentView(root);
    }


    private void showSettings() {
        if (missionTick != null) missionHandler.removeCallbacks(missionTick);
        onHome = false;
        onProgressPath = false;
        onProgressStage = false;
        refreshComboTimeout();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(242, 245, 252));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(18), dp(20), dp(18), dp(18));

        TextView title = new TextView(this);
        title.setText("تنظیمات");
        title.setTextColor(Color.rgb(35, 46, 76));
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        content.addView(title, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView backupTitle = new TextView(this);
        backupTitle.setText("داده‌ها و بکاپ");
        backupTitle.setTextColor(Color.rgb(56, 67, 97));
        backupTitle.setTextSize(16);
        backupTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        backupTitle.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        backupTitle.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams backupTitleLp = new LinearLayout.LayoutParams(-1, dp(42));
        backupTitleLp.setMargins(dp(4), dp(18), dp(4), dp(8));
        content.addView(backupTitle, backupTitleLp);

        LinearLayout backupRow = new LinearLayout(this);
        backupRow.setOrientation(LinearLayout.HORIZONTAL);
        backupRow.setGravity(Gravity.CENTER);
        backupRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        LinearLayout exportCard = createBackupAction("⇧", "Export");
        exportCard.setOnClickListener(v -> exportJourneyData());
        LinearLayout importCard = createBackupAction("⇩", "Import");
        importCard.setOnClickListener(v -> importJourneyData());

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(0, dp(118), 1f);
        cardLp.setMargins(dp(6), 0, dp(6), 0);
        backupRow.addView(exportCard, cardLp);
        backupRow.addView(importCard, cardLp);
        content.addView(backupRow, new LinearLayout.LayoutParams(-1, -2));

        TextView help = new TextView(this);
        help.setText("Export از تمام اطلاعات Journey بکاپ می‌گیرد. با Import می‌توانید اطلاعات را در نسخه‌های بعدی یا بعد از نصب مجدد برگردانید.");
        help.setTextColor(Color.rgb(105, 111, 133));
        help.setTextSize(12);
        help.setGravity(Gravity.RIGHT);
        help.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        help.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams helpLp = new LinearLayout.LayoutParams(-1, -2);
        helpLp.setMargins(dp(6), dp(12), dp(6), 0);
        content.addView(help, helpLp);

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -1);
        cp.topMargin = dp(44);
        cp.bottomMargin = dp(31);
        root.addView(content, cp);

        addTopBar();
        addBottomBar();
        setContentView(root);
    }

    private LinearLayout createBackupAction(String iconText, String labelText) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(8), dp(10), dp(8), dp(8));
        card.setClickable(true);
        card.setFocusable(true);

        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.rgb(255,255,255), Color.rgb(246,247,255)});
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1), Color.rgb(204, 207, 229));
        card.setBackground(bg);
        card.setElevation(dp(2));

        TextView icon = new TextView(this);
        icon.setText(iconText);
        icon.setTextColor(Color.rgb(91, 91, 215));
        icon.setTextSize(38);
        icon.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(58)));

        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(Color.rgb(47, 54, 86));
        label.setTextSize(13);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setGravity(Gravity.CENTER);
        card.addView(label, new LinearLayout.LayoutParams(-1, dp(28)));
        return card;
    }

    private void exportJourneyData() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "Journey-backup.json");
        startActivityForResult(intent, REQ_EXPORT_BACKUP);
    }

    private void importJourneyData() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_IMPORT_BACKUP);
    }

    private JSONObject buildJourneyBackup() throws Exception {
        JSONObject rootJson = new JSONObject();
        rootJson.put("format", "JourneyBackup");
        rootJson.put("version", 1);
        rootJson.put("created_at", System.currentTimeMillis());

        JSONObject allPrefs = new JSONObject();
        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            Object value = entry.getValue();
            JSONObject item = new JSONObject();

            if (value instanceof Integer) {
                item.put("type", "int");
                item.put("value", value);
            } else if (value instanceof Long) {
                item.put("type", "long");
                item.put("value", value);
            } else if (value instanceof Float) {
                item.put("type", "float");
                item.put("value", ((Float) value).doubleValue());
            } else if (value instanceof Boolean) {
                item.put("type", "boolean");
                item.put("value", value);
            } else if (value instanceof Set) {
                item.put("type", "string_set");
                JSONArray array = new JSONArray();
                for (Object itemValue : (Set<?>) value) {
                    if (itemValue != null) array.put(String.valueOf(itemValue));
                }
                item.put("value", array);
            } else {
                item.put("type", "string");
                item.put("value", value == null ? "" : String.valueOf(value));
            }
            allPrefs.put(entry.getKey(), item);
        }
        rootJson.put("preferences", allPrefs);
        return rootJson;
    }

    private void writeJourneyBackup(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
            if (out == null) throw new Exception("Unable to open backup file");
            byte[] bytes = buildJourneyBackup().toString(2).getBytes(StandardCharsets.UTF_8);
            out.write(bytes);
            out.flush();
            Toast.makeText(this, "بکاپ Journey ذخیره شد", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "خطا در Export اطلاعات", Toast.LENGTH_LONG).show();
        }
    }

    private void readJourneyBackup(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            if (in == null) throw new Exception("Unable to open backup file");

            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) text.append(line);

            JSONObject rootJson = new JSONObject(text.toString());
            if (!"JourneyBackup".equals(rootJson.optString("format"))) {
                throw new Exception("Not a Journey backup");
            }
            JSONObject allPrefs = rootJson.getJSONObject("preferences");
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();

            Iterator<String> keys = allPrefs.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                JSONObject item = allPrefs.getJSONObject(key);
                String type = item.optString("type", "string");

                if ("int".equals(type)) {
                    editor.putInt(key, item.getInt("value"));
                } else if ("long".equals(type)) {
                    editor.putLong(key, item.getLong("value"));
                } else if ("float".equals(type)) {
                    editor.putFloat(key, (float) item.getDouble("value"));
                } else if ("boolean".equals(type)) {
                    editor.putBoolean(key, item.getBoolean("value"));
                } else if ("string_set".equals(type)) {
                    JSONArray array = item.getJSONArray("value");
                    Set<String> values = new HashSet<>();
                    for (int i = 0; i < array.length(); i++) values.add(array.getString(i));
                    editor.putStringSet(key, values);
                } else {
                    editor.putString(key, item.optString("value", ""));
                }
            }

            if (!editor.commit()) throw new Exception("Unable to save imported data");
            Toast.makeText(this, "اطلاعات Journey با موفقیت Import شد", Toast.LENGTH_SHORT).show();
            showSettings();
        } catch (Exception e) {
            Toast.makeText(this, "فایل بکاپ معتبر نیست یا Import انجام نشد", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT_BACKUP) {
            writeJourneyBackup(uri);
        } else if (requestCode == REQ_IMPORT_BACKUP) {
            readJourneyBackup(uri);
        }
    }


    private void showProgressPath() {
        if (missionTick != null) missionHandler.removeCallbacks(missionTick);
        onHome = false;
        onProgressPath = true;
        onProgressStage = false;
        refreshComboTimeout();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(242, 246, 253));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
        }

        // Seven stacked 1:2 progress artworks: page 7 at the top, followed by pages 6 through 1.
        // The ScrollView stays underneath the permanent Header and Bottom Bar.
        ScrollView scroll = new ScrollView(this);
        currentProgressScroll = scroll;
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.VERTICAL);
        pages.setBackgroundColor(Color.rgb(242, 246, 253));

        int screenW = getResources().getDisplayMetrics().widthPixels;

        // Page 7 (top): connection-to-the-universe artwork, nodes 19-21 from bottom to top.
        FrameLayout page7 = createProgressPage(R.drawable.progress_path_7, screenW);
        int page7H = page7.getLayoutParams().height;
        addProgressTitleNode(page7, screenW, page7H, 19, 0.338f, 0.757f);
        addProgressTitleNode(page7, screenW, page7H, 20, 0.267f, 0.487f);
        addProgressTitleNode(page7, screenW, page7H, 21, 0.390f, 0.237f);
        pages.addView(page7);

        // Page 6 (top): analysis / information artwork, nodes 16-18 from bottom to top.
        FrameLayout page6 = createProgressPage(R.drawable.progress_path_6, screenW);
        int page6H = page6.getLayoutParams().height;
        addProgressTitleNode(page6, screenW, page6H, 16, 0.683f, 0.751f);
        addProgressTitleNode(page6, screenW, page6H, 17, 0.775f, 0.479f);
        addProgressTitleNode(page6, screenW, page6H, 18, 0.680f, 0.219f);
        pages.addView(page6);

        // Page 5: communication / calls / messaging artwork, nodes 13-15 from bottom to top.
        FrameLayout page5 = createProgressPage(R.drawable.progress_path_5, screenW);
        int page5H = page5.getLayoutParams().height;
        addProgressTitleNode(page5, screenW, page5H, 13, 0.308f, 0.759f);
        addProgressTitleNode(page5, screenW, page5H, 14, 0.236f, 0.489f);
        addProgressTitleNode(page5, screenW, page5H, 15, 0.378f, 0.236f);
        pages.addView(page5);

        // Page 4: solo desk/laptop work artwork, nodes 10-12 from bottom to top.
        FrameLayout page4 = createProgressPage(R.drawable.progress_path_4, screenW);
        int page4H = page4.getLayoutParams().height;
        addProgressTitleNode(page4, screenW, page4H, 10, 0.683f, 0.751f);
        addProgressTitleNode(page4, screenW, page4H, 11, 0.775f, 0.479f);
        addProgressTitleNode(page4, screenW, page4H, 12, 0.680f, 0.219f);
        pages.addView(page4);

        // Page 3: team celebration artwork, nodes 7-9 from bottom to top.
        FrameLayout topPage = createProgressPage(R.drawable.progress_path_3, screenW);
        int topH = topPage.getLayoutParams().height;
        addProgressTitleNode(topPage, screenW, topH, 7, 0.308f, 0.759f);
        addProgressTitleNode(topPage, screenW, topH, 8, 0.233f, 0.489f);
        addProgressTitleNode(topPage, screenW, topH, 9, 0.378f, 0.236f);
        pages.addView(topPage);

        // Page 2 (middle): focus / meditation themed artwork, nodes 4-6 from bottom to top.
        FrameLayout upperPage = createProgressPage(R.drawable.progress_path_2, screenW);
        int upperH = upperPage.getLayoutParams().height;
        addProgressTitleNode(upperPage, screenW, upperH, 4, 0.683f, 0.751f);
        addProgressTitleNode(upperPage, screenW, upperH, 5, 0.769f, 0.479f);
        addProgressTitleNode(upperPage, screenW, upperH, 6, 0.678f, 0.216f);
        pages.addView(upperPage);

        // Page 1 (bottom): current morning/business artwork, nodes 1-3 from bottom to top.
        FrameLayout lowerPage = createProgressPage(R.drawable.progress_path, screenW);
        int lowerH = lowerPage.getLayoutParams().height;
        addProgressTitleNode(lowerPage, screenW, lowerH, 1, 261f / 768f, 1162f / 1536f);
        addProgressTitleNode(lowerPage, screenW, lowerH, 2, 206f / 768f, 747f / 1536f);
        addProgressTitleNode(lowerPage, screenW, lowerH, 3, 299f / 768f, 363f / 1536f);
        pages.addView(lowerPage);

        scroll.addView(pages, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        // Bars are always the highest layer.
        addTopBar();
        addBottomBar();
        setContentView(root);

        // First entry starts on the first/lower image. Returning from a stage restores the exact previous path position.
        scroll.post(() -> {
            if (savedProgressScrollY >= 0) scroll.scrollTo(0, savedProgressScrollY);
            else scroll.fullScroll(View.FOCUS_DOWN);
        });
    }

    private FrameLayout createProgressPage(int drawableRes, int screenW) {
        android.graphics.drawable.Drawable drawable = getDrawable(drawableRes);
        int pageH = Math.round(screenW * (drawable.getIntrinsicHeight() / (float) drawable.getIntrinsicWidth()));

        FrameLayout page = new FrameLayout(this);
        page.setClipChildren(false);
        page.setClipToPadding(false);
        page.setLayoutParams(new LinearLayout.LayoutParams(-1, pageH));

        ImageView image = new ImageView(this);
        image.setImageResource(drawableRes);
        image.setScaleType(ImageView.ScaleType.FIT_XY);
        image.setAdjustViewBounds(false);
        page.addView(image, new FrameLayout.LayoutParams(-1, -1));
        return page;
    }

    private void addProgressTitleNode(FrameLayout page, int pageW, int pageH, int node, float normX, float normY) {
        boolean done = prefs.getBoolean("progress_node_done_" + node, false);
        boolean failed = prefs.getBoolean("progress_node_failed_" + node, false);
        boolean active = prefs.getInt("active_progress_node", 0) == node;

        int visualSize = Math.round(pageW * (248f / 768f));
        float cx = normX * pageW;
        float cy = normY * pageH;

        // State color overlays the printed circle without modifying the artwork asset itself.
        View stateOverlay = new View(this);
        GradientDrawable stateBg = new GradientDrawable();
        stateBg.setShape(GradientDrawable.OVAL);
        if (done) {
            stateBg.setColor(Color.argb(118, 55, 190, 104));
            stateBg.setStroke(dp(3), Color.rgb(38, 166, 91));
        } else if (failed) {
            stateBg.setColor(Color.argb(112, 232, 73, 86));
            stateBg.setStroke(dp(3), Color.rgb(211, 55, 68));
        } else if (active) {
            stateBg.setColor(Color.argb(82, 92, 135, 255));
            stateBg.setStroke(dp(3), Color.rgb(80, 118, 235));
        } else {
            stateBg.setColor(Color.TRANSPARENT);
        }
        stateOverlay.setBackground(stateBg);
        FrameLayout.LayoutParams stateLp = new FrameLayout.LayoutParams(visualSize, visualSize);
        stateLp.leftMargin = Math.round(cx - visualSize / 2f);
        stateLp.topMargin = Math.round(cy - visualSize / 2f);
        page.addView(stateOverlay, stateLp);

        TextView label = new TextView(this);
        label.setText(prefs.getString("progress_node_title_" + node, ""));
        label.setTextColor(done ? Color.rgb(24, 101, 58) : (failed ? Color.rgb(142, 42, 53) : Color.rgb(37, 52, 78)));
        label.setTextSize(13);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(3);
        label.setPadding(dp(8), dp(4), dp(8), dp(4));
        label.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if (done || failed) label.setPaintFlags(label.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

        FrameLayout.LayoutParams labelLp = new FrameLayout.LayoutParams(visualSize, visualSize);
        labelLp.leftMargin = Math.round(cx - visualSize / 2f);
        labelLp.topMargin = Math.round(cy - visualSize / 2f);
        page.addView(label, labelLp);

        View touch = new View(this);
        touch.setClickable(true);
        touch.setFocusable(true);
        touch.setBackgroundColor(Color.TRANSPARENT);

        int touchSize = Math.round(visualSize * 1.02f);
        // Latest calibrated touch offset shared by all seven path images.
        float touchCy = cy + dp(1);
        FrameLayout.LayoutParams touchLp = new FrameLayout.LayoutParams(touchSize, touchSize);
        touchLp.leftMargin = Math.round(cx - touchSize / 2f);
        touchLp.topMargin = Math.round(touchCy - touchSize / 2f);
        page.addView(touch, touchLp);

        // Result nodes use an intentional single/double-tap split:
        // one tap opens the stage page, while two taps within 300 ms reset the recorded result.
        // The short single-tap delay exists only for Done/Fail nodes so ordinary/active nodes stay instant.
        final Handler resultTapHandler = new Handler();
        final Runnable[] pendingResultSingleTap = {null};
        final long[] lastResultTapAt = {0L};
        final long RESULT_DOUBLE_TAP_MS = 300L;

        touch.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                GradientDrawable pressed = new GradientDrawable();
                pressed.setShape(GradientDrawable.OVAL);
                pressed.setColor(Color.argb(56, 86, 145, 255));
                pressed.setStroke(dp(3), Color.argb(235, 91, 150, 255));
                v.setBackground(pressed);
                v.animate().scaleX(.93f).scaleY(.93f).setDuration(70).start();
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                final long releasedAt = android.os.SystemClock.elapsedRealtime();
                v.animate().scaleX(1f).scaleY(1f).setDuration(70).withEndAction(() -> {
                    new Handler().postDelayed(() -> {
                        v.setBackgroundColor(Color.TRANSPARENT);
                        if (currentProgressScroll != null) savedProgressScrollY = currentProgressScroll.getScrollY();

                        boolean isDone = prefs.getBoolean("progress_node_done_" + node, false);
                        boolean isFailed = prefs.getBoolean("progress_node_failed_" + node, false);
                        if (isDone || isFailed) {
                            boolean isSecondTap = pendingResultSingleTap[0] != null
                                && lastResultTapAt[0] > 0L
                                && releasedAt - lastResultTapAt[0] <= RESULT_DOUBLE_TAP_MS;

                            if (isSecondTap) {
                                resultTapHandler.removeCallbacks(pendingResultSingleTap[0]);
                                pendingResultSingleTap[0] = null;
                                lastResultTapAt[0] = 0L;
                                if (resetProgressNodeResult(node)) {
                                    Toast.makeText(this, "مرحله ریست شد و امتیاز آن برگشت", Toast.LENGTH_SHORT).show();
                                    showProgressPath();
                                }
                            } else {
                                lastResultTapAt[0] = releasedAt;
                                pendingResultSingleTap[0] = () -> {
                                    pendingResultSingleTap[0] = null;
                                    lastResultTapAt[0] = 0L;
                                    // Single tap is review/edit only; Start remains blocked until a double-tap reset.
                                    showProgressStageEditor(node);
                                };
                                resultTapHandler.postDelayed(pendingResultSingleTap[0], RESULT_DOUBLE_TAP_MS);
                            }
                            return;
                        }

                        int activeNode = prefs.getInt("active_progress_node", 0);
                        if (activeNode == node) showRunningStage(node);
                        else showProgressStageEditor(node);
                    }, 90);
                }).start();
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                v.setBackgroundColor(Color.TRANSPARENT);
                v.animate().scaleX(1f).scaleY(1f).setDuration(60).start();
                return true;
            }
            return true;
        });
    }

    private void showProgressStageEditor(int node) {
        onHome = false;
        onProgressPath = false;
        onProgressStage = true;
        refreshComboTimeout();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(244, 248, 253));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
        }

        // Visual template shared by every one of the 21 progress stages.
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.progress_stage_editor);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setAdjustViewBounds(false);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        // Title: type directly into the empty title box. It is persisted live and is also shown in the path circle.
        EditText titleInput = new EditText(this);
        titleInput.setText(prefs.getString("progress_node_title_" + node, ""));
        titleInput.setTextColor(Color.rgb(36, 48, 95));
        titleInput.setHintTextColor(Color.rgb(145, 155, 183));
        titleInput.setTextSize(16);
        titleInput.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        titleInput.setSingleLine(true);
        titleInput.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        titleInput.setBackgroundColor(Color.TRANSPARENT);
        titleInput.setPadding(dp(14), 0, dp(18), 0);
        root.addView(titleInput, new FrameLayout.LayoutParams(1, 1));
        titleInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                prefs.edit().putString("progress_node_title_" + node, s == null ? "" : s.toString().trim()).apply();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Dynamic values remain empty until the user makes a selection.
        TextView timeValue = stageValueText();
        TextView importanceValue = stageValueText();
        TextView repeatValue = stageValueText();
        TextView reminderValue = stageValueText();
        updateStageValueText(timeValue, prefs.getInt("progress_node_time_" + node, 0), "time");
        importanceValue.setText(prefs.getString("progress_node_importance_" + node, ""));
        repeatValue.setText(prefs.getString("progress_node_repeat_" + node, ""));
        String savedReminder = prefs.getString("progress_node_reminder_" + node, "");
        updateReminderCheck(reminderValue, savedReminder);
        root.addView(timeValue, new FrameLayout.LayoutParams(1, 1));
        root.addView(importanceValue, new FrameLayout.LayoutParams(1, 1));
        root.addView(repeatValue, new FrameLayout.LayoutParams(1, 1));
        root.addView(reminderValue, new FrameLayout.LayoutParams(1, 1));

        View timeTouch = transparentTouch();
        View importanceTouch = transparentTouch();
        View repeatTouch = transparentTouch();
        View reminderTouch = transparentTouch();
        View startTouch = transparentTouch();
        View backTouch = transparentTouch();
        root.addView(timeTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(importanceTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(repeatTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(reminderTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(startTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(backTouch, new FrameLayout.LayoutParams(1,1));

        timeTouch.setOnClickListener(v -> {
            final String[] labels = {"5 min", "10 min", "20 min", "30 min"};
            final int[] values = {5, 10, 20, 30};
            new AlertDialog.Builder(this)
                .setTitle("زمان")
                .setItems(labels, (dialog, which) -> {
                    prefs.edit().putInt("progress_node_time_" + node, values[which]).apply();
                    updateStageValueText(timeValue, values[which], "time");
                }).show();
        });

        importanceTouch.setOnClickListener(v -> showStringChoice(
            "اهمیت", new String[]{"کم", "متوسط", "زیاد"},
            prefs.getString("progress_node_importance_" + node, ""),
            selected -> {
                prefs.edit().putString("progress_node_importance_" + node, selected).apply();
                importanceValue.setText(selected);
            }
        ));

        repeatTouch.setOnClickListener(v -> showStringChoice(
            "تکرار", new String[]{"بدون تکرار", "روزانه"},
            prefs.getString("progress_node_repeat_" + node, ""),
            selected -> {
                prefs.edit().putString("progress_node_repeat_" + node, selected).apply();
                repeatValue.setText(selected);
            }
        ));

        reminderTouch.setOnClickListener(v -> showStringChoice(
            "یادآور", new String[]{"خاموش", "5 دقیقه قبل", "10 دقیقه قبل", "30 دقیقه قبل"},
            prefs.getString("progress_node_reminder_" + node, ""),
            selected -> {
                prefs.edit().putString("progress_node_reminder_" + node, selected).apply();
                updateReminderCheck(reminderValue, selected);
            }
        ));

        startTouch.setOnClickListener(v -> {
            String title = titleInput.getText() == null ? "" : titleInput.getText().toString().trim();
            int minutes = prefs.getInt("progress_node_time_" + node, 0);
            if (title.isEmpty()) {
                Toast.makeText(this, "ابتدا عنوان مرحله را وارد کنید", Toast.LENGTH_SHORT).show();
                titleInput.requestFocus();
                return;
            }
            if (minutes == 0) {
                Toast.makeText(this, "زمان مرحله را انتخاب کنید", Toast.LENGTH_SHORT).show();
                return;
            }
            if (prefs.getBoolean("progress_node_done_" + node, false) || prefs.getBoolean("progress_node_failed_" + node, false)) {
                Toast.makeText(this, "این مرحله نتیجه ثبت‌شده دارد؛ ابتدا از مسیر آن را ریست کنید", Toast.LENGTH_SHORT).show();
                return;
            }
            int activeNode = prefs.getInt("active_progress_node", 0);
            if (activeNode == node) {
                // Never restart the same active mission from the editor; resume its persisted timer instead.
                showRunningStage(node);
                return;
            }
            if (activeNode != 0) {
                Toast.makeText(this, "یک مأموریت دیگر در حال اجراست", Toast.LENGTH_SHORT).show();
                return;
            }
            long durationMs = minutes * 60L * 1000L;
            long now = System.currentTimeMillis();
            prefs.edit()
                .putString("progress_node_title_" + node, title)
                .putInt("active_progress_node", node)
                .putLong("active_progress_remaining", durationMs)
                .putLong("active_progress_end", now + durationMs)
                .putBoolean("active_progress_paused", false)
                .putBoolean("active_progress_awaiting_result", false)
                .commit();
            showRunningStage(node);
        });

        backTouch.setOnClickListener(v -> showProgressPath());

        // Place all live controls exactly over the matching areas of the 1:2 visual template.
        root.post(() -> {
            int w = root.getWidth() - root.getPaddingLeft() - root.getPaddingRight();
            int h = root.getHeight() - root.getPaddingTop() - root.getPaddingBottom();
            placeNormalized(titleInput, w, h, .455f, .244f, .468f, .068f);

            placeNormalized(timeTouch, w, h, .455f, .333f, .485f, .082f);
            placeNormalized(importanceTouch, w, h, .455f, .420f, .485f, .082f);
            placeNormalized(repeatTouch, w, h, .455f, .505f, .485f, .082f);
            placeNormalized(reminderTouch, w, h, .455f, .590f, .485f, .082f);
            placeNormalized(startTouch, w, h, .075f, .818f, .830f, .082f);
            placeNormalized(backTouch, w, h, .040f, .050f, .120f, .080f);

            // Keep every selected value on the exact same horizontal line as its row label.
            // Full-row height + a tiny downward optical correction prevents values from floating above the label baseline.
            placeNormalized(timeValue, w, h, .515f, .333f, .150f, .082f);
            placeNormalized(importanceValue, w, h, .500f, .420f, .165f, .082f);
            placeNormalized(repeatValue, w, h, .485f, .505f, .180f, .082f);
            placeNormalized(reminderValue, w, h, .500f, .590f, .165f, .082f);
            timeValue.setTranslationY(dp(5));
            importanceValue.setTranslationY(dp(5));
            repeatValue.setTranslationY(dp(8));
            reminderValue.setTranslationY(dp(8));
        });

        // Header and bottom bar are always the highest layer, exactly like the 7 path images.
        addTopBar();
        addBottomBar();
        setContentView(root);
    }

    private interface StageChoiceCallback { void onSelected(String value); }

    private void showStringChoice(String title, String[] options, String current, StageChoiceCallback callback) {
        int checked = -1;
        for (int i = 0; i < options.length; i++) if (options[i].equals(current)) checked = i;
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(options, checked, (dialog, which) -> {
                callback.onSelected(options[which]);
                dialog.dismiss();
            })
            .show();
    }

    private TextView stageValueText() {
        TextView t = new TextView(this);
        t.setTextColor(Color.rgb(104, 113, 145));
        t.setTextSize(10.5f);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        return t;
    }

    private void updateReminderCheck(TextView view, String reminder) {
        boolean enabled = reminder != null && !reminder.isEmpty() && !"خاموش".equals(reminder);
        view.setText(enabled ? "✓" : "");
        view.setTextColor(Color.BLACK);
        view.setTextSize(18);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    }

    private void updateStageValueText(TextView view, int value, String type) {
        if ("time".equals(type) && value > 0) {
            String text = value + " min";
            SpannableString styled = new SpannableString(text);
            int start = String.valueOf(value).length() + 1;
            styled.setSpan(new RelativeSizeSpan(.78f), start, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            styled.setSpan(new ForegroundColorSpan(Color.rgb(132, 140, 165)), start, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            view.setText(styled);
        } else view.setText("");
    }

    private View transparentTouch() {
        View v = new View(this);
        v.setClickable(true);
        v.setFocusable(true);
        v.setBackgroundColor(Color.TRANSPARENT);
        return v;
    }

    private void placeNormalized(View view, int parentW, int parentH, float left, float top, float width, float height) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            Math.round(parentW * width), Math.round(parentH * height));
        lp.leftMargin = Math.round(parentW * left);
        lp.topMargin = Math.round(parentH * top);
        view.setLayoutParams(lp);
    }

    private void showRunningStage(int node) {
        int activeNode = prefs.getInt("active_progress_node", 0);
        if (node < 1 || node > 21 || activeNode != node) {
            showProgressPath();
            return;
        }
        onHome = false;
        onProgressPath = false;
        onProgressStage = true;
        refreshComboTimeout();
        if (missionTick != null) missionHandler.removeCallbacks(missionTick);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(244, 248, 253));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
        }

        // Exact 1:2 mission-running artwork requested by the user; permanent app bars are layered above it.
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.progress_stage_running);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setAdjustViewBounds(false);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        String title = prefs.getString("progress_node_title_" + node, "");
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(Color.rgb(35, 47, 93));
        titleView.setTextSize(23);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER);
        titleView.setSingleLine(true);
        titleView.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.addView(titleView, new FrameLayout.LayoutParams(1,1));

        // Four editable subtasks. Each checkbox is enabled only while its field contains text.
        EditText[] subInputs = new EditText[4];
        TextView[] subChecks = new TextView[4];
        for (int i = 0; i < 4; i++) {
            final int subIndex = i + 1;
            EditText input = new EditText(this);
            input.setText(prefs.getString("progress_node_subtask_" + node + "_" + subIndex, ""));
            input.setTextColor(Color.rgb(58, 67, 100));
            input.setHintTextColor(Color.TRANSPARENT);
            input.setTextSize(13.5f);
            input.setSingleLine(true);
            input.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            input.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            input.setBackgroundColor(Color.TRANSPARENT);
            input.setPadding(dp(8), 0, dp(8), 0);

            TextView check = new TextView(this);
            check.setGravity(Gravity.CENTER);
            check.setTextSize(16);
            check.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            check.setTextColor(Color.rgb(103, 79, 220));
            check.setClickable(true);

            boolean done = prefs.getBoolean("progress_node_subtask_done_" + node + "_" + subIndex, false);
            updateSubtaskCheck(check, input, done);

            input.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence cs, int st, int count, int after) {}
                @Override public void onTextChanged(CharSequence cs, int st, int before, int count) {
                    String value = cs == null ? "" : cs.toString();
                    prefs.edit().putString("progress_node_subtask_" + node + "_" + subIndex, value).apply();
                    if (value.trim().isEmpty()) {
                        prefs.edit().putBoolean("progress_node_subtask_done_" + node + "_" + subIndex, false).apply();
                        updateSubtaskCheck(check, input, false);
                    } else {
                        boolean currentDone = prefs.getBoolean("progress_node_subtask_done_" + node + "_" + subIndex, false);
                        updateSubtaskCheck(check, input, currentDone);
                    }
                }
                @Override public void afterTextChanged(Editable e) {}
            });
            check.setOnClickListener(v -> {
                String value = input.getText() == null ? "" : input.getText().toString().trim();
                if (value.isEmpty()) { input.requestFocus(); return; }
                boolean newDone = !prefs.getBoolean("progress_node_subtask_done_" + node + "_" + subIndex, false);
                prefs.edit().putBoolean("progress_node_subtask_done_" + node + "_" + subIndex, newDone).apply();
                updateSubtaskCheck(check, input, newDone);
            });

            subInputs[i] = input;
            subChecks[i] = check;
            root.addView(input, new FrameLayout.LayoutParams(1,1));
            root.addView(check, new FrameLayout.LayoutParams(1,1));
        }

        TextView timer = new TextView(this);
        timer.setTextColor(Color.rgb(31, 49, 112));
        timer.setTextSize(42);
        timer.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        timer.setGravity(Gravity.CENTER);
        timer.setSingleLine(true);
        root.addView(timer, new FrameLayout.LayoutParams(1,1));

        View failTouch = transparentTouch();
        View pauseTouch = transparentTouch();
        View doneTouch = transparentTouch();
        TextView pauseOverlay = new TextView(this);
        pauseOverlay.setTextColor(Color.WHITE);
        pauseOverlay.setTextSize(40);
        pauseOverlay.setGravity(Gravity.CENTER);
        pauseOverlay.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(failTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(pauseTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(doneTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(pauseOverlay, new FrameLayout.LayoutParams(1,1));
        pauseOverlay.setClickable(false);

        root.post(() -> {
            int w = root.getWidth() - root.getPaddingLeft() - root.getPaddingRight();
            int h = root.getHeight() - root.getPaddingTop() - root.getPaddingBottom();

            // Title appears by itself above the subtask list.
            placeNormalized(titleView, w, h, .455f, .175f, .480f, .055f);

            float[] rowY = {.252f, .313f, .374f, .435f};
            for (int i = 0; i < 4; i++) {
                // Text stays on the right side of each blank row; app-created checkbox sits cleanly on the left.
                placeNormalized(subInputs[i], w, h, .530f, rowY[i], .390f, .052f);
                placeNormalized(subChecks[i], w, h, .484f, rowY[i] + .008f, .045f, .035f);
            }

            // Timer uses the selected duration from the previous screen and starts automatically.
            // v45 calibration: keep the requested ~1 mm right position, but lift it ~0.5 mm from v44.
            placeNormalized(timer, w, h, .495f, .578f, .365f, .090f);
            timer.setTranslationX(dp(6));
            timer.setTranslationY(dp(10));

            // Background already contains the three circular controls; only their touch layers are live.
            placeNormalized(failTouch, w, h, .220f, .770f, .205f, .110f);
            placeNormalized(pauseTouch, w, h, .455f, .758f, .205f, .125f);
            placeNormalized(doneTouch, w, h, .690f, .770f, .205f, .110f);
            placeNormalized(pauseOverlay, w, h, .455f, .758f, .205f, .125f);
            // v45 calibration: pause/resume sits ~1 mm higher than v44 and is visually a little smaller.
            pauseTouch.setTranslationX(dp(6));
            pauseTouch.setTranslationY(dp(7));
            pauseOverlay.setTranslationX(dp(6));
            pauseOverlay.setTranslationY(dp(7));
        });

        final boolean[] paused = {prefs.getBoolean("active_progress_paused", false)};
        final boolean[] awaitingResult = {prefs.getBoolean("active_progress_awaiting_result", false)};
        final long[] remaining = {prefs.getLong("active_progress_remaining", 0)};

        // A zero-time mission never restarts from its original duration. The persisted end timestamp
        // is authoritative while running, so killing/reopening the app cannot reset the countdown.
        long nowForInit = System.currentTimeMillis();
        long savedEndForInit = prefs.getLong("active_progress_end", 0);
        if (!awaitingResult[0] && !paused[0] && savedEndForInit > 0 && savedEndForInit <= nowForInit) {
            awaitingResult[0] = true;
            paused[0] = true;
            remaining[0] = 0;
            prefs.edit()
                .putBoolean("active_progress_paused", true)
                .putBoolean("active_progress_awaiting_result", true)
                .putLong("active_progress_remaining", 0)
                .commit();
        }
        if (!awaitingResult[0] && paused[0] && remaining[0] <= 0) {
            awaitingResult[0] = true;
            prefs.edit().putBoolean("active_progress_awaiting_result", true).commit();
        }

        if (awaitingResult[0]) {
            paused[0] = true;
            remaining[0] = 0;
            pauseOverlay.setText("?");
        } else {
            if (remaining[0] <= 0) {
                int mins = prefs.getInt("progress_node_time_" + node, 10);
                remaining[0] = mins * 60L * 1000L;
            }
            pauseOverlay.setText(paused[0] ? "▶" : "Ⅱ");
            if (!paused[0]) {
                long end = prefs.getLong("active_progress_end", 0);
                if (end <= 0) {
                    end = System.currentTimeMillis() + remaining[0];
                    prefs.edit().putLong("active_progress_end", end).commit();
                }
            }
        }

        missionTick = new Runnable() {
            @Override public void run() {
                long left;
                if (paused[0]) {
                    left = prefs.getLong("active_progress_remaining", remaining[0]);
                } else {
                    long end = prefs.getLong("active_progress_end", System.currentTimeMillis());
                    left = Math.max(0, end - System.currentTimeMillis());
                }
                remaining[0] = left;
                long totalSec = (left + 999) / 1000;
                long mm = totalSec / 60;
                long ss = totalSec % 60;
                timer.setText(String.format(java.util.Locale.US, "%02d:%02d", mm, ss));
                if (left > 0 && !paused[0]) {
                    missionHandler.postDelayed(this, 250);
                } else if (left <= 0) {
                    paused[0] = true;
                    awaitingResult[0] = true;
                    prefs.edit()
                        .putBoolean("active_progress_paused", true)
                        .putBoolean("active_progress_awaiting_result", true)
                        .putLong("active_progress_remaining", 0)
                        .commit();
                    timer.setText("00:00");
                    pauseOverlay.setText("?");
                }
            }
        };
        missionHandler.post(missionTick);

        pauseTouch.setOnClickListener(v -> {
            if (awaitingResult[0] || remaining[0] <= 0) return;
            if (paused[0]) {
                paused[0] = false;
                long end = System.currentTimeMillis() + remaining[0];
                prefs.edit().putBoolean("active_progress_paused", false).putLong("active_progress_end", end).commit();
                pauseOverlay.setText("Ⅱ");
                missionHandler.removeCallbacks(missionTick);
                missionHandler.post(missionTick);
            } else {
                long end = prefs.getLong("active_progress_end", System.currentTimeMillis());
                remaining[0] = Math.max(0, end - System.currentTimeMillis());
                paused[0] = true;
                prefs.edit().putBoolean("active_progress_paused", true).putLong("active_progress_remaining", remaining[0]).commit();
                missionHandler.removeCallbacks(missionTick);
                pauseOverlay.setText("▶");
            }
        });

        final boolean[] resultSubmitting = {false};
        doneTouch.setOnClickListener(v -> {
            if (resultSubmitting[0]) return;
            resultSubmitting[0] = true;
            missionHandler.removeCallbacks(missionTick);
            if (finalizeMissionResult(node, true)) {
                Toast.makeText(this, "مرحله انجام شد", Toast.LENGTH_SHORT).show();
                showProgressPath();
            } else {
                resultSubmitting[0] = false;
            }
        });

        failTouch.setOnClickListener(v -> {
            if (resultSubmitting[0]) return;
            resultSubmitting[0] = true;
            missionHandler.removeCallbacks(missionTick);
            if (finalizeMissionResult(node, false)) {
                Toast.makeText(this, "مرحله انجام نشد", Toast.LENGTH_SHORT).show();
                showProgressPath();
            } else {
                resultSubmitting[0] = false;
            }
        });

        pauseTouch.setOnLongClickListener(v -> {
            if (awaitingResult[0]) {
                Toast.makeText(this, "نتیجه را با ✓ یا ✕ مشخص کنید", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        addTopBar();
        addBottomBar();
        setContentView(root);
    }

    private void updateSubtaskCheck(TextView check, EditText input, boolean done) {
        String value = input.getText() == null ? "" : input.getText().toString().trim();
        boolean hasText = !value.isEmpty();
        GradientDrawable box = new GradientDrawable();
        box.setCornerRadius(dp(5));
        box.setColor(Color.argb(248, 255, 255, 255));
        if (hasText) box.setStroke(dp(1), Color.rgb(138, 140, 182));
        check.setBackground(box);
        check.setText(hasText && done ? "✓" : "");
        if (done && hasText) {
            input.setPaintFlags(input.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            input.setTextColor(Color.rgb(132, 136, 156));
        } else {
            input.setPaintFlags(input.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            input.setTextColor(Color.rgb(58, 67, 100));
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override protected void onDestroy() {
        if (missionTick != null) missionHandler.removeCallbacks(missionTick);
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (onProgressStage) {
            showProgressPath();
        } else if (!onHome) {
            showHome();
        } else {
            finish();
        }
    }
}

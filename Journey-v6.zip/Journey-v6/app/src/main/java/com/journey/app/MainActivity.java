package com.journey.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private FrameLayout root;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        showHome();
    }

    private void configureWindow() {
        Window w = getWindow();
        // Keep app content strictly between Android system bars.
        // Do not draw the background underneath the status/navigation bars.
        w.setStatusBarColor(Color.rgb(2, 15, 38));
        w.setNavigationBarColor(Color.rgb(2, 15, 38));
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    private void showHome() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 15, 38));

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.journey_background);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bg.setAdjustViewBounds(false);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        // Touch zones cover each complete island and its black label.
        addHotspot("جام جهانی", .24f, .17f, .76f, .35f);
        addHotspot("مرکز خرید", .00f, .29f, .47f, .47f);
        addHotspot("کاخ آرزوها", .54f, .29f, 1.00f, .48f);
        addHotspot("سفر در زمان", .03f, .43f, .49f, .63f);
        addHotspot("جنگل", .52f, .45f, 1.00f, .66f);
        addHotspot("مسیر پیشرفت", .23f, .66f, .78f, .91f);

        setContentView(root);
    }

    private void addHotspot(String title, float l, float t, float r, float b) {
        View v = new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setOnClickListener(view -> showSection(title));
        root.post(() -> {
            int w = root.getWidth(), h = root.getHeight();
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                Math.round((r-l)*w), Math.round((b-t)*h));
            p.leftMargin = Math.round(l*w);
            p.topMargin = Math.round(t*h);
            v.setLayoutParams(p);
        });
        root.addView(v, new FrameLayout.LayoutParams(1,1));
    }

    private void showSection(String title) {
        FrameLayout page = new FrameLayout(this);
        page.setBackgroundColor(Color.rgb(2, 15, 38));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        heading.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.addView(heading, new FrameLayout.LayoutParams(-1, -1));

        setContentView(page);
    }

    @Override public void onBackPressed() {
        if (root != null && root.getParent() == null) showHome();
        else super.onBackPressed();
    }
}

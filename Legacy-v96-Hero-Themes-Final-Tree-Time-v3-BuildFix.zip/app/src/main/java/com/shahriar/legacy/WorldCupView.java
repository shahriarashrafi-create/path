package com.shahriar.legacy;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/**
 * Entire World Cup / global progression overlay is rendered in code.
 * The photographic background is selected by MainActivity from the active Hero theme.
 */
public class WorldCupView extends View {
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Path path = new Path();
    private final String[] countries = {"ایران", "ترکیه", "امارات", "ایتالیا", "ژاپن"};
    private final int[] levels = {1, 10, 20, 30, 40};
    private final RectF[] countryRects = {new RectF(), new RectF(), new RectF(), new RectF(), new RectF()};
    private final RectF travelRect = new RectF();

    private int level = 1;
    private int xp = 0;
    private int xpNeed = 100;

    public WorldCupView(Context context) {
        super(context);
        d = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setClickable(true);
    }

    public void setGameState(int level, int xp, int xpNeed) {
        this.level = Math.max(1, level);
        this.xp = Math.max(0, xp);
        this.xpNeed = Math.max(1, xpNeed);
        invalidate();
    }

    private float dp(float x) { return x * d; }
    private int alpha(int c, int a) { return (c & 0x00FFFFFF) | ((a & 0xFF) << 24); }

    private void roundPanel(Canvas c, RectF r, int fill, int stroke, float radius, float strokeW) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setColor(fill);
        p.clearShadowLayer();
        c.drawRoundRect(r, radius, radius, p);
        if (strokeW > 0f) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(strokeW);
            p.setColor(stroke);
            c.drawRoundRect(r, radius, radius, p);
        }
    }

    private void glowPanel(Canvas c, RectF r, boolean active) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                active ? new int[]{0xF2F8FCFF, 0xE9EAF4FF} : new int[]{0xE9F7FBFF, 0xE4EEF7FF},
                null, Shader.TileMode.CLAMP));
        if (active) p.setShadowLayer(dp(9), 0, 0, 0x6654A9FF); else p.clearShadowLayer();
        c.drawRoundRect(r, dp(16), dp(16), p);
        p.clearShadowLayer();
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(active ? dp(1.6f) : dp(1));
        p.setColor(active ? 0xFF2F8DFF : 0x7764A9D8);
        c.drawRoundRect(r, dp(16), dp(16), p);
    }

    private void drawText(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean bold) {
        text.setShader(null);
        text.clearShadowLayer();
        text.setColor(color);
        text.setTextSize(dp(size));
        text.setTextAlign(align);
        text.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        c.drawText(s, x, y, text);
    }

    private void drawGlobeIcon(Canvas c, float cx, float cy, float r) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.5f));
        p.setColor(0xFF70E8FF);
        p.setShadowLayer(dp(8), 0, 0, 0xAA22CCFF);
        c.drawCircle(cx, cy, r, p);
        c.drawOval(new RectF(cx-r*.48f, cy-r, cx+r*.48f, cy+r), p);
        c.drawOval(new RectF(cx-r, cy-r*.38f, cx+r, cy+r*.38f), p);
        c.drawLine(cx-r*.92f, cy, cx+r*.92f, cy, p);
        p.clearShadowLayer();
    }

    private void drawHexLevel(Canvas c, float cx, float cy, float r) {
        path.reset();
        for (int i=0;i<6;i++) {
            double a = Math.toRadians(60*i-30);
            float x = cx + (float)Math.cos(a)*r;
            float y = cy + (float)Math.sin(a)*r;
            if (i==0) path.moveTo(x,y); else path.lineTo(x,y);
        }
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFE6F2FF);
        p.setShadowLayer(dp(6),0,0,0x554E8CFF);
        c.drawPath(path,p);
        p.clearShadowLayer();
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.6f));p.setColor(0xFF2F8DFF);c.drawPath(path,p);
        drawText(c, String.valueOf(level), cx, cy+dp(5), 14, 0xFF17345D, Paint.Align.CENTER, true);
    }

    private void drawTrophy(Canvas c, float cx, float cy, float s) {
        p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(dp(2));p.setColor(0xFF2F8DFF);
        RectF cup = new RectF(cx-s*.42f,cy-s*.45f,cx+s*.42f,cy+s*.20f);
        c.drawArc(cup,0,180,false,p);
        c.drawLine(cx-s*.31f,cy-s*.43f,cx-s*.22f,cy+s*.03f,p);
        c.drawLine(cx+s*.31f,cy-s*.43f,cx+s*.22f,cy+s*.03f,p);
        c.drawLine(cx,cy+s*.18f,cx,cy+s*.48f,p);
        c.drawLine(cx-s*.22f,cy+s*.48f,cx+s*.22f,cy+s*.48f,p);
        c.drawArc(new RectF(cx-s*.68f,cy-s*.35f,cx-s*.20f,cy+s*.06f),95,180,false,p);
        c.drawArc(new RectF(cx+s*.20f,cy-s*.35f,cx+s*.68f,cy+s*.06f),-95,180,false,p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawLock(Canvas c, float cx, float cy, float s) {
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.4f));p.setColor(0xFF315D87);
        c.drawArc(new RectF(cx-s*.30f,cy-s*.48f,cx+s*.30f,cy+s*.08f),180,-180,false,p);
        p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(cx-s*.42f,cy-s*.06f,cx+s*.42f,cy+s*.50f),dp(2),dp(2),p);
    }

    private void drawPlane(Canvas c, float cx, float cy, float s, float angleDeg, int color) {
        c.save(); c.rotate(angleDeg,cx,cy);
        p.setStyle(Paint.Style.FILL); p.setColor(color);
        path.reset();
        path.moveTo(cx+s*.78f,cy);
        path.lineTo(cx+s*.10f,cy-s*.13f);
        path.lineTo(cx-s*.10f,cy-s*.64f);
        path.lineTo(cx-s*.30f,cy-s*.64f);
        path.lineTo(cx-s*.20f,cy-s*.10f);
        path.lineTo(cx-s*.68f,cy-s*.04f);
        path.lineTo(cx-s*.78f,cy-s*.28f);
        path.lineTo(cx-s*.92f,cy-s*.28f);
        path.lineTo(cx-s*.83f,cy);
        path.lineTo(cx-s*.92f,cy+s*.28f);
        path.lineTo(cx-s*.78f,cy+s*.28f);
        path.lineTo(cx-s*.68f,cy+s*.04f);
        path.lineTo(cx-s*.20f,cy+s*.10f);
        path.lineTo(cx-s*.30f,cy+s*.64f);
        path.lineTo(cx-s*.10f,cy+s*.64f);
        path.lineTo(cx+s*.10f,cy+s*.13f);
        path.close(); c.drawPath(path,p); c.restore();
    }

    private int currentStage() {
        int s=0; for(int i=0;i<levels.length;i++) if(level>=levels[i]) s=i; return s;
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        if(w<=0||h<=0)return;
        int current=currentStage();

        // A restrained dark wash keeps code-rendered information readable while the photographic background stays visible.
        p.setStyle(Paint.Style.FILL);p.setColor(0x10FFFFFF);c.drawRect(0,0,w,h,p);

        // Main title card — placed well below the global app HUD.
        RectF title = new RectF(w*.05f,h*.315f,w*.95f,h*.405f);
        roundPanel(c,title,0xEAF8FBFF,0x8864B5FF,dp(18),dp(1));
        drawGlobeIcon(c,title.left+title.width()*.135f,title.centerY(),Math.min(title.height()*.28f,w*.052f));
        drawText(c,"جام جهانی",title.right-dp(24),title.top+title.height()*.46f,27,0xFF17345D,Paint.Align.RIGHT,true);
        drawText(c,"با هر سطح، یک کشور جدید را فتح کن",title.right-dp(24),title.top+title.height()*.75f,12.5f,0xFF60758F,Paint.Align.RIGHT,false);

        // Level progress + travel badge row.
        RectF prog = new RectF(w*.05f,h*.414f,w*.665f,h*.478f);
        roundPanel(c,prog,0xE8F8FBFF,0x7764B5FF,dp(15),dp(1));
        drawHexLevel(c,prog.left+prog.height()*.58f,prog.centerY(),prog.height()*.32f);
        drawText(c,"Level "+level,prog.left+prog.height()*1.17f,prog.top+prog.height()*.34f,12.5f,0xFF17345D,Paint.Align.LEFT,true);
        drawText(c,xp+" / "+xpNeed+" XP",prog.right-dp(13),prog.top+prog.height()*.34f,10.5f,0xFF315D87,Paint.Align.RIGHT,true);
        RectF bar=new RectF(prog.left+prog.height()*1.17f,prog.top+prog.height()*.57f,prog.right-dp(13),prog.bottom-dp(10));
        p.setStyle(Paint.Style.FILL);p.setColor(0xBDE3EEF8);c.drawRoundRect(bar,bar.height()/2,bar.height()/2,p);
        float frac=Math.max(0f,Math.min(1f,xp/(float)xpNeed));
        if(frac>0){RectF fill=new RectF(bar.left,bar.top,bar.left+bar.width()*frac,bar.bottom);p.setShader(new LinearGradient(fill.left,0,fill.right,0,new int[]{0xFF25E7FF,0xFF318CFF},null,Shader.TileMode.CLAMP));p.setShadowLayer(dp(5),0,0,0x9935E6FF);c.drawRoundRect(fill,fill.height()/2,fill.height()/2,p);p.clearShadowLayer();p.setShader(null);}

        travelRect.set(w*.68f,h*.414f,w*.95f,h*.478f);
        roundPanel(c,travelRect,0xE8F8FBFF,0x7764B5FF,dp(15),dp(1));
        drawTrophy(c,travelRect.left+travelRect.width()*.25f,travelRect.centerY(),dp(18));
        drawText(c,"سفر به",travelRect.right-dp(17),travelRect.top+travelRect.height()*.42f,12,0xFF17345D,Paint.Align.RIGHT,true);
        drawText(c,"دور دنیا",travelRect.right-dp(17),travelRect.top+travelRect.height()*.72f,12,0xFF17345D,Paint.Align.RIGHT,true);
        drawText(c,"‹",travelRect.left+dp(11),travelRect.centerY()+dp(7),24,0xFF2F8DFF,Paint.Align.LEFT,true);

        // Code-rendered route layer.  No route/card image assets are used.
        float[][] route = {
                {w*.50f,h*.666f}, // Iran
                {w*.20f,h*.682f}, // Turkey
                {w*.80f,h*.700f}, // UAE
                {w*.24f,h*.565f}, // Italy
                {w*.80f,h*.565f}  // Japan
        };
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.5f));p.setColor(0xD7DFF8FF);p.setPathEffect(new DashPathEffect(new float[]{dp(7),dp(7)},0));p.setShadowLayer(dp(3),0,0,0x9930D6FF);
        for(int i=0;i<route.length-1;i++){
            float x1=route[i][0], y1=route[i][1], x2=route[i+1][0], y2=route[i+1][1];
            path.reset();path.moveTo(x1,y1);float bend=((i&1)==0?-1:1)*h*.025f;path.quadTo((x1+x2)/2f,(y1+y2)/2f+bend,x2,y2);c.drawPath(path,p);
            float mx=(x1+x2)/2f,my=(y1+y2)/2f+bend*.55f;float ang=(float)Math.toDegrees(Math.atan2(y2-y1,x2-x1));drawPlane(c,mx,my,dp(10),ang,0xFFF0FBFF);
        }
        p.clearShadowLayer();p.setPathEffect(null);

        // Minimal country cards: labels/status only — deliberately no Iran/Japan/etc. photos.
        float cardW=w*.205f, cardH=h*.067f;
        setCard(countryRects[3], w*.21f, h*.548f, cardW, cardH); // Italy
        setCard(countryRects[4], w*.79f, h*.548f, cardW, cardH); // Japan
        setCard(countryRects[0], w*.50f, h*.650f, cardW, cardH); // Iran
        setCard(countryRects[1], w*.20f, h*.680f, cardW, cardH); // Turkey
        setCard(countryRects[2], w*.80f, h*.700f, cardW, cardH); // UAE

        for(int i=0;i<countries.length;i++){
            boolean unlocked=level>=levels[i], active=i==current;
            RectF r=countryRects[i];
            glowPanel(c,r,active);
            if(!unlocked)drawLock(c,r.right-dp(12),r.top+dp(13),dp(7));
            if(active){
                p.setStyle(Paint.Style.FILL);p.setColor(0xFF32E9FF);p.setShadowLayer(dp(6),0,0,0xDD25DDFF);c.drawCircle(r.centerX(),r.bottom+dp(5),dp(3.2f),p);p.clearShadowLayer();
            }
            drawText(c,countries[i],r.centerX(),r.top+r.height()*.47f,13.5f,0xFF17345D,Paint.Align.CENTER,true);
            String sub = i==0 ? "شروع مسیر" : (unlocked ? "باز شده" : "Level "+levels[i]);
            drawText(c,sub,r.centerX(),r.top+r.height()*.75f,9.5f,unlocked?0xFF315D87:0xFF8799AA,Paint.Align.CENTER,false);
        }

        // Bottom level roadmap.
        RectF road = new RectF(w*.04f,h*.855f,w*.96f,h*.952f);
        roundPanel(c,road,0xEAF8FBFF,0x7764B5FF,dp(18),dp(1));
        float left=road.left+road.width()*.10f, right=road.right-road.width()*.10f, y=road.top+road.height()*.42f;
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(0x665A8FB8);c.drawLine(left,y,right,y,p);
        float curX=left+(right-left)*(current/(float)(levels.length-1));p.setColor(0xFF39DFFF);p.setShadowLayer(dp(5),0,0,0xAA2CE1FF);c.drawLine(left,y,curX,y,p);p.clearShadowLayer();
        for(int i=0;i<levels.length;i++){
            float x=left+(right-left)*(i/(float)(levels.length-1)); boolean unlocked=level>=levels[i], active=i==current;
            float rr=active?dp(17):dp(14);
            p.setStyle(Paint.Style.FILL);p.setColor(active?0xFF2F8DFF:(unlocked?0xFFDCEEFF:0xFFCBD7E3));if(active)p.setShadowLayer(dp(9),0,0,0xCC29DFFF);c.drawCircle(x,y,rr,p);p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(active?dp(1.8f):dp(1));p.setColor(active?0xFFFFFFFF:0xFF6B8EAC);c.drawCircle(x,y,rr,p);
            if(!unlocked)drawLock(c,x,y-dp(21),dp(6));
            drawText(c,String.valueOf(levels[i]),x,y+dp(4.5f),11,active?Color.WHITE:0xFF17345D,Paint.Align.CENTER,true);
            drawText(c,countries[i],x,road.bottom-dp(9),10.5f,0xFF315D87,Paint.Align.CENTER,false);
        }
    }

    private void setCard(RectF r,float cx,float cy,float w,float h){r.set(cx-w/2f,cy-h/2f,cx+w/2f,cy+h/2f);}

    @Override public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        float x=e.getX(),y=e.getY();
        if(travelRect.contains(x,y)){
            Toast.makeText(getContext(),"کشورهای جدید با افزایش Level باز می‌شوند",Toast.LENGTH_SHORT).show();
            performClick(); return true;
        }
        for(int i=0;i<countryRects.length;i++)if(countryRects[i].contains(x,y)){
            if(level>=levels[i]) Toast.makeText(getContext(),countries[i]+" باز شده",Toast.LENGTH_SHORT).show();
            else Toast.makeText(getContext(),"در Level "+levels[i]+" باز می‌شود",Toast.LENGTH_SHORT).show();
            performClick(); return true;
        }
        return true;
    }

    @Override public boolean performClick(){super.performClick();return true;}
}

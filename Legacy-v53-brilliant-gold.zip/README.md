# Legacy v53 — Brilliant Gold

Based on v52.

- The next unresolved mission circle now uses a much richer saturated gold fill and stronger bright-gold rim.
- Added a restrained continuous sparkle effect: soft glow flash plus a tiny breathing scale pulse.
- Mission text stays dark/navy, bold and high-contrast for readability over the gold.
- Music and all v52 behavior remain unchanged.

Legacy v17 — HUD reference match pass 3. Home artwork and six hit targets unchanged. Header layout, XP track, capsule density, avatar scale, and HUD accents refined.


v18: final HUD density/alignment polish; Home artwork and six touch targets unchanged.

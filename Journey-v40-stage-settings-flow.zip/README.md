Journey v40 — Stage setup flow

Implemented step by step from the latest seven-image Progress Path baseline:

1. Kept all 7 Progress Path images and all 21 node touch positions/calibration unchanged.
2. Every node now opens the same unified stage page instead of a separate title-only page.
3. Added the approved 1:2 pastel/anime stage-layout artwork as the visual background for every stage.
4. Title is entered directly in the empty Title box. It is saved live in SharedPreferences and appears back inside that same node circle on the Progress Path.
5. Time row is touchable. Options: 5, 10, 20, 30 minutes. No default time text is shown; after selection the chosen value is shown as “N min”.
6. Importance row is touchable. Options: کم / متوسط / زیاد. No default label is shown until selected.
7. Repeat row is touchable. Options: بدون تکرار / روزانه. No default label is shown until selected.
8. Reminder row is touchable. Options: خاموش / 5 دقیقه قبل / 10 دقیقه قبل / 30 دقیقه قبل. No default label is shown until selected.
9. Notes section is not present.
10. Start Mission stays at the bottom in the approved visual. Its touch area validates title + time, saves settings, and opens the running-stage view.
11. Header and Bottom Bar remain on the highest layer on the stage editor and running-stage pages, preserving the existing safe-area rule.
12. All stage-specific values are stored separately for nodes 1 through 21.

Build note: the project remains Java/Android with the existing Gradle workflow and Java 17 setup.

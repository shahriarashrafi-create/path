package com.journey.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.os.Build;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private FrameLayout root;
    private boolean onHome = true;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        prefs = getSharedPreferences("journey_progress", MODE_PRIVATE);
        if (!prefs.contains("level")) prefs.edit().putInt("level",1).putInt("xp",0).putInt("coins",0).putInt("combo",0).apply();
        showHome();
    }

    private void configureWindow() {
        Window w = getWindow();
        // Keep app content strictly between Android system bars.
        // Do not draw the background underneath the status/navigation bars.
        w.setStatusBarColor(Color.rgb(2, 15, 38));
        w.setNavigationBarColor(Color.rgb(2, 15, 38));
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    private void showHome() {
        onHome = true;
        refreshComboTimeout();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 15, 38));
        // Permanent Journey rule: all app UI stays strictly inside Android system bars.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(0, top, 0, bottom);
                return insets;
            });
        }

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.journey_background);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bg.setAdjustViewBounds(false);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        addTopBar();

        // Touch zones cover each complete island and its black label.
        addHotspot("جام جهانی", .24f, .148f, .76f, .328f);
        addHotspot("مرکز خرید", .00f, .268f, .47f, .448f);
        addHotspot("کاخ آرزوها", .54f, .268f, 1.00f, .458f);
        addHotspot("سفر در زمان", .03f, .408f, .49f, .608f);
        addHotspot("جنگل", .52f, .428f, 1.00f, .638f);
        addHotspot("مسیر پیشرفت", .23f, .638f, .78f, .888f);

        setContentView(root);
    }


    private void addTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(3), dp(10), dp(3));
        GradientDrawable panel = new GradientDrawable();
        panel.setColor(Color.argb(235, 2, 10, 25));
        panel.setStroke(dp(1), Color.rgb(210, 155, 45));
        panel.setCornerRadii(new float[]{0,0,0,0,dp(18),dp(18),dp(18),dp(18)});
        bar.setBackground(panel);

        int level = prefs.getInt("level",1);
        int xp = prefs.getInt("xp",0);

        // Left: default avatar + level + compact XP progress bar.
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);

        TextView avatar = new TextView(this);
        avatar.setText("◆");
        avatar.setTextColor(Color.rgb(225, 171, 58));
        avatar.setTextSize(16);
        avatar.setGravity(Gravity.CENTER);
        GradientDrawable avatarBg = new GradientDrawable();
        avatarBg.setShape(GradientDrawable.OVAL);
        avatarBg.setColor(Color.rgb(10, 20, 38));
        avatarBg.setStroke(dp(1), Color.rgb(230, 173, 55));
        avatar.setBackground(avatarBg);
        left.addView(avatar, new LinearLayout.LayoutParams(dp(38), dp(38)));

        LinearLayout progressBox = new LinearLayout(this);
        progressBox.setOrientation(LinearLayout.VERTICAL);
        progressBox.setGravity(Gravity.CENTER_VERTICAL);
        progressBox.setPadding(dp(7),0,0,0);
        TextView levelText = headerText("Lv " + level, 13, Gravity.LEFT);
        levelText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        progressBox.addView(levelText, new LinearLayout.LayoutParams(-1, dp(19)));

        ProgressBar xpBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        xpBar.setMax(level * 100);
        xpBar.setProgress(xp);
        GradientDrawable track = new GradientDrawable();
        track.setColor(Color.rgb(18, 21, 31));
        track.setCornerRadius(dp(6));
        GradientDrawable fill = new GradientDrawable();
        fill.setColor(Color.rgb(255, 188, 35));
        fill.setCornerRadius(dp(6));
        android.graphics.drawable.ClipDrawable clip = new android.graphics.drawable.ClipDrawable(fill, Gravity.LEFT, android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable layers = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{track, clip});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        xpBar.setProgressDrawable(layers);
        progressBox.addView(xpBar, new LinearLayout.LayoutParams(dp(82), dp(7)));
        left.addView(progressBox, new LinearLayout.LayoutParams(-2, -1));
        bar.addView(left, new LinearLayout.LayoutParams(0, -1, 1.20f));

        // Center: official Journey emblem only. No JOURNEY text and no square background.
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.journey_header_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setPadding(dp(1), dp(1), dp(1), dp(1));
        bar.addView(logo, new LinearLayout.LayoutParams(0, dp(47), .82f));

        // Right: resources in separate dark/gold capsules.
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        stats.addView(statCapsule("⭐", xp));
        stats.addView(statCapsule("🪙", prefs.getInt("coins",0)));
        stats.addView(statCapsule("🔥", prefs.getInt("combo",0)));
        bar.addView(stats, new LinearLayout.LayoutParams(0, -1, 1.70f));

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(54));
        bp.gravity = Gravity.TOP;
        root.addView(bar, bp);
    }

    private TextView statCapsule(String icon, int value) {
        TextView v = headerText(icon + "  " + value, 12, Gravity.CENTER);
        v.setSingleLine(true);
        v.setPadding(dp(9),0,dp(9),0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(185, 5, 10, 20));
        bg.setStroke(dp(1), Color.rgb(155, 116, 45));
        bg.setCornerRadius(dp(14));
        v.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(30));
        p.setMargins(dp(2),0,dp(2),0);
        v.setLayoutParams(p);
        return v;
    }

    private TextView headerText(String text, float size, int gravity) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(Color.WHITE); v.setTextSize(size); v.setGravity(gravity | Gravity.CENTER_VERTICAL);
        v.setMaxLines(2); return v;
    }

    // Reward rules reserved for mission completion: low 10XP/5 coins, medium 20XP/10 coins, high 30XP/15 coins.
    // Combo: consecutive successful missions; 30-minute default window. Fail/timeout resets to zero.
    // Combo 3+ => x1.5 rewards, Combo 7+ => x2 rewards.
    private void awardMission(int baseXp, int baseCoins, boolean success) {
        if (!success) { prefs.edit().putInt("combo",0).apply(); return; }
        int combo = prefs.getInt("combo",0) + 1;
        float mult = combo >= 7 ? 2f : (combo >= 3 ? 1.5f : 1f);
        int level = prefs.getInt("level",1);
        int xp = prefs.getInt("xp",0) + Math.round(baseXp * mult);
        int coins = prefs.getInt("coins",0) + Math.round(baseCoins * mult);
        while (xp >= level * 100) { xp -= level * 100; level++; }
        prefs.edit().putInt("level",level).putInt("xp",xp).putInt("coins",coins).putInt("combo",combo)
            .putLong("combo_deadline", System.currentTimeMillis() + 30L*60L*1000L).apply();
    }

    private void refreshComboTimeout() {
        long deadline = prefs.getLong("combo_deadline",0);
        if (prefs.getInt("combo",0) > 0 && deadline > 0 && System.currentTimeMillis() > deadline)
            prefs.edit().putInt("combo",0).putLong("combo_deadline",0).apply();
    }

    private void addHotspot(String title, float l, float t, float r, float b) {
        View v = new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setClickable(true);
        v.setOnClickListener(view -> {
            GradientDrawable glow = new GradientDrawable();
            glow.setColor(Color.argb(42, 255, 193, 7));
            glow.setStroke(dp(2), Color.argb(180, 255, 193, 7));
            glow.setCornerRadius(dp(28));
            view.setBackground(glow);
            new Handler().postDelayed(() -> {
                view.setBackgroundColor(Color.TRANSPARENT);
                showSection(title);
            }, 110);
        });
        root.post(() -> {
            int w = root.getWidth(), h = root.getHeight();
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                Math.round((r-l)*w), Math.round((b-t)*h));
            p.leftMargin = Math.round(l*w);
            p.topMargin = Math.round(t*h);
            v.setLayoutParams(p);
        });
        root.addView(v, new FrameLayout.LayoutParams(1,1));
    }

    private void showSection(String title) {
        onHome = false;
        FrameLayout page = new FrameLayout(this);
        page.setBackgroundColor(Color.rgb(2, 15, 38));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        heading.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.addView(heading, new FrameLayout.LayoutParams(-1, -1));

        setContentView(page);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override public void onBackPressed() {
        if (!onHome) {
            showHome();
        } else {
            finish();
        }
    }
}

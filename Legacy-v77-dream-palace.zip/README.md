Legacy v77 – Dream Palace

Base: Legacy-v76-progress-tree-final.zip

Dream Palace added:
- New 4×5 Dream Palace screen using the supplied palace artwork (20 slots per page).
- Tap an empty slot to pick a photo, crop/zoom/pan it, then save title, Persian target year, and price/value.
- Filled slots show only the image; the baked gold placeholder frame is covered.
- Tap a filled slot for a clean full-screen viewer; tap toggles title/year/price.
- Long-press a full-screen dream to edit its metadata or replace/crop the image.
- The next 20-slot page unlocks only after the current page is completely filled; horizontal swipe moves between unlocked pages.
- A gold dream-viewer portal appears over the sun only after the first dream is saved.
- The portal opens dreams in saved order; each upward swipe snaps to exactly the next dream and downward swipe returns to the previous one.
- Dream data and images persist locally across app restarts.
- Existing Progress Path, Tree, missions, settings, audio, notifications, and other Legacy v76 behavior are preserved.

Legacy v76 – final progress/tree closure polish

Base: Legacy-v75-tree-daily-zoom-controls.zip

Final fixes:
- Back press now plays exactly one UI sound while still navigating exactly one level.
- Persian tree search is normalized for Arabic/Persian character variants (ی/ي/ى, ک/ك), ZWNJ/directional marks, diacritics, and repeated spaces.
- Tree History no longer has the previous 30-date display cap; all saved snapshot dates are shown in the scrollable history list.
- PV / GPV / count remain cumulative across the configurable logical-day boundary. At the new day, the values stay in place but stats_day no longer matches the new logical day, so the person is treated as not-yet-recorded until fresh actual stats are saved.
- Existing configurable day start (default 06:00), mission day boundaries, tree colors, zoom/search/history behavior, To Do, and Actions remain intact.

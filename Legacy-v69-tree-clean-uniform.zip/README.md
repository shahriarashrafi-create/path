Legacy v69 – Tree visual/layout refinement

Changes:
- All person circles are the exact same size at every generation.
- Removed profile photos/avatars from tree nodes; nodes are intentionally minimal.
- Removed the add-person plus and short line above leaf/person circles.
- New people are added only from each member card via “افزودن فرد”.
- Expand/collapse orb exists only for nodes that already have children: minus when open, plus when closed.
- Branches redraw symmetrically around each parent and reflow when collapsed/expanded.
- Branch lines are thinner, softer, curved, and connect through the branch control.
- Default zoom shows name only; PV/GPV/count appear only when zoomed in.
- Long names stay on one line and auto-fit.
- Root remains anchored near the lower center; pan and pinch zoom are preserved.
- Re-layout after branch toggles gets a short soft fade.

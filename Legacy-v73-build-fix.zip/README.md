Legacy v73 build fix

Fix:
- Corrected the Java regex escape in MainActivity.java that caused GitHub Actions to fail with: illegal escape character.
- The faulty split("\|") literal is now the valid Java regex literal split("\\|").
- Scanned MainActivity.java for other invalid Java string escapes: none found.
- Basic delimiter sanity checks passed (balanced braces and parentheses).

Base: Legacy-v72-tree-todo-actions-editor.zip

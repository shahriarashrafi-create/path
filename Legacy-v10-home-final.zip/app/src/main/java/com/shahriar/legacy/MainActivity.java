package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content;
    private long lastBackAt = 0;
    private boolean isHome = true;
    private int homeGeneration = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","جنگل شکوفایی","سفر در زمان","مرکز خرید","جام جهانی"};
    // Coordinates measured against the supplied 709x1536 artwork. Centers are bottom -> top.
    private final float[][] centers = {{0.735f,0.626f},{0.715f,0.538f},{0.724f,0.447f},{0.716f,0.397f},{0.724f,0.323f},{0.713f,0.247f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void showHome(){
        isHome = true;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        setContentView(root);
        root.setFitsSystemWindows(true);

        // Home artwork fills the whole app-safe area. The HUD is an overlay, not a separate toolbar.
        ImageView home=new ImageView(this); home.setImageResource(com.shahriar.legacy.R.drawable.home_background);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // Premium transparent HUD: compact, balanced and fully overlaid on the artwork.
        LinearLayout header=new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14),dp(4),dp(10),dp(2));
        header.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(66),Gravity.TOP);
        root.addView(header,hp);

        ImageView avatar=new ImageView(this);
        avatar.setImageResource(com.shahriar.legacy.R.drawable.avatar_legacy);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        avatar.setAdjustViewBounds(true);
        header.addView(avatar,new LinearLayout.LayoutParams(dp(52),dp(52)));

        LinearLayout stats=new LinearLayout(this);
        stats.setOrientation(LinearLayout.VERTICAL);
        stats.setGravity(Gravity.CENTER_VERTICAL);
        stats.setPadding(dp(7),0,dp(7),0);

        TextView level=tv("سطح 1",13,Color.WHITE);
        level.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        stats.addView(level,new LinearLayout.LayoutParams(-1,dp(20)));

        ProgressBar xp=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        xp.setMax(100); xp.setProgress(0);
        xp.setProgressTintList(ColorStateList.valueOf(0xFFFFC247));
        xp.setProgressBackgroundTintList(ColorStateList.valueOf(0xAA3F5D78));
        xp.setMinimumHeight(dp(8));
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(8));
        xpLp.setMargins(0,dp(1),0,dp(1));
        stats.addView(xp,xpLp);

        TextView xpTxt=tv("0 / 100 XP",9,0xFFF4F7FB);
        xpTxt.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        stats.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(17)));
        header.addView(stats,new LinearLayout.LayoutParams(0,dp(54),1f));

        // Compact glass capsules, visually subordinate to level progress.
        TextView coin=tv("◉  0",12,0xFFFFD45B);
        coin.setGravity(Gravity.CENTER);
        GradientDrawable coinBg=bg(0x66324F6C,dp(18));
        coinBg.setStroke(dp(1),0x334E789B);
        coin.setBackground(coinBg);
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(30));
        coinLp.setMargins(dp(1),0,dp(4),0);
        header.addView(coin,coinLp);

        TextView combo=tv("🔥  0",12,Color.WHITE);
        combo.setGravity(Gravity.CENTER);
        GradientDrawable comboBg=bg(0x66324F6C,dp(18));
        comboBg.setStroke(dp(1),0x334E789B);
        combo.setBackground(comboBg);
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(50),dp(30));
        comboLp.setMargins(0,0,dp(4),0);
        header.addView(combo,comboLp);

        TextView gear=tv("⚙",17,Color.WHITE);
        gear.setGravity(Gravity.CENTER);
        gear.setContentDescription("تنظیمات");
        gear.setOnClickListener(v->showPlaceholder("تنظیمات"));
        header.addView(gear,new LinearLayout.LayoutParams(dp(38),dp(44)));

        // Transparent hit targets follow the six visible artwork buttons. The image is never stretched.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=709f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            int hitW=Math.max(dp(132), Math.round(326f*scale));
            int hitH=Math.max(dp(56), Math.round(104f*scale));
            for(int i=0;i<6;i++){
                if (!isHome || generation != homeGeneration) return;
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                float sourceX=srcW*centers[i][0], sourceY=srcH*centers[i][1];
                int cx=Math.round(offsetX + sourceX*scale), cy=Math.round(offsetY + sourceY*scale);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-Math.round(hitW*0.42f); lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==android.view.MotionEvent.ACTION_DOWN){ v.setAlpha(0.55f); return true; }
                    if(e.getAction()==android.view.MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==android.view.MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->showPlaceholder(names[idx])); content.addView(hit,lp);
            }
        });
        // Keep HUD above all touch targets/artwork.
        header.bringToFront();
    }

    private void showPlaceholder(String title){
        isHome = false;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(Color.rgb(10,31,51));
        TextView t=tv(title,28,Color.WHITE); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,0xFFBFD4E6); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        Button back=new Button(this); back.setText("بازگشت"); back.setOnClickListener(v->showHome()); p.addView(back,new LinearLayout.LayoutParams(-1,dp(56)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
    }
    @Override public void onBackPressed(){
        // On a section, Back returns Home. On Home, double Back exits.
        if(!isHome){ showHome(); return; }
        long now=System.currentTimeMillis();
        if(now-lastBackAt<1800){ super.onBackPressed(); }
        else { lastBackAt=now; Toast.makeText(this,"برای خروج دوباره بزنید",Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
}

# Legacy v57 — New Progress Path Artwork + Touch Calibration

- Replaced both Progress Path artworks with the two new 864×1536 images supplied by the user.
- Preserved the images at native 9:16 aspect ratio (no stretching).
- Re-measured all six mission-circle centers from the new images.
- Recalibrated mission text, Done/Fail fill, and touch targets from the same shared centers.
- Kept all v56 Running Mission, SFX, reward, Back, popup, and Home changes intact.

Version: 1.37 (41).

# Legacy v56

Progress Path interaction finalization + professional Running Mission experience, based on v55.

- Done / Fail state is written immediately and the Progress Path rebuild reflects it as soon as the path is shown.
- Restore returns the mission to Ready immediately and restores reward/combo state as before.
- Re-measured all six mission-circle centers directly from the two 768x1536 progress artworks; touch area, title, and state fill now share the exact same geometry.
- Completed missions use a strong green interior with high-contrast white text.
- Failed missions use a dark-red interior with high-contrast white text.
- No code-drawn rim/stroke is added around progress circles.
- Removed active-state color fill so only Done/Fail change the circle interior.
- Running Mission polish: stronger timer typography, FOCUS label, live reward preview, final-minute/final-10-second timer emphasis, and live subtask completion badge.
- Added touch ripple feedback to Done / Fail / Music / Sound / Reset / Subtasks controls.
- Added compact event-specific SFX: generic click, confirm, fail, restore, subtask, music, toggle, reset, reward, start and timer-end.
- The global click router chooses an appropriate SFX from button text/content description; dialogs use the same routing.
- Default three music modes still point to the same tiny focus loop to keep app size low.
- Retains instant/no-slide popup behavior, one-step Back navigation and the selected Home artwork/touch zones.

Version: 1.36 (40).

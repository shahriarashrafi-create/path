Legacy v47 — Pastel Mission Popups & Reward Animations

Changes in this build:
- Restore now reverses the mission's XP/Coin reward and restores mission state; combo rollback is handled safely.
- Editing Done/Fail missions cannot start them again until Restore is used.
- New pastel blue/purple code-driven popup theme for Subtasks, Music, Success, Fail, Later/Reset, Restore, Delete, Level Up, notification content, and active-mission warning.
- Slower, clearer reward animations: trophy/star pulse, XP/Coin/Combo flight to HUD, particles, failure crystal, reset spin, restore feedback.
- Music picker keeps 3 built-in focus tracks and saved tracks added from the phone.
- Custom mission-finished notification layout with Done / Later / Fail actions.


## v48 — Visual Polish Stage 1
- Unified pastel dialog surface, border softness, radius and spacing.
- Replaced raw Android mission action menu with themed dialog.
- Replaced raw mission-title prompt with themed input dialog.
- Replaced raw Combo window selector with themed pastel selector.
- No gameplay/reward/mission timing logic intentionally changed.

## v50 – Visual Polish Stage 3
- Simplified all shared Pastel popup opening behavior.
- Removed vertical/side-motion impression, overshoot/bounce, and icon pulse.
- Popups now stay centered and use only a very short fade-in.
- Reduced popup elevation and backdrop dim slightly for a cleaner, calmer UI.
- Preserved mission/reward logic and existing screen artwork.

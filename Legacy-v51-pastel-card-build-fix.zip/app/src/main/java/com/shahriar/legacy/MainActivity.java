package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.text.InputType;
import android.view.*;
import android.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content;
    private View activeBar;
    private boolean isRunningMissionScreen=false;
    private final java.util.HashMap<String,TextView> progressMissionViews=new java.util.HashMap<>();
    private final java.util.HashMap<String,View> progressGuideViews=new java.util.HashMap<>();
    private final java.util.HashMap<String,ImageView> progressHeroViews=new java.util.HashMap<>();
    private TextView hudLevel, hudXpText, hudCoinText, hudComboText; private XpBarView hudXpBar;
    private long lastBackAt = 0;
    private Runnable homeActiveTick, dailyResetTick;
    private String lastObservedMissionDay="";
    private boolean isHome = true;
    private int homeGeneration = 0;
    private android.media.SoundPool uiSoundPool; private int uiClickSoundId=0; private float touchDownX,touchDownY; private long touchDownAt=0; private boolean pageTransitioning=false;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","جنگل شکوفایی","سفر در زمان","مرکز خرید","جام جهانی"};
    // Touch centers measured against the current 768x1536 Home artwork.
    // Order matches names: Progress, Dream Palace, Growth Forest, Time Travel, Shop, World Cup.
    private final float[][] centers = {{0.505f,0.804f},{0.293f,0.535f},{0.807f,0.680f},{0.813f,0.439f},{0.370f,0.303f},{0.832f,0.218f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); initUiSound(); showHome(); }
    @Override protected void onResume(){
        super.onResume();
        loadGameState(); updateHud();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        if(isRunningMissionScreen&&!progressPrefs.getBoolean("active",false)){stopMissionTimer();stopMissionMusic();showProgressPath();consumePendingMissionFeedback();startDailyResetTicker();return;}
        refreshProgressMissionVisuals();
        if(!isRunningMissionScreen)addActiveMissionBar();
        consumePendingMissionFeedback();
        startDailyResetTicker();
    }
    @Override protected void onPause(){
        super.onPause();
        if(dailyResetTick!=null){missionHandler.removeCallbacks(dailyResetTick);dailyResetTick=null;}
    }
    @Override protected void onDestroy(){
        try{if(uiSoundPool!=null){uiSoundPool.release();uiSoundPool=null;}}catch(Exception ignored){}
        super.onDestroy();
    }
    private void initUiSound(){
        try{
            if(android.os.Build.VERSION.SDK_INT>=21){
                android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
                uiSoundPool=new android.media.SoundPool.Builder().setMaxStreams(3).setAudioAttributes(aa).build();
            }else uiSoundPool=new android.media.SoundPool(3,android.media.AudioManager.STREAM_MUSIC,0);
            uiClickSoundId=uiSoundPool.load(this,R.raw.ui_click,1);
        }catch(Exception ignored){}
    }
    private void playUiClick(){try{if(uiSoundPool!=null&&uiClickSoundId!=0)uiSoundPool.play(uiClickSoundId,.34f,.34f,1,0,1f);}catch(Exception ignored){}}
    @Override public boolean dispatchTouchEvent(MotionEvent ev){
        if(ev!=null){
            if(ev.getAction()==MotionEvent.ACTION_DOWN){touchDownX=ev.getRawX();touchDownY=ev.getRawY();touchDownAt=System.currentTimeMillis();}
            else if(ev.getAction()==MotionEvent.ACTION_UP){float dx=ev.getRawX()-touchDownX,dy=ev.getRawY()-touchDownY;long dt=System.currentTimeMillis()-touchDownAt;if(dt<850&&dx*dx+dy*dy<dp(18)*dp(18))playUiClick();}
        }
        return super.dispatchTouchEvent(ev);
    }
    private void animatePageEnter(final View v){if(v==null)return;v.animate().cancel();v.setAlpha(0f);v.setScaleX(.996f);v.setScaleY(.996f);v.setTranslationY(dp(8));v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0).setDuration(420).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();}
    private void transitionTo(final Runnable next){
        if(pageTransitioning){return;}pageTransitioning=true;final View v=(!isHome&&content!=null)?content:root;if(v==null){pageTransitioning=false;if(next!=null)next.run();return;}
        v.animate().cancel();v.animate().alpha(.08f).scaleX(.994f).scaleY(.994f).translationY(-dp(4)).setDuration(260).setInterpolator(new android.view.animation.AccelerateInterpolator()).withEndAction(()->{v.setAlpha(1f);v.setScaleX(1f);v.setScaleY(1f);v.setTranslationY(0);pageTransitioning=false;if(next!=null)next.run();}).start();
    }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private class CoinRainView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Bitmap coin;
        private final float[] x={.18f,.36f,.55f,.72f,.84f};
        private final float[] off={.03f,.24f,.47f,.69f,.86f};
        private final float[] sc={.78f,.60f,.88f,.66f,.72f};
        private ValueAnimator anim; private float phase=0f;
        CoinRainView(android.content.Context c){super(c);setClickable(false);setFocusable(false);coin=android.graphics.BitmapFactory.decodeResource(getResources(),R.drawable.hud_coin);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);if(coin==null)return;for(int i=0;i<x.length;i++){float q=(phase+off[i])%1f;float yy=(-.08f+1.12f*q)*getHeight();float sway=(float)Math.sin((q*6.283f)+(i*.8f))*dp(2.5f);float size=dp(7+4*sc[i]);float xx=x[i]*getWidth()+sway-size/2;float edge=Math.min(1f,Math.min(q/.16f,(1f-q)/.18f));paint.setAlpha(Math.round(145*Math.max(0f,edge)));RectF dst=new RectF(xx,yy-size/2,xx+size,yy+size/2);c.drawBitmap(coin,null,dst,paint);}}
        private void start(){if(anim!=null||getVisibility()!=View.VISIBLE)return;anim=ValueAnimator.ofFloat(0f,1f);anim.setDuration(4200);anim.setRepeatCount(ValueAnimator.INFINITE);anim.setInterpolator(new android.view.animation.LinearInterpolator());anim.addUpdateListener(a->{phase=(Float)a.getAnimatedValue();invalidate();});anim.start();}
        private void stop(){if(anim!=null){anim.cancel();anim=null;}}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();start();}
        @Override protected void onVisibilityChanged(View changedView,int visibility){super.onVisibilityChanged(changedView,visibility);if(visibility==View.VISIBLE&&isAttachedToWindow())start();else stop();}
        @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
    }

    private void animateMissionCircleTap(final View v,final Runnable after){
        if(v==null){if(after!=null)after.run();return;}v.animate().cancel();
        AnimatorSet a=new AnimatorSet();a.playSequentially(
            ObjectAnimator.ofPropertyValuesHolder(v,PropertyValuesHolder.ofFloat("scaleX",1f,1.07f),PropertyValuesHolder.ofFloat("scaleY",1f,1.07f)),
            ObjectAnimator.ofPropertyValuesHolder(v,PropertyValuesHolder.ofFloat("scaleX",1.07f,.98f,1f),PropertyValuesHolder.ofFloat("scaleY",1.07f,.98f,1f))
        );a.setDuration(170);a.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());a.addListener(new AnimatorListenerAdapter(){@Override public void onAnimationEnd(Animator x){if(after!=null)after.run();}});a.start();
    }
    private void animateMissionLaunch(final String title,final Runnable end){
        if(root==null){if(end!=null)end.run();return;}
        final java.util.ArrayList<View> fx=new java.util.ArrayList<>();int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);int cx=rw/2,cy=Math.round(rh*.53f);
        View ring=new View(this);GradientDrawable rg=bg(0x18FFFFFF,dp(999));rg.setStroke(dp(2),0xAA42BEFF);ring.setBackground(rg);FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(156),dp(156));rp.leftMargin=cx-dp(78);rp.topMargin=cy-dp(78);root.addView(ring,rp);fx.add(ring);ring.setAlpha(0f);ring.setScaleX(.70f);ring.setScaleY(.70f);ring.animate().alpha(.92f).scaleX(1.04f).scaleY(1.04f).setDuration(650).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        TextView play=tv("▶",44,0xFF275CCB);GradientDrawable pg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFFF4FBFF,0xFFE9F0FF,0xFFF3ECFF});pg.setCornerRadius(dp(999));pg.setStroke(dp(2),0xAA45B9FF);play.setBackground(pg);play.setElevation(dp(8));FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(86),dp(86));pp.leftMargin=cx-dp(43);pp.topMargin=cy-dp(43);root.addView(play,pp);fx.add(play);play.setAlpha(0f);play.setScaleX(.72f);play.setScaleY(.72f);play.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).setInterpolator(new android.view.animation.OvershootInterpolator(.45f)).start();
        TextView cap=tv("MISSION START",17,0xFF204B9B);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(250),dp(40));cp.leftMargin=cx-dp(125);cp.topMargin=cy+dp(66);root.addView(cap,cp);fx.add(cap);cap.setAlpha(0f);cap.setTranslationY(dp(8));cap.animate().alpha(1f).translationY(0).setStartDelay(180).setDuration(430).start();
        TextView subt=tv(title==null?"":title,13,0xFF60718E);FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(280),dp(34));sp.leftMargin=cx-dp(140);sp.topMargin=cy+dp(98);root.addView(subt,sp);fx.add(subt);subt.setAlpha(0f);subt.animate().alpha(1f).setStartDelay(260).setDuration(400).start();
        missionHandler.postDelayed(()->{for(View v:fx)try{if(v.getParent() instanceof ViewGroup)((ViewGroup)v.getParent()).removeView(v);}catch(Exception ignored){}if(end!=null)end.run();},1250);
    }
    private GradientDrawable pastelButtonBg(int c1,int c2){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{c1,c2});g.setCornerRadius(dp(15));return g;
    }
    private GradientDrawable pastelCardBg(int accent){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFFF9FCFF,0xFFF0F5FF,0xFFF5F0FF});
        g.setCornerRadius(dp(24));
        int stroke=(accent&0x00FFFFFF)|0x55000000;
        g.setStroke(Math.max(1,dp(1)),stroke);
        return g;
    }
    private TextView dialogButton(String text,int c1,int c2,boolean light){
        TextView b=tv(text,14,light?0xFF17345D:Color.WHITE);b.setGravity(Gravity.CENTER);b.setBackground(pastelButtonBg(c1,c2));b.setElevation(dp(3));b.setPadding(dp(8),0,dp(8),0);return b;
    }
    private TextView rewardChip(String text,int textColor,int fill,int stroke){
        TextView v=tv(text,13,textColor);v.setGravity(Gravity.CENTER);GradientDrawable g=bg(fill,dp(13));g.setStroke(Math.max(1,dp(1)),stroke);v.setBackground(g);v.setPadding(dp(10),0,dp(10),0);return v;
    }
    private int popupIconResource(String icon){
        if(icon==null)return 0;
        if("♫".equals(icon))return R.drawable.popup_music;
        if("☑".equals(icon))return R.drawable.popup_subtask;
        if("🏆".equals(icon))return R.drawable.popup_trophy;
        if("◆".equals(icon))return R.drawable.popup_crystal;
        if("⌛".equals(icon))return R.drawable.popup_hourglass;
        if("↻".equals(icon))return R.drawable.popup_restore;
        if("⌫".equals(icon)||"×".equals(icon))return R.drawable.popup_delete;
        if("★".equals(icon))return R.drawable.popup_level;
        if("!".equals(icon))return R.drawable.popup_alert;
        if("✎".equals(icon))return R.drawable.popup_edit;
        return 0;
    }
    private Dialog buildPastelDialog(String icon,String title,String subtitle,int accent,View body,String positive,int positiveColor,Runnable positiveAction,String negative,Runnable negativeAction){
        final Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(18),dp(10),dp(18),dp(18));card.setBackground(pastelCardBg(accent));card.setElevation(dp(14));
        View strip=new View(this);strip.setBackground(pastelButtonBg(0xFF42C5FF,0xFF8A66FF));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(dp(92),dp(4));slp.bottomMargin=dp(5);card.addView(strip,slp);
        FrameLayout top=new FrameLayout(this);card.addView(top,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView close=tv("×",22,0xFF29436E);close.setGravity(Gravity.CENTER);GradientDrawable xg=bg(0x66FFFFFF,dp(999));xg.setStroke(Math.max(1,dp(1)),0x224B6A99);close.setBackground(xg);FrameLayout.LayoutParams xlp=new FrameLayout.LayoutParams(dp(38),dp(38),Gravity.RIGHT|Gravity.TOP);top.addView(close,xlp);
        final View ico;int iconRes=popupIconResource(icon);
        if(iconRes!=0){ImageView iv=new ImageView(this);iv.setImageResource(iconRes);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);iv.setPadding(dp(3),dp(3),dp(3),dp(3));ico=iv;}
        else{TextView it=tv(icon==null?"✦":icon,28,accent);it.setGravity(Gravity.CENTER);ico=it;}
        GradientDrawable ig=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFFF8FCFF,0xFFEAF3FF,0xFFF1ECFF});ig.setCornerRadius(dp(999));ig.setStroke(Math.max(1,dp(1)),0x664A8DFF);ico.setBackground(ig);ico.setElevation(dp(5));FrameLayout.LayoutParams ilp=new FrameLayout.LayoutParams(dp(58),dp(58),Gravity.CENTER);top.addView(ico,ilp);
        TextView t=tv(title==null?"":title,19,0xFF142C54);t.setGravity(Gravity.CENTER);card.addView(t,new LinearLayout.LayoutParams(-1,dp(35)));
        if(subtitle!=null&&subtitle.trim().length()>0){TextView sub=tv(subtitle,13,0xFF536785);sub.setGravity(Gravity.CENTER);sub.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);sub.setPadding(dp(6),0,dp(6),0);card.addView(sub,new LinearLayout.LayoutParams(-1,-2));}
        if(body!=null){LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,-2);blp.topMargin=dp(12);card.addView(body,blp);}
        final TextView[] positiveButton={null};
        if((positive!=null&&positive.length()>0)||(negative!=null&&negative.length()>0)){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(54));rlp.topMargin=dp(14);card.addView(row,rlp);
            if(positive!=null&&positive.length()>0){TextView ok=dialogButton(positive,positiveColor,0xFF7B61FF,false);positiveButton[0]=ok;LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(50),1f);lp.setMargins(dp(5),0,0,0);row.addView(ok,lp);ok.setOnClickListener(v->{d.dismiss();if(positiveAction!=null)positiveAction.run();});}
            if(negative!=null&&negative.length()>0){TextView no=dialogButton(negative,0xFFF8FAFF,0xFFEFF3FB,true);GradientDrawable ng=pastelButtonBg(0xFFF8FAFF,0xFFEFF3FB);ng.setStroke(Math.max(1,dp(1)),0x334D6B9A);no.setBackground(ng);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(50),1f);lp.setMargins(0,0,dp(5),0);row.addView(no,lp);no.setOnClickListener(v->{d.dismiss();if(negativeAction!=null)negativeAction.run();});}
        }
        close.setOnClickListener(v->d.dismiss());
        d.setContentView(card);d.setCanceledOnTouchOutside(true);
        d.setOnShowListener(x->{
            Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setWindowAnimations(R.style.PastelDialogAnimation);WindowManager.LayoutParams a=w.getAttributes();a.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(24),dp(400));a.height=WindowManager.LayoutParams.WRAP_CONTENT;a.gravity=Gravity.CENTER;a.dimAmount=.42f;w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setAttributes(a);}
            card.setAlpha(0f);card.setScaleX(.91f);card.setScaleY(.91f);card.setTranslationY(dp(28));card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0).setDuration(460).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            PropertyValuesHolder sx=PropertyValuesHolder.ofFloat("scaleX",.82f,1f),sy=PropertyValuesHolder.ofFloat("scaleY",.82f,1f);ObjectAnimator pulse=ObjectAnimator.ofPropertyValuesHolder(ico,sx,sy);pulse.setDuration(420);pulse.setStartDelay(80);pulse.start();
        });
        return d;
    }
    private void showPastelInputDialog(String title,String initial,Runnable afterSave,java.util.function.Consumer<String> saver){
        EditText input=new EditText(this);input.setSingleLine(true);input.setText(initial==null?"":initial);input.setSelection(input.getText().length());input.setTextSize(15);input.setTextColor(0xFF17345D);input.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);input.setPadding(dp(12),0,dp(12),0);GradientDrawable ig=bg(0xFFF5F8FF,dp(14));ig.setStroke(Math.max(1,dp(1)),0x443B7CFF);input.setBackground(ig);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.addView(input,new LinearLayout.LayoutParams(-1,dp(50)));
        final Dialog[] ref={null};ref[0]=buildPastelDialog("✎",title,"",0xFF4E8CFF,body,"ذخیره",0xFF3F8CFF,()->{String n=input.getText().toString().trim();if(n.length()>0){saver.accept(n);if(afterSave!=null)afterSave.run();}},"لغو",null);ref[0].show();
    }

    private void showHome(){
        stopMissionTimer();
        stopHomeActiveTicker();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome = true; isRunningMissionScreen=false;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        activeBar=null;progressMissionViews.clear();progressGuideViews.clear();progressHeroViews.clear();
        setContentView(root);
        root.setFitsSystemWindows(true);

        ImageView home=new ImageView(this); home.setImageResource(R.drawable.home_background);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // Legacy HUD reference final polish: premium RPG HUD.
        FrameLayout header=new FrameLayout(this);
        header.setPadding(dp(4),0,dp(4),0);
        header.setBackground(new HudBackground());
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(46),Gravity.TOP);
        hp.setMargins(dp(8),dp(4),dp(8),0);
        root.addView(header,hp);

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(1),0,dp(1),0);
        header.addView(row,new FrameLayout.LayoutParams(-1,-1));

        ImageView avatar=new ImageView(this);
        avatar.setImageResource(R.drawable.avatar_legacy);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        avatar.setContentDescription("آواتار"); avatar.setElevation(dp(2));
        LinearLayout.LayoutParams avLp=new LinearLayout.LayoutParams(dp(45),dp(45));
        avLp.setMargins(dp(2),0,dp(4),0); row.addView(avatar,avLp);

        loadGameState();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        hudLevel=tv("LV "+gameLevel,13,0xFFFFE7A0); TextView level=hudLevel;
        level.setGravity(Gravity.CENTER);
        level.setShadowLayer(dp(1),0,0,0x665E3A00);
        LinearLayout.LayoutParams levelLp=new LinearLayout.LayoutParams(dp(40),dp(34));
        levelLp.setMargins(0,0,dp(1),0); row.addView(level,levelLp);

        LinearLayout xpGroup=new LinearLayout(this);
        xpGroup.setOrientation(LinearLayout.VERTICAL);
        xpGroup.setGravity(Gravity.CENTER_VERTICAL);
        XpBarView xp=new XpBarView(this); hudXpBar=xp;
        xp.setProgress(gameXp,xpNeeded(gameLevel));
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(9));
        xpLp.setMargins(0,dp(4),0,0); xpGroup.addView(xp,xpLp);
        hudXpText=tv(gameXp+" / "+xpNeeded(gameLevel)+" XP",8,0xFFE5F7FF); TextView xpTxt=hudXpText;
        xpTxt.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        xpGroup.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(14)));
        LinearLayout.LayoutParams xpgLp=new LinearLayout.LayoutParams(dp(110),dp(35));
        xpgLp.setMargins(0,0,dp(3),0); row.addView(xpGroup,xpgLp);

        LinearLayout coinBox=glassCapsule();
        ImageView coinIcon=new ImageView(this);
        coinIcon.setImageResource(R.drawable.hud_coin); coinIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        coinBox.addView(coinIcon,new LinearLayout.LayoutParams(dp(24),dp(24)));
        hudCoinText=tv(String.valueOf(gameCoins),13,0xFFFFF3CF); TextView coin=hudCoinText; coin.setPadding(dp(1),0,0,0);
        coinBox.addView(coin,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(25));
        coinLp.setMargins(0,0,dp(1),0); row.addView(coinBox,coinLp);

        LinearLayout comboBox=glassCapsule();
        comboBox.setClickable(true);
        comboBox.setContentDescription("Combo");
        comboBox.setOnClickListener(v->showGameSettings());
        ImageView flame=new ImageView(this); flame.setImageResource(R.drawable.hud_flame);
        flame.setScaleType(ImageView.ScaleType.FIT_CENTER);
        comboBox.addView(flame,new LinearLayout.LayoutParams(dp(22),dp(25)));
        hudComboText=tv(String.valueOf(gameCombo),13,Color.WHITE); TextView combo=hudComboText; comboBox.addView(combo,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(44),dp(25));
        comboLp.setMargins(0,0,dp(1),0); row.addView(comboBox,comboLp);

        ImageView gear=new ImageView(this); gear.setImageResource(R.drawable.hud_gear);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER); gear.setPadding(dp(4),dp(4),dp(4),dp(4));
        gear.setContentDescription("تنظیمات");
        gear.setOnClickListener(v->showGameSettings());
        row.addView(gear,new LinearLayout.LayoutParams(dp(34),dp(40)));

        // Hit targets follow the six labels baked into the selected 768x1536 Home artwork.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=768f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            // The touch zones sit on the signboards and slightly above their text,
            // matching the new 768x1536 fantasy Home artwork.
            int hitW=Math.max(dp(112), Math.round(220f*scale));
            int hitH=Math.max(dp(48), Math.round(92f*scale));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=Math.round(offsetX + srcW*centers[i][0]*scale);
                int cy=Math.round(offsetY + srcH*centers[i][1]*scale);
                if(idx==0){CoinRainView rain=new CoinRainView(this);int rw2=Math.max(dp(72),Math.round(hitW*.62f)),rh2=Math.max(dp(42),Math.round(hitH*.90f));FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(rw2,rh2);gp.leftMargin=cx-rw2/2;gp.topMargin=cy-rh2/2-dp(6);content.addView(rain,gp);}
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-hitW/2; lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==MotionEvent.ACTION_DOWN){ v.setAlpha(.55f); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->transitionTo(()->{ if(idx==0) showProgressPath(); else showPlaceholder(names[idx]); })); content.addView(hit,lp);
            }
        });
        addActiveMissionBar();
        header.bringToFront();
        animatePageEnter(root);
    }

    private LinearLayout glassCapsule(){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0x3803080E,dp(12)); g.setStroke(dp(1),0x225D7180); box.setBackground(g);
        return box;
    }

    private class XpBarView extends View {
        private final Paint p=new Paint(1); private int value=0,max=100;
        XpBarView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void setProgress(int v,int m){ value=Math.max(0,v); max=Math.max(1,m); invalidate(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float h=getHeight(), r=h/2f; RectF track=new RectF(dp(1),dp(1),getWidth()-dp(1),h-dp(1));
            p.setStyle(Paint.Style.FILL); p.setColor(0xAA071522); c.drawRoundRect(track,r,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xAA5EB8E8); c.drawRoundRect(track,r,r,p);
            float frac=Math.min(1f,value/(float)max);
            if(frac>0f){ RectF fill=new RectF(track.left,track.top,track.left+track.width()*frac,track.bottom);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF25E6FF); p.setShadowLayer(dp(4),0,0,0xCC19D9FF); c.drawRoundRect(fill,r,r,p); p.clearShadowLayer(); }
            else { p.setStyle(Paint.Style.FILL); p.setColor(0xFF36E8FF); p.setShadowLayer(dp(3),0,0,0xAA28DFFF); c.drawCircle(track.left+dp(2),h/2f,dp(1.3f),p); p.clearShadowLayer(); }
        }
    }

    private class HudBackground extends android.graphics.drawable.Drawable {
        private final Paint fill=new Paint(1), stroke=new Paint(1), bottomGlow=new Paint(1), topAccent=new Paint(1);
        HudBackground(){
            fill.setColor(0xED08131F); fill.setStyle(Paint.Style.FILL);
            stroke.setColor(0x3D8398A6); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            bottomGlow.setColor(0xA027D5FF); bottomGlow.setStyle(Paint.Style.STROKE); bottomGlow.setStrokeWidth(dp(1));
            topAccent.setColor(0xF0E8BD62); topAccent.setStyle(Paint.Style.STROKE); topAccent.setStrokeWidth(dp(1));
        }
        private Path shape(){
            RectF b=new RectF(getBounds()); float c=dp(7); Path p=new Path();
            p.moveTo(b.left+c,b.top); p.lineTo(b.right-c,b.top); p.lineTo(b.right,b.top+c);
            p.lineTo(b.right,b.bottom-c); p.lineTo(b.right-c,b.bottom); p.lineTo(b.left+c,b.bottom);
            p.lineTo(b.left,b.bottom-c); p.lineTo(b.left,b.top+c); p.close(); return p;
        }
        @Override public void draw(Canvas c){
            RectF b=new RectF(getBounds()); Path p=shape(); c.drawPath(p,fill); c.drawPath(p,stroke);
            c.drawLine(b.left+dp(11),b.bottom-dp(1),b.right-dp(11),b.bottom-dp(1),bottomGlow);
            c.drawLine(b.left+dp(12),b.top+dp(1),b.right-dp(12),b.top+dp(1),topAccent);
        }
        @Override public void setAlpha(int a){} @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){ return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private class CoinView extends View {
        Paint p=new Paint(1); CoinView(android.content.Context c){super(c);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float r=Math.min(getWidth(),getHeight())*.43f, x=getWidth()/2f,y=getHeight()/2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFB82E); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xFFFFF0A8); c.drawCircle(x,y,r-dp(1),p);
            p.setColor(0xFFD98A00); c.drawCircle(x,y,r-dp(3),p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF8C5A00); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(10));
            c.drawText("L",x,y-(p.ascent()+p.descent())/2,p);
        }
    }

    private int gameLevel=1, gameXp=0, gameCoins=0, gameCombo=0, comboWindowMinutes=30; private long lastSuccessAt=0;
    private SharedPreferences gamePrefs;
    private int xpNeeded(int level){ return 100+Math.max(0,level-1)*50; }
    private void loadGameState(){ gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gameLevel=gamePrefs.getInt("level",1);gameXp=gamePrefs.getInt("xp",0);gameCoins=gamePrefs.getInt("coins",0);gameCombo=gamePrefs.getInt("combo",0);lastSuccessAt=gamePrefs.getLong("lastSuccessAt",0);comboWindowMinutes=gamePrefs.getInt("comboWindowMinutes",30);expireComboIfNeeded(); }
    private void saveGameState(){ if(gamePrefs==null)gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gamePrefs.edit().putInt("level",gameLevel).putInt("xp",gameXp).putInt("coins",gameCoins).putInt("combo",gameCombo).putLong("lastSuccessAt",lastSuccessAt).putInt("comboWindowMinutes",comboWindowMinutes).apply();updateHud(); }
    private void updateHud(){ if(hudLevel!=null)hudLevel.setText("LV "+gameLevel);if(hudXpBar!=null)hudXpBar.setProgress(gameXp,xpNeeded(gameLevel));if(hudXpText!=null)hudXpText.setText(gameXp+" / "+xpNeeded(gameLevel)+" XP");if(hudCoinText!=null)hudCoinText.setText(String.valueOf(gameCoins));if(hudComboText!=null)hudComboText.setText(String.valueOf(gameCombo)); }
    private void showHudState(int level,int xp,int coins,int combo){if(hudLevel!=null)hudLevel.setText("LV "+level);if(hudXpBar!=null)hudXpBar.setProgress(xp,xpNeeded(level));if(hudXpText!=null)hudXpText.setText(xp+" / "+xpNeeded(level)+" XP");if(hudCoinText!=null)hudCoinText.setText(String.valueOf(coins));if(hudComboText!=null)hudComboText.setText(String.valueOf(combo));}
    private void pulseHudRewards(){View[] vs={hudXpText,hudCoinText,hudComboText,hudLevel};for(View v:vs)if(v!=null){v.setScaleX(1f);v.setScaleY(1f);v.animate().scaleX(1.20f).scaleY(1.20f).setDuration(420).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(620).start()).start();}if(hudXpBar!=null){hudXpBar.setScaleY(1f);hudXpBar.animate().scaleY(1.55f).setDuration(420).withEndAction(()->hudXpBar.animate().scaleY(1f).setDuration(620).start()).start();}}
    private float comboMultiplier(){return gameCombo>=10?3f:gameCombo>=7?2f:gameCombo>=3?1.5f:1f;}
    private void expireComboIfNeeded(){if(gameCombo>0&&lastSuccessAt>0&&System.currentTimeMillis()-lastSuccessAt>comboWindowMinutes*60000L){gameCombo=0;lastSuccessAt=0;if(gamePrefs!=null)gamePrefs.edit().putInt("combo",0).putLong("lastSuccessAt",0).apply();}}

    private int[] missionTimes={5,10,20,30,45};
    private String mf(int s,int k,String f){return "m_"+s+"_"+k+"_"+f;}
    private String mv(int s,int k,String f,String d){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);return progressPrefs.getString(mf(s,k,f),d);}
    private void ms(int s,int k,String f,String v){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);progressPrefs.edit().putString(mf(s,k,f),v).apply();}
    private GradientDrawable sel(boolean on){GradientDrawable g=bg(Color.TRANSPARENT,dp(999));if(on)g.setStroke(Math.max(1,Math.round(dp(.55f))),0xFF2477E8);return g;}
    private TextView eh(String t,int z){TextView v=tv(t,z,0xFF17345D);v.setGravity(Gravity.CENTER);return v;}

    private String missionDay(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US);return f.format(new java.util.Date());}
    private void startDailyResetTicker(){
        if(dailyResetTick!=null)missionHandler.removeCallbacks(dailyResetTick);
        lastObservedMissionDay=missionDay();
        dailyResetTick=new Runnable(){public void run(){
            String nowDay=missionDay();
            if(!nowDay.equals(lastObservedMissionDay)){lastObservedMissionDay=nowDay;applyDailyMissionResets();refreshProgressMissionVisuals();}
            missionHandler.postDelayed(this,60000L);
        }};
        missionHandler.postDelayed(dailyResetTick,60000L);
    }
    private String missionState(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressTitle(section,slot).trim().length()==0)return "empty";
        if(progressPrefs.getBoolean("active",false)&&progressPrefs.getInt("active_s",-1)==section&&progressPrefs.getInt("active_k",-1)==slot)return "active";
        String state=mv(section,slot,"state","ready");
        if("active".equals(state))state="ready";
        return state;
    }
    private void setMissionState(int section,int slot,String state){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        SharedPreferences.Editor ed=progressPrefs.edit().putString(mf(section,slot,"state"),state);
        if("done".equals(state)||"fail".equals(state))ed.putString(mf(section,slot,"state_day"),missionDay());
        else ed.remove(mf(section,slot,"state_day"));
        ed.apply();
    }

    private void saveMissionRewardSnapshot(int section,int slot){
        if(section<1||slot<0)return;if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit()
            .putBoolean(mf(section,slot,"reward_snapshot"),true)
            .putInt(mf(section,slot,"prev_level"),gameLevel)
            .putInt(mf(section,slot,"prev_xp"),gameXp)
            .putInt(mf(section,slot,"prev_coins"),gameCoins)
            .putInt(mf(section,slot,"prev_combo"),gameCombo)
            .putLong(mf(section,slot,"prev_last_success"),lastSuccessAt)
            .putInt(mf(section,slot,"reward_xp"),0)
            .putInt(mf(section,slot,"reward_coins"),0)
            .remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at"))
            .apply();
    }
    private void recordMissionReward(int section,int slot,int xp,int coins){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putInt(mf(section,slot,"reward_xp"),xp).putInt(mf(section,slot,"reward_coins"),coins)
            .putString(mf(section,slot,"reward_outcome"),xp>0?"done":"fail").putLong(mf(section,slot,"reward_at"),System.currentTimeMillis()).apply();
    }
    private long lifetimeXp(){long total=gameXp;for(int l=1;l<gameLevel;l++)total+=xpNeeded(l);return total;}
    private void setLifetimeXp(long total){total=Math.max(0,total);int level=1;while(total>=xpNeeded(level)){total-=xpNeeded(level);level++;if(level>10000)break;}gameLevel=level;gameXp=(int)Math.max(0,total);}
    private void clearMissionRewardSnapshot(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit()
            .remove(mf(section,slot,"reward_snapshot")).remove(mf(section,slot,"prev_level")).remove(mf(section,slot,"prev_xp"))
            .remove(mf(section,slot,"prev_coins")).remove(mf(section,slot,"prev_combo")).remove(mf(section,slot,"prev_last_success"))
            .remove(mf(section,slot,"reward_xp")).remove(mf(section,slot,"reward_coins")).remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at")).apply();
    }
    private void restoreMissionAndRewards(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressPrefs.getBoolean(mf(section,slot,"reward_snapshot"),false)){
            int earnedXp=progressPrefs.getInt(mf(section,slot,"reward_xp"),0),earnedCoins=progressPrefs.getInt(mf(section,slot,"reward_coins"),0),prevCombo=progressPrefs.getInt(mf(section,slot,"prev_combo"),gameCombo);long prevLast=progressPrefs.getLong(mf(section,slot,"prev_last_success"),lastSuccessAt),rewardAt=progressPrefs.getLong(mf(section,slot,"reward_at"),0);String outcome=progressPrefs.getString(mf(section,slot,"reward_outcome"),earnedXp>0?"done":"fail");
            if(earnedXp>0)setLifetimeXp(lifetimeXp()-earnedXp);if(earnedCoins>0)gameCoins=Math.max(0,gameCoins-earnedCoins);
            if("done".equals(outcome)){
                if(rewardAt>0&&Math.abs(lastSuccessAt-rewardAt)<2500){gameCombo=prevCombo;lastSuccessAt=prevLast;}else if(gameCombo>0)gameCombo=Math.max(0,gameCombo-1);
            }else if("fail".equals(outcome)){
                if(lastSuccessAt==0||lastSuccessAt<=rewardAt){gameCombo=prevCombo;lastSuccessAt=prevLast;}
            }
            saveGameState();
        }
        clearMissionRewardSnapshot(section,slot);setMissionState(section,slot,"ready");showProgressPath();animateRestoreFeedback();
    }
    private LinearLayout restoreRewardBody(int section,int slot){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);body.addView(row,new LinearLayout.LayoutParams(-1,dp(46)));
        int xp=progressPrefs.getInt(mf(section,slot,"reward_xp"),0),coins=progressPrefs.getInt(mf(section,slot,"reward_coins"),0),prevCombo=progressPrefs.getInt(mf(section,slot,"prev_combo"),gameCombo);
        TextView a=rewardChip((xp>0?"−":"")+xp+" XP",0xFF0878D8,0xFFEAF7FF,0x553C9DFF);TextView b=rewardChip((coins>0?"−":"")+coins+" Coin",0xFFB57700,0xFFFFF7DF,0x55E5B42B);TextView c=rewardChip("Combo → "+prevCombo,0xFF9A4C17,0xFFFFF0E6,0x55FF9A53);
        row.addView(a,new LinearLayout.LayoutParams(0,dp(38),1f));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(0,dp(38),1f);blp.setMargins(dp(6),0,dp(6),0);row.addView(b,blp);row.addView(c,new LinearLayout.LayoutParams(0,dp(38),1f));return body;
    }
    private void showRestoreMissionDialog(int section,int slot){
        Dialog d=buildPastelDialog("↻","Restore Mission?",progressTitle(section,slot),0xFF26A8F2,restoreRewardBody(section,slot),"Restore",0xFF2D9DFF,()->restoreMissionAndRewards(section,slot),"Cancel",null);d.show();
    }
    private void showDeleteMissionDialog(int section,int slot){
        Dialog d=buildPastelDialog("⌫","Delete Mission?",progressTitle(section,slot),0xFFFF6078,null,"Delete",0xFFFF5268,()->{clearMissionSlot(section,slot);showProgressPath();},"Cancel",null);d.show();
    }
    private void showActiveMissionWarning(){
        Dialog d=buildPastelDialog("!","یک مأموریت در حال اجراست","ابتدا مأموریت فعلی را تعیین تکلیف کنید",0xFFFF6B82,null,"ادامه مأموریت",0xFF4E8CFF,()->transitionTo(()->resumeActiveMission()),"بستن",null);d.show();
    }
    private void showCompletedMissionLockedDialog(String title){
        Dialog d=buildPastelDialog("✓","نتیجه ثبت شده",title+"  •  Restore برای اجرای دوباره",0xFF6B8FFF,null,"باشه",0xFF4E8CFF,null,null,null);d.show();
    }
    private void applyDailyMissionResets(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        String today=missionDay();
        int count=Math.max(1,progressPrefs.getInt("progress_section_count",1));
        for(int s=1;s<=count;s++)for(int k=0;k<3;k++){
            if(progressTitle(s,k).trim().length()==0)continue;
            if(!"1".equals(mv(s,k,"repeat","1")))continue;
            String state=missionState(s,k);
            if(!("done".equals(state)||"fail".equals(state)))continue;
            String day=mv(s,k,"state_day","");
            if(!today.equals(day)){
                setMissionState(s,k,"ready");
                clearMissionRewardSnapshot(s,k);
                SharedPreferences sub=getSharedPreferences("legacy_subtasks_"+s+"_"+k,MODE_PRIVATE);
                sub.edit().putString("day",today).putString("done_ids","").apply();
            }
        }
    }
    private String missionViewKey(int section,int slot){return section+":"+slot;}
    private void styleMissionSlot(TextView mission,String state){
        mission.setShadowLayer(0,0,0,Color.TRANSPARENT);
        mission.setPaintFlags(mission.getPaintFlags()&~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        GradientDrawable g=bg(Color.TRANSPARENT,dp(999));
        if("active".equals(state)){g.setColor(0x16168CFF);g.setStroke(dp(3),0xFF168CFF);mission.setTextColor(0xFF0E66D0);mission.setShadowLayer(dp(3),0,0,0x55168CFF);}
        else if("done".equals(state)){g.setColor(0x1200C853);g.setStroke(dp(3),0xFF13B85B);mission.setTextColor(0xFF078A43);mission.setPaintFlags(mission.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);}
        else if("fail".equals(state)){g.setColor(0x12FF1744);g.setStroke(dp(3),0xFFE83E55);mission.setTextColor(0xFFBD2639);mission.setPaintFlags(mission.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);}
        else{mission.setTextColor(0xFF162D54);}
        mission.setBackground(g);
    }
    private void refreshProgressMissionVisuals(){
        if(progressMissionViews.isEmpty())return;
        for(java.util.Map.Entry<String,TextView> entry:progressMissionViews.entrySet()){
            try{String[] p=entry.getKey().split(":");int s=Integer.parseInt(p[0]),k=Integer.parseInt(p[1]);TextView v=entry.getValue();v.setText(progressTitle(s,k));styleMissionSlot(v,missionState(s,k));}catch(Exception ignored){}
        }refreshProgressMissionGuides();
    }
    private TextView popupActionRow(String icon,String text,int textColor,int fill,int stroke){
        TextView v=tv(icon+"   "+text,14,textColor);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(dp(16),0,dp(16),0);GradientDrawable g=bg(fill,dp(14));g.setStroke(Math.max(1,dp(1)),stroke);v.setBackground(g);v.setElevation(dp(1));return v;
    }
    private void showMissionSlotMenu(final int section,final int slot){
        String title=progressTitle(section,slot);if(title.trim().length()==0){transitionTo(()->showMissionEditor(section,slot));return;}
        String state=missionState(section,slot);if("active".equals(state)){resumeActiveMission();return;}
        int minutes=10;try{minutes=Integer.parseInt(mv(section,slot,"minutes","10"));}catch(Exception ignored){}
        String repeat="1".equals(mv(section,slot,"repeat","1"))?"Daily":"One-time";
        String stateText="ready".equals(state)?"Ready":"done".equals(state)?"Completed":"fail".equals(state)?"Failed":state;
        int stateColor="done".equals(state)?0xFF2DAE78:"fail".equals(state)?0xFFE4546F:0xFF357EEB;
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.HORIZONTAL);info.setGravity(Gravity.CENTER);info.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);body.addView(info,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView st=rewardChip(stateText,stateColor,0xFFF2F7FF,0x334D8DFF);TextView tm=rewardChip("◷  "+minutes+" min",0xFF38547B,0xFFF5F8FF,0x334D6B9A);TextView rp=rewardChip("↻  "+repeat,0xFF5B54A7,0xFFF5F1FF,0x336F63C7);info.addView(st,new LinearLayout.LayoutParams(0,dp(38),1f));LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(0,dp(38),1f);ilp.setMargins(dp(5),0,dp(5),0);info.addView(tm,ilp);info.addView(rp,new LinearLayout.LayoutParams(0,dp(38),1f));
        final Dialog[] dlg={null};
        if("done".equals(state)||"fail".equals(state)){TextView restore=popupActionRow("↻","Restore",0xFF226DD1,0xFFEAF5FF,0x6647A1FF);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.topMargin=dp(8);body.addView(restore,lp);restore.setOnClickListener(v->{if(dlg[0]!=null)dlg[0].dismiss();showRestoreMissionDialog(section,slot);});}
        TextView edit=popupActionRow("✎","ویرایش مأموریت",0xFF2B4F86,0xFFF6F8FF,0x334F77B8);LinearLayout.LayoutParams elp=new LinearLayout.LayoutParams(-1,dp(50));elp.topMargin=dp(7);body.addView(edit,elp);edit.setOnClickListener(v->{if(dlg[0]!=null)dlg[0].dismiss();missionHandler.postDelayed(()->transitionTo(()->showMissionEditor(section,slot)),220);});
        TextView del=popupActionRow("⌫","حذف مأموریت",0xFFD13F58,0xFFFFF1F4,0x55FF6C82);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,dp(50));dlp.topMargin=dp(7);body.addView(del,dlp);del.setOnClickListener(v->{if(dlg[0]!=null)dlg[0].dismiss();showDeleteMissionDialog(section,slot);});
        String flag="done".equals(state)?"✓":"fail".equals(state)?"◆":"⚑";int accent="done".equals(state)?0xFF48C89B:"fail".equals(state)?0xFFFF6B82:0xFF4C8DFF;
        dlg[0]=buildPastelDialog(flag,"Mission Details",title,accent,body,"بستن",0xFF4A8EFF,null,null,null);dlg[0].show();
    }
    private void confirmDeleteMission(final int section,final int slot){showDeleteMissionDialog(section,slot);}

    private void showMissionEditor(final int section,final int slot){
        stopHomeActiveTicker();
        isHome=false;isRunningMissionScreen=false;++homeGeneration;getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);content.removeAllViews();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);applyDailyMissionResets();
        FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(R.drawable.mission_editor_reference);art.setScaleType(ImageView.ScaleType.FIT_XY);
        e.addView(art,new FrameLayout.LayoutParams(-1,-1));

        final String old=progressTitle(section,slot);
        final String entryState=missionState(section,slot);
        final boolean resultLocked="done".equals(entryState)||"fail".equals(entryState);
        final EditText title=new EditText(this);title.setSingleLine(true);title.setText(old.length()==0?"عنوان":old);
        title.setTextSize(15);title.setTextColor(0xFF17345D);title.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        title.setPadding(dp(8),0,dp(8),0);title.setBackgroundColor(Color.TRANSPARENT);title.setLongClickable(false);title.setTextIsSelectable(false);
        if(android.os.Build.VERSION.SDK_INT>=29){
            try{
                title.setTextCursorDrawable(getDrawable(R.drawable.editor_cursor));
                title.setTextSelectHandle(getDrawable(R.drawable.editor_handle_invisible));
                title.setTextSelectHandleLeft(getDrawable(R.drawable.editor_handle_invisible));
                title.setTextSelectHandleRight(getDrawable(R.drawable.editor_handle_invisible));
            }catch(Exception ignored){}
        }
        FrameLayout.LayoutParams tl=new FrameLayout.LayoutParams(0,0);e.addView(title,tl);

        final TextView circleTitle=eh(old,16);circleTitle.setTextColor(0xFF17345D);circleTitle.setTranslationX(dp(2.5f));circleTitle.setTranslationY(-dp(1.5f));
        FrameLayout.LayoutParams cl=new FrameLayout.LayoutParams(0,0);e.addView(circleTitle,cl);

        // Every truly new/empty mission starts from the agreed defaults.
        if(old.trim().length()==0){
            progressPrefs.edit()
                .putString(mf(section,slot,"importance"),"0")
                .putString(mf(section,slot,"minutes"),"10")
                .putString(mf(section,slot,"repeat"),"1")
                .putString(mf(section,slot,"state"),"ready")
                .remove(mf(section,slot,"state_day"))
                .apply();
        }
        final int[] imp={Integer.parseInt(mv(section,slot,"importance","0"))};
        final TextView[] iv={eh("",1),eh("",1),eh("",1)};
        for(TextView v:iv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        int saved=Integer.parseInt(mv(section,slot,"minutes","10"));final int[] ti={1};
        for(int i=0;i<missionTimes.length;i++)if(missionTimes[i]==saved)ti[0]=i;
        final TextView minus=eh("",1),time=eh(missionTimes[ti[0]]+" دقیقه",15),plus=eh("",1);time.setTranslationY(0f);
        e.addView(minus,new FrameLayout.LayoutParams(0,0));e.addView(time,new FrameLayout.LayoutParams(0,0));e.addView(plus,new FrameLayout.LayoutParams(0,0));

        final int[] rp={Integer.parseInt(mv(section,slot,"repeat","1"))};
        final TextView[] rv={eh("",1),eh("",1)};
        for(TextView v:rv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        final CoinRainView startRain=new CoinRainView(this);startRain.setVisibility(resultLocked?View.INVISIBLE:View.VISIBLE);e.addView(startRain,new FrameLayout.LayoutParams(0,0));
        final TextView start=eh("Start Mission",1);start.setTextColor(Color.TRANSPARENT);start.setBackgroundColor(Color.TRANSPARENT);
        e.addView(start,new FrameLayout.LayoutParams(0,0));start.bringToFront();

        // Exact responsive hit areas from the approved 768x1536 artwork.
        e.addOnLayoutChangeListener((v,l,t,r,bt,ol,ot,or,ob)->{
            int w=e.getWidth(),h=e.getHeight();
            java.util.function.BiConsumer<View,float[]> place=(view,q)->{
                FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();
                p.width=Math.round(w*q[2]);p.height=Math.round(h*q[3]);
                p.leftMargin=Math.round(w*q[0]);p.topMargin=Math.round(h*q[1]);view.setLayoutParams(p);
            };
            place.accept(title,new float[]{.379f,.410f,.440f,.040f});
            // Calibrated against the supplied phone screenshot: label box matches the full cyan circle.
            place.accept(circleTitle,new float[]{.523f,.152f,.337f,.164f});
            // Pixel-calibrated to the colored pills in the 768x1536 reference artwork.
            place.accept(iv[0],new float[]{.388f,.493f,.159f,.0385f});
            place.accept(iv[1],new float[]{.574f,.493f,.163f,.0385f});
            place.accept(iv[2],new float[]{.763f,.493f,.160f,.0385f});
            place.accept(minus,new float[]{.382f,.565f,.090f,.055f});
            place.accept(time,new float[]{.470f,.571f,.250f,.055f});
            place.accept(plus,new float[]{.718f,.565f,.090f,.055f});
            place.accept(rv[0],new float[]{.396f,.665f,.237f,.038f});
            place.accept(rv[1],new float[]{.663f,.665f,.253f,.038f});
            place.accept(startRain,new float[]{.285f,.790f,.430f,.060f});
            place.accept(start,new float[]{.130f,.785f,.740f,.075f});
        });

        // Defaults are visible immediately.
        for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));
        for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));
        time.setText(missionTimes[ti[0]]+" دقیقه");

        title.setOnFocusChangeListener((v,has)->{
            if(has&&"عنوان".contentEquals(title.getText()))title.setText("");
            if(!has){String x=title.getText().toString().trim();
                if(x.length()==0){
                    if(resultLocked){title.setText(old);circleTitle.setText(old);}
                    else{title.setText("عنوان");circleTitle.setText("");progressPrefs.edit().remove("title_"+section+"_"+slot).putString(mf(section,slot,"state"),"ready").remove(mf(section,slot,"state_day")).apply();}
                }else{progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();if(!resultLocked&&"empty".equals(missionState(section,slot)))setMissionState(section,slot,"ready");circleTitle.setText(x);}
            }
        });
        title.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence x,int a,int b,int c){}
            public void onTextChanged(CharSequence x,int a,int b,int c){String q=x.toString().trim();circleTitle.setText("عنوان".equals(q)?"":q);}
            public void afterTextChanged(android.text.Editable x){}
        });
        for(int i=0;i<3;i++){final int q=i;iv[i].setClickable(true);iv[i].setOnClickListener(v->{imp[0]=q;ms(section,slot,"importance",""+q);for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));});}
        minus.setClickable(true);plus.setClickable(true);
        minus.setOnClickListener(v->{if(ti[0]>0)ti[0]--;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        plus.setOnClickListener(v->{if(ti[0]<missionTimes.length-1)ti[0]++;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        for(int i=0;i<2;i++){final int q=i;rv[i].setClickable(true);rv[i].setOnClickListener(v->{rp[0]=q;ms(section,slot,"repeat",""+q);for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));});}
        start.setClickable(true);start.setOnClickListener(v->{
            String x=title.getText().toString().trim();
            if(x.length()==0||"عنوان".equals(x)){Toast.makeText(this,"عنوان مأموریت را وارد کنید",Toast.LENGTH_SHORT).show();return;}
            progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();
            if("empty".equals(missionState(section,slot)))setMissionState(section,slot,"ready");
            hideKeyboard(title);
            if(resultLocked){showCompletedMissionLockedDialog(x);return;}
            if(progressPrefs.getBoolean("active",false)){
                int as=progressPrefs.getInt("active_s",-1),ak=progressPrefs.getInt("active_k",-1);
                if(as==section&&ak==slot){resumeActiveMission();return;}
                showActiveMissionWarning();return;
            }
            clearMissionRewardSnapshot(section,slot);
            start.setClickable(false);final int mm=missionTimes[ti[0]];animateMissionLaunch(x,()->startRunningMission(section,slot,x,mm));
        });
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
        animatePageEnter(content);
    }

    private void hideKeyboard(View v){
        try{((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}
    }

    private android.os.Handler missionHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable missionTick;
    private android.media.MediaPlayer missionPlayer; private boolean missionMuted=false; private static final int REQ_MISSION_MUSIC=9042;

    private class MissionProgressView extends View {
        private final Paint p=new Paint(1); private float fraction=0f;
        MissionProgressView(android.content.Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setFraction(float f){fraction=Math.max(0f,Math.min(1f,f));invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float sw=dp(8),pad=sw/2f+dp(3);RectF r=new RectF(pad,pad,getWidth()-pad,getHeight()-pad);
            p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(sw);p.setColor(0xFFF8FBFF);c.drawArc(r,-90,360,false,p);
            if(fraction>0f){p.setColor(0xFF168CFF);p.setShadowLayer(dp(5),0,0,0x77168CFF);c.drawArc(r,-90,360f*fraction,false,p);p.clearShadowLayer();}
            float a=(float)Math.toRadians(-90+360f*fraction),cx=r.centerX()+r.width()/2f*(float)Math.cos(a),cy=r.centerY()+r.height()/2f*(float)Math.sin(a);
            p.setStyle(Paint.Style.FILL);p.setColor(0xFF087EF2);p.setShadowLayer(dp(5),0,0,0x99168CFF);c.drawCircle(cx,cy,dp(7),p);p.clearShadowLayer();
        }
    }

    private void startRunningMission(final int section,final int slot,final String title,final int minutes){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressPrefs.getBoolean("active",false)){
            int as=progressPrefs.getInt("active_s",-1),ak=progressPrefs.getInt("active_k",-1);
            if(as==section&&ak==slot){resumeActiveMission();return;}
            showActiveMissionWarning();
            return;
        }
        setMissionState(section,slot,"ready");
        final long total=minutes*60000L;
        final long endAt=System.currentTimeMillis()+total;
        progressPrefs.edit()
            .putBoolean("active",true)
            .putInt("active_s",section)
            .putInt("active_k",slot)
            .putString("active_title",title)
            .putLong("active_end",endAt)
            .putLong("active_total",total)
            .putBoolean("active_alerted",false)
            .apply();
        ensureNotificationPermission();
        cancelMissionNotification();
        scheduleMissionAlarm(endAt);
        showRunningMissionScreen(section,slot,title,endAt,total);
    }

    private void resumeActiveMission(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(!progressPrefs.getBoolean("active",false)){Toast.makeText(this,"ماموریت فعالی وجود ندارد",Toast.LENGTH_SHORT).show();showProgressPath();return;}
        int section=progressPrefs.getInt("active_s",-1),slot=progressPrefs.getInt("active_k",-1);
        long endAt=progressPrefs.getLong("active_end",0),total=progressPrefs.getLong("active_total",0);
        String title=progressPrefs.getString("active_title","");
        if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        if(section<1||slot<0||endAt<=0||total<=0){clearActiveMissionState();Toast.makeText(this,"اطلاعات مأموریت فعال ناقص بود",Toast.LENGTH_SHORT).show();showProgressPath();return;}
        showRunningMissionScreen(section,slot,title,endAt,total);
    }

    private void showRunningMissionScreen(final int section,final int slot,final String title,final long endAt,final long total){
        stopHomeActiveTicker();
        removeActiveMissionBar();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        isHome=false;isRunningMissionScreen=true;++homeGeneration;content.removeAllViews();
        final FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(R.drawable.mission_running_reference);art.setScaleType(ImageView.ScaleType.FIT_XY);e.addView(art,new FrameLayout.LayoutParams(-1,-1));
        final TextView missionTitle=eh(title,16);missionTitle.setTextColor(0xFF17345D);e.addView(missionTitle,new FrameLayout.LayoutParams(0,0));
        final MissionProgressView ring=new MissionProgressView(this);e.addView(ring,new FrameLayout.LayoutParams(0,0));
        final TextView timer=eh("",34);timer.setTextColor(0xFF071A4A);e.addView(timer,new FrameLayout.LayoutParams(0,0));
        final View done=new View(this),fail=new View(this),music=new View(this),sound=new View(this),reset=new View(this),subtasks=new View(this);
        done.setContentDescription("Done");fail.setContentDescription("Fail");music.setContentDescription("Choose music");sound.setContentDescription("Sound on/off");reset.setContentDescription("Reset mission");subtasks.setContentDescription("Subtasks");
        e.addView(done,new FrameLayout.LayoutParams(0,0));e.addView(fail,new FrameLayout.LayoutParams(0,0));e.addView(music,new FrameLayout.LayoutParams(0,0));e.addView(sound,new FrameLayout.LayoutParams(0,0));e.addView(reset,new FrameLayout.LayoutParams(0,0));e.addView(subtasks,new FrameLayout.LayoutParams(0,0));
        e.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{int w=e.getWidth(),h=e.getHeight();java.util.function.BiConsumer<View,float[]> place=(view,q)->{FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();p.width=Math.round(w*q[2]);p.height=Math.round(h*q[3]);p.leftMargin=Math.round(w*q[0]);p.topMargin=Math.round(h*q[1]);view.setLayoutParams(p);};
            place.accept(missionTitle,new float[]{.565f,.113f,.330f,.155f});
            place.accept(ring,new float[]{.238f,.442f,.525f,.263f});
            place.accept(timer,new float[]{.270f,.505f,.460f,.120f});
            place.accept(done,new float[]{.135f,.690f,.240f,.130f});place.accept(fail,new float[]{.625f,.690f,.240f,.130f});
            place.accept(music,new float[]{.105f,.842f,.165f,.090f});place.accept(sound,new float[]{.285f,.842f,.165f,.090f});place.accept(reset,new float[]{.545f,.842f,.165f,.090f});place.accept(subtasks,new float[]{.725f,.842f,.165f,.090f});
        });
        missionMuted=missionAudioPrefs().getBoolean("muted",false);
        playSavedMissionMusic();
        if(missionTick!=null)missionHandler.removeCallbacks(missionTick);
        missionTick=new Runnable(){public void run(){
            long rem=Math.max(0,endAt-System.currentTimeMillis());
            long elapsed=Math.min(total,Math.max(0,total-rem));
            ring.setFraction(total<=0?1f:elapsed/(float)total);
            long sec=(rem+999)/1000;
            timer.setText(String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60));
            if(rem>0)missionHandler.postDelayed(this,250);
            else{
                timer.setText("00:00");
                ring.setFraction(1f);
                stopMissionMusic();
                if(progressPrefs!=null&&!progressPrefs.getBoolean("active_alerted",false))finishMissionTimerAlert();
            }
        }};missionHandler.post(missionTick);
        done.setOnClickListener(v->completeMission(true));fail.setOnClickListener(v->completeMission(false));
        music.setOnClickListener(v->chooseMissionMusic());
        sound.setOnClickListener(v->{
            missionMuted=!missionMuted;
            missionAudioPrefs().edit().putBoolean("muted",missionMuted).apply();
            if(missionPlayer!=null)missionPlayer.setVolume(missionMuted?0f:1f,missionMuted?0f:1f);
            Toast.makeText(this,missionMuted?"صدا قطع شد":"صدا وصل شد",Toast.LENGTH_SHORT).show();
        });
        reset.setOnClickListener(v->showLaterConfirm(section,slot,title));
        subtasks.setOnClickListener(v->showSubtasksPopup(section,slot));
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
        animatePageEnter(content);
    }

    private SharedPreferences missionAudioPrefs(){
        return getSharedPreferences("legacy_mission_audio",MODE_PRIVATE);
    }
    private final int[] defaultFocusMusic={R.raw.focus_deep,R.raw.focus_calm,R.raw.focus_flow};
    private final String[] defaultFocusMusicNames={"انرژیک • 2:00","آرام • 2:00","متعادل • 2:00"};

    private String selectedMissionMusic(){
        SharedPreferences sp=missionAudioPrefs();
        String selected=sp.getString("selected","");
        if(selected.length()==0){
            // One-time migration from the v43 single-URI setting.
            String old=sp.getString("uri","");
            if(old.length()>0){
                selected="u:"+old;
                addUserMusicTrack(old,displayNameForUri(android.net.Uri.parse(old)));
            }else selected="d:0";
            sp.edit().putString("selected",selected).apply();
        }
        return selected;
    }
    private java.util.ArrayList<String[]> loadUserMusicTracks(){
        java.util.ArrayList<String[]> out=new java.util.ArrayList<>();
        String raw=missionAudioPrefs().getString("user_tracks","");
        for(String line:raw.split("\n")){
            if(line.trim().length()==0)continue;
            String[] parts=line.split("\t",2);
            if(parts.length<2)continue;
            try{
                out.add(new String[]{android.net.Uri.decode(parts[0]),android.net.Uri.decode(parts[1])});
            }catch(Exception ignored){}
        }
        return out;
    }
    private void saveUserMusicTracks(java.util.ArrayList<String[]> tracks){
        java.util.ArrayList<String> lines=new java.util.ArrayList<>();
        for(String[] x:tracks){
            if(x==null||x.length<2||x[0]==null||x[0].trim().length()==0)continue;
            lines.add(android.net.Uri.encode(x[0])+"\t"+android.net.Uri.encode(x[1]==null?"موسیقی":x[1]));
        }
        missionAudioPrefs().edit().putString("user_tracks",android.text.TextUtils.join("\n",lines)).apply();
    }
    private void addUserMusicTrack(String uri,String name){
        if(uri==null||uri.trim().length()==0)return;
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        for(String[] x:tracks)if(uri.equals(x[0]))return;
        tracks.add(new String[]{uri,(name==null||name.trim().length()==0)?"موسیقی گوشی":name.trim()});
        saveUserMusicTracks(tracks);
    }
    private void removeUserMusicTrack(String uri){
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        java.util.ArrayList<String[]> keep=new java.util.ArrayList<>();
        for(String[] x:tracks)if(!uri.equals(x[0]))keep.add(x);
        saveUserMusicTracks(keep);
        if(("u:"+uri).equals(selectedMissionMusic())){
            missionAudioPrefs().edit().putString("selected","d:0").apply();
            playMissionDefault(0);
        }
    }
    private String displayNameForUri(android.net.Uri uri){
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);
            if(c!=null&&c.moveToFirst()){
                int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if(i>=0){String n=c.getString(i);if(n!=null&&n.trim().length()>0)return n;}
            }
        }catch(Exception ignored){}finally{try{if(c!=null)c.close();}catch(Exception ignored){}}
        String last=uri==null?null:uri.getLastPathSegment();
        return last==null?"موسیقی گوشی":last;
    }

    private void showMissionMusicPicker(){
        final LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(4),0,dp(4),dp(2));outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final Dialog[] dlg={null};String selected=selectedMissionMusic();
        TextView defaultHead=tv("Focus Music (Default)",12,0xFF536785);defaultHead.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);defaultHead.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);outer.addView(defaultHead,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout tiles=new LinearLayout(this);tiles.setOrientation(LinearLayout.HORIZONTAL);tiles.setGravity(Gravity.CENTER);tiles.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);outer.addView(tiles,new LinearLayout.LayoutParams(-1,dp(112)));
        String[] glyph={"◉","✦","◈"};
        for(int i=0;i<defaultFocusMusic.length;i++){
            final int q=i;final boolean on=("d:"+i).equals(selected);
            LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(4),dp(6),dp(4),dp(6));
            GradientDrawable tg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{on?0xFFE9F7FF:0xFFF7F9FF,on?0xFFEFE8FF:0xFFF0F4FF});tg.setCornerRadius(dp(16));tg.setStroke(Math.max(1,dp(1)),on?0xFF4C8DFF:0x22466FA8);tile.setBackground(tg);tile.setElevation(on?dp(3):0);
            TextView art=tv(glyph[i%glyph.length],28,on?0xFF416DFF:0xFF6E7FA5);art.setGravity(Gravity.CENTER);tile.addView(art,new LinearLayout.LayoutParams(-1,dp(52)));
            TextView nm=tv(defaultFocusMusicNames[i],11,0xFF17345D);nm.setGravity(Gravity.CENTER);tile.addView(nm,new LinearLayout.LayoutParams(-1,dp(30)));
            tile.setOnClickListener(v->{missionAudioPrefs().edit().putString("selected","d:"+q).apply();playMissionDefault(q);if(dlg[0]!=null)dlg[0].dismiss();});
            LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,dp(100),1f);tlp.setMargins(dp(4),dp(4),dp(4),dp(4));tiles.addView(tile,tlp);
        }
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        TextView phoneHead=tv("My Music (From Phone)",12,0xFF536785);phoneHead.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);phoneHead.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);LinearLayout.LayoutParams ph=new LinearLayout.LayoutParams(-1,dp(34));ph.topMargin=dp(4);outer.addView(phoneHead,ph);
        if(tracks.isEmpty()){
            TextView none=tv("هنوز موسیقی‌ای از گوشی اضافه نشده",12,0xFF8190A8);none.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);none.setGravity(Gravity.CENTER);outer.addView(none,new LinearLayout.LayoutParams(-1,dp(48)));
        }else{
            for(String[] x:tracks){final String uri=x[0],name=x[1];addMusicPickerRow(outer,name,("u:"+uri).equals(selected),()->{missionAudioPrefs().edit().putString("selected","u:"+uri).putString("uri",uri).apply();playMissionMusic(android.net.Uri.parse(uri));if(dlg[0]!=null)dlg[0].dismiss();},()->{removeUserMusicTrack(uri);if(dlg[0]!=null)dlg[0].dismiss();showMissionMusicPicker();});}
        }
        TextView add=dialogButton("＋  Add Music",0xFF2FA8FF,0xFF7B61FF,false);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(50));alp.topMargin=dp(10);outer.addView(add,alp);add.setOnClickListener(v->{if(dlg[0]!=null)dlg[0].dismiss();chooseMissionMusicFromPhone();});
        ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);scroll.addView(outer,new ScrollView.LayoutParams(-1,-2));LinearLayout holder=new LinearLayout(this);holder.setOrientation(LinearLayout.VERTICAL);holder.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(480),getResources().getDisplayMetrics().heightPixels*2/3)));
        dlg[0]=buildPastelDialog("♫","Music Selection","",0xFF4D8EFF,holder,null,0,null,null,null);dlg[0].show();
    }
    private void addMusicPickerRow(LinearLayout outer,String name,boolean selected,Runnable choose,Runnable delete){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),0,dp(10),0);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        GradientDrawable rg=bg(selected?0xFFEAF4FF:0x00FFFFFF,dp(12));if(selected)rg.setStroke(1,0xFF2477E8);row.setBackground(rg);
        TextView label=tv((selected?"✓  ":"")+name,14,0xFF17345D);label.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        row.addView(label,new LinearLayout.LayoutParams(0,dp(46),1f));
        if(delete!=null){
            TextView del=tv("×",20,0xFFD84A55);del.setGravity(Gravity.CENTER);del.setContentDescription("حذف موسیقی");
            row.addView(del,new LinearLayout.LayoutParams(dp(42),dp(46)));
            del.setOnClickListener(v->delete.run());
        }
        row.setOnClickListener(v->choose.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.bottomMargin=dp(4);outer.addView(row,lp);
    }
    private void chooseMissionMusicFromPhone(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_MISSION_MUSIC);
    }
    private void chooseMissionMusic(){showMissionMusicPicker();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_MISSION_MUSIC&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{
                android.net.Uri u=data.getData();
                int takeFlags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try{getContentResolver().takePersistableUriPermission(u,takeFlags&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                String uri=u.toString();
                addUserMusicTrack(uri,displayNameForUri(u));
                missionAudioPrefs().edit().putString("selected","u:"+uri).putString("uri",uri).apply();
                playMissionMusic(u);
                Toast.makeText(this,"به لیست موسیقی‌ها اضافه شد",Toast.LENGTH_SHORT).show();
            }catch(Exception ex){Toast.makeText(this,"موزیک قابل پخش نیست",Toast.LENGTH_SHORT).show();}
        }
    }
    private void playMissionDefault(int index){
        stopMissionMusic();
        try{
            int q=Math.max(0,Math.min(defaultFocusMusic.length-1,index));
            missionPlayer=android.media.MediaPlayer.create(this,defaultFocusMusic[q]);
            if(missionPlayer!=null){
                missionPlayer.setLooping(true);missionPlayer.setVolume(missionMuted?0f:1f,missionMuted?0f:1f);missionPlayer.start();
            }
        }catch(Exception ignored){}
    }
    private void playMissionMusic(android.net.Uri u){
        stopMissionMusic();
        try{
            missionPlayer=android.media.MediaPlayer.create(this,u);
            if(missionPlayer!=null){missionPlayer.setLooping(true);missionPlayer.setVolume(missionMuted?0f:1f,missionMuted?0f:1f);missionPlayer.start();}
        }catch(Exception ignored){}
    }
    private void playSavedMissionMusic(){
        if(missionPlayer!=null)return;
        String selected=selectedMissionMusic();
        try{
            if(selected.startsWith("d:")){
                int q=Integer.parseInt(selected.substring(2));playMissionDefault(q);
            }else if(selected.startsWith("u:")){
                playMissionMusic(android.net.Uri.parse(selected.substring(2)));
                if(missionPlayer==null){missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
            }else{missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
        }catch(Exception ex){missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
    }
    private void stopMissionMusic(){try{if(missionPlayer!=null){missionPlayer.stop();missionPlayer.release();missionPlayer=null;}}catch(Exception ignored){missionPlayer=null;}}

    private String subtaskDay(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US);return f.format(new java.util.Date());}
    private void showSubtasksPopup(final int section,final int slot){
        final SharedPreferences sp=getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE);String day=subtaskDay();if(!day.equals(sp.getString("day","")))sp.edit().putString("day",day).putString("done_ids","").apply();
        final LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(2),0,dp(2),dp(2));outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final ScrollView scroll=new ScrollView(this);scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);final LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));outer.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(420),getResources().getDisplayMetrics().heightPixels/2)));
        final Runnable[] render={null};render[0]=()->{
            list.removeAllViews();String raw=sp.getString("items","");java.util.LinkedHashSet<String> doneIds=new java.util.LinkedHashSet<>();for(String x:sp.getString("done_ids","").split("\\n"))if(x.trim().length()>0)doneIds.add(x.trim());java.util.ArrayList<String[]> active=new java.util.ArrayList<>(),done=new java.util.ArrayList<>();
            for(String line:raw.split("\\n")){if(line.trim().length()==0)continue;String[] parts=line.split("\\|",2);if(parts.length<2)continue;(doneIds.contains(parts[0])?done:active).add(parts);}
            if(active.isEmpty()&&done.isEmpty()){TextView empty=tv("هنوز ساب‌تسکی اضافه نشده",13,0xFF8290A6);empty.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(70)));}
            if(!active.isEmpty()){TextView a=tv("فعال",12,0xFF42526B);a.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);a.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);list.addView(a,new LinearLayout.LayoutParams(-1,dp(30)));}
            for(String[] x:active)addSubtaskRow(list,x[0],x[1],false,sp,render[0]);
            if(!done.isEmpty()){TextView sep=tv("انجام‌شده",12,0xFF6D7890);sep.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);sep.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,dp(34));slp.topMargin=dp(8);list.addView(sep,slp);}
            for(String[] x:done)addSubtaskRow(list,x[0],x[1],true,sp,render[0]);
        };
        TextView add=dialogButton("＋  Add Subtask",0xFF2FA8FF,0xFF7B61FF,false);LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(50));alp.topMargin=dp(12);outer.addView(add,alp);
        add.setOnClickListener(v->showPastelInputDialog("Add Subtask","",render[0],n->{String raw=sp.getString("items","");String id=System.currentTimeMillis()+"_"+Math.abs((n+System.nanoTime()).hashCode());sp.edit().putString("items",raw+(raw.length()>0?"\n":"")+id+"|"+n.replace("\n"," ")).apply();}));
        render[0].run();Dialog d=buildPastelDialog("☑","Subtasks","",0xFF587DFF,outer,null,0,null,null,null);d.show();
    }
    private void addSubtaskRow(LinearLayout list,String id,String text,boolean checked,SharedPreferences sp,Runnable render){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setPadding(dp(8),0,dp(4),0);GradientDrawable rg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{checked?0xFFF0F5F8:0xFFF9FBFF,checked?0xFFF3F0FA:0xFFF1F5FF});rg.setCornerRadius(dp(14));rg.setStroke(Math.max(1,dp(1)),checked?0x223F607F:0x334D8DFF);row.setBackground(rg);
        CheckBox c=new CheckBox(this);c.setText(text);c.setChecked(checked);c.setTextSize(14);c.setTextColor(checked?0xFF8792A4:0xFF17345D);c.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);try{c.setButtonTintList(ColorStateList.valueOf(0xFF4D8DFF));}catch(Exception ignored){}if(checked)c.setPaintFlags(c.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        TextView edit=tv("✎",17,0xFF2477E8);edit.setGravity(Gravity.CENTER);edit.setContentDescription("ویرایش");
        TextView del=tv("×",20,0xFFD84A55);del.setGravity(Gravity.CENTER);del.setContentDescription("حذف");
        row.addView(c,new LinearLayout.LayoutParams(0,dp(50),1f));row.addView(edit,new LinearLayout.LayoutParams(dp(40),dp(50)));row.addView(del,new LinearLayout.LayoutParams(dp(40),dp(50)));
        c.setOnCheckedChangeListener((b,on)->{
            java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();
            for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0)set.add(x.trim());
            if(on)set.add(id);else set.remove(id);
            sp.edit().putString("done_ids",android.text.TextUtils.join("\n",set)).apply();
            b.post(render);
        });
        edit.setOnClickListener(v->showPastelInputDialog("ویرایش ساب‌تسک",text,render,n->updateSubtaskText(sp,id,n)));
        del.setOnClickListener(v->{
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView msg=tv("«"+text+"» حذف شود؟",13,0xFF65748D);msg.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);body.addView(msg,new LinearLayout.LayoutParams(-1,dp(44)));
            Dialog d=buildPastelDialog("×","حذف ساب‌تسک","",0xFFFF6078,body,"حذف",0xFFFF5268,()->{deleteSubtask(sp,id);render.run();},"لغو",null);d.show();
        });
        LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(52));rlp.bottomMargin=dp(6);list.addView(row,rlp);
    }
    private void updateSubtaskText(SharedPreferences sp,String id,String newText){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);
            if(p.length==2&&id.equals(p[0]))out.add(id+"|"+newText.replace("\n"," "));
            else out.add(line);
        }
        sp.edit().putString("items",android.text.TextUtils.join("\n",out)).apply();
    }
    private void deleteSubtask(SharedPreferences sp,String id){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);if(p.length==2&&id.equals(p[0]))continue;out.add(line);
        }
        java.util.LinkedHashSet<String> done=new java.util.LinkedHashSet<>();
        for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0&&!id.equals(x.trim()))done.add(x.trim());
        sp.edit().putString("items",android.text.TextUtils.join("\n",out)).putString("done_ids",android.text.TextUtils.join("\n",done)).apply();
    }

    private void stopMissionTimer(){if(missionTick!=null){missionHandler.removeCallbacks(missionTick);missionTick=null;}}
    private void stopHomeActiveTicker(){if(homeActiveTick!=null){missionHandler.removeCallbacks(homeActiveTick);homeActiveTick=null;}}
    private void completeMission(boolean success){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        int section=progressPrefs.getInt("active_s",-1),slot=progressPrefs.getInt("active_k",-1);
        String title=progressPrefs.getString("active_title","");if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        stopMissionTimer();stopMissionMusic();expireComboIfNeeded();
        if(section>0&&slot>=0)saveMissionRewardSnapshot(section,slot);
        if(section>0&&slot>=0)setMissionState(section,slot,success?"done":"fail");
        if(success){
            float mult=comboMultiplier();int earnedXp=Math.max(1,Math.round(20f*mult));int earnedCoins=Math.max(1,Math.round(5f*mult));int oldLevel=gameLevel,oldXp=gameXp,oldCoins=gameCoins,oldCombo=gameCombo;
            gameXp+=earnedXp;gameCoins+=earnedCoins;gameCombo++;lastSuccessAt=System.currentTimeMillis();
            while(gameXp>=xpNeeded(gameLevel)){gameXp-=xpNeeded(gameLevel);gameLevel++;}
            boolean leveled=gameLevel>oldLevel;int newLevel=gameLevel,newCombo=gameCombo;
            if(section>0&&slot>=0)recordMissionReward(section,slot,earnedXp,earnedCoins);
            saveGameState();showHudState(oldLevel,oldXp,oldCoins,oldCombo);clearActiveMissionState();animateRewardAndReturn(title,earnedXp,earnedCoins,newCombo,leveled,newLevel);
        }else{
            int previousCombo=gameCombo;if(section>0&&slot>=0)recordMissionReward(section,slot,0,0);
            gameCombo=0;lastSuccessAt=0;saveGameState();clearActiveMissionState();animateFailureAndReturn(title,previousCombo);
        }
    }
    private void showLaterConfirm(int section,int slot,String title){
        Dialog d=buildPastelDialog("⌛","Mission Paused",title+"  •  شروع مجدد از زمان کامل",0xFF6E8FFF,null,"Restart",0xFF4B8DFF,()->laterMission(section,slot),"Cancel",null);d.show();
    }
    private void laterMission(int section,int slot){
        String title=progressPrefs==null?"":progressPrefs.getString("active_title","");if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        stopMissionTimer();stopMissionMusic();if(section>0&&slot>=0){setMissionState(section,slot,"ready");clearMissionRewardSnapshot(section,slot);}clearActiveMissionState();animateResetAndReturn(title);
    }
    private void clearActiveMissionState(){
        cancelMissionAlarm();cancelMissionNotification();removeActiveMissionBar();if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putBoolean("active",false).remove("active_s").remove("active_k").remove("active_title").remove("active_end").remove("active_total").remove("active_alerted").apply();
    }
    private void animateRewardAndReturn(String title,int xp,int coins,int combo,boolean leveled,int newLevel){
        if(root==null){showProgressPath();showMissionSuccessDialog(title,xp,coins,combo,leveled,newLevel);return;}
        final java.util.ArrayList<View> fx=new java.util.ArrayList<>();int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);int cx=rw/2,cy=Math.round(rh*.57f);
        final TextView badge=tv("★",58,0xFFFFC84A);badge.setShadowLayer(dp(10),0,0,0x88FFD85A);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(92),dp(92));bp.leftMargin=cx-dp(46);bp.topMargin=cy-dp(46);root.addView(badge,bp);fx.add(badge);badge.setAlpha(0f);badge.setScaleX(.55f);badge.setScaleY(.55f);badge.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(760).setInterpolator(new android.view.animation.OvershootInterpolator(.45f)).start();
        String[] labels={"+"+xp+" XP","+"+coins+" Coin","Combo +1"};int[] colors={0xFF17CFFF,0xFFFFC244,0xFFFF764D};float[] tx={rw*.38f,rw*.64f,rw*.82f};
        for(int i=0;i<3;i++){final TextView fly=tv(labels[i],15,colors[i]);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(118),dp(42));lp.leftMargin=cx-dp(59);lp.topMargin=cy+dp(44+i*12);root.addView(fly,lp);fx.add(fly);fly.setAlpha(0f);float dx=tx[i]-cx,dy=dp(22)-(cy+dp(44+i*12));AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(fly,"alpha",0f,1f,1f,.10f),ObjectAnimator.ofFloat(fly,"translationX",0,dx),ObjectAnimator.ofFloat(fly,"translationY",0,dy));a.setStartDelay(420+i*180);a.setDuration(1250);a.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());a.start();}
        for(int i=0;i<5;i++){ImageView coinFx=new ImageView(this);coinFx.setImageResource(R.drawable.hud_coin);coinFx.setScaleType(ImageView.ScaleType.FIT_CENTER);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(18),dp(18));cp.leftMargin=cx-dp(9);cp.topMargin=cy+dp(8);root.addView(coinFx,cp);fx.add(coinFx);coinFx.setAlpha(0f);float ddx=dp(-70+i*35),ddy=dp(-70-(i%2)*26);AnimatorSet ca=new AnimatorSet();ca.playTogether(ObjectAnimator.ofFloat(coinFx,"alpha",0f,.85f,0f),ObjectAnimator.ofFloat(coinFx,"translationX",0,ddx),ObjectAnimator.ofFloat(coinFx,"translationY",0,ddy),ObjectAnimator.ofFloat(coinFx,"rotation",0f,240f));ca.setStartDelay(260+i*90);ca.setDuration(1100);ca.start();}
        TextView cheer=tv("عالی!  یک قدم جلوتر",16,0xFF2459B2);FrameLayout.LayoutParams clp=new FrameLayout.LayoutParams(dp(280),dp(44));clp.leftMargin=cx-dp(140);clp.topMargin=cy-dp(108);root.addView(cheer,clp);fx.add(cheer);cheer.setAlpha(0f);cheer.animate().alpha(1f).setStartDelay(360).setDuration(520).start();
        missionHandler.postDelayed(()->{updateHud();pulseHudRewards();},1500);
        missionHandler.postDelayed(()->{for(View v:fx)try{if(v.getParent() instanceof ViewGroup)((ViewGroup)v.getParent()).removeView(v);}catch(Exception ignored){}showProgressPath();missionHandler.postDelayed(()->showMissionSuccessDialog(title,xp,coins,combo,leveled,newLevel),180);},2550);
    }
    private void animateFailureAndReturn(String title,int previousCombo){
        if(root==null){showProgressPath();showMissionFailDialog(title,previousCombo);return;}int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);TextView crystal=tv("◆",68,0xFFFF5B85);crystal.setShadowLayer(dp(10),0,0,0x66FF4A75);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(112),dp(112));lp.leftMargin=rw/2-dp(56);lp.topMargin=Math.round(rh*.52f)-dp(56);root.addView(crystal,lp);crystal.setAlpha(0f);crystal.setScaleX(.7f);crystal.setScaleY(.7f);crystal.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();missionHandler.postDelayed(()->{try{root.removeView(crystal);}catch(Exception ignored){}showProgressPath();missionHandler.postDelayed(()->showMissionFailDialog(title,previousCombo),160);},1450);
    }
    private void animateResetAndReturn(String title){
        if(root==null){showProgressPath();return;}int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);TextView r=tv("↻",62,0xFF4D8DFF);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(104),dp(104));lp.leftMargin=rw/2-dp(52);lp.topMargin=Math.round(rh*.55f)-dp(52);root.addView(r,lp);r.setAlpha(0f);AnimatorSet a=new AnimatorSet();a.playTogether(ObjectAnimator.ofFloat(r,"alpha",0f,1f,0f),ObjectAnimator.ofFloat(r,"rotation",0f,300f),ObjectAnimator.ofFloat(r,"scaleX",.75f,1f),ObjectAnimator.ofFloat(r,"scaleY",.75f,1f));a.setDuration(980);a.start();missionHandler.postDelayed(()->{try{root.removeView(r);}catch(Exception ignored){}showProgressPath();},1050);
    }
    private void animateRestoreFeedback(){
        if(root==null)return;final TextView v=tv("↻  Restored",15,0xFF287EDC);GradientDrawable g=bg(0xF2EFF8FF,dp(18));g.setStroke(Math.max(1,dp(1)),0x664A8DFF);v.setBackground(g);v.setElevation(dp(5));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(160),dp(46),Gravity.CENTER_HORIZONTAL|Gravity.TOP);lp.topMargin=dp(92);root.addView(v,lp);v.setAlpha(0f);v.setTranslationY(dp(8));v.animate().alpha(1f).translationY(0).setDuration(420).withEndAction(()->v.animate().alpha(0f).setStartDelay(520).setDuration(320).withEndAction(()->{try{root.removeView(v);}catch(Exception ignored){}}).start()).start();
    }
    private void showMissionSuccessDialog(String title,int xp,int coins,int combo,boolean leveled,int newLevel){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);body.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView a=rewardChip("★ +"+xp+" XP",0xFF0878D8,0xFFE9F8FF,0x5543B4FF),b=rewardChip("● +"+coins,0xFFB77700,0xFFFFF7DD,0x55E9B63B),c=rewardChip("🔥 "+combo,0xFFC84F2A,0xFFFFEEE9,0x55FF855F);row.addView(a,new LinearLayout.LayoutParams(0,dp(40),1f));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(0,dp(40),1f);blp.setMargins(dp(6),0,dp(6),0);row.addView(b,blp);row.addView(c,new LinearLayout.LayoutParams(0,dp(40),1f));
        Dialog d=buildPastelDialog("🏆","Mission Completed!",title,0xFFFFC84A,body,"Continue",0xFF3F8CFF,()->{if(leveled)showLevelUpCard(newLevel);},null,null);d.show();
    }
    private void showMissionFailDialog(String title,int previousCombo){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);TextView chip=rewardChip(previousCombo>0?"🔥 Combo "+previousCombo+" → 0":"🔥 Combo Reset",0xFFC73A45,0xFFFFECEF,0x55FF5B72);body.addView(chip,new LinearLayout.LayoutParams(dp(170),dp(40)));
        Dialog d=buildPastelDialog("◆","Mission Failed",title,0xFFFF6078,body,"Continue",0xFF6B7EFF,null,null,null);d.show();
    }
    private void showMissionPausedInfoDialog(String title){
        Dialog d=buildPastelDialog("⌛","Mission Paused",title,0xFF708FFF,null,"Continue",0xFF4E8CFF,null,null,null);d.show();
    }
    private void showLevelUpCard(int level){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setGravity(Gravity.CENTER);TextView l=tv("Level "+level,24,0xFF234D9A);body.addView(l,new LinearLayout.LayoutParams(-1,dp(42)));TextView r=rewardChip("Rank: Explorer",0xFF4F5F7E,0xFFF0F4FF,0x445D7CFF);body.addView(r,new LinearLayout.LayoutParams(dp(190),dp(40)));Dialog d=buildPastelDialog("★","Level Up!","سطح جدید شما",0xFFFFC84A,body,"Continue",0xFF3F8CFF,null,null,null);d.show();
    }
    private void consumePendingMissionFeedback(){
        SharedPreferences gp=getSharedPreferences("legacy_game",MODE_PRIVATE);int xp=gp.getInt("pending_reward_xp",0),coins=gp.getInt("pending_reward_coins",0),lvl=gp.getInt("pending_level_up",0),combo=gp.getInt("pending_combo",gameCombo),prevCombo=gp.getInt("pending_prev_combo",gameCombo);String title=gp.getString("pending_title","");String result=gp.getString("pending_result","");
        if(xp==0&&coins==0&&lvl==0&&result.length()==0)return;
        gp.edit().remove("pending_reward_xp").remove("pending_reward_coins").remove("pending_level_up").remove("pending_combo").remove("pending_prev_combo").remove("pending_title").remove("pending_result").apply();
        if("done".equals(result))showMissionSuccessDialog(title,xp,coins,combo,lvl>0,lvl);else if("fail".equals(result))showMissionFailDialog(title,prevCombo);else if("later".equals(result))showMissionPausedInfoDialog(title);else if(lvl>0)showLevelUpCard(lvl);
    }
    private void ensureNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            try{requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},4102);}catch(Exception ignored){}
        }
    }
    private android.app.PendingIntent missionAlarmPendingIntent(){
        Intent i=new Intent(this,MissionAlarmReceiver.class);i.setAction("com.shahriar.legacy.MISSION_ALARM");
        return android.app.PendingIntent.getBroadcast(this,4101,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    }
    private android.app.PendingIntent missionActionPendingIntent(String action,int requestCode){
        Intent i=new Intent(this,MissionActionReceiver.class);i.setAction(action);
        return android.app.PendingIntent.getBroadcast(this,requestCode,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    }
    private void scheduleMissionAlarm(long endAt){
        try{
            android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);
            android.app.PendingIntent pi=missionAlarmPendingIntent();
            if(android.os.Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,endAt,pi);
            else am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,endAt,pi);
        }catch(Exception ignored){}
    }
    private void cancelMissionAlarm(){try{android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);am.cancel(missionAlarmPendingIntent());}catch(Exception ignored){}}
    private void cancelMissionNotification(){try{android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.cancel(4101);}catch(Exception ignored){}}
    private void finishMissionTimerAlert(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putBoolean("active_alerted",true).apply();
        try{android.os.Vibrator vb=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);if(vb!=null){if(android.os.Build.VERSION.SDK_INT>=26)vb.vibrate(android.os.VibrationEffect.createOneShot(500,android.os.VibrationEffect.DEFAULT_AMPLITUDE));else vb.vibrate(500);}}catch(Exception ignored){}
        try{
            if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            boolean muted=missionAudioPrefs().getBoolean("muted",false);
            String ch=muted?"mission_timer_silent_v44":"mission_timer_sound_v44";
            android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if(android.os.Build.VERSION.SDK_INT>=26){
                android.app.NotificationChannel nc=new android.app.NotificationChannel(ch,muted?"Mission Timer (Silent)":"Mission Timer",android.app.NotificationManager.IMPORTANCE_HIGH);
                if(muted)nc.setSound(null,null);
                nm.createNotificationChannel(nc);
            }
            Intent open=new Intent(this,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            android.app.PendingIntent contentPi=android.app.PendingIntent.getActivity(this,4101,open,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder nb=android.os.Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,ch):new android.app.Notification.Builder(this);
            android.app.PendingIntent donePi=missionActionPendingIntent(MissionActionReceiver.ACTION_DONE,4201),laterPi=missionActionPendingIntent(MissionActionReceiver.ACTION_LATER,4202),failPi=missionActionPendingIntent(MissionActionReceiver.ACTION_FAIL,4203);
            android.widget.RemoteViews rv=new android.widget.RemoteViews(getPackageName(),R.layout.notification_mission_complete);long notifMin=Math.max(1,progressPrefs.getLong("active_total",60000L)/60000L);rv.setTextViewText(R.id.notif_title,"Mission Completed!");rv.setTextViewText(R.id.notif_mission,progressPrefs.getString("active_title","Mission")+"  •  "+notifMin+" min");rv.setOnClickPendingIntent(R.id.notif_done,donePi);rv.setOnClickPendingIntent(R.id.notif_later,laterPi);rv.setOnClickPendingIntent(R.id.notif_fail,failPi);
            nb.setSmallIcon(R.drawable.ic_launcher_legacy).setContentTitle("Mission Completed!").setContentText(progressPrefs.getString("active_title","Mission")).setContentIntent(contentPi).setAutoCancel(true).setCustomContentView(rv).setCustomBigContentView(rv)
              .addAction(0,"Done",donePi).addAction(0,"Later",laterPi).addAction(0,"Fail",failPi);
            if(android.os.Build.VERSION.SDK_INT>=24)nb.setStyle(new android.app.Notification.DecoratedCustomViewStyle());
            if(android.os.Build.VERSION.SDK_INT<26)nb.setSound(muted?null:android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION));
            nm.notify(4101,nb.build());
        }catch(Exception ignored){}
    }

    private void removeActiveMissionBar(){
        stopHomeActiveTicker();
        try{if(activeBar!=null&&activeBar.getParent() instanceof ViewGroup)((ViewGroup)activeBar.getParent()).removeView(activeBar);}catch(Exception ignored){}
        activeBar=null;
    }
    private void addActiveMissionBar(){
        removeActiveMissionBar();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(!progressPrefs.getBoolean("active",false)||root==null||isRunningMissionScreen)return;
        final TextView bar=tv("",13,Color.WHITE);activeBar=bar;bar.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0xE6132236,dp(18));g.setStroke(Math.max(1,Math.round(dp(.7f))),0xAAE6B94A);bar.setBackground(g);
        bar.setPadding(dp(12),0,dp(12),0);bar.setElevation(dp(5));bar.setContentDescription("Continue Mission");
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(245),dp(42),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=dp(16);root.addView(bar,bp);
        bar.setOnClickListener(v->transitionTo(()->resumeActiveMission()));
        homeActiveTick=new Runnable(){public void run(){
            if(bar.getParent()==null||progressPrefs==null||!progressPrefs.getBoolean("active",false)){homeActiveTick=null;return;}
            long end=progressPrefs.getLong("active_end",0);long rem=Math.max(0,end-System.currentTimeMillis());long sec=(rem+999)/1000;
            String t=String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60);
            bar.setText(rem>0?"Continue Mission  •  "+t:"Continue Mission  •  00:00");
            missionHandler.postDelayed(this,1000);
        }};missionHandler.post(homeActiveTick);
    }

    // Progress Path rebuild: visual structure only. Mission logic will be added step by step.
    private ScrollView progressScroll;
    private LinearLayout progressPages;
    private int progressSectionCount=1;
    private SharedPreferences progressPrefs;

    private String progressTitle(int section,int slot){
        if(progressPrefs==null) progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        return progressPrefs.getString("title_"+section+"_"+slot,"");
    }
    private void askProgressTitle(final int section,final int slot,final TextView label){
        showPastelInputDialog("عنوان مأموریت",progressTitle(section,slot),null,n->{if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);progressPrefs.edit().putString("title_"+section+"_"+slot,n).apply();label.setText(n);});
    }

    private void showProgressPath(){
        stopMissionTimer();
        stopHomeActiveTicker();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome=false;isRunningMissionScreen=false; ++homeGeneration; content.removeAllViews();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        progressMissionViews.clear();progressGuideViews.clear();progressHeroViews.clear();
        int savedSections=Math.max(1,progressPrefs.getInt("progress_section_count",1));
        progressSectionCount=1;
        progressScroll=new ScrollView(this);
        progressScroll.setFillViewport(true);
        progressScroll.setClipToPadding(false);
        progressScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        progressScroll.setBackgroundColor(Color.TRANSPARENT);
        progressPages=new LinearLayout(this);
        progressPages.setOrientation(LinearLayout.VERTICAL);
        progressPages.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        progressScroll.addView(progressPages,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1);
        lp.topMargin=0;
        content.addView(progressScroll,lp);
        addProgressSection(false);
        while(progressSectionCount<savedSections){progressSectionCount++;addProgressSection(false);}
        refreshProgressMissionGuides();addActiveMissionBar();animatePageEnter(content);
    }

    private String nextMissionGuideKey(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        for(int ss=1;ss<=progressSectionCount;ss++)for(int kk=0;kk<3;kk++)if("active".equals(missionState(ss,kk)))return missionViewKey(ss,kk);
        for(int ss=1;ss<=progressSectionCount;ss++)for(int kk=2;kk>=0;kk--){String st=missionState(ss,kk);if(!"done".equals(st)&&!"fail".equals(st))return missionViewKey(ss,kk);}
        return null;
    }
    private String heroMissionGuideKey(){return nextMissionGuideKey();}
    private void refreshProgressMissionGuides(){
        String next=nextMissionGuideKey();
        for(java.util.Map.Entry<String,View> e:progressGuideViews.entrySet()){
            boolean on=false;try{String[] p=e.getKey().split(":");int ss=Integer.parseInt(p[0]),kk=Integer.parseInt(p[1]);String st=missionState(ss,kk);String title=progressTitle(ss,kk).trim();on=e.getKey().equals(next)&&title.length()==0&&!"done".equals(st)&&!"fail".equals(st);}catch(Exception ignored){}
            e.getValue().setVisibility(on?View.VISIBLE:View.INVISIBLE);
        }
        for(java.util.Map.Entry<String,ImageView> e:progressHeroViews.entrySet()){
            boolean on=false;try{String[] p=e.getKey().split(":");int ss=Integer.parseInt(p[0]),kk=Integer.parseInt(p[1]);String st=missionState(ss,kk);String title=progressTitle(ss,kk).trim();on=e.getKey().equals(next)&&title.length()>0&&!"done".equals(st)&&!"fail".equals(st);}catch(Exception ignored){}
            ImageView iv=e.getValue();iv.setVisibility(on?View.VISIBLE:View.INVISIBLE);
            TextView label=progressMissionViews.get(e.getKey());if(label!=null){if(on){label.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);label.setPadding(dp(6),dp(14),dp(6),dp(6));}else{label.setGravity(Gravity.CENTER);label.setPadding(dp(6),dp(6),dp(6),dp(6));}}
            try{android.graphics.drawable.Drawable d=iv.getDrawable();if(d instanceof android.graphics.drawable.AnimationDrawable){if(on)((android.graphics.drawable.AnimationDrawable)d).start();else ((android.graphics.drawable.AnimationDrawable)d).stop();}}catch(Exception ignored){}
        }
    }

    private void refreshProgressArrows(){if(progressPages==null)return;for(int i=0;i<progressPages.getChildCount();i++){View p=progressPages.getChildAt(i);View u=p.findViewWithTag("progress_up"),d=p.findViewWithTag("progress_down");if(u!=null){u.setVisibility(i==0?View.VISIBLE:View.GONE);u.setEnabled(i==0);}if(d!=null)d.setVisibility(i==0&&progressSectionCount>1?View.VISIBLE:View.GONE);}}

    private void addProgressSection(boolean animateToNew){
        final int sectionNumber=progressSectionCount;
        final FrameLayout page=new FrameLayout(this);
        int w=getResources().getDisplayMetrics().widthPixels;
        int pageHeight=Math.round(w*2f);

        ImageView art=new ImageView(this);
        art.setImageResource(sectionNumber%2==1?R.drawable.progress_path_first:R.drawable.progress_path_second);
        art.setScaleType(ImageView.ScaleType.FIT_XY);
        page.addView(art,new FrameLayout.LayoutParams(-1,-1));

        // Tiny naked up-arrow: top-left, no circle/square/background.
        TextView up=tv("↑",22,0xFF174FD6);
        up.setContentDescription("ادامه مسیر"); up.setTag("progress_up");
        up.setBackgroundColor(Color.TRANSPARENT);
        up.setShadowLayer(dp(2),0,dp(1),0xAAFFFFFF);
        up.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.TOP|Gravity.LEFT);
        ap.leftMargin=dp(8);
        ap.topMargin=dp(52);
        page.addView(up,ap);
        up.setOnClickListener(v->{
            progressSectionCount++;
            if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
            progressPrefs.edit().putInt("progress_section_count",progressSectionCount).apply();
            addProgressSection(true);
        });

        // Touch centers measured from the supplied 768x1536 progress artworks.
        // Odd pages: 3 circles on the left. Even pages: 3 circles on the right.
        final float[][] odd={{0.3667f,0.2370f},{0.2377f,0.4891f},{0.3096f,0.7581f}};
        final float[][] even={{0.6333f,0.2370f},{0.7623f,0.4891f},{0.6904f,0.7581f}};
        final float[][] pts=(sectionNumber%2==1)?odd:even;
        final int circleSize=Math.round(w*0.318f);

        for(int i=0;i<3;i++){
            final int slot=i;
            TextView mission=tv(progressTitle(sectionNumber,slot),14,0xFF162D54);
            mission.setGravity(Gravity.CENTER);
            mission.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            mission.setMaxLines(2);
            mission.setPadding(dp(6),dp(6),dp(6),dp(6));
            mission.setContentDescription("جایگاه مأموریت "+(slot+1));
            styleMissionSlot(mission,missionState(sectionNumber,slot));
            progressMissionViews.put(missionViewKey(sectionNumber,slot),mission);
            int cx=Math.round(w*pts[i][0]);
            int cy=Math.round(pageHeight*pts[i][1]);
            int guideSize=Math.round(circleSize*.56f);CoinRainView guide=new CoinRainView(this);FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(guideSize,guideSize);gp.leftMargin=cx-guideSize/2;gp.topMargin=cy-guideSize/2;page.addView(guide,gp);progressGuideViews.put(missionViewKey(sectionNumber,slot),guide);guide.setVisibility(View.INVISIBLE);
            ImageView heroMarker=new ImageView(this);heroMarker.setImageResource(R.drawable.hero_walk_anim);heroMarker.setScaleType(ImageView.ScaleType.FIT_CENTER);heroMarker.setVisibility(View.INVISIBLE);heroMarker.setContentDescription("Hero mission guide");heroMarker.setClickable(false);heroMarker.setFocusable(false);
            int heroW=Math.round(circleSize*.50f),heroH=Math.round(circleSize*.76f);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(heroW,heroH);hp.leftMargin=cx-heroW/2;hp.topMargin=cy+circleSize/2-heroH-Math.round(circleSize*.02f);page.addView(heroMarker,hp);progressHeroViews.put(missionViewKey(sectionNumber,slot),heroMarker);
            FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(circleSize,circleSize);
            mp.leftMargin=cx-circleSize/2;
            mp.topMargin=cy-circleSize/2;
            page.addView(mission,mp);
            mission.setOnClickListener(v->{
                String state=missionState(sectionNumber,slot);
                if("active".equals(state)){animateMissionCircleTap(mission,()->transitionTo(()->resumeActiveMission()));return;}
                if("done".equals(state)||"fail".equals(state)){animateMissionCircleTap(mission,()->showMissionSlotMenu(sectionNumber,slot));return;}
                animateMissionCircleTap(mission,()->transitionTo(()->showMissionEditor(sectionNumber,slot)));
            });
            mission.setOnLongClickListener(v->{showMissionSlotMenu(sectionNumber,slot);return true;});
        }

        TextView down=tv("↓",22,0xFF174FD6);down.setTag("progress_down");down.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams dl=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.BOTTOM|Gravity.LEFT);dl.leftMargin=dp(8);dl.bottomMargin=dp(8);page.addView(down,dl);
        down.setOnClickListener(v->{
            boolean empty=true;for(int k=0;k<3;k++)if(progressTitle(sectionNumber,k).trim().length()>0)empty=false;
            if(!empty){Toast.makeText(this,"برای حذف صفحه، دایره‌ها باید خالی باشند",Toast.LENGTH_SHORT).show();return;}
            if(sectionNumber==progressSectionCount&&progressSectionCount>1){
                progressPages.removeView(page);
                for(int k=0;k<3;k++){clearMissionSlot(sectionNumber,k);progressMissionViews.remove(missionViewKey(sectionNumber,k));progressGuideViews.remove(missionViewKey(sectionNumber,k));progressHeroViews.remove(missionViewKey(sectionNumber,k));}
                progressSectionCount--;
                if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
                progressPrefs.edit().putInt("progress_section_count",progressSectionCount).apply();
                refreshProgressArrows();
            }
        });
        progressPages.addView(page,0,new LinearLayout.LayoutParams(-1,pageHeight));refreshProgressArrows();refreshProgressMissionGuides();
        if(animateToNew){
            progressScroll.post(()->progressScroll.smoothScrollTo(0,0));
        }else{
            progressScroll.post(()->progressScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void clearMissionSlot(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        SharedPreferences.Editor ed=progressPrefs.edit()
            .remove("title_"+section+"_"+slot)
            .remove(mf(section,slot,"importance"))
            .remove(mf(section,slot,"minutes"))
            .remove(mf(section,slot,"repeat"))
            .remove(mf(section,slot,"state"))
            .remove(mf(section,slot,"state_day"))
            .remove(mf(section,slot,"reward_snapshot"))
            .remove(mf(section,slot,"prev_level")).remove(mf(section,slot,"prev_xp")).remove(mf(section,slot,"prev_coins"))
            .remove(mf(section,slot,"prev_combo")).remove(mf(section,slot,"prev_last_success"))
            .remove(mf(section,slot,"reward_xp")).remove(mf(section,slot,"reward_coins")).remove(mf(section,slot,"reward_outcome")).remove(mf(section,slot,"reward_at"))
            .remove(mf(section,slot,"defaults_v41"));
        ed.apply();
        getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE).edit().clear().apply();
    }

    private void showGameSettings(){
        final String[] opts={"10 دقیقه","15 دقیقه","20 دقیقه","30 دقیقه","45 دقیقه","60 دقیقه"};final int[] vals={10,15,20,30,45,60};
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final Dialog[] dlg={null};for(int i=0;i<opts.length;i++){final int q=i;boolean on=vals[i]==comboWindowMinutes;TextView row=popupActionRow(on?"✓":"○",opts[i],on?0xFF275FD0:0xFF425A7C,on?0xFFEAF4FF:0xFFF8FAFF,on?0x664D8DFF:0x224D6B9A);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.bottomMargin=dp(5);body.addView(row,lp);row.setOnClickListener(v->{comboWindowMinutes=vals[q];expireComboIfNeeded();saveGameState();if(dlg[0]!=null)dlg[0].dismiss();Toast.makeText(this,"مهلت Combo: "+comboWindowMinutes+" دقیقه",Toast.LENGTH_SHORT).show();});}
        dlg[0]=buildPastelDialog("🔥","Combo Window","",0xFF6E72FF,body,"بستن",0xFF4A8EFF,null,null,null);dlg[0].show();
    }

    private void showPlaceholder(String title){
        stopHomeActiveTicker();
        isHome = false; isRunningMissionScreen=false;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24));GradientDrawable pg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFFF5FAFF,0xFFE9F3FF,0xFFF2ECFF,0xFFEDF7FF});p.setBackground(pg);
        TextView t=tv(title,28,0xFF17345D); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();animatePageEnter(content);
    }
    @Override public void onBackPressed(){
        // On a section, Back returns Home. On Home, double Back exits.
        if(!isHome){ transitionTo(()->showHome()); return; }
        long now=System.currentTimeMillis();
        if(now-lastBackAt<1800){ super.onBackPressed(); }
        else { lastBackAt=now; Toast.makeText(this,"برای خروج دوباره بزنید",Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
    private float dp(float x){ return x*getResources().getDisplayMetrics().density; }
}

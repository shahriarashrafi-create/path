# Legacy v50

Focused gaming-polish pass built on v49.

- Coin rain is intentionally subtle: five small coins, lower opacity, smaller zones.
- Home rain stays only around Progress Path; Start Mission rain stays only over a small center zone of the gold button.
- Progress Path: empty next circle = subtle coin rain; titled ready/active circle = transparent 7-frame hero at bottom-center; Done/Fail = no guide animation.
- Seven transparent hero PNG frames and smoother 7-frame animation-list.
- Removed extra pulse/particle loops; simplified Mission Start and result feedback.
- Faster page/dialog navigation while completion rewards remain visible long enough to understand.
- Three built-in focus tracks remain exactly 2:00: energetic, calm, balanced.
- Global click sound remains enabled.
- App version: 1.35 (39).

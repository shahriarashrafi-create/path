package com.shahriar.legacy;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;

public class MissionAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        android.content.SharedPreferences sp=context.getSharedPreferences("legacy_progress_rebuild",Context.MODE_PRIVATE);
        if(!sp.getBoolean("active",false)) return;
        long end=sp.getLong("active_end",0);
        if(end>System.currentTimeMillis()+2000) return;
        sp.edit().putBoolean("active_alerted",true).apply();
        try{
            android.os.Vibrator vb=(android.os.Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
            if(vb!=null){
                if(Build.VERSION.SDK_INT>=26)vb.vibrate(android.os.VibrationEffect.createOneShot(500,android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                else vb.vibrate(500);
            }
        }catch(Exception ignored){}
        try{
            if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return;
            String ch="mission_timer";
            NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"Mission Timer",NotificationManager.IMPORTANCE_HIGH));
            Intent open=new Intent(context,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent contentPi=PendingIntent.getActivity(context,4101,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,ch):new Notification.Builder(context);
            nb.setSmallIcon(R.drawable.ic_launcher_legacy)
              .setContentTitle("Mission complete")
              .setContentText("زمان مأموریت تمام شد؛ Done یا Fail را انتخاب کنید")
              .setContentIntent(contentPi)
              .setAutoCancel(true);
            nm.notify(4101,nb.build());
        }catch(Exception ignored){}
    }
}

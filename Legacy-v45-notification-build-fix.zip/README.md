Legacy v17 — HUD reference match pass 3. Home artwork and six hit targets unchanged. Header layout, XP track, capsule density, avatar scale, and HUD accents refined.


v18: final HUD density/alignment polish; Home artwork and six touch targets unchanged.


## v28 – Progress Path hardening 1
- Optional mission reminder with time picker and Android notification channel.
- Timer-finished notification added.
- Daily completion resets to ready on the next calendar day.
- Reminder identity uses stable mission UUID so mission shifting/deletion does not target the wrong mission.
- Reminder alarm is cancelled when a mission is deleted or reminder is disabled.
- Android 13+ notification permission request added.


## v29 – Progress Path hardening 2
- Active mission timer is deadline-based and survives navigation/recreation.
- Added AlarmManager-backed mission finish receiver for background/app-closed notification.
- Active mission bar is restored on Home/resume.
- Timer finish alarms are cancelled on Done/Fail/Later/delete.
- At zero, mission remains active awaiting outcome.

## v30 – Progress Path hardening 3
- Combo window is configurable: 10/15/20/30/45/60 minutes.
- Expired combo is cleared consistently when HUD/active mission state refreshes.
- Combo reward calculation uses the selected window.
- Successful non-daily missions leave the path and remaining missions compact downward.
- Daily missions remain in place after success for same-day completed/restore behavior.

## v31 — Progress Path hardening 4 / visual polish
- Final Progress Path presentation pass.
- Mission titles now auto-size inside path circles (Android 8+), improving long-title fit.
- Active mission circle gets a continuous subtle pulse to clearly distinguish the running mission.
- Newly unlocked A/B page scrolls smoothly to the beginning of the new section.
- Added bottom breathing room so the persistent active-mission bar does not visually cover the path ending.
- Preserved A/B alternating artwork, three slots per page, mission compaction after deletion/completion, Home artwork and HUD behavior.

v41: Mission editor keyboard keeps 9x18 layout (ADJUST_NOTHING), one-time corrected defaults (low/10m/daily), slimmer inset selection outlines, less intrusive text selection, and optical centering adjustments for circle title/time. Start Mission running screen retains countdown progress ring + moving blue dot, Done/Fail, Later reset behavior, and 00:00 alert/manual result.

## v43 — mission editor calibration + active mission hardening
- Recalibrated mission title overlay to the actual cyan circle center from the supplied phone screenshot.
- Raised the time text by removing the old +3dp offset; selection outlines are thinner and inset inside the colored pills.
- New blank missions always start Low / 10m / Daily; placeholder title never appears in the circle.
- Added blue custom cursor and nearly invisible selection handles for the mission title field.
- Progress Path page count persists after leaving/reopening the section.
- Only one mission can run at a time; the active mission resumes instead of being edited/replaced.
- Active mission state resumes after navigation/recreation and shows a Continue Mission bar on Home.
- Mission deadline is backed by AlarmManager/receiver for app-process loss; notification permission is requested on Android 13+.
- Timer notification/alarm is cancelled on Done, Fail, or reset/Later.
- Saved mission music auto-loads; mute state persists.
- Subtasks are mission-specific, scrollable, preserve duplicate names via IDs, and daily completion resets.

## v44 — Home world map + mission polish
- Replaced Home artwork with the supplied 768x1536 floating-islands world map; six touch zones were recalibrated to each signboard and shifted slightly above the baked Persian labels.
- Recalibrated mission importance and repeat selection outlines to the actual colored capsules; outlines are now a 1px capsule stroke instead of oversized boxes.
- Raised the mission time text by a tiny amount for optical alignment with minus/plus/clock.
- Music control now opens a persistent picker with three built-in original focus loops: Deep Focus, Calm, and Flow.
- Phone-picked audio is added to the persistent music list, can be selected later, shows the active selection, and can be removed.
- The first built-in focus track is the default for new users; chosen music and mute state persist.
- Mute now also suppresses mission-finish notification sound while preserving the timer alert flow.
- Subtasks now support visible add, check/uncheck, edit, delete, active/done grouping, per-mission storage, scrolling, and daily reset of completed checks.
- Timer music stops at 00:00 while Done/Fail remain manual.

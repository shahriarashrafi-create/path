# Legacy v14 — HUD Reference Match

- Reworked header proportions to better match the approved reference.
- Reduced HUD height and dead space.
- Larger avatar presence while remaining fully inside the HUD.
- LV and XP now form one compact horizontal block.
- XP track is brighter blue and XP text sits under the bar.
- Coin and combo capsules are smaller/subtler; flame and settings are clearer.
- Darker glass, subtler border, stronger restrained blue edge glow.
- Home artwork and all six Home touch targets are unchanged from v13.

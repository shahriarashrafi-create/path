Legacy v60

Changes:
- Replaced Home and Progress Path artworks with upscaled 1536x3072 versions of the three latest images.
- Added full-width blue bars at the very top and bottom of every Progress Path page.
- When opening Progress Path (from Home, Back, Done, or Fail), the screen now first settles low and then smoothly scrolls to the first mission circle from the bottom that is not Done/Fail.
- Importance-based rewards from v59 are preserved.

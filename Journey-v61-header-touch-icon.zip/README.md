Journey v54

Changes in this version:
- Replaced the previous header with a new compact blue HUD-style header similar to the approved mockup.
- Added the business anime avatar as the header profile image.
- Replaced the launcher icon with the same avatar image.
- Kept the current home background/touch calibration from v53.
- Settings backup actions remain available (Export / Import).

Version v58: updated home background with final high-quality six-panel artwork.

## v59
- Replaced the Home background with the supplied final 1:2 artwork at original quality.
- Recalibrated all six Home touch zones to the visible wide cards.
- Preserved the requested +1dp downward touch offset.
- Ensured Header and Bottom Bar are layered above Home touch zones.

## v60
- Replaced the Home background with the newly approved lower-glare six-panel artwork at full 887×1774 quality.
- Recalibrated all six Home touch zones to the new card positions and sizes.
- Preserved the requested +1dp downward touch calibration.
- Header and Bottom Bar remain above the Home background and touch layers.

## v61 home/header calibration
- Header moved slightly lower and made lighter/cleaner.
- Header avatar reduced and positioned so only a small amount rises above the pill while its bottom stays inside.
- Level badge reduced; Explorer/progress group tightened and shifted left.
- Resource chips remain balanced; settings control reduced slightly.
- Home touch zones recalibrated upward against the current six-card artwork from the real-device screenshot.
- Launcher icon avatar enlarged for stronger visibility on the home screen.

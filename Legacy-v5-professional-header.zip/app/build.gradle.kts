plugins { id("com.android.application") }

android {
    namespace = "com.shahriar.legacy"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.shahriar.legacy"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }
}

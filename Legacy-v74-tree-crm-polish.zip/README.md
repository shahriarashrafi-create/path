Legacy v74 — Tree CRM interaction polish

Base: Legacy-v73-build-fix.zip

Changes applied:
- Tree search now shows live name suggestions while typing.
- Selecting a search suggestion expands ancestors, centers the person, and zooms into that circle.
- To Do is now a real multi-item checklist: type in the top input and press keyboard Enter/Done to add; every item has its own checkbox; the old single Done row is removed.
- Old single To Do data migrates into the new checklist automatically.
- Action registration now includes the target person's name.
- Done action and Next action are styled dropdown selectors using the agreed options:
  ارتباط سازی، پیش مشاوره، دعوت، معرفی کار، فالوآپ، ثبت سفارش اولیه، معرفی محصول، ثبت فروش
- Existing action records are backward-compatible with the new format.
- Tree circle stats are clearer: larger clean numbers, clearer labels, more horizontal spacing, stronger contrast, and column separators.
- Member editor keeps the person's name under «ویرایش اطلاعات», field labels beside inputs, clear-on-focus behavior, and restore-old-value when left empty.
- Tree history snapshot format now includes multi-item To Do data while still reading older v73 history snapshots safely.

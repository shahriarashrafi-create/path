Legacy v71 – Tree interaction/history polish

Tree changes:
- Tree zoom and pan are preserved after Edit, Add Person, To Do updates and Delete.
- Search icon added at the top of the tree; search centers the canvas on the matching person and expands ancestor branches when needed.
- History icon added beside Search. Daily tree snapshots are stored and can be opened read-only by date.
- Member card action row now uses three adjacent icon assets only: Add, To Do, Delete. Add/Delete text buttons were removed.
- Root delete is disabled; deleting any other person removes that person and their subtree after confirmation.
- To Do is stored per person and shown in the member card.
- PV / GPV / count / target fields use numeric keyboards, sanitize negative/non-numeric input, and display formatted numbers with separators.
- Long Persian names shrink further and use horizontal fitting instead of ellipsis so the full name remains visible.
- Branch open/close re-layout now animates for ~260ms; add/delete rebuilds use preserved previous node positions for a smooth re-layout.
- Historical views are read-only and hide branch controls/action editing.
- Existing uniform node size, avatar-free circles, curved branches and pan/pinch zoom remain intact.

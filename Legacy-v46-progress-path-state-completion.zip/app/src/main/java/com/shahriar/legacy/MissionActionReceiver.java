package com.shahriar.legacy;

import android.app.*;
import android.content.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MissionActionReceiver extends BroadcastReceiver {
    public static final String ACTION_DONE="com.shahriar.legacy.MISSION_DONE";
    public static final String ACTION_LATER="com.shahriar.legacy.MISSION_LATER";
    public static final String ACTION_FAIL="com.shahriar.legacy.MISSION_FAIL";

    @Override public void onReceive(Context context, Intent intent){
        if(intent==null)return;
        String action=intent.getAction();
        if(!ACTION_DONE.equals(action)&&!ACTION_LATER.equals(action)&&!ACTION_FAIL.equals(action))return;
        SharedPreferences progress=context.getSharedPreferences("legacy_progress_rebuild",Context.MODE_PRIVATE);
        if(!progress.getBoolean("active",false)){cancelNotification(context);return;}
        int section=progress.getInt("active_s",-1),slot=progress.getInt("active_k",-1);
        if(section<1||slot<0){clearActive(context,progress);return;}

        String state=ACTION_DONE.equals(action)?"done":ACTION_FAIL.equals(action)?"fail":"ready";
        SharedPreferences.Editor pe=progress.edit().putString(mf(section,slot,"state"),state);
        if("done".equals(state)||"fail".equals(state))pe.putString(mf(section,slot,"state_day"),today());
        else pe.remove(mf(section,slot,"state_day"));
        pe.apply();

        SharedPreferences game=context.getSharedPreferences("legacy_game",Context.MODE_PRIVATE);
        if(ACTION_DONE.equals(action)){
            int level=game.getInt("level",1),xp=game.getInt("xp",0),coins=game.getInt("coins",0),combo=game.getInt("combo",0);
            long last=game.getLong("lastSuccessAt",0);int window=game.getInt("comboWindowMinutes",30);long now=System.currentTimeMillis();
            if(combo>0&&last>0&&now-last>window*60000L){combo=0;last=0;}
            float mult=combo>=10?3f:combo>=7?2f:combo>=3?1.5f:1f;
            int earnedXp=Math.max(1,Math.round(20f*mult)),earnedCoins=Math.max(1,Math.round(5f*mult));
            int oldLevel=level;xp+=earnedXp;coins+=earnedCoins;combo++;last=now;
            while(xp>=xpNeeded(level)){xp-=xpNeeded(level);level++;}
            game.edit().putInt("level",level).putInt("xp",xp).putInt("coins",coins).putInt("combo",combo).putLong("lastSuccessAt",last)
                .putInt("pending_reward_xp",earnedXp).putInt("pending_reward_coins",earnedCoins).putInt("pending_level_up",level>oldLevel?level:0).putString("pending_result","done").apply();
        }else if(ACTION_FAIL.equals(action)){
            game.edit().putInt("combo",0).putLong("lastSuccessAt",0).putString("pending_result","fail").apply();
        }else{
            game.edit().putString("pending_result","later").apply();
        }
        clearActive(context,progress);
    }
    private static int xpNeeded(int level){return 100+Math.max(0,level-1)*50;}
    private static String mf(int s,int k,String f){return "m_"+s+"_"+k+"_"+f;}
    private static String today(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
    private static void clearActive(Context context,SharedPreferences progress){
        progress.edit().putBoolean("active",false).remove("active_s").remove("active_k").remove("active_title").remove("active_end").remove("active_total").remove("active_alerted").apply();
        try{
            AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            Intent i=new Intent(context,MissionAlarmReceiver.class);i.setAction("com.shahriar.legacy.MISSION_ALARM");
            PendingIntent pi=PendingIntent.getBroadcast(context,4101,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
        }catch(Exception ignored){}
        cancelNotification(context);
    }
    private static void cancelNotification(Context context){try{NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);nm.cancel(4101);}catch(Exception ignored){}}
}

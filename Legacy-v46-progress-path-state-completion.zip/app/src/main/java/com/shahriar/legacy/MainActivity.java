package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.text.InputType;
import android.view.*;
import android.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content;
    private View activeBar;
    private boolean isRunningMissionScreen=false;
    private final java.util.HashMap<String,TextView> progressMissionViews=new java.util.HashMap<>();
    private TextView hudLevel, hudXpText, hudCoinText, hudComboText; private XpBarView hudXpBar;
    private long lastBackAt = 0;
    private Runnable homeActiveTick, dailyResetTick;
    private String lastObservedMissionDay="";
    private boolean isHome = true;
    private int homeGeneration = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","جنگل شکوفایی","سفر در زمان","مرکز خرید","جام جهانی"};
    // Touch centers measured against the current 768x1536 Home artwork.
    // Order matches names: Progress, Dream Palace, Growth Forest, Time Travel, Shop, World Cup.
    private final float[][] centers = {{0.505f,0.804f},{0.293f,0.535f},{0.807f,0.680f},{0.813f,0.439f},{0.370f,0.303f},{0.832f,0.218f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }
    @Override protected void onResume(){
        super.onResume();
        loadGameState(); updateHud();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        if(isRunningMissionScreen&&!progressPrefs.getBoolean("active",false)){stopMissionTimer();stopMissionMusic();showProgressPath();consumePendingMissionFeedback();startDailyResetTicker();return;}
        refreshProgressMissionVisuals();
        if(!isRunningMissionScreen)addActiveMissionBar();
        consumePendingMissionFeedback();
        startDailyResetTicker();
    }
    @Override protected void onPause(){
        super.onPause();
        if(dailyResetTick!=null){missionHandler.removeCallbacks(dailyResetTick);dailyResetTick=null;}
    }
    @Override protected void onDestroy(){ super.onDestroy(); }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void showHome(){
        stopMissionTimer();
        stopHomeActiveTicker();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome = true; isRunningMissionScreen=false;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        activeBar=null;progressMissionViews.clear();
        setContentView(root);
        root.setFitsSystemWindows(true);

        ImageView home=new ImageView(this); home.setImageResource(R.drawable.home_background);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // Legacy HUD reference final polish: premium RPG HUD.
        FrameLayout header=new FrameLayout(this);
        header.setPadding(dp(4),0,dp(4),0);
        header.setBackground(new HudBackground());
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(46),Gravity.TOP);
        hp.setMargins(dp(8),dp(4),dp(8),0);
        root.addView(header,hp);

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(1),0,dp(1),0);
        header.addView(row,new FrameLayout.LayoutParams(-1,-1));

        ImageView avatar=new ImageView(this);
        avatar.setImageResource(R.drawable.avatar_legacy);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        avatar.setContentDescription("آواتار"); avatar.setElevation(dp(2));
        LinearLayout.LayoutParams avLp=new LinearLayout.LayoutParams(dp(45),dp(45));
        avLp.setMargins(dp(2),0,dp(4),0); row.addView(avatar,avLp);

        loadGameState();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        hudLevel=tv("LV "+gameLevel,13,0xFFFFE7A0); TextView level=hudLevel;
        level.setGravity(Gravity.CENTER);
        level.setShadowLayer(dp(1),0,0,0x665E3A00);
        LinearLayout.LayoutParams levelLp=new LinearLayout.LayoutParams(dp(40),dp(34));
        levelLp.setMargins(0,0,dp(1),0); row.addView(level,levelLp);

        LinearLayout xpGroup=new LinearLayout(this);
        xpGroup.setOrientation(LinearLayout.VERTICAL);
        xpGroup.setGravity(Gravity.CENTER_VERTICAL);
        XpBarView xp=new XpBarView(this); hudXpBar=xp;
        xp.setProgress(gameXp,xpNeeded(gameLevel));
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(9));
        xpLp.setMargins(0,dp(4),0,0); xpGroup.addView(xp,xpLp);
        hudXpText=tv(gameXp+" / "+xpNeeded(gameLevel)+" XP",8,0xFFE5F7FF); TextView xpTxt=hudXpText;
        xpTxt.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        xpGroup.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(14)));
        LinearLayout.LayoutParams xpgLp=new LinearLayout.LayoutParams(dp(110),dp(35));
        xpgLp.setMargins(0,0,dp(3),0); row.addView(xpGroup,xpgLp);

        LinearLayout coinBox=glassCapsule();
        ImageView coinIcon=new ImageView(this);
        coinIcon.setImageResource(R.drawable.hud_coin); coinIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        coinBox.addView(coinIcon,new LinearLayout.LayoutParams(dp(24),dp(24)));
        hudCoinText=tv(String.valueOf(gameCoins),13,0xFFFFF3CF); TextView coin=hudCoinText; coin.setPadding(dp(1),0,0,0);
        coinBox.addView(coin,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(25));
        coinLp.setMargins(0,0,dp(1),0); row.addView(coinBox,coinLp);

        LinearLayout comboBox=glassCapsule();
        comboBox.setClickable(true);
        comboBox.setContentDescription("Combo");
        comboBox.setOnClickListener(v->showGameSettings());
        ImageView flame=new ImageView(this); flame.setImageResource(R.drawable.hud_flame);
        flame.setScaleType(ImageView.ScaleType.FIT_CENTER);
        comboBox.addView(flame,new LinearLayout.LayoutParams(dp(22),dp(25)));
        hudComboText=tv(String.valueOf(gameCombo),13,Color.WHITE); TextView combo=hudComboText; comboBox.addView(combo,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(44),dp(25));
        comboLp.setMargins(0,0,dp(1),0); row.addView(comboBox,comboLp);

        ImageView gear=new ImageView(this); gear.setImageResource(R.drawable.hud_gear);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER); gear.setPadding(dp(4),dp(4),dp(4),dp(4));
        gear.setContentDescription("تنظیمات");
        gear.setOnClickListener(v->showGameSettings());
        row.addView(gear,new LinearLayout.LayoutParams(dp(34),dp(40)));

        // Hit targets follow the six labels baked into the selected 768x1536 Home artwork.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=768f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            // The touch zones sit on the signboards and slightly above their text,
            // matching the new 768x1536 fantasy Home artwork.
            int hitW=Math.max(dp(112), Math.round(220f*scale));
            int hitH=Math.max(dp(48), Math.round(92f*scale));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=Math.round(offsetX + srcW*centers[i][0]*scale);
                int cy=Math.round(offsetY + srcH*centers[i][1]*scale);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-hitW/2; lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==MotionEvent.ACTION_DOWN){ v.setAlpha(.55f); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->{ if(idx==0) showProgressPath(); else showPlaceholder(names[idx]); }); content.addView(hit,lp);
            }
        });
        addActiveMissionBar();
        header.bringToFront();
    }

    private LinearLayout glassCapsule(){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0x3803080E,dp(12)); g.setStroke(dp(1),0x225D7180); box.setBackground(g);
        return box;
    }

    private class XpBarView extends View {
        private final Paint p=new Paint(1); private int value=0,max=100;
        XpBarView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void setProgress(int v,int m){ value=Math.max(0,v); max=Math.max(1,m); invalidate(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float h=getHeight(), r=h/2f; RectF track=new RectF(dp(1),dp(1),getWidth()-dp(1),h-dp(1));
            p.setStyle(Paint.Style.FILL); p.setColor(0xAA071522); c.drawRoundRect(track,r,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xAA5EB8E8); c.drawRoundRect(track,r,r,p);
            float frac=Math.min(1f,value/(float)max);
            if(frac>0f){ RectF fill=new RectF(track.left,track.top,track.left+track.width()*frac,track.bottom);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF25E6FF); p.setShadowLayer(dp(4),0,0,0xCC19D9FF); c.drawRoundRect(fill,r,r,p); p.clearShadowLayer(); }
            else { p.setStyle(Paint.Style.FILL); p.setColor(0xFF36E8FF); p.setShadowLayer(dp(3),0,0,0xAA28DFFF); c.drawCircle(track.left+dp(2),h/2f,dp(1.3f),p); p.clearShadowLayer(); }
        }
    }

    private class HudBackground extends android.graphics.drawable.Drawable {
        private final Paint fill=new Paint(1), stroke=new Paint(1), bottomGlow=new Paint(1), topAccent=new Paint(1);
        HudBackground(){
            fill.setColor(0xED08131F); fill.setStyle(Paint.Style.FILL);
            stroke.setColor(0x3D8398A6); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            bottomGlow.setColor(0xA027D5FF); bottomGlow.setStyle(Paint.Style.STROKE); bottomGlow.setStrokeWidth(dp(1));
            topAccent.setColor(0xF0E8BD62); topAccent.setStyle(Paint.Style.STROKE); topAccent.setStrokeWidth(dp(1));
        }
        private Path shape(){
            RectF b=new RectF(getBounds()); float c=dp(7); Path p=new Path();
            p.moveTo(b.left+c,b.top); p.lineTo(b.right-c,b.top); p.lineTo(b.right,b.top+c);
            p.lineTo(b.right,b.bottom-c); p.lineTo(b.right-c,b.bottom); p.lineTo(b.left+c,b.bottom);
            p.lineTo(b.left,b.bottom-c); p.lineTo(b.left,b.top+c); p.close(); return p;
        }
        @Override public void draw(Canvas c){
            RectF b=new RectF(getBounds()); Path p=shape(); c.drawPath(p,fill); c.drawPath(p,stroke);
            c.drawLine(b.left+dp(11),b.bottom-dp(1),b.right-dp(11),b.bottom-dp(1),bottomGlow);
            c.drawLine(b.left+dp(12),b.top+dp(1),b.right-dp(12),b.top+dp(1),topAccent);
        }
        @Override public void setAlpha(int a){} @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){ return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private class CoinView extends View {
        Paint p=new Paint(1); CoinView(android.content.Context c){super(c);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float r=Math.min(getWidth(),getHeight())*.43f, x=getWidth()/2f,y=getHeight()/2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFB82E); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xFFFFF0A8); c.drawCircle(x,y,r-dp(1),p);
            p.setColor(0xFFD98A00); c.drawCircle(x,y,r-dp(3),p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF8C5A00); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(10));
            c.drawText("L",x,y-(p.ascent()+p.descent())/2,p);
        }
    }

    private int gameLevel=1, gameXp=0, gameCoins=0, gameCombo=0, comboWindowMinutes=30; private long lastSuccessAt=0;
    private SharedPreferences gamePrefs;
    private int xpNeeded(int level){ return 100+Math.max(0,level-1)*50; }
    private void loadGameState(){ gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gameLevel=gamePrefs.getInt("level",1);gameXp=gamePrefs.getInt("xp",0);gameCoins=gamePrefs.getInt("coins",0);gameCombo=gamePrefs.getInt("combo",0);lastSuccessAt=gamePrefs.getLong("lastSuccessAt",0);comboWindowMinutes=gamePrefs.getInt("comboWindowMinutes",30);expireComboIfNeeded(); }
    private void saveGameState(){ if(gamePrefs==null)gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gamePrefs.edit().putInt("level",gameLevel).putInt("xp",gameXp).putInt("coins",gameCoins).putInt("combo",gameCombo).putLong("lastSuccessAt",lastSuccessAt).putInt("comboWindowMinutes",comboWindowMinutes).apply();updateHud(); }
    private void updateHud(){ if(hudLevel!=null)hudLevel.setText("LV "+gameLevel);if(hudXpBar!=null)hudXpBar.setProgress(gameXp,xpNeeded(gameLevel));if(hudXpText!=null)hudXpText.setText(gameXp+" / "+xpNeeded(gameLevel)+" XP");if(hudCoinText!=null)hudCoinText.setText(String.valueOf(gameCoins));if(hudComboText!=null)hudComboText.setText(String.valueOf(gameCombo)); }
    private float comboMultiplier(){return gameCombo>=10?3f:gameCombo>=7?2f:gameCombo>=3?1.5f:1f;}
    private void expireComboIfNeeded(){if(gameCombo>0&&lastSuccessAt>0&&System.currentTimeMillis()-lastSuccessAt>comboWindowMinutes*60000L){gameCombo=0;lastSuccessAt=0;if(gamePrefs!=null)gamePrefs.edit().putInt("combo",0).putLong("lastSuccessAt",0).apply();}}

    private int[] missionTimes={5,10,20,30,45};
    private String mf(int s,int k,String f){return "m_"+s+"_"+k+"_"+f;}
    private String mv(int s,int k,String f,String d){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);return progressPrefs.getString(mf(s,k,f),d);}
    private void ms(int s,int k,String f,String v){if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);progressPrefs.edit().putString(mf(s,k,f),v).apply();}
    private GradientDrawable sel(boolean on){GradientDrawable g=bg(Color.TRANSPARENT,dp(999));if(on)g.setStroke(Math.max(1,Math.round(dp(.55f))),0xFF2477E8);return g;}
    private TextView eh(String t,int z){TextView v=tv(t,z,0xFF17345D);v.setGravity(Gravity.CENTER);return v;}

    private String missionDay(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US);return f.format(new java.util.Date());}
    private void startDailyResetTicker(){
        if(dailyResetTick!=null)missionHandler.removeCallbacks(dailyResetTick);
        lastObservedMissionDay=missionDay();
        dailyResetTick=new Runnable(){public void run(){
            String nowDay=missionDay();
            if(!nowDay.equals(lastObservedMissionDay)){lastObservedMissionDay=nowDay;applyDailyMissionResets();refreshProgressMissionVisuals();}
            missionHandler.postDelayed(this,60000L);
        }};
        missionHandler.postDelayed(dailyResetTick,60000L);
    }
    private String missionState(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressTitle(section,slot).trim().length()==0)return "empty";
        if(progressPrefs.getBoolean("active",false)&&progressPrefs.getInt("active_s",-1)==section&&progressPrefs.getInt("active_k",-1)==slot)return "active";
        String state=mv(section,slot,"state","ready");
        if("active".equals(state))state="ready";
        return state;
    }
    private void setMissionState(int section,int slot,String state){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        SharedPreferences.Editor ed=progressPrefs.edit().putString(mf(section,slot,"state"),state);
        if("done".equals(state)||"fail".equals(state))ed.putString(mf(section,slot,"state_day"),missionDay());
        else ed.remove(mf(section,slot,"state_day"));
        ed.apply();
    }
    private void applyDailyMissionResets(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        String today=missionDay();
        int count=Math.max(1,progressPrefs.getInt("progress_section_count",1));
        for(int s=1;s<=count;s++)for(int k=0;k<3;k++){
            if(progressTitle(s,k).trim().length()==0)continue;
            if(!"1".equals(mv(s,k,"repeat","1")))continue;
            String state=missionState(s,k);
            if(!("done".equals(state)||"fail".equals(state)))continue;
            String day=mv(s,k,"state_day","");
            if(!today.equals(day)){
                setMissionState(s,k,"ready");
                SharedPreferences sub=getSharedPreferences("legacy_subtasks_"+s+"_"+k,MODE_PRIVATE);
                sub.edit().putString("day",today).putString("done_ids","").apply();
            }
        }
    }
    private String missionViewKey(int section,int slot){return section+":"+slot;}
    private void styleMissionSlot(TextView mission,String state){
        mission.setShadowLayer(0,0,0,Color.TRANSPARENT);
        mission.setPaintFlags(mission.getPaintFlags()&~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        GradientDrawable g=bg(Color.TRANSPARENT,dp(999));
        if("active".equals(state)){g.setColor(0x16168CFF);g.setStroke(dp(3),0xFF168CFF);mission.setTextColor(0xFF0E66D0);mission.setShadowLayer(dp(3),0,0,0x55168CFF);}
        else if("done".equals(state)){g.setColor(0x1200C853);g.setStroke(dp(3),0xFF13B85B);mission.setTextColor(0xFF078A43);mission.setPaintFlags(mission.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);}
        else if("fail".equals(state)){g.setColor(0x12FF1744);g.setStroke(dp(3),0xFFE83E55);mission.setTextColor(0xFFBD2639);mission.setPaintFlags(mission.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);}
        else{mission.setTextColor(0xFF162D54);}
        mission.setBackground(g);
    }
    private void refreshProgressMissionVisuals(){
        if(progressMissionViews.isEmpty())return;
        for(java.util.Map.Entry<String,TextView> entry:progressMissionViews.entrySet()){
            try{String[] p=entry.getKey().split(":");int s=Integer.parseInt(p[0]),k=Integer.parseInt(p[1]);TextView v=entry.getValue();v.setText(progressTitle(s,k));styleMissionSlot(v,missionState(s,k));}catch(Exception ignored){}
        }
    }
    private void showMissionSlotMenu(final int section,final int slot){
        String title=progressTitle(section,slot);if(title.trim().length()==0){showMissionEditor(section,slot);return;}
        String state=missionState(section,slot);
        if("active".equals(state)){resumeActiveMission();return;}
        java.util.ArrayList<String> items=new java.util.ArrayList<>();
        if("done".equals(state)||"fail".equals(state))items.add("Restore");
        items.add("ویرایش مأموریت");items.add("حذف مأموریت");
        final String[] arr=items.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(title).setItems(arr,(d,which)->{
            String chosen=arr[which];
            if("Restore".equals(chosen)){setMissionState(section,slot,"ready");showProgressPath();}
            else if("ویرایش مأموریت".equals(chosen))showMissionEditor(section,slot);
            else if("حذف مأموریت".equals(chosen))confirmDeleteMission(section,slot);
        }).setNegativeButton("بستن",null).show();
    }
    private void confirmDeleteMission(final int section,final int slot){
        new AlertDialog.Builder(this).setTitle("حذف مأموریت").setMessage("این مأموریت و ساب‌تسک‌هایش حذف شوند؟")
            .setPositiveButton("حذف",(d,w)->{clearMissionSlot(section,slot);showProgressPath();}).setNegativeButton("لغو",null).show();
    }

    private void showMissionEditor(final int section,final int slot){
        stopHomeActiveTicker();
        isHome=false;isRunningMissionScreen=false;++homeGeneration;getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);content.removeAllViews();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);applyDailyMissionResets();
        FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(R.drawable.mission_editor_reference);art.setScaleType(ImageView.ScaleType.FIT_XY);
        e.addView(art,new FrameLayout.LayoutParams(-1,-1));

        final String old=progressTitle(section,slot);
        final EditText title=new EditText(this);title.setSingleLine(true);title.setText(old.length()==0?"عنوان":old);
        title.setTextSize(15);title.setTextColor(0xFF17345D);title.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        title.setPadding(dp(8),0,dp(8),0);title.setBackgroundColor(Color.TRANSPARENT);title.setLongClickable(false);title.setTextIsSelectable(false);
        if(android.os.Build.VERSION.SDK_INT>=29){
            try{
                title.setTextCursorDrawable(getDrawable(R.drawable.editor_cursor));
                title.setTextSelectHandle(getDrawable(R.drawable.editor_handle_invisible));
                title.setTextSelectHandleLeft(getDrawable(R.drawable.editor_handle_invisible));
                title.setTextSelectHandleRight(getDrawable(R.drawable.editor_handle_invisible));
            }catch(Exception ignored){}
        }
        FrameLayout.LayoutParams tl=new FrameLayout.LayoutParams(0,0);e.addView(title,tl);

        final TextView circleTitle=eh(old,16);circleTitle.setTextColor(0xFF17345D);circleTitle.setTranslationX(dp(2.5f));circleTitle.setTranslationY(-dp(1.5f));
        FrameLayout.LayoutParams cl=new FrameLayout.LayoutParams(0,0);e.addView(circleTitle,cl);

        // Every truly new/empty mission starts from the agreed defaults.
        if(old.trim().length()==0){
            progressPrefs.edit()
                .putString(mf(section,slot,"importance"),"0")
                .putString(mf(section,slot,"minutes"),"10")
                .putString(mf(section,slot,"repeat"),"1")
                .putString(mf(section,slot,"state"),"ready")
                .remove(mf(section,slot,"state_day"))
                .apply();
        }
        final int[] imp={Integer.parseInt(mv(section,slot,"importance","0"))};
        final TextView[] iv={eh("",1),eh("",1),eh("",1)};
        for(TextView v:iv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        int saved=Integer.parseInt(mv(section,slot,"minutes","10"));final int[] ti={1};
        for(int i=0;i<missionTimes.length;i++)if(missionTimes[i]==saved)ti[0]=i;
        final TextView minus=eh("",1),time=eh(missionTimes[ti[0]]+" دقیقه",15),plus=eh("",1);time.setTranslationY(0f);
        e.addView(minus,new FrameLayout.LayoutParams(0,0));e.addView(time,new FrameLayout.LayoutParams(0,0));e.addView(plus,new FrameLayout.LayoutParams(0,0));

        final int[] rp={Integer.parseInt(mv(section,slot,"repeat","1"))};
        final TextView[] rv={eh("",1),eh("",1)};
        for(TextView v:rv)e.addView(v,new FrameLayout.LayoutParams(0,0));

        final TextView start=eh("Start Mission",1);start.setTextColor(Color.TRANSPARENT);start.setBackgroundColor(Color.TRANSPARENT);
        e.addView(start,new FrameLayout.LayoutParams(0,0));

        // Exact responsive hit areas from the approved 768x1536 artwork.
        e.addOnLayoutChangeListener((v,l,t,r,bt,ol,ot,or,ob)->{
            int w=e.getWidth(),h=e.getHeight();
            java.util.function.BiConsumer<View,float[]> place=(view,q)->{
                FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();
                p.width=Math.round(w*q[2]);p.height=Math.round(h*q[3]);
                p.leftMargin=Math.round(w*q[0]);p.topMargin=Math.round(h*q[1]);view.setLayoutParams(p);
            };
            place.accept(title,new float[]{.379f,.410f,.440f,.040f});
            // Calibrated against the supplied phone screenshot: label box matches the full cyan circle.
            place.accept(circleTitle,new float[]{.523f,.152f,.337f,.164f});
            // Pixel-calibrated to the colored pills in the 768x1536 reference artwork.
            place.accept(iv[0],new float[]{.388f,.493f,.159f,.0385f});
            place.accept(iv[1],new float[]{.574f,.493f,.163f,.0385f});
            place.accept(iv[2],new float[]{.763f,.493f,.160f,.0385f});
            place.accept(minus,new float[]{.382f,.565f,.090f,.055f});
            place.accept(time,new float[]{.470f,.571f,.250f,.055f});
            place.accept(plus,new float[]{.718f,.565f,.090f,.055f});
            place.accept(rv[0],new float[]{.396f,.665f,.237f,.038f});
            place.accept(rv[1],new float[]{.663f,.665f,.253f,.038f});
            place.accept(start,new float[]{.130f,.785f,.740f,.075f});
        });

        // Defaults are visible immediately.
        for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));
        for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));
        time.setText(missionTimes[ti[0]]+" دقیقه");

        title.setOnFocusChangeListener((v,has)->{
            if(has&&"عنوان".contentEquals(title.getText()))title.setText("");
            if(!has){String x=title.getText().toString().trim();
                if(x.length()==0){title.setText("عنوان");circleTitle.setText("");progressPrefs.edit().remove("title_"+section+"_"+slot).putString(mf(section,slot,"state"),"ready").remove(mf(section,slot,"state_day")).apply();}
                else{progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();if("empty".equals(missionState(section,slot)))setMissionState(section,slot,"ready");circleTitle.setText(x);}
            }
        });
        title.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence x,int a,int b,int c){}
            public void onTextChanged(CharSequence x,int a,int b,int c){String q=x.toString().trim();circleTitle.setText("عنوان".equals(q)?"":q);}
            public void afterTextChanged(android.text.Editable x){}
        });
        for(int i=0;i<3;i++){final int q=i;iv[i].setClickable(true);iv[i].setOnClickListener(v->{imp[0]=q;ms(section,slot,"importance",""+q);for(int j=0;j<3;j++)iv[j].setBackground(sel(j==imp[0]));});}
        minus.setClickable(true);plus.setClickable(true);
        minus.setOnClickListener(v->{if(ti[0]>0)ti[0]--;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        plus.setOnClickListener(v->{if(ti[0]<missionTimes.length-1)ti[0]++;time.setText(missionTimes[ti[0]]+" دقیقه");ms(section,slot,"minutes",""+missionTimes[ti[0]]);});
        for(int i=0;i<2;i++){final int q=i;rv[i].setClickable(true);rv[i].setOnClickListener(v->{rp[0]=q;ms(section,slot,"repeat",""+q);for(int j=0;j<2;j++)rv[j].setBackground(sel(j==rp[0]));});}
        start.setClickable(true);start.setOnClickListener(v->{
            String x=title.getText().toString().trim();
            if(x.length()==0||"عنوان".equals(x)){Toast.makeText(this,"عنوان مأموریت را وارد کنید",Toast.LENGTH_SHORT).show();return;}
            progressPrefs.edit().putString("title_"+section+"_"+slot,x).apply();
            if("empty".equals(missionState(section,slot)))setMissionState(section,slot,"ready");
            hideKeyboard(title);
            if(progressPrefs.getBoolean("active",false)){
                int as=progressPrefs.getInt("active_s",-1),ak=progressPrefs.getInt("active_k",-1);
                if(as==section&&ak==slot){resumeActiveMission();return;}
                new AlertDialog.Builder(this)
                    .setTitle("ماموریت در حال اجرا")
                    .setMessage("برای شروع مأموریت جدید، ابتدا مأموریت فعال را تعیین تکلیف کنید.")
                    .setPositiveButton("ادامه مأموریت",(d,w)->resumeActiveMission())
                    .setNegativeButton("لغو",null)
                    .show();
                return;
            }
            startRunningMission(section,slot,x,missionTimes[ti[0]]);
        });
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
    }

    private void hideKeyboard(View v){
        try{((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}
    }

    private android.os.Handler missionHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable missionTick;
    private android.media.MediaPlayer missionPlayer; private boolean missionMuted=false; private static final int REQ_MISSION_MUSIC=9042;

    private class MissionProgressView extends View {
        private final Paint p=new Paint(1); private float fraction=0f;
        MissionProgressView(android.content.Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setFraction(float f){fraction=Math.max(0f,Math.min(1f,f));invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float sw=dp(8),pad=sw/2f+dp(3);RectF r=new RectF(pad,pad,getWidth()-pad,getHeight()-pad);
            p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(sw);p.setColor(0xFFF8FBFF);c.drawArc(r,-90,360,false,p);
            if(fraction>0f){p.setColor(0xFF168CFF);p.setShadowLayer(dp(5),0,0,0x77168CFF);c.drawArc(r,-90,360f*fraction,false,p);p.clearShadowLayer();}
            float a=(float)Math.toRadians(-90+360f*fraction),cx=r.centerX()+r.width()/2f*(float)Math.cos(a),cy=r.centerY()+r.height()/2f*(float)Math.sin(a);
            p.setStyle(Paint.Style.FILL);p.setColor(0xFF087EF2);p.setShadowLayer(dp(5),0,0,0x99168CFF);c.drawCircle(cx,cy,dp(7),p);p.clearShadowLayer();
        }
    }

    private void startRunningMission(final int section,final int slot,final String title,final int minutes){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(progressPrefs.getBoolean("active",false)){
            int as=progressPrefs.getInt("active_s",-1),ak=progressPrefs.getInt("active_k",-1);
            if(as==section&&ak==slot){resumeActiveMission();return;}
            new AlertDialog.Builder(this)
                .setTitle("ماموریت در حال اجرا")
                .setMessage("همزمان فقط یک مأموریت می‌تواند فعال باشد.")
                .setPositiveButton("ادامه مأموریت",(d,w)->resumeActiveMission())
                .setNegativeButton("لغو",null)
                .show();
            return;
        }
        setMissionState(section,slot,"ready");
        final long total=minutes*60000L;
        final long endAt=System.currentTimeMillis()+total;
        progressPrefs.edit()
            .putBoolean("active",true)
            .putInt("active_s",section)
            .putInt("active_k",slot)
            .putString("active_title",title)
            .putLong("active_end",endAt)
            .putLong("active_total",total)
            .putBoolean("active_alerted",false)
            .apply();
        ensureNotificationPermission();
        cancelMissionNotification();
        scheduleMissionAlarm(endAt);
        showRunningMissionScreen(section,slot,title,endAt,total);
    }

    private void resumeActiveMission(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(!progressPrefs.getBoolean("active",false)){Toast.makeText(this,"ماموریت فعالی وجود ندارد",Toast.LENGTH_SHORT).show();showProgressPath();return;}
        int section=progressPrefs.getInt("active_s",-1),slot=progressPrefs.getInt("active_k",-1);
        long endAt=progressPrefs.getLong("active_end",0),total=progressPrefs.getLong("active_total",0);
        String title=progressPrefs.getString("active_title","");
        if(title.trim().length()==0&&section>0&&slot>=0)title=progressTitle(section,slot);
        if(section<1||slot<0||endAt<=0||total<=0){clearActiveMissionState();Toast.makeText(this,"اطلاعات مأموریت فعال ناقص بود",Toast.LENGTH_SHORT).show();showProgressPath();return;}
        showRunningMissionScreen(section,slot,title,endAt,total);
    }

    private void showRunningMissionScreen(final int section,final int slot,final String title,final long endAt,final long total){
        stopHomeActiveTicker();
        removeActiveMissionBar();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        isHome=false;isRunningMissionScreen=true;++homeGeneration;content.removeAllViews();
        final FrameLayout e=new FrameLayout(this);
        ImageView art=new ImageView(this);art.setImageResource(R.drawable.mission_running_reference);art.setScaleType(ImageView.ScaleType.FIT_XY);e.addView(art,new FrameLayout.LayoutParams(-1,-1));
        final TextView missionTitle=eh(title,16);missionTitle.setTextColor(0xFF17345D);e.addView(missionTitle,new FrameLayout.LayoutParams(0,0));
        final MissionProgressView ring=new MissionProgressView(this);e.addView(ring,new FrameLayout.LayoutParams(0,0));
        final TextView timer=eh("",34);timer.setTextColor(0xFF071A4A);e.addView(timer,new FrameLayout.LayoutParams(0,0));
        final View done=new View(this),fail=new View(this),music=new View(this),sound=new View(this),reset=new View(this),subtasks=new View(this);
        done.setContentDescription("Done");fail.setContentDescription("Fail");music.setContentDescription("Choose music");sound.setContentDescription("Sound on/off");reset.setContentDescription("Reset mission");subtasks.setContentDescription("Subtasks");
        e.addView(done,new FrameLayout.LayoutParams(0,0));e.addView(fail,new FrameLayout.LayoutParams(0,0));e.addView(music,new FrameLayout.LayoutParams(0,0));e.addView(sound,new FrameLayout.LayoutParams(0,0));e.addView(reset,new FrameLayout.LayoutParams(0,0));e.addView(subtasks,new FrameLayout.LayoutParams(0,0));
        e.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{int w=e.getWidth(),h=e.getHeight();java.util.function.BiConsumer<View,float[]> place=(view,q)->{FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)view.getLayoutParams();p.width=Math.round(w*q[2]);p.height=Math.round(h*q[3]);p.leftMargin=Math.round(w*q[0]);p.topMargin=Math.round(h*q[1]);view.setLayoutParams(p);};
            place.accept(missionTitle,new float[]{.565f,.113f,.330f,.155f});
            place.accept(ring,new float[]{.238f,.442f,.525f,.263f});
            place.accept(timer,new float[]{.270f,.505f,.460f,.120f});
            place.accept(done,new float[]{.135f,.690f,.240f,.130f});place.accept(fail,new float[]{.625f,.690f,.240f,.130f});
            place.accept(music,new float[]{.105f,.842f,.165f,.090f});place.accept(sound,new float[]{.285f,.842f,.165f,.090f});place.accept(reset,new float[]{.545f,.842f,.165f,.090f});place.accept(subtasks,new float[]{.725f,.842f,.165f,.090f});
        });
        missionMuted=missionAudioPrefs().getBoolean("muted",false);
        playSavedMissionMusic();
        if(missionTick!=null)missionHandler.removeCallbacks(missionTick);
        missionTick=new Runnable(){public void run(){
            long rem=Math.max(0,endAt-System.currentTimeMillis());
            long elapsed=Math.min(total,Math.max(0,total-rem));
            ring.setFraction(total<=0?1f:elapsed/(float)total);
            long sec=(rem+999)/1000;
            timer.setText(String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60));
            if(rem>0)missionHandler.postDelayed(this,250);
            else{
                timer.setText("00:00");
                ring.setFraction(1f);
                stopMissionMusic();
                if(progressPrefs!=null&&!progressPrefs.getBoolean("active_alerted",false))finishMissionTimerAlert();
            }
        }};missionHandler.post(missionTick);
        done.setOnClickListener(v->completeMission(true));fail.setOnClickListener(v->completeMission(false));
        music.setOnClickListener(v->chooseMissionMusic());
        sound.setOnClickListener(v->{
            missionMuted=!missionMuted;
            missionAudioPrefs().edit().putBoolean("muted",missionMuted).apply();
            if(missionPlayer!=null)missionPlayer.setVolume(missionMuted?0f:1f,missionMuted?0f:1f);
            Toast.makeText(this,missionMuted?"صدا قطع شد":"صدا وصل شد",Toast.LENGTH_SHORT).show();
        });
        reset.setOnClickListener(v->laterMission(section,slot));
        subtasks.setOnClickListener(v->showSubtasksPopup(section,slot));
        content.addView(e,new FrameLayout.LayoutParams(-1,-1));
    }

    private SharedPreferences missionAudioPrefs(){
        return getSharedPreferences("legacy_mission_audio",MODE_PRIVATE);
    }
    private final int[] defaultFocusMusic={R.raw.focus_deep,R.raw.focus_calm,R.raw.focus_flow};
    private final String[] defaultFocusMusicNames={"تمرکز عمیق","آرامش","جریان"};

    private String selectedMissionMusic(){
        SharedPreferences sp=missionAudioPrefs();
        String selected=sp.getString("selected","");
        if(selected.length()==0){
            // One-time migration from the v43 single-URI setting.
            String old=sp.getString("uri","");
            if(old.length()>0){
                selected="u:"+old;
                addUserMusicTrack(old,displayNameForUri(android.net.Uri.parse(old)));
            }else selected="d:0";
            sp.edit().putString("selected",selected).apply();
        }
        return selected;
    }
    private java.util.ArrayList<String[]> loadUserMusicTracks(){
        java.util.ArrayList<String[]> out=new java.util.ArrayList<>();
        String raw=missionAudioPrefs().getString("user_tracks","");
        for(String line:raw.split("\n")){
            if(line.trim().length()==0)continue;
            String[] parts=line.split("\t",2);
            if(parts.length<2)continue;
            try{
                out.add(new String[]{android.net.Uri.decode(parts[0]),android.net.Uri.decode(parts[1])});
            }catch(Exception ignored){}
        }
        return out;
    }
    private void saveUserMusicTracks(java.util.ArrayList<String[]> tracks){
        java.util.ArrayList<String> lines=new java.util.ArrayList<>();
        for(String[] x:tracks){
            if(x==null||x.length<2||x[0]==null||x[0].trim().length()==0)continue;
            lines.add(android.net.Uri.encode(x[0])+"\t"+android.net.Uri.encode(x[1]==null?"موسیقی":x[1]));
        }
        missionAudioPrefs().edit().putString("user_tracks",android.text.TextUtils.join("\n",lines)).apply();
    }
    private void addUserMusicTrack(String uri,String name){
        if(uri==null||uri.trim().length()==0)return;
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        for(String[] x:tracks)if(uri.equals(x[0]))return;
        tracks.add(new String[]{uri,(name==null||name.trim().length()==0)?"موسیقی گوشی":name.trim()});
        saveUserMusicTracks(tracks);
    }
    private void removeUserMusicTrack(String uri){
        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        java.util.ArrayList<String[]> keep=new java.util.ArrayList<>();
        for(String[] x:tracks)if(!uri.equals(x[0]))keep.add(x);
        saveUserMusicTracks(keep);
        if(("u:"+uri).equals(selectedMissionMusic())){
            missionAudioPrefs().edit().putString("selected","d:0").apply();
            playMissionDefault(0);
        }
    }
    private String displayNameForUri(android.net.Uri uri){
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);
            if(c!=null&&c.moveToFirst()){
                int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if(i>=0){String n=c.getString(i);if(n!=null&&n.trim().length()>0)return n;}
            }
        }catch(Exception ignored){}finally{try{if(c!=null)c.close();}catch(Exception ignored){}}
        String last=uri==null?null:uri.getLastPathSegment();
        return last==null?"موسیقی گوشی":last;
    }

    private void showMissionMusicPicker(){
        final LinearLayout outer=new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(16),dp(10),dp(16),dp(8));
        outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final AlertDialog[] dlg={null};
        String selected=selectedMissionMusic();

        TextView defaultHead=tv("موسیقی‌های تمرکز",13,0xFF42526B);
        defaultHead.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        outer.addView(defaultHead,new LinearLayout.LayoutParams(-1,dp(36)));
        for(int i=0;i<defaultFocusMusic.length;i++){
            final int q=i;
            String key="d:"+i;
            addMusicPickerRow(outer,defaultFocusMusicNames[i],key.equals(selected),
                ()->{ missionAudioPrefs().edit().putString("selected","d:"+q).apply();playMissionDefault(q);if(dlg[0]!=null)dlg[0].dismiss(); },
                null);
        }

        java.util.ArrayList<String[]> tracks=loadUserMusicTracks();
        if(!tracks.isEmpty()){
            TextView phoneHead=tv("موسیقی‌های گوشی",13,0xFF42526B);
            phoneHead.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams ph=new LinearLayout.LayoutParams(-1,dp(38));ph.topMargin=dp(4);outer.addView(phoneHead,ph);
            for(String[] x:tracks){
                final String uri=x[0],name=x[1];
                addMusicPickerRow(outer,name,("u:"+uri).equals(selected),
                    ()->{ missionAudioPrefs().edit().putString("selected","u:"+uri).putString("uri",uri).apply();playMissionMusic(android.net.Uri.parse(uri));if(dlg[0]!=null)dlg[0].dismiss(); },
                    ()->{ removeUserMusicTrack(uri);if(dlg[0]!=null)dlg[0].dismiss();showMissionMusicPicker(); });
            }
        }

        TextView add=tv("＋  افزودن موسیقی از گوشی",14,0xFF176EDB);
        add.setGravity(Gravity.CENTER);
        GradientDrawable ag=bg(0xFFF2F6FF,dp(14));ag.setStroke(1,0x553177D7);add.setBackground(ag);
        LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(48));alp.topMargin=dp(10);outer.addView(add,alp);
        add.setOnClickListener(v->{ if(dlg[0]!=null)dlg[0].dismiss();chooseMissionMusicFromPhone(); });

        ScrollView scroll=new ScrollView(this);scroll.addView(outer,new ScrollView.LayoutParams(-1,-2));
        dlg[0]=new AlertDialog.Builder(this).setTitle("Music").setView(scroll).setNegativeButton("بستن",null).create();
        dlg[0].show();
    }
    private void addMusicPickerRow(LinearLayout outer,String name,boolean selected,Runnable choose,Runnable delete){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),0,dp(10),0);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        GradientDrawable rg=bg(selected?0xFFEAF4FF:0x00FFFFFF,dp(12));if(selected)rg.setStroke(1,0xFF2477E8);row.setBackground(rg);
        TextView label=tv((selected?"✓  ":"")+name,14,0xFF17345D);label.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        row.addView(label,new LinearLayout.LayoutParams(0,dp(46),1f));
        if(delete!=null){
            TextView del=tv("×",20,0xFFD84A55);del.setGravity(Gravity.CENTER);del.setContentDescription("حذف موسیقی");
            row.addView(del,new LinearLayout.LayoutParams(dp(42),dp(46)));
            del.setOnClickListener(v->delete.run());
        }
        row.setOnClickListener(v->choose.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.bottomMargin=dp(4);outer.addView(row,lp);
    }
    private void chooseMissionMusicFromPhone(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_MISSION_MUSIC);
    }
    private void chooseMissionMusic(){showMissionMusicPicker();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_MISSION_MUSIC&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{
                android.net.Uri u=data.getData();
                int takeFlags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try{getContentResolver().takePersistableUriPermission(u,takeFlags&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                String uri=u.toString();
                addUserMusicTrack(uri,displayNameForUri(u));
                missionAudioPrefs().edit().putString("selected","u:"+uri).putString("uri",uri).apply();
                playMissionMusic(u);
                Toast.makeText(this,"به لیست موسیقی‌ها اضافه شد",Toast.LENGTH_SHORT).show();
            }catch(Exception ex){Toast.makeText(this,"موزیک قابل پخش نیست",Toast.LENGTH_SHORT).show();}
        }
    }
    private void playMissionDefault(int index){
        stopMissionMusic();
        try{
            int q=Math.max(0,Math.min(defaultFocusMusic.length-1,index));
            missionPlayer=android.media.MediaPlayer.create(this,defaultFocusMusic[q]);
            if(missionPlayer!=null){
                missionPlayer.setLooping(true);missionPlayer.setVolume(missionMuted?0f:1f,missionMuted?0f:1f);missionPlayer.start();
            }
        }catch(Exception ignored){}
    }
    private void playMissionMusic(android.net.Uri u){
        stopMissionMusic();
        try{
            missionPlayer=android.media.MediaPlayer.create(this,u);
            if(missionPlayer!=null){missionPlayer.setLooping(true);missionPlayer.setVolume(missionMuted?0f:1f,missionMuted?0f:1f);missionPlayer.start();}
        }catch(Exception ignored){}
    }
    private void playSavedMissionMusic(){
        if(missionPlayer!=null)return;
        String selected=selectedMissionMusic();
        try{
            if(selected.startsWith("d:")){
                int q=Integer.parseInt(selected.substring(2));playMissionDefault(q);
            }else if(selected.startsWith("u:")){
                playMissionMusic(android.net.Uri.parse(selected.substring(2)));
                if(missionPlayer==null){missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
            }else{missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
        }catch(Exception ex){missionAudioPrefs().edit().putString("selected","d:0").apply();playMissionDefault(0);}
    }
    private void stopMissionMusic(){try{if(missionPlayer!=null){missionPlayer.stop();missionPlayer.release();missionPlayer=null;}}catch(Exception ignored){missionPlayer=null;}}

    private String subtaskDay(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US);return f.format(new java.util.Date());}
    private void showSubtasksPopup(final int section,final int slot){
        final SharedPreferences sp=getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE);
        String day=subtaskDay();
        if(!day.equals(sp.getString("day",""))){sp.edit().putString("day",day).putString("done_ids","").apply();}

        final LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setPadding(dp(14),dp(8),dp(14),dp(8));outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final LinearLayout addRow=new LinearLayout(this);addRow.setOrientation(LinearLayout.HORIZONTAL);addRow.setGravity(Gravity.CENTER_VERTICAL);addRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final EditText add=new EditText(this);add.setHint("ساب‌تسک جدید");add.setSingleLine(true);add.setTextSize(14);add.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        TextView addButton=tv("＋",22,0xFF176EDB);addButton.setGravity(Gravity.CENTER);
        addRow.addView(add,new LinearLayout.LayoutParams(0,dp(48),1f));addRow.addView(addButton,new LinearLayout.LayoutParams(dp(48),dp(48)));outer.addView(addRow,new LinearLayout.LayoutParams(-1,dp(50)));

        final ScrollView scroll=new ScrollView(this);final LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(list,new ScrollView.LayoutParams(-1,-2));outer.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(440),getResources().getDisplayMetrics().heightPixels/2)));
        final Runnable render=new Runnable(){public void run(){
            list.removeAllViews();
            String raw=sp.getString("items","");
            java.util.LinkedHashSet<String> doneIds=new java.util.LinkedHashSet<>();
            for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0)doneIds.add(x.trim());
            java.util.ArrayList<String[]> active=new java.util.ArrayList<>(),done=new java.util.ArrayList<>();
            for(String line:raw.split("\n")){
                if(line.trim().length()==0)continue;
                String[] parts=line.split("\\|",2);if(parts.length<2)continue;
                (doneIds.contains(parts[0])?done:active).add(parts);
            }
            if(active.isEmpty()&&done.isEmpty()){
                TextView empty=tv("هنوز ساب‌تسکی اضافه نشده",13,0xFF8290A6);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(58)));
                return;
            }
            if(!active.isEmpty()){TextView a=tv("فعال",12,0xFF42526B);a.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);list.addView(a,new LinearLayout.LayoutParams(-1,dp(32)));}
            for(String[] x:active)addSubtaskRow(list,x[0],x[1],false,sp,this);
            if(!done.isEmpty()){TextView sep=tv("انجام‌شده",12,0xFF6D7890);sep.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,dp(36));slp.topMargin=dp(6);list.addView(sep,slp);}
            for(String[] x:done)addSubtaskRow(list,x[0],x[1],true,sp,this);
        }};
        Runnable addAction=()->{
            String x=add.getText().toString().trim();
            if(x.length()==0)return;
            String raw=sp.getString("items","");
            String id=System.currentTimeMillis()+"_"+Math.abs((x+System.nanoTime()).hashCode());
            sp.edit().putString("items",raw+(raw.length()>0?"\n":"")+id+"|"+x.replace("\n"," ")).apply();
            add.setText("");render.run();
        };
        addButton.setOnClickListener(v->addAction.run());
        add.setOnEditorActionListener((v,a,event)->{addAction.run();return true;});
        render.run();
        new AlertDialog.Builder(this).setTitle("Subtasks").setView(outer).setNegativeButton("بستن",null).show();
    }
    private void addSubtaskRow(LinearLayout list,String id,String text,boolean checked,SharedPreferences sp,Runnable render){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        CheckBox c=new CheckBox(this);c.setText(text);c.setChecked(checked);c.setTextSize(14);c.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        TextView edit=tv("✎",17,0xFF2477E8);edit.setGravity(Gravity.CENTER);edit.setContentDescription("ویرایش");
        TextView del=tv("×",20,0xFFD84A55);del.setGravity(Gravity.CENTER);del.setContentDescription("حذف");
        row.addView(c,new LinearLayout.LayoutParams(0,dp(50),1f));row.addView(edit,new LinearLayout.LayoutParams(dp(42),dp(50)));row.addView(del,new LinearLayout.LayoutParams(dp(42),dp(50)));
        c.setOnCheckedChangeListener((b,on)->{
            java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();
            for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0)set.add(x.trim());
            if(on)set.add(id);else set.remove(id);
            sp.edit().putString("done_ids",android.text.TextUtils.join("\n",set)).apply();
            b.post(render);
        });
        edit.setOnClickListener(v->{
            final EditText input=new EditText(this);input.setSingleLine(true);input.setText(text);input.setSelection(input.getText().length());
            new AlertDialog.Builder(this).setTitle("ویرایش ساب‌تسک").setView(input)
                .setPositiveButton("ذخیره",(d,w)->{String n=input.getText().toString().trim();if(n.length()>0){updateSubtaskText(sp,id,n);render.run();}})
                .setNegativeButton("لغو",null).show();
        });
        del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("این ساب‌تسک حذف شود؟")
            .setPositiveButton("حذف",(d,w)->{deleteSubtask(sp,id);render.run();}).setNegativeButton("لغو",null).show());
        list.addView(row,new LinearLayout.LayoutParams(-1,dp(52)));
    }
    private void updateSubtaskText(SharedPreferences sp,String id,String newText){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);
            if(p.length==2&&id.equals(p[0]))out.add(id+"|"+newText.replace("\n"," "));
            else out.add(line);
        }
        sp.edit().putString("items",android.text.TextUtils.join("\n",out)).apply();
    }
    private void deleteSubtask(SharedPreferences sp,String id){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(String line:sp.getString("items","").split("\n")){
            if(line.trim().length()==0)continue;
            String[] p=line.split("\\|",2);if(p.length==2&&id.equals(p[0]))continue;out.add(line);
        }
        java.util.LinkedHashSet<String> done=new java.util.LinkedHashSet<>();
        for(String x:sp.getString("done_ids","").split("\n"))if(x.trim().length()>0&&!id.equals(x.trim()))done.add(x.trim());
        sp.edit().putString("items",android.text.TextUtils.join("\n",out)).putString("done_ids",android.text.TextUtils.join("\n",done)).apply();
    }

    private void stopMissionTimer(){if(missionTick!=null){missionHandler.removeCallbacks(missionTick);missionTick=null;}}
    private void stopHomeActiveTicker(){if(homeActiveTick!=null){missionHandler.removeCallbacks(homeActiveTick);homeActiveTick=null;}}
    private void completeMission(boolean success){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        int section=progressPrefs.getInt("active_s",-1),slot=progressPrefs.getInt("active_k",-1);
        stopMissionTimer();stopMissionMusic();
        if(section>0&&slot>=0)setMissionState(section,slot,success?"done":"fail");
        if(success){
            expireComboIfNeeded();
            float mult=comboMultiplier();
            int earnedXp=Math.max(1,Math.round(20f*mult));
            int earnedCoins=Math.max(1,Math.round(5f*mult));
            int oldLevel=gameLevel;
            gameXp+=earnedXp;gameCoins+=earnedCoins;gameCombo++;lastSuccessAt=System.currentTimeMillis();
            while(gameXp>=xpNeeded(gameLevel)){gameXp-=xpNeeded(gameLevel);gameLevel++;}
            boolean leveled=gameLevel>oldLevel;int newLevel=gameLevel;
            saveGameState();clearActiveMissionState();
            animateRewardAndReturn(earnedXp,earnedCoins,leveled,newLevel);
        }else{
            gameCombo=0;lastSuccessAt=0;saveGameState();clearActiveMissionState();
            Toast.makeText(this,"Mission Failed",Toast.LENGTH_SHORT).show();showProgressPath();
        }
    }
    private void laterMission(int section,int slot){
        stopMissionTimer();stopMissionMusic();
        if(section>0&&slot>=0)setMissionState(section,slot,"ready");
        clearActiveMissionState();
        Toast.makeText(this,"مأموریت برای اجرای بعدی از زمان کامل آماده شد",Toast.LENGTH_SHORT).show();
        showProgressPath();
    }
    private void clearActiveMissionState(){
        cancelMissionAlarm();cancelMissionNotification();removeActiveMissionBar();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit()
            .putBoolean("active",false)
            .remove("active_s").remove("active_k").remove("active_title")
            .remove("active_end").remove("active_total").remove("active_alerted")
            .apply();
    }
    private void animateRewardAndReturn(int xp,int coins,boolean leveled,int newLevel){
        if(root==null){showProgressPath();if(leveled)showLevelUpCard(newLevel);return;}
        final TextView xpFly=tv("+"+xp+" XP",16,0xFF16D9FF);
        final TextView coinFly=tv("+"+coins+" Coins",16,0xFFFFC544);
        xpFly.setShadowLayer(dp(4),0,0,0xAA16D9FF);coinFly.setShadowLayer(dp(4),0,0,0xAAFFB100);
        int rw=Math.max(root.getWidth(),getResources().getDisplayMetrics().widthPixels),rh=Math.max(root.getHeight(),getResources().getDisplayMetrics().heightPixels);
        int flyW=dp(130),flyH=dp(44),startX=rw/2-flyW/2,startY=Math.round(rh*.68f);
        FrameLayout.LayoutParams xlp=new FrameLayout.LayoutParams(flyW,flyH);xlp.leftMargin=startX;xlp.topMargin=startY;root.addView(xpFly,xlp);
        FrameLayout.LayoutParams clp=new FrameLayout.LayoutParams(flyW,flyH);clp.leftMargin=startX;clp.topMargin=startY+dp(45);root.addView(coinFly,clp);
        float xpDx=rw*.38f-(startX+flyW/2f),coinDx=rw*.64f-(startX+flyW/2f),targetY=dp(22);
        float xpDy=targetY-startY,coinDy=targetY-(startY+dp(45));
        AnimatorSet xa=new AnimatorSet();xa.playTogether(ObjectAnimator.ofFloat(xpFly,"translationY",0,xpDy),ObjectAnimator.ofFloat(xpFly,"translationX",0,xpDx),ObjectAnimator.ofFloat(xpFly,"alpha",1f,.1f));xa.setDuration(700);xa.start();
        AnimatorSet ca=new AnimatorSet();ca.playTogether(ObjectAnimator.ofFloat(coinFly,"translationY",0,coinDy),ObjectAnimator.ofFloat(coinFly,"translationX",0,coinDx),ObjectAnimator.ofFloat(coinFly,"alpha",1f,.1f));ca.setDuration(700);ca.start();
        missionHandler.postDelayed(()->{try{root.removeView(xpFly);root.removeView(coinFly);}catch(Exception ignored){}showProgressPath();Toast.makeText(this,"Done  +"+xp+" XP  +"+coins+" Coins",Toast.LENGTH_SHORT).show();if(leveled)showLevelUpCard(newLevel);},760);
    }
    private void showLevelUpCard(int level){
        new AlertDialog.Builder(this).setTitle("Level Up").setMessage("سطح جدید شما\nLevel "+level+"\nRank: Explorer").setPositiveButton("ادامه",null).show();
    }
    private void consumePendingMissionFeedback(){
        SharedPreferences gp=getSharedPreferences("legacy_game",MODE_PRIVATE);
        int xp=gp.getInt("pending_reward_xp",0),coins=gp.getInt("pending_reward_coins",0),lvl=gp.getInt("pending_level_up",0);
        String result=gp.getString("pending_result","");
        if(xp==0&&coins==0&&lvl==0&&result.length()==0)return;
        gp.edit().remove("pending_reward_xp").remove("pending_reward_coins").remove("pending_level_up").remove("pending_result").apply();
        if("done".equals(result))Toast.makeText(this,"Done  +"+xp+" XP  +"+coins+" Coins",Toast.LENGTH_SHORT).show();
        else if("fail".equals(result))Toast.makeText(this,"Mission Failed",Toast.LENGTH_SHORT).show();
        else if("later".equals(result))Toast.makeText(this,"مأموریت برای اجرای بعدی آماده شد",Toast.LENGTH_SHORT).show();
        if(lvl>0)showLevelUpCard(lvl);
    }
    private void ensureNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            try{requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},4102);}catch(Exception ignored){}
        }
    }
    private android.app.PendingIntent missionAlarmPendingIntent(){
        Intent i=new Intent(this,MissionAlarmReceiver.class);i.setAction("com.shahriar.legacy.MISSION_ALARM");
        return android.app.PendingIntent.getBroadcast(this,4101,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    }
    private android.app.PendingIntent missionActionPendingIntent(String action,int requestCode){
        Intent i=new Intent(this,MissionActionReceiver.class);i.setAction(action);
        return android.app.PendingIntent.getBroadcast(this,requestCode,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
    }
    private void scheduleMissionAlarm(long endAt){
        try{
            android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);
            android.app.PendingIntent pi=missionAlarmPendingIntent();
            if(android.os.Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,endAt,pi);
            else am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,endAt,pi);
        }catch(Exception ignored){}
    }
    private void cancelMissionAlarm(){try{android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);am.cancel(missionAlarmPendingIntent());}catch(Exception ignored){}}
    private void cancelMissionNotification(){try{android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.cancel(4101);}catch(Exception ignored){}}
    private void finishMissionTimerAlert(){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        progressPrefs.edit().putBoolean("active_alerted",true).apply();
        try{android.os.Vibrator vb=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);if(vb!=null){if(android.os.Build.VERSION.SDK_INT>=26)vb.vibrate(android.os.VibrationEffect.createOneShot(500,android.os.VibrationEffect.DEFAULT_AMPLITUDE));else vb.vibrate(500);}}catch(Exception ignored){}
        try{
            if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            boolean muted=missionAudioPrefs().getBoolean("muted",false);
            String ch=muted?"mission_timer_silent_v44":"mission_timer_sound_v44";
            android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if(android.os.Build.VERSION.SDK_INT>=26){
                android.app.NotificationChannel nc=new android.app.NotificationChannel(ch,muted?"Mission Timer (Silent)":"Mission Timer",android.app.NotificationManager.IMPORTANCE_HIGH);
                if(muted)nc.setSound(null,null);
                nm.createNotificationChannel(nc);
            }
            Intent open=new Intent(this,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            android.app.PendingIntent contentPi=android.app.PendingIntent.getActivity(this,4101,open,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder nb=android.os.Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,ch):new android.app.Notification.Builder(this);
            nb.setSmallIcon(R.drawable.ic_launcher_legacy).setContentTitle("Mission complete").setContentText("Done / Later / Fail را انتخاب کنید").setContentIntent(contentPi).setAutoCancel(true)
              .addAction(0,"Done",missionActionPendingIntent(MissionActionReceiver.ACTION_DONE,4201))
              .addAction(0,"Later",missionActionPendingIntent(MissionActionReceiver.ACTION_LATER,4202))
              .addAction(0,"Fail",missionActionPendingIntent(MissionActionReceiver.ACTION_FAIL,4203));
            if(android.os.Build.VERSION.SDK_INT<26)nb.setSound(muted?null:android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION));
            nm.notify(4101,nb.build());
        }catch(Exception ignored){}
    }

    private void removeActiveMissionBar(){
        stopHomeActiveTicker();
        try{if(activeBar!=null&&activeBar.getParent() instanceof ViewGroup)((ViewGroup)activeBar.getParent()).removeView(activeBar);}catch(Exception ignored){}
        activeBar=null;
    }
    private void addActiveMissionBar(){
        removeActiveMissionBar();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        if(!progressPrefs.getBoolean("active",false)||root==null||isRunningMissionScreen)return;
        final TextView bar=tv("",13,Color.WHITE);activeBar=bar;bar.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0xE6132236,dp(18));g.setStroke(Math.max(1,Math.round(dp(.7f))),0xAAE6B94A);bar.setBackground(g);
        bar.setPadding(dp(12),0,dp(12),0);bar.setElevation(dp(5));bar.setContentDescription("Continue Mission");
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(245),dp(42),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=dp(16);root.addView(bar,bp);
        bar.setOnClickListener(v->resumeActiveMission());
        homeActiveTick=new Runnable(){public void run(){
            if(bar.getParent()==null||progressPrefs==null||!progressPrefs.getBoolean("active",false)){homeActiveTick=null;return;}
            long end=progressPrefs.getLong("active_end",0);long rem=Math.max(0,end-System.currentTimeMillis());long sec=(rem+999)/1000;
            String t=String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60);
            bar.setText(rem>0?"Continue Mission  •  "+t:"Continue Mission  •  00:00");
            missionHandler.postDelayed(this,1000);
        }};missionHandler.post(homeActiveTick);
    }

    // Progress Path rebuild: visual structure only. Mission logic will be added step by step.
    private ScrollView progressScroll;
    private LinearLayout progressPages;
    private int progressSectionCount=1;
    private SharedPreferences progressPrefs;

    private String progressTitle(int section,int slot){
        if(progressPrefs==null) progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        return progressPrefs.getString("title_"+section+"_"+slot,"");
    }
    private void askProgressTitle(final int section,final int slot,final TextView label){
        final EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setText(progressTitle(section,slot));
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(this)
            .setTitle("عنوان مأموریت")
            .setView(input)
            .setPositiveButton("تأیید",(d,w)->{
                String title=input.getText().toString().trim();
                if(title.length()==0) return;
                if(progressPrefs==null) progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
                progressPrefs.edit().putString("title_"+section+"_"+slot,title).apply();
                label.setText(title);
            })
            .setNegativeButton("لغو",null)
            .show();
    }

    private void showProgressPath(){
        stopMissionTimer();
        stopHomeActiveTicker();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        isHome=false;isRunningMissionScreen=false; ++homeGeneration; content.removeAllViews();
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        applyDailyMissionResets();
        progressMissionViews.clear();
        int savedSections=Math.max(1,progressPrefs.getInt("progress_section_count",1));
        progressSectionCount=1;
        progressScroll=new ScrollView(this);
        progressScroll.setFillViewport(true);
        progressScroll.setClipToPadding(false);
        progressScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        progressScroll.setBackgroundColor(Color.TRANSPARENT);
        progressPages=new LinearLayout(this);
        progressPages.setOrientation(LinearLayout.VERTICAL);
        progressPages.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        progressScroll.addView(progressPages,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1);
        lp.topMargin=0;
        content.addView(progressScroll,lp);
        addProgressSection(false);
        while(progressSectionCount<savedSections){progressSectionCount++;addProgressSection(false);}
        addActiveMissionBar();
    }

    private void refreshProgressArrows(){if(progressPages==null)return;for(int i=0;i<progressPages.getChildCount();i++){View p=progressPages.getChildAt(i);View u=p.findViewWithTag("progress_up"),d=p.findViewWithTag("progress_down");if(u!=null){u.setVisibility(i==0?View.VISIBLE:View.GONE);u.setEnabled(i==0);}if(d!=null)d.setVisibility(i==0&&progressSectionCount>1?View.VISIBLE:View.GONE);}}

    private void addProgressSection(boolean animateToNew){
        final int sectionNumber=progressSectionCount;
        final FrameLayout page=new FrameLayout(this);
        int w=getResources().getDisplayMetrics().widthPixels;
        int pageHeight=Math.round(w*2f);

        ImageView art=new ImageView(this);
        art.setImageResource(sectionNumber%2==1?R.drawable.progress_path_first:R.drawable.progress_path_second);
        art.setScaleType(ImageView.ScaleType.FIT_XY);
        page.addView(art,new FrameLayout.LayoutParams(-1,-1));

        // Tiny naked up-arrow: top-left, no circle/square/background.
        TextView up=tv("↑",22,0xFF174FD6);
        up.setContentDescription("ادامه مسیر"); up.setTag("progress_up");
        up.setBackgroundColor(Color.TRANSPARENT);
        up.setShadowLayer(dp(2),0,dp(1),0xAAFFFFFF);
        up.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.TOP|Gravity.LEFT);
        ap.leftMargin=dp(8);
        ap.topMargin=dp(52);
        page.addView(up,ap);
        up.setOnClickListener(v->{
            progressSectionCount++;
            if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
            progressPrefs.edit().putInt("progress_section_count",progressSectionCount).apply();
            addProgressSection(true);
        });

        // Touch centers measured from the supplied 768x1536 progress artworks.
        // Odd pages: 3 circles on the left. Even pages: 3 circles on the right.
        final float[][] odd={{0.3667f,0.2370f},{0.2377f,0.4891f},{0.3096f,0.7581f}};
        final float[][] even={{0.6333f,0.2370f},{0.7623f,0.4891f},{0.6904f,0.7581f}};
        final float[][] pts=(sectionNumber%2==1)?odd:even;
        final int circleSize=Math.round(w*0.318f);

        for(int i=0;i<3;i++){
            final int slot=i;
            TextView mission=tv(progressTitle(sectionNumber,slot),14,0xFF162D54);
            mission.setGravity(Gravity.CENTER);
            mission.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            mission.setMaxLines(2);
            mission.setPadding(dp(6),dp(6),dp(6),dp(6));
            mission.setContentDescription("جایگاه مأموریت "+(slot+1));
            styleMissionSlot(mission,missionState(sectionNumber,slot));
            progressMissionViews.put(missionViewKey(sectionNumber,slot),mission);
            int cx=Math.round(w*pts[i][0]);
            int cy=Math.round(pageHeight*pts[i][1]);
            FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(circleSize,circleSize);
            mp.leftMargin=cx-circleSize/2;
            mp.topMargin=cy-circleSize/2;
            page.addView(mission,mp);
            mission.setOnClickListener(v->{
                String state=missionState(sectionNumber,slot);
                if("active".equals(state)){resumeActiveMission();return;}
                if("done".equals(state)||"fail".equals(state)){showMissionSlotMenu(sectionNumber,slot);return;}
                showMissionEditor(sectionNumber,slot);
            });
            mission.setOnLongClickListener(v->{showMissionSlotMenu(sectionNumber,slot);return true;});
        }

        TextView down=tv("↓",22,0xFF174FD6);down.setTag("progress_down");down.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams dl=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.BOTTOM|Gravity.LEFT);dl.leftMargin=dp(8);dl.bottomMargin=dp(8);page.addView(down,dl);
        down.setOnClickListener(v->{
            boolean empty=true;for(int k=0;k<3;k++)if(progressTitle(sectionNumber,k).trim().length()>0)empty=false;
            if(!empty){Toast.makeText(this,"برای حذف صفحه، دایره‌ها باید خالی باشند",Toast.LENGTH_SHORT).show();return;}
            if(sectionNumber==progressSectionCount&&progressSectionCount>1){
                progressPages.removeView(page);
                for(int k=0;k<3;k++)clearMissionSlot(sectionNumber,k);
                progressSectionCount--;
                if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
                progressPrefs.edit().putInt("progress_section_count",progressSectionCount).apply();
                refreshProgressArrows();
            }
        });
        progressPages.addView(page,0,new LinearLayout.LayoutParams(-1,pageHeight));refreshProgressArrows();
        if(animateToNew){
            progressScroll.post(()->progressScroll.smoothScrollTo(0,0));
        }else{
            progressScroll.post(()->progressScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void clearMissionSlot(int section,int slot){
        if(progressPrefs==null)progressPrefs=getSharedPreferences("legacy_progress_rebuild",MODE_PRIVATE);
        SharedPreferences.Editor ed=progressPrefs.edit()
            .remove("title_"+section+"_"+slot)
            .remove(mf(section,slot,"importance"))
            .remove(mf(section,slot,"minutes"))
            .remove(mf(section,slot,"repeat"))
            .remove(mf(section,slot,"state"))
            .remove(mf(section,slot,"state_day"))
            .remove(mf(section,slot,"defaults_v41"));
        ed.apply();
        getSharedPreferences("legacy_subtasks_"+section+"_"+slot,MODE_PRIVATE).edit().clear().apply();
    }

    private void showGameSettings(){
        final String[] opts={"10 دقیقه","15 دقیقه","20 دقیقه","30 دقیقه","45 دقیقه","60 دقیقه"};
        final int[] vals={10,15,20,30,45,60}; int checked=3; for(int i=0;i<vals.length;i++)if(vals[i]==comboWindowMinutes)checked=i;
        new AlertDialog.Builder(this).setTitle("مهلت ادامه Combo").setSingleChoiceItems(opts,checked,(d,which)->{comboWindowMinutes=vals[which];expireComboIfNeeded();saveGameState();d.dismiss();Toast.makeText(this,"مهلت Combo: "+comboWindowMinutes+" دقیقه",Toast.LENGTH_SHORT).show();}).setNegativeButton("بستن",null).show();
    }

    private void showPlaceholder(String title){
        stopHomeActiveTicker();
        isHome = false; isRunningMissionScreen=false;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(Color.rgb(10,31,51));
        TextView t=tv(title,28,Color.WHITE); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,0xFFBFD4E6); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
        addActiveMissionBar();
    }
    @Override public void onBackPressed(){
        // On a section, Back returns Home. On Home, double Back exits.
        if(!isHome){ showHome(); return; }
        long now=System.currentTimeMillis();
        if(now-lastBackAt<1800){ super.onBackPressed(); }
        else { lastBackAt=now; Toast.makeText(this,"برای خروج دوباره بزنید",Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
    private float dp(float x){ return x*getResources().getDisplayMetrics().density; }
}

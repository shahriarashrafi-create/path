package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.view.*;
import android.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content;
    private long lastBackAt = 0;
    private boolean isHome = true;
    private int homeGeneration = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","جنگل شکوفایی","سفر در زمان","مرکز خرید","جام جهانی"};
    // Touch centers measured against the current 768x1536 Home artwork.
    // Order matches names: Progress, Dream Palace, Growth Forest, Time Travel, Shop, World Cup.
    private final float[][] centers = {{0.510f,0.773f},{0.195f,0.542f},{0.715f,0.606f},{0.842f,0.426f},{0.320f,0.325f},{0.845f,0.217f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void showHome(){
        isHome = true;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        setContentView(root);
        root.setFitsSystemWindows(true);

        ImageView home=new ImageView(this); home.setImageResource(R.drawable.home_background);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // Legacy HUD reference final polish: premium RPG HUD.
        FrameLayout header=new FrameLayout(this);
        header.setPadding(dp(4),0,dp(4),0);
        header.setBackground(new HudBackground());
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(46),Gravity.TOP);
        hp.setMargins(dp(8),dp(4),dp(8),0);
        root.addView(header,hp);

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(1),0,dp(1),0);
        header.addView(row,new FrameLayout.LayoutParams(-1,-1));

        ImageView avatar=new ImageView(this);
        avatar.setImageResource(R.drawable.avatar_legacy);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        avatar.setContentDescription("آواتار"); avatar.setElevation(dp(2));
        LinearLayout.LayoutParams avLp=new LinearLayout.LayoutParams(dp(68),dp(68));
        avLp.setMargins(dp(-5),dp(-11),dp(4),dp(-11)); row.addView(avatar,avLp);

        TextView level=tv("LV 1",13,0xFFFFE7A0);
        level.setGravity(Gravity.CENTER);
        level.setShadowLayer(dp(1),0,0,0x665E3A00);
        LinearLayout.LayoutParams levelLp=new LinearLayout.LayoutParams(dp(40),dp(34));
        levelLp.setMargins(0,0,dp(1),0); row.addView(level,levelLp);

        LinearLayout xpGroup=new LinearLayout(this);
        xpGroup.setOrientation(LinearLayout.VERTICAL);
        xpGroup.setGravity(Gravity.CENTER_VERTICAL);
        XpBarView xp=new XpBarView(this);
        xp.setProgress(0,100);
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(9));
        xpLp.setMargins(0,dp(4),0,0); xpGroup.addView(xp,xpLp);
        TextView xpTxt=tv("0 / 100 XP",8,0xFFE5F7FF);
        xpTxt.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        xpGroup.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(14)));
        LinearLayout.LayoutParams xpgLp=new LinearLayout.LayoutParams(dp(102),dp(35));
        xpgLp.setMargins(0,0,dp(2),0); row.addView(xpGroup,xpgLp);

        LinearLayout coinBox=glassCapsule();
        CoinView coinIcon=new CoinView(this);
        coinBox.addView(coinIcon,new LinearLayout.LayoutParams(dp(22),dp(22)));
        TextView coin=tv("0",13,0xFFFFF3CF); coin.setPadding(dp(1),0,0,0);
        coinBox.addView(coin,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(25));
        coinLp.setMargins(0,0,dp(1),0); row.addView(coinBox,coinLp);

        LinearLayout comboBox=glassCapsule();
        TextView flame=tv("🔥",16,Color.WHITE); comboBox.addView(flame,new LinearLayout.LayoutParams(dp(23),-1));
        TextView combo=tv("0",13,Color.WHITE); comboBox.addView(combo,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(44),dp(25));
        comboLp.setMargins(0,0,dp(1),0); row.addView(comboBox,comboLp);

        TextView gear=tv("⚙",21,0xFFE0E4E8);
        gear.setGravity(Gravity.CENTER); gear.setContentDescription("تنظیمات");
        gear.setShadowLayer(dp(1.5f),0,dp(1),0xAA000000);
        gear.setOnClickListener(v->showPlaceholder("تنظیمات"));
        row.addView(gear,new LinearLayout.LayoutParams(dp(31),dp(40)));

        // Hit targets follow the six labels baked into the selected 768x1536 Home artwork.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=768f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            int hitW=Math.max(dp(118), Math.round(245f*scale));
            int hitH=Math.max(dp(48), Math.round(72f*scale));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=Math.round(offsetX + srcW*centers[i][0]*scale);
                int cy=Math.round(offsetY + srcH*centers[i][1]*scale);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-hitW/2; lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==MotionEvent.ACTION_DOWN){ v.setAlpha(.55f); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->showPlaceholder(names[idx])); content.addView(hit,lp);
            }
        });
        header.bringToFront();
    }

    private LinearLayout glassCapsule(){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0x3803080E,dp(12)); g.setStroke(dp(1),0x225D7180); box.setBackground(g);
        return box;
    }

    private class XpBarView extends View {
        private final Paint p=new Paint(1); private int value=0,max=100;
        XpBarView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void setProgress(int v,int m){ value=Math.max(0,v); max=Math.max(1,m); invalidate(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float h=getHeight(), r=h/2f; RectF track=new RectF(dp(1),dp(1),getWidth()-dp(1),h-dp(1));
            p.setStyle(Paint.Style.FILL); p.setColor(0xAA071522); c.drawRoundRect(track,r,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xAA5EB8E8); c.drawRoundRect(track,r,r,p);
            float frac=Math.min(1f,value/(float)max);
            if(frac>0f){ RectF fill=new RectF(track.left,track.top,track.left+track.width()*frac,track.bottom);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF25E6FF); p.setShadowLayer(dp(4),0,0,0xCC19D9FF); c.drawRoundRect(fill,r,r,p); p.clearShadowLayer(); }
            else { p.setStyle(Paint.Style.FILL); p.setColor(0xFF36E8FF); p.setShadowLayer(dp(3),0,0,0xAA28DFFF); c.drawCircle(track.left+dp(2),h/2f,dp(1.3f),p); p.clearShadowLayer(); }
        }
    }

    private class HudBackground extends android.graphics.drawable.Drawable {
        private final Paint fill=new Paint(1), stroke=new Paint(1), bottomGlow=new Paint(1), topAccent=new Paint(1);
        HudBackground(){
            fill.setColor(0xED08131F); fill.setStyle(Paint.Style.FILL);
            stroke.setColor(0x3D8398A6); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            bottomGlow.setColor(0x9027D5FF); bottomGlow.setStyle(Paint.Style.STROKE); bottomGlow.setStrokeWidth(dp(1));
            topAccent.setColor(0xE0E4B85A); topAccent.setStyle(Paint.Style.STROKE); topAccent.setStrokeWidth(dp(1));
        }
        private Path shape(){
            RectF b=new RectF(getBounds()); float c=dp(7); Path p=new Path();
            p.moveTo(b.left+c,b.top); p.lineTo(b.right-c,b.top); p.lineTo(b.right,b.top+c);
            p.lineTo(b.right,b.bottom-c); p.lineTo(b.right-c,b.bottom); p.lineTo(b.left+c,b.bottom);
            p.lineTo(b.left,b.bottom-c); p.lineTo(b.left,b.top+c); p.close(); return p;
        }
        @Override public void draw(Canvas c){
            RectF b=new RectF(getBounds()); Path p=shape(); c.drawPath(p,fill); c.drawPath(p,stroke);
            c.drawLine(b.left+dp(11),b.bottom-dp(1),b.right-dp(11),b.bottom-dp(1),bottomGlow);
            c.drawLine(b.left+dp(12),b.top+dp(1),b.right-dp(12),b.top+dp(1),topAccent);
        }
        @Override public void setAlpha(int a){} @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){ return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private class CoinView extends View {
        Paint p=new Paint(1); CoinView(android.content.Context c){super(c);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float r=Math.min(getWidth(),getHeight())*.43f, x=getWidth()/2f,y=getHeight()/2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFB82E); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xFFFFF0A8); c.drawCircle(x,y,r-dp(1),p);
            p.setColor(0xFFD98A00); c.drawCircle(x,y,r-dp(3),p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF8C5A00); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(10));
            c.drawText("L",x,y-(p.ascent()+p.descent())/2,p);
        }
    }

    private void showPlaceholder(String title){
        isHome = false;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(Color.rgb(10,31,51));
        TextView t=tv(title,28,Color.WHITE); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,0xFFBFD4E6); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
    }
    @Override public void onBackPressed(){
        // On a section, Back returns Home. On Home, double Back exits.
        if(!isHome){ showHome(); return; }
        long now=System.currentTimeMillis();
        if(now-lastBackAt<1800){ super.onBackPressed(); }
        else { lastBackAt=now; Toast.makeText(this,"برای خروج دوباره بزنید",Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
    private float dp(float x){ return x*getResources().getDisplayMetrics().density; }
}

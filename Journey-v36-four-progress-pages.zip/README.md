Journey-v36-four-progress-pages

Changes:
- Added the fourth progress artwork above the previous three pages.
- Progress Path now scrolls through four stacked 1:2 images.
- Added nodes 10, 11, and 12 with the same tap feedback, title editor, persistent title storage, and touch calibration as the previous nodes.
- Header and Bottom Bar remain fixed above the scrolling artwork.
- The new artwork keeps its original 887x1774 dimensions and is stored as high-quality WebP to reduce APK size.

Legacy v61

Changes:
- Home background replaced with the updated first-screen art containing the corrected label «درخت تصاعد».
- Mission editor now uses the new seated-man artwork shown after tapping a progress circle. Touch/hit areas were recalibrated for title, importance, time, repeat, and start.
- Running mission now uses the new frosted-panel artwork shown after pressing Start. Touch/hit areas were recalibrated for Done, Fail, Music, Sound, Reset, and Subtasks.
- Major artwork files were converted to high-quality WebP to keep visual quality high while reducing ZIP size.
- Existing progress-path scrolling-to-first-pending behavior and reward logic remain intact.

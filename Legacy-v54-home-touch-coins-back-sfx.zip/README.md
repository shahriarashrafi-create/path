# Legacy v54

Visual/interaction update based on v53.

- Replaced Home artwork with the supplied fantasy castle/hero image.
- Recalibrated all six Home touch zones to the new artwork.
- Dialogs use an animation-free dialog theme and have window transitions disabled before `show()`.
- The gold next-mission circle keeps its bright gold pulse and now has a very slow coin-rain effect inside the circle.
- The first empty white mission circle shows an animated `.`, `..`, `...` prompt.
- Back navigation now moves exactly one screen level: Running/Editor -> Progress Path -> Home -> system back.
- Added a tiny UI click sound via SoundPool for clickable controls, including dialog buttons.
- Removed the three large Yanni audio files from the app package.
- Kept the three music modes (شاد / متعادل / آرام); all three temporarily point to the same compact focus loop.

Note: local Gradle build could not run in the execution environment because the wrapper attempted to reach services.gradle.org and network access is unavailable. XML and source structure were statically checked.

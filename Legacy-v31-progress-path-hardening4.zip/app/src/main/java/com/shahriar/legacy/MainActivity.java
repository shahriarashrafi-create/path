package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.text.InputType;
import android.view.*;
import android.animation.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content, activeBar;
    private TextView hudLevel, hudXpText, hudCoinText, hudComboText; private XpBarView hudXpBar;
    private long lastBackAt = 0;
    private boolean isHome = true;
    private int homeGeneration = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","جنگل شکوفایی","سفر در زمان","مرکز خرید","جام جهانی"};
    // Touch centers measured against the current 768x1536 Home artwork.
    // Order matches names: Progress, Dream Palace, Growth Forest, Time Travel, Shop, World Cup.
    private final float[][] centers = {{0.510f,0.773f},{0.195f,0.542f},{0.715f,0.606f},{0.842f,0.426f},{0.320f,0.325f},{0.845f,0.217f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); ensureNotificationChannel(); requestNotificationPermission(); showHome(); }
    @Override protected void onResume(){ super.onResume(); if(root!=null){ loadProgressMissions(); startMissionTicker(); updateActiveMissionBar(); } }
    @Override protected void onDestroy(){ if(missionTicker!=null) missionHandler.removeCallbacks(missionTicker); super.onDestroy(); }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void showHome(){
        isHome = true;
        final int generation = ++homeGeneration;
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        setContentView(root);
        root.setFitsSystemWindows(true);

        ImageView home=new ImageView(this); home.setImageResource(R.drawable.home_background);
        home.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));

        content=new FrameLayout(this);
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));

        // Legacy HUD reference final polish: premium RPG HUD.
        FrameLayout header=new FrameLayout(this);
        header.setPadding(dp(4),0,dp(4),0);
        header.setBackground(new HudBackground());
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(46),Gravity.TOP);
        hp.setMargins(dp(8),dp(4),dp(8),0);
        root.addView(header,hp);

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(1),0,dp(1),0);
        header.addView(row,new FrameLayout.LayoutParams(-1,-1));

        ImageView avatar=new ImageView(this);
        avatar.setImageResource(R.drawable.avatar_legacy);
        avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        avatar.setContentDescription("آواتار"); avatar.setElevation(dp(2));
        LinearLayout.LayoutParams avLp=new LinearLayout.LayoutParams(dp(45),dp(45));
        avLp.setMargins(dp(2),0,dp(4),0); row.addView(avatar,avLp);

        loadGameState();
        hudLevel=tv("LV "+gameLevel,13,0xFFFFE7A0); TextView level=hudLevel;
        level.setGravity(Gravity.CENTER);
        level.setShadowLayer(dp(1),0,0,0x665E3A00);
        LinearLayout.LayoutParams levelLp=new LinearLayout.LayoutParams(dp(40),dp(34));
        levelLp.setMargins(0,0,dp(1),0); row.addView(level,levelLp);

        LinearLayout xpGroup=new LinearLayout(this);
        xpGroup.setOrientation(LinearLayout.VERTICAL);
        xpGroup.setGravity(Gravity.CENTER_VERTICAL);
        XpBarView xp=new XpBarView(this); hudXpBar=xp;
        xp.setProgress(gameXp,xpNeeded(gameLevel));
        LinearLayout.LayoutParams xpLp=new LinearLayout.LayoutParams(-1,dp(9));
        xpLp.setMargins(0,dp(4),0,0); xpGroup.addView(xp,xpLp);
        hudXpText=tv(gameXp+" / "+xpNeeded(gameLevel)+" XP",8,0xFFE5F7FF); TextView xpTxt=hudXpText;
        xpTxt.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        xpGroup.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(14)));
        LinearLayout.LayoutParams xpgLp=new LinearLayout.LayoutParams(dp(110),dp(35));
        xpgLp.setMargins(0,0,dp(3),0); row.addView(xpGroup,xpgLp);

        LinearLayout coinBox=glassCapsule();
        ImageView coinIcon=new ImageView(this);
        coinIcon.setImageResource(R.drawable.hud_coin); coinIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        coinBox.addView(coinIcon,new LinearLayout.LayoutParams(dp(24),dp(24)));
        hudCoinText=tv(String.valueOf(gameCoins),13,0xFFFFF3CF); TextView coin=hudCoinText; coin.setPadding(dp(1),0,0,0);
        coinBox.addView(coin,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams coinLp=new LinearLayout.LayoutParams(dp(52),dp(25));
        coinLp.setMargins(0,0,dp(1),0); row.addView(coinBox,coinLp);

        LinearLayout comboBox=glassCapsule();
        ImageView flame=new ImageView(this); flame.setImageResource(R.drawable.hud_flame);
        flame.setScaleType(ImageView.ScaleType.FIT_CENTER);
        comboBox.addView(flame,new LinearLayout.LayoutParams(dp(22),dp(25)));
        hudComboText=tv(String.valueOf(gameCombo),13,Color.WHITE); TextView combo=hudComboText; comboBox.addView(combo,new LinearLayout.LayoutParams(-2,-1));
        LinearLayout.LayoutParams comboLp=new LinearLayout.LayoutParams(dp(44),dp(25));
        comboLp.setMargins(0,0,dp(1),0); row.addView(comboBox,comboLp);

        ImageView gear=new ImageView(this); gear.setImageResource(R.drawable.hud_gear);
        gear.setScaleType(ImageView.ScaleType.FIT_CENTER); gear.setPadding(dp(4),dp(4),dp(4),dp(4));
        gear.setContentDescription("تنظیمات");
        gear.setOnClickListener(v->showGameSettings());
        row.addView(gear,new LinearLayout.LayoutParams(dp(34),dp(40)));

        // Hit targets follow the six labels baked into the selected 768x1536 Home artwork.
        content.post(()->{
            if (!isHome || generation != homeGeneration || content == null) return;
            int w=content.getWidth(), h=content.getHeight();
            final float srcW=768f, srcH=1536f;
            float scale=Math.max(w/srcW, h/srcH);
            float drawnW=srcW*scale, drawnH=srcH*scale;
            float offsetX=(w-drawnW)/2f, offsetY=(h-drawnH)/2f;
            int hitW=Math.max(dp(118), Math.round(245f*scale));
            int hitH=Math.max(dp(48), Math.round(72f*scale));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=Math.round(offsetX + srcW*centers[i][0]*scale);
                int cy=Math.round(offsetY + srcH*centers[i][1]*scale);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH);
                lp.leftMargin=cx-hitW/2; lp.topMargin=cy-hitH/2;
                hit.setOnTouchListener((v,e)->{
                    if(e.getAction()==MotionEvent.ACTION_DOWN){ v.setAlpha(.55f); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP){ v.setAlpha(1f); v.performClick(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_CANCEL){ v.setAlpha(1f); return true; }
                    return true;
                });
                hit.setOnClickListener(v->{ if(idx==0) showProgressPath(); else showPlaceholder(names[idx]); }); content.addView(hit,lp);
            }
        });
        loadProgressMissions(); updateActiveMissionBar(); header.bringToFront();
    }

    private LinearLayout glassCapsule(){
        LinearLayout box=new LinearLayout(this); box.setGravity(Gravity.CENTER);
        GradientDrawable g=bg(0x3803080E,dp(12)); g.setStroke(dp(1),0x225D7180); box.setBackground(g);
        return box;
    }

    private class XpBarView extends View {
        private final Paint p=new Paint(1); private int value=0,max=100;
        XpBarView(android.content.Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void setProgress(int v,int m){ value=Math.max(0,v); max=Math.max(1,m); invalidate(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float h=getHeight(), r=h/2f; RectF track=new RectF(dp(1),dp(1),getWidth()-dp(1),h-dp(1));
            p.setStyle(Paint.Style.FILL); p.setColor(0xAA071522); c.drawRoundRect(track,r,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xAA5EB8E8); c.drawRoundRect(track,r,r,p);
            float frac=Math.min(1f,value/(float)max);
            if(frac>0f){ RectF fill=new RectF(track.left,track.top,track.left+track.width()*frac,track.bottom);
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF25E6FF); p.setShadowLayer(dp(4),0,0,0xCC19D9FF); c.drawRoundRect(fill,r,r,p); p.clearShadowLayer(); }
            else { p.setStyle(Paint.Style.FILL); p.setColor(0xFF36E8FF); p.setShadowLayer(dp(3),0,0,0xAA28DFFF); c.drawCircle(track.left+dp(2),h/2f,dp(1.3f),p); p.clearShadowLayer(); }
        }
    }

    private class HudBackground extends android.graphics.drawable.Drawable {
        private final Paint fill=new Paint(1), stroke=new Paint(1), bottomGlow=new Paint(1), topAccent=new Paint(1);
        HudBackground(){
            fill.setColor(0xED08131F); fill.setStyle(Paint.Style.FILL);
            stroke.setColor(0x3D8398A6); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1));
            bottomGlow.setColor(0xA027D5FF); bottomGlow.setStyle(Paint.Style.STROKE); bottomGlow.setStrokeWidth(dp(1));
            topAccent.setColor(0xF0E8BD62); topAccent.setStyle(Paint.Style.STROKE); topAccent.setStrokeWidth(dp(1));
        }
        private Path shape(){
            RectF b=new RectF(getBounds()); float c=dp(7); Path p=new Path();
            p.moveTo(b.left+c,b.top); p.lineTo(b.right-c,b.top); p.lineTo(b.right,b.top+c);
            p.lineTo(b.right,b.bottom-c); p.lineTo(b.right-c,b.bottom); p.lineTo(b.left+c,b.bottom);
            p.lineTo(b.left,b.bottom-c); p.lineTo(b.left,b.top+c); p.close(); return p;
        }
        @Override public void draw(Canvas c){
            RectF b=new RectF(getBounds()); Path p=shape(); c.drawPath(p,fill); c.drawPath(p,stroke);
            c.drawLine(b.left+dp(11),b.bottom-dp(1),b.right-dp(11),b.bottom-dp(1),bottomGlow);
            c.drawLine(b.left+dp(12),b.top+dp(1),b.right-dp(12),b.top+dp(1),topAccent);
        }
        @Override public void setAlpha(int a){} @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){ return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private class CoinView extends View {
        Paint p=new Paint(1); CoinView(android.content.Context c){super(c);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float r=Math.min(getWidth(),getHeight())*.43f, x=getWidth()/2f,y=getHeight()/2f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFB82E); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0xFFFFF0A8); c.drawCircle(x,y,r-dp(1),p);
            p.setColor(0xFFD98A00); c.drawCircle(x,y,r-dp(3),p);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF8C5A00); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(10));
            c.drawText("L",x,y-(p.ascent()+p.descent())/2,p);
        }
    }

    private int gameLevel=1, gameXp=0, gameCoins=0, gameCombo=0, comboWindowMinutes=30; private long lastSuccessAt=0;
    private SharedPreferences gamePrefs;
    private int xpNeeded(int level){ return 100+Math.max(0,level-1)*50; }
    private void loadGameState(){ gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gameLevel=gamePrefs.getInt("level",1);gameXp=gamePrefs.getInt("xp",0);gameCoins=gamePrefs.getInt("coins",0);gameCombo=gamePrefs.getInt("combo",0);lastSuccessAt=gamePrefs.getLong("lastSuccessAt",0);comboWindowMinutes=gamePrefs.getInt("comboWindowMinutes",30);expireComboIfNeeded(); }
    private void saveGameState(){ if(gamePrefs==null)gamePrefs=getSharedPreferences("legacy_game",MODE_PRIVATE);gamePrefs.edit().putInt("level",gameLevel).putInt("xp",gameXp).putInt("coins",gameCoins).putInt("combo",gameCombo).putLong("lastSuccessAt",lastSuccessAt).putInt("comboWindowMinutes",comboWindowMinutes).apply();updateHud(); }
    private void updateHud(){ if(hudLevel!=null)hudLevel.setText("LV "+gameLevel);if(hudXpBar!=null)hudXpBar.setProgress(gameXp,xpNeeded(gameLevel));if(hudXpText!=null)hudXpText.setText(gameXp+" / "+xpNeeded(gameLevel)+" XP");if(hudCoinText!=null)hudCoinText.setText(String.valueOf(gameCoins));if(hudComboText!=null)hudComboText.setText(String.valueOf(gameCombo)); }
    private float comboMultiplier(){return gameCombo>=10?3f:gameCombo>=7?2f:gameCombo>=3?1.5f:1f;}
    private void expireComboIfNeeded(){if(gameCombo>0&&lastSuccessAt>0&&System.currentTimeMillis()-lastSuccessAt>comboWindowMinutes*60000L){gameCombo=0;lastSuccessAt=0;if(gamePrefs!=null)gamePrefs.edit().putInt("combo",0).putLong("lastSuccessAt",0).apply();}}
    private void rewardMission(Mission m){ long now=System.currentTimeMillis();if(lastSuccessAt>0&&now-lastSuccessAt<=comboWindowMinutes*60000L)gameCombo++;else gameCombo=1;lastSuccessAt=now;int baseXp=m.importance==0?10:m.importance==2?30:20;int baseCoins=m.importance==0?5:m.importance==2?15:10;float mult=comboMultiplier();gameXp+=Math.round(baseXp*mult);gameCoins+=Math.round(baseCoins*mult);while(gameXp>=xpNeeded(gameLevel)){gameXp-=xpNeeded(gameLevel);gameLevel++;gameCoins+=gameLevel*5;}saveGameState();}
    private void breakCombo(){gameCombo=0;lastSuccessAt=0;saveGameState();}

    private ScrollView progressScroll;
    private LinearLayout progressPages;
    private final ArrayList<Mission> progressMissions = new ArrayList<>();
    private SharedPreferences progressPrefs;
    private static final float[][] PATH_A_SLOTS = {{.260f,.220f},{.260f,.510f},{.260f,.780f}};
    private static final float[][] PATH_B_SLOTS = {{.660f,.205f},{.760f,.440f},{.715f,.695f}};
    private final android.os.Handler missionHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable missionTicker;

    private static class Mission {
        String id=java.util.UUID.randomUUID().toString(); String title=""; int minutes=10; int importance=1; boolean daily=false; String checklist=""; int state=0; // 0 ready,1 active,2 done,3 failed
        long endAt=0; String doneDay=""; boolean reminder=false; int reminderHour=9, reminderMinute=0;
    }

    private String todayKey(){return new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(new java.util.Date());}
    private void updateActiveMissionBar(){ expireComboIfNeeded(); if(root==null)return;if(activeBar!=null){root.removeView(activeBar);activeBar=null;}int i=activeMissionIndex();if(i<0)return;Mission m=progressMissions.get(i);activeBar=new FrameLayout(this);GradientDrawable g=bg(0xF0142638,dp(14));g.setStroke(dp(1),0xAA45DFFF);activeBar.setBackground(g);TextView t=tv(m.title+"   •   "+formatRemaining(m.endAt-System.currentTimeMillis())+(gameCombo>0?"   ×"+String.valueOf(comboMultiplier()).replace(".0",""):""),13,Color.WHITE);activeBar.addView(t,new FrameLayout.LayoutParams(-1,-1));final int idx=i;activeBar.setOnClickListener(v->showMissionRunning(idx));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(46),Gravity.BOTTOM);lp.setMargins(dp(12),0,dp(12),dp(8));root.addView(activeBar,lp);activeBar.bringToFront();}

    private void showProgressPath(){
        isHome=false; ++homeGeneration; content.removeAllViews(); loadProgressMissions();
        progressScroll=new ScrollView(this); progressScroll.setFillViewport(true); progressScroll.setClipToPadding(false);
        progressScroll.setOverScrollMode(View.OVER_SCROLL_NEVER); progressScroll.setBackgroundColor(0xFFF7F9FF);
        progressPages=new LinearLayout(this); progressPages.setOrientation(LinearLayout.VERTICAL); progressPages.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL); progressPages.setPadding(0,0,0,dp(58));
        progressScroll.addView(progressPages,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1); lp.topMargin=dp(54); content.addView(progressScroll,lp);
        rebuildProgressPages(false); startMissionTicker(); updateActiveMissionBar();
    }

    private String enc(String s){ return android.util.Base64.encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP); }
    private String dec(String s){ try{return new String(android.util.Base64.decode(s,android.util.Base64.NO_WRAP),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){return "";} }
    private void loadProgressMissions(){
        progressMissions.clear(); progressPrefs=getSharedPreferences("progress_path",MODE_PRIVATE); int count=progressPrefs.getInt("count",0);
        for(int i=0;i<count;i++){
            String raw=progressPrefs.getString("m"+i,""); if(raw==null||raw.isEmpty()) continue;
            Mission m=new Mission(); String[] a=raw.split("\\|",-1);
            try{ if(a.length>=7){m.title=dec(a[0]);m.minutes=Integer.parseInt(a[1]);m.importance=Integer.parseInt(a[2]);m.daily="1".equals(a[3]);m.checklist=dec(a[4]);m.state=Integer.parseInt(a[5]);m.endAt=Long.parseLong(a[6]);if(a.length>=8)m.doneDay=a[7];if(a.length>=9&&!a[8].isEmpty())m.id=a[8];if(a.length>=10)m.reminder="1".equals(a[9]);if(a.length>=11)m.reminderHour=Integer.parseInt(a[10]);if(a.length>=12)m.reminderMinute=Integer.parseInt(a[11]);} else {m.title=raw;} }catch(Exception e){m.title=raw;}
            if(m.daily&&m.state==2&&!todayKey().equals(m.doneDay)){m.state=0;m.doneDay="";} progressMissions.add(m); if(m.reminder) scheduleMissionReminder(m);
        }
    }
    private void saveProgressMissions(){
        if(progressPrefs==null) progressPrefs=getSharedPreferences("progress_path",MODE_PRIVATE); SharedPreferences.Editor e=progressPrefs.edit().clear(); e.putInt("count",progressMissions.size());
        for(int i=0;i<progressMissions.size();i++){Mission m=progressMissions.get(i);e.putString("m"+i,enc(m.title)+"|"+m.minutes+"|"+m.importance+"|"+(m.daily?1:0)+"|"+enc(m.checklist)+"|"+m.state+"|"+m.endAt+"|"+m.doneDay+"|"+m.id+"|"+(m.reminder?1:0)+"|"+m.reminderHour+"|"+m.reminderMinute);} e.apply();
    }
    private void rebuildProgressPages(boolean scrollToNewPage){
        if(progressPages==null)return; progressPages.removeAllViews(); int pageCount=Math.max(1,(progressMissions.size()/3)+1);
        for(int page=0;page<pageCount;page++)addProgressPage(page);
        if(scrollToNewPage)progressScroll.postDelayed(()->{int pageH=Math.round(getResources().getDisplayMetrics().widthPixels*2f);int lastTop=Math.max(0,progressPages.getHeight()-pageH);progressScroll.smoothScrollTo(0,lastTop);},220);
    }
    private GradientDrawable missionCircle(int state){
        int stroke=0xFF55B9E9; if(state==1)stroke=0xFF7D5CFF; else if(state==2)stroke=0xFF36B96F; else if(state==3)stroke=0xFFE25353;
        GradientDrawable g=new GradientDrawable();g.setShape(GradientDrawable.OVAL);g.setColor(0x22FFFFFF);g.setStroke(dp(state==1?4:3),stroke);return g;
    }
    private void addProgressPage(final int pageIndex){
        final FrameLayout page=new FrameLayout(this); int pageHeight=Math.round(getResources().getDisplayMetrics().widthPixels*2f); progressPages.addView(page,new LinearLayout.LayoutParams(-1,pageHeight));
        ImageView art=new ImageView(this);art.setImageResource(pageIndex%2==0?R.drawable.progress_path_a:R.drawable.progress_path_b);art.setScaleType(ImageView.ScaleType.FIT_XY);page.addView(art,new FrameLayout.LayoutParams(-1,-1));
        final float[][] slots=pageIndex%2==0?PATH_A_SLOTS:PATH_B_SLOTS;
        page.post(()->{int w=page.getWidth(),h=page.getHeight(),size=Math.round(w*.28f);for(int slot=0;slot<3;slot++){
            final int idx=pageIndex*3+slot; boolean filled=idx<progressMissions.size(); Mission m=filled?progressMissions.get(idx):null;
            String label=filled?m.title:"+"; if(filled&&m.state==2)label="✓\n"+label; else if(filled&&m.state==3)label="✕\n"+label;
            TextView target=tv(label,filled?14:27,filled?0xFF173B59:0xFF57A9D9);target.setGravity(Gravity.CENTER);target.setPadding(dp(10),dp(8),dp(10),dp(8));target.setMaxLines(4);target.setBackground(missionCircle(filled?m.state:0));
            if(filled && android.os.Build.VERSION.SDK_INT>=26) target.setAutoSizeTextTypeUniformWithConfiguration(9,14,1,android.util.TypedValue.COMPLEX_UNIT_SP);
            FrameLayout.LayoutParams tlp=new FrameLayout.LayoutParams(size,size);tlp.leftMargin=Math.round(slots[slot][0]*w-size/2f);tlp.topMargin=Math.round(slots[slot][1]*h-size/2f);page.addView(target,tlp);
            if(filled&&m.state==1){android.animation.ObjectAnimator pulse=android.animation.ObjectAnimator.ofFloat(target,View.ALPHA,1f,.58f,1f);pulse.setDuration(1100);pulse.setRepeatCount(android.animation.ValueAnimator.INFINITE);pulse.start();}
            if(filled)target.setOnClickListener(v->showMissionDetail(idx)); else if(idx==progressMissions.size())target.setOnClickListener(v->showMissionForm(-1)); else target.setAlpha(.20f);
        }});
    }
    private boolean hasActiveMission(){for(Mission m:progressMissions)if(m.state==1)return true;return false;}
    private int activeMissionIndex(){for(int i=0;i<progressMissions.size();i++)if(progressMissions.get(i).state==1)return i;return -1;}
    private String importanceName(int x){return x==0?"کم":x==2?"زیاد":"متوسط";}

    private void showMissionForm(final int editIndex){
        final Mission old=editIndex>=0?progressMissions.get(editIndex):null;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);
        EditText title=new EditText(this);title.setHint("عنوان مأموریت");title.setSingleLine(true);title.setTextDirection(View.TEXT_DIRECTION_RTL);if(old!=null)title.setText(old.title);box.addView(title);
        Spinner duration=new Spinner(this);String[] ds={"5 دقیقه","10 دقیقه","20 دقیقه","30 دقیقه","45 دقیقه"};duration.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ds));int[] mins={5,10,20,30,45};if(old!=null)for(int i=0;i<mins.length;i++)if(mins[i]==old.minutes)duration.setSelection(i);else{} box.addView(duration);
        Spinner importance=new Spinner(this);String[] im={"اهمیت کم","اهمیت متوسط","اهمیت زیاد"};importance.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,im));importance.setSelection(old==null?1:old.importance);box.addView(importance);
        CheckBox daily=new CheckBox(this);daily.setText("تکرار روزانه");daily.setChecked(old!=null&&old.daily);box.addView(daily);
        CheckBox reminder=new CheckBox(this);reminder.setText("یادآوری مأموریت");reminder.setChecked(old!=null&&old.reminder);box.addView(reminder);
        TimePicker reminderTime=new TimePicker(this);reminderTime.setIs24HourView(true);reminderTime.setHour(old!=null?old.reminderHour:9);reminderTime.setMinute(old!=null?old.reminderMinute:0);reminderTime.setVisibility(reminder.isChecked()?View.VISIBLE:View.GONE);box.addView(reminderTime);reminder.setOnCheckedChangeListener((button,checked)->reminderTime.setVisibility(checked?View.VISIBLE:View.GONE));
        EditText checklist=new EditText(this);checklist.setHint("چک‌لیست اختیاری (هر مورد در یک خط)");checklist.setMinLines(2);checklist.setGravity(Gravity.TOP|Gravity.RIGHT);if(old!=null)checklist.setText(old.checklist);box.addView(checklist);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(old==null?"مأموریت جدید":"ویرایش مأموریت").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره",null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String t=title.getText().toString().trim();if(t.isEmpty()){title.setError("عنوان مأموریت را بنویس");return;}int before=Math.max(1,(progressMissions.size()/3)+1);Mission m=old==null?new Mission():old;m.title=t;m.minutes=mins[duration.getSelectedItemPosition()];m.importance=importance.getSelectedItemPosition();m.daily=daily.isChecked();m.reminder=reminder.isChecked();m.reminderHour=reminderTime.getHour();m.reminderMinute=reminderTime.getMinute();m.checklist=checklist.getText().toString().trim();if(old==null)progressMissions.add(m);if(m.reminder)scheduleMissionReminder(m);else cancelMissionReminder(m);saveProgressMissions();int after=Math.max(1,(progressMissions.size()/3)+1);rebuildProgressPages(after>before);d.dismiss();}));d.show();
    }
    private void showMissionDetail(final int index){
        if(index<0||index>=progressMissions.size())return;Mission m=progressMissions.get(index);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(8),dp(22),0);
        TextView info=tv(m.minutes+" دقیقه   •   اهمیت "+importanceName(m.importance)+(m.daily?"   •   روزانه":"")+(m.reminder?("   •   یادآوری "+String.format(java.util.Locale.US,"%02d:%02d",m.reminderHour,m.reminderMinute)):""),15,0xFF28465F);info.setGravity(Gravity.RIGHT);box.addView(info,new LinearLayout.LayoutParams(-1,dp(48)));
        if(!m.checklist.isEmpty()){TextView ck=tv("چک‌لیست\n"+m.checklist,14,0xFF3C5870);ck.setGravity(Gravity.RIGHT);box.addView(ck,new LinearLayout.LayoutParams(-1,-2));}
        TextView del=tv("حذف مأموریت",13,0xFFD24B4B);del.setGravity(Gravity.RIGHT);del.setPadding(0,dp(12),0,dp(8));del.setEnabled(m.state!=1);del.setAlpha(m.state==1?.35f:1f);box.addView(del,new LinearLayout.LayoutParams(-1,dp(44)));
        String action=m.state==1?"ادامه مأموریت":m.state==3?"شروع دوباره":m.state==2&&m.daily?"بازگردانی":"شروع مأموریت";
        AlertDialog d=new AlertDialog.Builder(this).setTitle(m.title).setView(box).setNegativeButton("بستن",null).setNeutralButton("ویرایش",null).setPositiveButton(action,null).create();
        d.setOnShowListener(x->{
            del.setOnClickListener(v->{if(m.state!=1){removeProgressMission(index);d.dismiss();}});
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(m.state!=1);d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{if(m.state!=1){d.dismiss();showMissionForm(index);}});
            Button b=d.getButton(AlertDialog.BUTTON_POSITIVE);boolean blocked=hasActiveMission()&&m.state!=1;b.setEnabled(!blocked);
            b.setOnClickListener(v->{if(blocked)return;if(m.state==2&&m.daily){m.state=0;m.endAt=0;m.doneDay="";saveProgressMissions();rebuildProgressPages(false);d.dismiss();return;}if(m.state!=1){m.state=1;m.endAt=System.currentTimeMillis()+m.minutes*60000L;scheduleMissionFinish(m);saveProgressMissions();rebuildProgressPages(false);updateActiveMissionBar();}d.dismiss();showMissionRunning(index);});
        });d.show();
    }
    private void showMissionRunning(final int index){
        if(index<0||index>=progressMissions.size())return;Mission m=progressMissions.get(index);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(10),dp(22),0);
        TextView timer=tv(formatRemaining(m.endAt-System.currentTimeMillis()),30,0xFF235D8B);box.addView(timer,new LinearLayout.LayoutParams(-1,dp(70)));
        if(!m.checklist.isEmpty()){TextView ck=tv(m.checklist,14,0xFF3C5870);ck.setGravity(Gravity.RIGHT);box.addView(ck,new LinearLayout.LayoutParams(-1,-2));}
        AlertDialog d=new AlertDialog.Builder(this).setTitle(m.title).setView(box).setNegativeButton("بعداً",null).setNeutralButton("انجام نشد",null).setPositiveButton("انجام شد",null).create();
        final Runnable tick=new Runnable(){public void run(){if(d.isShowing()){timer.setText(formatRemaining(m.endAt-System.currentTimeMillis()));timer.postDelayed(this,1000);}}};
        d.setOnShowListener(x->{timer.post(tick);d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{cancelMissionFinish(m);m.state=2;m.endAt=0;m.doneDay=todayKey();rewardMission(m);if(!m.daily&&index>=0&&index<progressMissions.size())progressMissions.remove(index);saveProgressMissions();rebuildProgressPages(false);updateActiveMissionBar();d.dismiss();});d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{cancelMissionFinish(m);m.state=3;m.endAt=0;breakCombo();saveProgressMissions();rebuildProgressPages(false);updateActiveMissionBar();d.dismiss();});d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v->{cancelMissionFinish(m);m.state=0;m.endAt=0;saveProgressMissions();rebuildProgressPages(false);updateActiveMissionBar();d.dismiss();});});d.show();
    }
    private String formatRemaining(long ms){if(ms<0)ms=0;long s=ms/1000;return String.format(java.util.Locale.US,"%02d:%02d",s/60,s%60);}
    private void startMissionTicker(){
        if(missionTicker!=null)missionHandler.removeCallbacks(missionTicker);missionTicker=new Runnable(){public void run(){int i=activeMissionIndex();if(i>=0&&progressPages!=null){Mission m=progressMissions.get(i);updateActiveMissionBar();if(m.endAt>0&&System.currentTimeMillis()>=m.endAt){Toast.makeText(MainActivity.this,"زمان مأموریت «"+m.title+"» تمام شد",Toast.LENGTH_LONG).show();showTimerFinishedNotification(m);m.endAt=0;saveProgressMissions();rebuildProgressPages(false);}}missionHandler.postDelayed(this,1000);}};missionHandler.postDelayed(missionTicker,1000);
    }
    private void removeProgressMission(final int index){if(index<0||index>=progressMissions.size()||progressMissions.get(index).state==1)return;Mission doomed=progressMissions.get(index);cancelMissionReminder(doomed);cancelMissionFinish(doomed);progressMissions.remove(index);saveProgressMissions();rebuildProgressPages(false);}

    private static final String MISSION_CHANNEL="legacy_missions";
    private void ensureNotificationChannel(){if(android.os.Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(MISSION_CHANNEL,"ماموریت‌ها",NotificationManager.IMPORTANCE_HIGH);c.setDescription("پایان زمان و یادآوری مأموریت‌ها");getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private void requestNotificationPermission(){if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},700);}
    private int reminderRequestCode(Mission m){return 10000+(m.id.hashCode()&0x3fffffff)%50000;}
    private void scheduleMissionReminder(Mission m){if(!m.reminder)return;Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,m.reminderHour);c.set(Calendar.MINUTE,m.reminderMinute);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);Intent i=new Intent(this,MissionReminderReceiver.class);i.putExtra("missionId",m.id);PendingIntent pi=PendingIntent.getBroadcast(this,reminderRequestCode(m),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);((AlarmManager)getSystemService(ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);}
    private void cancelMissionReminder(Mission m){Intent i=new Intent(this,MissionReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,reminderRequestCode(m),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null){((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi);pi.cancel();}}
    private int finishRequestCode(Mission m){return 20000+(m.id.hashCode()&0x3fffffff)%50000;}
    private void scheduleMissionFinish(Mission m){
        Intent i=new Intent(this,MissionTimerReceiver.class);i.putExtra("missionId",m.id);i.putExtra("title",m.title);
        PendingIntent pi=PendingIntent.getBroadcast(this,finishRequestCode(m),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager)getSystemService(ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,m.endAt,pi);
    }
    private void cancelMissionFinish(Mission m){
        Intent i=new Intent(this,MissionTimerReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,finishRequestCode(m),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
        if(pi!=null){((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi);pi.cancel();}
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(3000+(m.id.hashCode()&0x7fffffff)%50000);
    }
    private void showTimerFinishedNotification(Mission m){Intent i=new Intent(this,MainActivity.class);i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent pi=PendingIntent.getActivity(this,2000+(m.id.hashCode()&0x7fffffff)%50000,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(this,MISSION_CHANNEL).setSmallIcon(R.drawable.ic_launcher_legacy).setContentTitle("زمان مأموریت تمام شد").setContentText(m.title).setContentIntent(pi).setAutoCancel(true).build();((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(3000+(m.id.hashCode()&0x7fffffff)%50000,n);}

    private void showGameSettings(){
        final String[] opts={"10 دقیقه","15 دقیقه","20 دقیقه","30 دقیقه","45 دقیقه","60 دقیقه"};
        final int[] vals={10,15,20,30,45,60}; int checked=3; for(int i=0;i<vals.length;i++)if(vals[i]==comboWindowMinutes)checked=i;
        new AlertDialog.Builder(this).setTitle("مهلت ادامه Combo").setSingleChoiceItems(opts,checked,(d,which)->{comboWindowMinutes=vals[which];expireComboIfNeeded();saveGameState();d.dismiss();Toast.makeText(this,"مهلت Combo: "+comboWindowMinutes+" دقیقه",Toast.LENGTH_SHORT).show();}).setNegativeButton("بستن",null).show();
    }

    private void showPlaceholder(String title){
        isHome = false;
        ++homeGeneration; // invalidates any pending Home hit-target layout pass
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(Color.rgb(10,31,51));
        TextView t=tv(title,28,Color.WHITE); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,0xFFBFD4E6); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
    }
    @Override public void onBackPressed(){
        // On a section, Back returns Home. On Home, double Back exits.
        if(!isHome){ showHome(); return; }
        long now=System.currentTimeMillis();
        if(now-lastBackAt<1800){ super.onBackPressed(); }
        else { lastBackAt=now; Toast.makeText(this,"برای خروج دوباره بزنید",Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
    private float dp(float x){ return x*getResources().getDisplayMetrics().density; }
}

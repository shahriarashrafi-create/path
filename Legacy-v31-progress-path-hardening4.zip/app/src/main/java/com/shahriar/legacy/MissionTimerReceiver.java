package com.shahriar.legacy;
import android.app.*;import android.content.*;import android.os.Build;import android.util.Base64;import java.nio.charset.StandardCharsets;
public class MissionTimerReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent in){
  String id=in.getStringExtra("missionId"); if(id==null)return;
  android.content.SharedPreferences p=c.getSharedPreferences("progress_path",Context.MODE_PRIVATE); int n=p.getInt("count",0); String title=in.getStringExtra("title");
  android.content.SharedPreferences.Editor ed=p.edit();
  for(int x=0;x<n;x++){String raw=p.getString("m"+x,"");String[] a=raw.split("\\|",-1);if(a.length>=9&&id.equals(a[8])){if(a.length>=7&&"1".equals(a[5])){a[6]="0";StringBuilder b=new StringBuilder();for(int j=0;j<a.length;j++){if(j>0)b.append('|');b.append(a[j]);}ed.putString("m"+x,b.toString());try{title=new String(Base64.decode(a[0],Base64.NO_WRAP),StandardCharsets.UTF_8);}catch(Exception e){}}break;}}
  ed.apply(); if(title==null)title="مأموریت";
  if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("legacy_missions","ماموریت‌ها",NotificationManager.IMPORTANCE_HIGH);c.getSystemService(NotificationManager.class).createNotificationChannel(ch);}
  Intent open=new Intent(c,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent pi=PendingIntent.getActivity(c,2000+(id.hashCode()&0x7fffffff)%50000,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification no=new Notification.Builder(c,"legacy_missions").setSmallIcon(R.drawable.ic_launcher_legacy).setContentTitle("زمان مأموریت تمام شد").setContentText(title).setContentIntent(pi).setAutoCancel(true).build();c.getSystemService(NotificationManager.class).notify(3000+(id.hashCode()&0x7fffffff)%50000,no);
 }
}

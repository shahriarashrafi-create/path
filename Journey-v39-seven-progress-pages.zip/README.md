Journey-v39-seven-progress-pages

Changes:
- Added page 7 above page 6 in Progress Path.
- Page 7 uses the universe/connection artwork with no dashed continuation above the top circle.
- Added nodes 19, 20, and 21 from bottom to top.
- Uses the same touch calibration, pressed feedback, title editor, persistent title storage, Header, Bottom Bar, and safe-area behavior as the previous pages.
- Artwork dimensions preserved; stored as high-quality WebP to reduce APK size.

# Journey v4
Android app project for Journey.

- App name: Journey
- Background: 1080x2040 WebP (9:17)
- Background is fit to screen width without center-crop side loss.
- Edge-to-edge system bars remain transparent.

## v24
- Replaced Progress Path artwork with transparent adult-anime morning/stretch illustration.
- Optimized asset as high-quality WebP with alpha to reduce APK size while preserving visual quality.
- Existing scroll behavior, global header/bottom bars, and safe-area behavior retained.

## v25
- Replaced Progress Path artwork with the new minimal business-morning illustration.
- Optimized the 887x1774 artwork to high-quality WebP (~80 KB) to preserve visual quality while keeping APK size low.
- Added 3 clickable milestone circles, ordered from bottom to top.
- Press feedback is shown directly on the tapped circle before navigation.
- Each milestone opens its own temporary stage page; stage content will be defined next.
- Header, bottom bar, safe area, and progress scrolling remain global.

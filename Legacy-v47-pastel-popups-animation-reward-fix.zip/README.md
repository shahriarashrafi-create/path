Legacy v47 — Pastel Mission Popups & Reward Animations

Changes in this build:
- Restore now reverses the mission's XP/Coin reward and restores mission state; combo rollback is handled safely.
- Editing Done/Fail missions cannot start them again until Restore is used.
- New pastel blue/purple code-driven popup theme for Subtasks, Music, Success, Fail, Later/Reset, Restore, Delete, Level Up, notification content, and active-mission warning.
- Slower, clearer reward animations: trophy/star pulse, XP/Coin/Combo flight to HUD, particles, failure crystal, reset spin, restore feedback.
- Music picker keeps 3 built-in focus tracks and saved tracks added from the phone.
- Custom mission-finished notification layout with Done / Later / Fail actions.

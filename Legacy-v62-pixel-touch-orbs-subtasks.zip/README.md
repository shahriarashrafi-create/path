Legacy v62

Changes:
- Removed full-width blue bars from Progress Path pages.
- Added a small glowing blue orb centered at the very top and bottom of every Progress Path artwork.
- Removed unnecessary Persian helper labels from Subtasks; Subtasks UI now stays clean and English-only.
- Recalibrated Mission Editor controls from the actual 768x1536 artwork: title, importance choices, time controls, repeat choices, and Start.
- Recalibrated Running Mission from the actual 768x1536 artwork: mission title, progress ring, timer, reward preview, Done/Fail, and the four bottom controls.
- Reduced the custom progress-ring thickness so it fits the baked-in timer circle precisely.
- Strengthened selected-state outlines for editor choices.

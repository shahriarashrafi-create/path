# Legacy v86 — Time Travel stability + full backup/restore

This build continues from v85 and focuses on stability, performance, and data safety.

## Time Travel
- Real two-page week transition: outgoing and incoming weeks slide together.
- Touch is locked during the short week transition.
- Single haptic per interaction.
- New week always opens at 100% zoom and centered pan.
- Dark timetable layers stay visually fixed during zoom/pan/week changes.
- Weekly conflict checking includes stored one-off programs from other weeks.
- Merge preserves existing per-week Done/Fail history where possible.
- Time Travel dialogs use real system-bar/cutout insets and explicit RTL layout.
- Week data/statuses are cached for smoother zoom/pan rendering.
- Event depth rendering is hardware-friendly.
- Overview helper text removed; overview is ordered from the current weekday, then forward through the week, and by time within each day.
- Done / Fail / No status are one-tap actions: they save immediately and close Edit.
- Dead intermediate entry-actions menu removed.

## Full backup / restore
- Settings header now includes Export and Import icons side by side.
- Export writes a ZIP backup through Android's document picker.
- Backup contains all SharedPreferences, app-owned files (including Dream Palace images), databases if present, and copies of accessible user-selected mission music.
- Import validates the Legacy backup before replacing current local data, restores preferences/files, refreshes caches, and re-schedules an active mission alarm when needed.
- Backup filenames use the current Jalali date.

## Version
- Android versionCode: 50
- Android versionName: 1.46


## v95 World Cup final visual rebuild
- World Cup screen is rendered from the real background plus code-drawn glass UI.
- The full reference mockup is not bundled or loaded at runtime.
- Country artwork is stored as separate small assets; layout, paths, locks, XP, footer progression and glass cards are code-rendered.
- Responsive normalized geometry replaces density-heavy dp layout to prevent oversized/overlapping UI on real devices.
- Persian labels use RTL StaticLayout rendering for reliable direction/shaping.

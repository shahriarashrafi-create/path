package com.journey.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.os.Build;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.text.style.ForegroundColorSpan;

public class MainActivity extends Activity {
    private FrameLayout root;
    private boolean onHome = true;
    private boolean onProgressPath = false;
    private boolean onProgressStage = false;
    private SharedPreferences prefs;
    private ScrollView currentProgressScroll;
    private int savedProgressScrollY = -1;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        prefs = getSharedPreferences("journey_progress", MODE_PRIVATE);
        if (!prefs.contains("level")) prefs.edit().putInt("level",1).putInt("xp",0).putInt("coins",0).putInt("combo",0).apply();
        showHome();
    }

    private void configureWindow() {
        Window w = getWindow();
        // Keep app content strictly between Android system bars.
        // Do not draw the background underneath the status/navigation bars.
        w.setStatusBarColor(Color.rgb(2, 15, 38));
        w.setNavigationBarColor(Color.rgb(2, 15, 38));
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    private void showHome() {
        onHome = true;
        onProgressPath = false;
        onProgressStage = false;
        refreshComboTimeout();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 15, 38));
        // Permanent Journey rule: all app UI stays strictly inside Android system bars.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(0, top, 0, bottom);
                return insets;
            });
        }

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.journey_background);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bg.setAdjustViewBounds(false);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        addTopBar();
        addBottomBar();

        // Touch zones cover each complete island and its black label.
        addHotspot("جام جهانی", .24f, .148f, .76f, .328f);
        addHotspot("مرکز خرید", .00f, .268f, .47f, .448f);
        addHotspot("کاخ آرزوها", .54f, .268f, 1.00f, .458f);
        addHotspot("سفر در زمان", .03f, .408f, .49f, .608f);
        addHotspot("جنگل", .52f, .428f, 1.00f, .638f);
        addHotspot("مسیر پیشرفت", .23f, .638f, .78f, .888f);

        setContentView(root);
    }


    private void addTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(9), 0, dp(7), 0);
        GradientDrawable panel = new GradientDrawable();
        panel.setColor(Color.argb(210, 2, 10, 25));
        panel.setStroke(1, Color.argb(145, 135, 99, 38));
        panel.setCornerRadii(new float[]{0,0,0,0,dp(16),dp(16),dp(16),dp(16)});
        bar.setBackground(panel);

        int level = prefs.getInt("level",1);
        int xp = prefs.getInt("xp",0);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);

        FrameLayout avatarFrame = new FrameLayout(this);
        GradientDrawable avatarBg = new GradientDrawable();
        avatarBg.setShape(GradientDrawable.OVAL);
        avatarBg.setColor(Color.rgb(7, 15, 28));
        avatarBg.setStroke(dp(1), Color.rgb(230, 173, 55));
        avatarFrame.setBackground(avatarBg);
        avatarFrame.setPadding(dp(1), dp(1), dp(1), dp(1));
        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.journey_avatar);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarFrame.addView(avatar, new FrameLayout.LayoutParams(-1, -1));
        left.addView(avatarFrame, new LinearLayout.LayoutParams(dp(34), dp(34)));

        LinearLayout progressBox = new LinearLayout(this);
        progressBox.setOrientation(LinearLayout.VERTICAL);
        progressBox.setGravity(Gravity.CENTER_VERTICAL);
        progressBox.setPadding(dp(4),0,0,0);
        TextView levelText = headerText("Lv " + level, 12, Gravity.LEFT);
        levelText.setTranslationY(dp(1));
        levelText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        progressBox.addView(levelText, new LinearLayout.LayoutParams(-1, dp(15)));

        ProgressBar xpBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        xpBar.setMax(level * 100);
        xpBar.setProgress(xp);
        GradientDrawable track = new GradientDrawable();
        track.setColor(Color.rgb(12, 14, 22));
        track.setStroke(1, Color.rgb(116, 83, 37));
        track.setCornerRadius(dp(5));
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(255,151,16), Color.rgb(255,220,78)});
        fill.setCornerRadius(dp(5));
        android.graphics.drawable.ClipDrawable clip = new android.graphics.drawable.ClipDrawable(fill, Gravity.LEFT, android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable layers = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{track, clip});
        layers.setId(0, android.R.id.background); layers.setId(1, android.R.id.progress);
        xpBar.setProgressDrawable(layers);
        progressBox.addView(xpBar, new LinearLayout.LayoutParams(dp(62), dp(7)));
        left.addView(progressBox, new LinearLayout.LayoutParams(-2, -1));
        bar.addView(left, new LinearLayout.LayoutParams(0, -1, 1.08f));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.journey_header_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        bar.addView(logo, new LinearLayout.LayoutParams(0, dp(50), .94f));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        stats.addView(statCapsule("⭐", xp));
        stats.addView(statCapsule("🪙", prefs.getInt("coins",0)));
        stats.addView(statCapsule("🔥", prefs.getInt("combo",0)));
        bar.addView(stats, new LinearLayout.LayoutParams(0, -1, 1.48f));

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(37));
        bp.gravity = Gravity.TOP;
        root.addView(bar, bp);
    }

    // Bottom navigation is 100% native code: no bitmap/image asset is used.
    // The center Home control floats above the panel and is deliberately not clipped.
    private void addBottomBar() {
        FrameLayout navRoot = new FrameLayout(this);
        navRoot.setClipChildren(false);
        navRoot.setClipToPadding(false);

        View panelView = new View(this);
        GradientDrawable panel = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.argb(210, 30, 19, 13), Color.argb(226, 2, 10, 24)});
        panel.setStroke(1, Color.argb(165, 165, 119, 38));
        panel.setCornerRadii(new float[]{dp(24),dp(24),dp(24),dp(24),0,0,0,0});
        panelView.setBackground(panel);
        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(-1, dp(31), Gravity.BOTTOM);
        navRoot.addView(panelView, panelLp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        row.setPadding(dp(18), 0, dp(18), 0);
        row.setClipChildren(false);
        row.setClipToPadding(false);

        LinearLayout notifications = bottomItem(NavIconView.BELL, "اعلان‌ها", false, true);
        notifications.setOnClickListener(v -> showSection("اعلان‌ها"));
        LinearLayout.LayoutParams sideLp = new LinearLayout.LayoutParams(0, dp(31), 1f);
        row.addView(notifications, sideLp);

        LinearLayout home = bottomItem(NavIconView.HOME, "خانه", true, false);
        home.setOnClickListener(v -> showHome());
        LinearLayout.LayoutParams homeLp = new LinearLayout.LayoutParams(0, dp(47), 1f);
        row.addView(home, homeLp);

        LinearLayout settings = bottomItem(NavIconView.GEAR, "تنظیمات", false, false);
        settings.setOnClickListener(v -> showSection("تنظیمات"));
        row.addView(settings, new LinearLayout.LayoutParams(0, dp(31), 1f));

        FrameLayout.LayoutParams rowLp = new FrameLayout.LayoutParams(-1, dp(47), Gravity.BOTTOM);
        navRoot.addView(row, rowLp);

        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-1, dp(47));
        np.gravity = Gravity.BOTTOM;
        root.addView(navRoot, np);
    }

    private LinearLayout bottomItem(int iconType, String label, boolean selected, boolean notificationDot) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        box.setClickable(true);
        box.setClipChildren(false);
        box.setClipToPadding(false);

        FrameLayout iconHolder = new FrameLayout(this);
        iconHolder.setClipChildren(false);
        int holder = selected ? dp(42) : dp(25);
        if (selected) {
            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            circle.setColor(Color.rgb(12, 13, 19));
            circle.setStroke(dp(2), Color.rgb(244, 169, 35));
            iconHolder.setBackground(circle);
        }
        NavIconView icon = new NavIconView(iconType, selected);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(selected ? dp(27) : dp(20), selected ? dp(27) : dp(20), Gravity.CENTER);
        iconHolder.addView(icon, ip);

        if (notificationDot && hasUnreadNotifications()) {
            View dot = new View(this);
            GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(Color.rgb(255,55,45));
            d.setStroke(dp(1), Color.rgb(255,180,120)); dot.setBackground(d);
            FrameLayout.LayoutParams dpv = new FrameLayout.LayoutParams(dp(7), dp(7), Gravity.TOP | Gravity.RIGHT);
            dpv.setMargins(0, 0, 0, 0); iconHolder.addView(dot, dpv);
        }
        box.addView(iconHolder, new LinearLayout.LayoutParams(holder, holder));

        return box;
    }

    private boolean hasUnreadNotifications() {
        return prefs.getBoolean("has_unread_notifications", false);
    }

    private class NavIconView extends View {
        static final int BELL=1, HOME=2, GEAR=3;
        private final int type; private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        NavIconView(int type, boolean selected) {
            super(MainActivity.this); this.type=type;
            paint.setColor(selected ? Color.rgb(255,184,35) : Color.rgb(255,222,142));
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2));
            paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
            if(type==HOME){
                paint.setColor(Color.rgb(255,184,35)); paint.setStyle(Paint.Style.FILL);
                Path homePath=new Path();
                homePath.moveTo(w*.10f,h*.48f); homePath.lineTo(cx,h*.10f); homePath.lineTo(w*.90f,h*.48f);
                homePath.lineTo(w*.78f,h*.48f); homePath.lineTo(w*.78f,h*.88f); homePath.lineTo(w*.22f,h*.88f);
                homePath.lineTo(w*.22f,h*.48f); homePath.close(); c.drawPath(homePath,paint);
                paint.setColor(Color.rgb(12,13,19)); c.drawRoundRect(new RectF(w*.44f,h*.63f,w*.59f,h*.88f),dp(1),dp(1),paint);
            } else if(type==BELL){
                paint.setStyle(Paint.Style.STROKE);
                Path p=new Path(); p.moveTo(w*.25f,h*.68f); p.quadTo(w*.32f,h*.60f,w*.32f,h*.42f); p.quadTo(w*.32f,h*.20f,cx,h*.20f); p.quadTo(w*.68f,h*.20f,w*.68f,h*.42f); p.quadTo(w*.68f,h*.60f,w*.75f,h*.68f); p.lineTo(w*.25f,h*.68f); c.drawPath(p,paint);
                c.drawLine(w*.22f,h*.72f,w*.78f,h*.72f,paint); c.drawArc(new RectF(w*.42f,h*.70f,w*.58f,h*.86f),0,180,false,paint);
            } else {
                paint.setStyle(Paint.Style.STROKE); c.drawCircle(cx,cy,Math.min(w,h)*.25f,paint); c.drawCircle(cx,cy,Math.min(w,h)*.09f,paint);
                for(int i=0;i<8;i++){ double a=i*Math.PI/4; float x1=cx+(float)Math.cos(a)*w*.31f, y1=cy+(float)Math.sin(a)*h*.31f; float x2=cx+(float)Math.cos(a)*w*.42f, y2=cy+(float)Math.sin(a)*h*.42f; c.drawLine(x1,y1,x2,y2,paint); }
            }
        }
    }

    private TextView statCapsule(String icon, int value) {
        TextView v = headerText(icon + " " + value, 12, Gravity.CENTER);
        v.setSingleLine(true); v.setPadding(dp(5),0,dp(5),0); v.setMinWidth(dp(44));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.argb(185, 5, 10, 20));
        bg.setStroke(1, Color.argb(150, 150, 109, 39)); bg.setCornerRadius(dp(13)); v.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(24)); p.setMargins(dp(1),0,dp(1),0); v.setLayoutParams(p);
        return v;
    }

    private TextView headerText(String text, float size, int gravity) {
        TextView v = new TextView(this); v.setText(text); v.setTextColor(Color.WHITE); v.setTextSize(size); v.setGravity(gravity | Gravity.CENTER_VERTICAL); v.setMaxLines(2); return v;
    }

    // Reward rules reserved for mission completion: low 10XP/5 coins, medium 20XP/10 coins, high 30XP/15 coins.
    // Combo: consecutive successful missions; 30-minute default window. Fail/timeout resets to zero.
    // Combo 3+ => x1.5 rewards, Combo 7+ => x2 rewards.
    private void awardMission(int baseXp, int baseCoins, boolean success) {
        if (!success) { prefs.edit().putInt("combo",0).apply(); return; }
        int combo = prefs.getInt("combo",0) + 1;
        float mult = combo >= 7 ? 2f : (combo >= 3 ? 1.5f : 1f);
        int level = prefs.getInt("level",1);
        int xp = prefs.getInt("xp",0) + Math.round(baseXp * mult);
        int coins = prefs.getInt("coins",0) + Math.round(baseCoins * mult);
        while (xp >= level * 100) { xp -= level * 100; level++; }
        prefs.edit().putInt("level",level).putInt("xp",xp).putInt("coins",coins).putInt("combo",combo)
            .putLong("combo_deadline", System.currentTimeMillis() + 30L*60L*1000L).apply();
    }

    private void refreshComboTimeout() {
        long deadline = prefs.getLong("combo_deadline",0);
        if (prefs.getInt("combo",0) > 0 && deadline > 0 && System.currentTimeMillis() > deadline)
            prefs.edit().putInt("combo",0).putLong("combo_deadline",0).apply();
    }

    private void addHotspot(String title, float l, float t, float r, float b) {
        View v = new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setClickable(true);
        v.setOnClickListener(view -> {
            GradientDrawable glow = new GradientDrawable();
            glow.setColor(Color.argb(42, 255, 193, 7));
            glow.setStroke(dp(2), Color.argb(180, 255, 193, 7));
            glow.setCornerRadius(dp(28));
            view.setBackground(glow);
            new Handler().postDelayed(() -> {
                view.setBackgroundColor(Color.TRANSPARENT);
                showSection(title);
            }, 110);
        });
        root.post(() -> {
            int w = root.getWidth(), h = root.getHeight();
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                Math.round((r-l)*w), Math.round((b-t)*h));
            p.leftMargin = Math.round(l*w);
            p.topMargin = Math.max(0, Math.round(t*h) - dp(36));
            v.setLayoutParams(p);
        });
        root.addView(v, new FrameLayout.LayoutParams(1,1));
    }

    private void showSection(String title) {
        if ("مسیر پیشرفت".equals(title)) { showProgressPath(); return; }
        onHome = false;
        onProgressPath = false;
        onProgressStage = false;
        refreshComboTimeout();

        // Every Journey page uses the same permanent shell: safe-area + Header + Bottom Bar.
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 15, 38));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(0, top, 0, bottom);
                return insets;
            });
        }

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        heading.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        FrameLayout.LayoutParams contentLp = new FrameLayout.LayoutParams(-1, -1);
        contentLp.topMargin = dp(37);
        contentLp.bottomMargin = dp(31);
        root.addView(heading, contentLp);

        addTopBar();
        addBottomBar();
        setContentView(root);
    }


    private void showProgressPath() {
        onHome = false;
        onProgressPath = true;
        onProgressStage = false;
        refreshComboTimeout();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(242, 246, 253));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
        }

        // Seven stacked 1:2 progress artworks: page 7 at the top, followed by pages 6 through 1.
        // The ScrollView stays underneath the permanent Header and Bottom Bar.
        ScrollView scroll = new ScrollView(this);
        currentProgressScroll = scroll;
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.VERTICAL);
        pages.setBackgroundColor(Color.rgb(242, 246, 253));

        int screenW = getResources().getDisplayMetrics().widthPixels;

        // Page 7 (top): connection-to-the-universe artwork, nodes 19-21 from bottom to top.
        FrameLayout page7 = createProgressPage(R.drawable.progress_path_7, screenW);
        int page7H = page7.getLayoutParams().height;
        addProgressTitleNode(page7, screenW, page7H, 19, 0.338f, 0.757f);
        addProgressTitleNode(page7, screenW, page7H, 20, 0.267f, 0.487f);
        addProgressTitleNode(page7, screenW, page7H, 21, 0.390f, 0.237f);
        pages.addView(page7);

        // Page 6 (top): analysis / information artwork, nodes 16-18 from bottom to top.
        FrameLayout page6 = createProgressPage(R.drawable.progress_path_6, screenW);
        int page6H = page6.getLayoutParams().height;
        addProgressTitleNode(page6, screenW, page6H, 16, 0.683f, 0.751f);
        addProgressTitleNode(page6, screenW, page6H, 17, 0.775f, 0.479f);
        addProgressTitleNode(page6, screenW, page6H, 18, 0.680f, 0.219f);
        pages.addView(page6);

        // Page 5: communication / calls / messaging artwork, nodes 13-15 from bottom to top.
        FrameLayout page5 = createProgressPage(R.drawable.progress_path_5, screenW);
        int page5H = page5.getLayoutParams().height;
        addProgressTitleNode(page5, screenW, page5H, 13, 0.308f, 0.759f);
        addProgressTitleNode(page5, screenW, page5H, 14, 0.236f, 0.489f);
        addProgressTitleNode(page5, screenW, page5H, 15, 0.378f, 0.236f);
        pages.addView(page5);

        // Page 4: solo desk/laptop work artwork, nodes 10-12 from bottom to top.
        FrameLayout page4 = createProgressPage(R.drawable.progress_path_4, screenW);
        int page4H = page4.getLayoutParams().height;
        addProgressTitleNode(page4, screenW, page4H, 10, 0.683f, 0.751f);
        addProgressTitleNode(page4, screenW, page4H, 11, 0.775f, 0.479f);
        addProgressTitleNode(page4, screenW, page4H, 12, 0.680f, 0.219f);
        pages.addView(page4);

        // Page 3: team celebration artwork, nodes 7-9 from bottom to top.
        FrameLayout topPage = createProgressPage(R.drawable.progress_path_3, screenW);
        int topH = topPage.getLayoutParams().height;
        addProgressTitleNode(topPage, screenW, topH, 7, 0.308f, 0.759f);
        addProgressTitleNode(topPage, screenW, topH, 8, 0.233f, 0.489f);
        addProgressTitleNode(topPage, screenW, topH, 9, 0.378f, 0.236f);
        pages.addView(topPage);

        // Page 2 (middle): focus / meditation themed artwork, nodes 4-6 from bottom to top.
        FrameLayout upperPage = createProgressPage(R.drawable.progress_path_2, screenW);
        int upperH = upperPage.getLayoutParams().height;
        addProgressTitleNode(upperPage, screenW, upperH, 4, 0.683f, 0.751f);
        addProgressTitleNode(upperPage, screenW, upperH, 5, 0.769f, 0.479f);
        addProgressTitleNode(upperPage, screenW, upperH, 6, 0.678f, 0.216f);
        pages.addView(upperPage);

        // Page 1 (bottom): current morning/business artwork, nodes 1-3 from bottom to top.
        FrameLayout lowerPage = createProgressPage(R.drawable.progress_path, screenW);
        int lowerH = lowerPage.getLayoutParams().height;
        addProgressTitleNode(lowerPage, screenW, lowerH, 1, 261f / 768f, 1162f / 1536f);
        addProgressTitleNode(lowerPage, screenW, lowerH, 2, 206f / 768f, 747f / 1536f);
        addProgressTitleNode(lowerPage, screenW, lowerH, 3, 299f / 768f, 363f / 1536f);
        pages.addView(lowerPage);

        scroll.addView(pages, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        // Bars are always the highest layer.
        addTopBar();
        addBottomBar();
        setContentView(root);

        // First entry starts on the first/lower image. Returning from a stage restores the exact previous path position.
        scroll.post(() -> {
            if (savedProgressScrollY >= 0) scroll.scrollTo(0, savedProgressScrollY);
            else scroll.fullScroll(View.FOCUS_DOWN);
        });
    }

    private FrameLayout createProgressPage(int drawableRes, int screenW) {
        android.graphics.drawable.Drawable drawable = getDrawable(drawableRes);
        int pageH = Math.round(screenW * (drawable.getIntrinsicHeight() / (float) drawable.getIntrinsicWidth()));

        FrameLayout page = new FrameLayout(this);
        page.setClipChildren(false);
        page.setClipToPadding(false);
        page.setLayoutParams(new LinearLayout.LayoutParams(-1, pageH));

        ImageView image = new ImageView(this);
        image.setImageResource(drawableRes);
        image.setScaleType(ImageView.ScaleType.FIT_XY);
        image.setAdjustViewBounds(false);
        page.addView(image, new FrameLayout.LayoutParams(-1, -1));
        return page;
    }

    private void addProgressTitleNode(FrameLayout page, int pageW, int pageH, int node, float normX, float normY) {
        TextView label = new TextView(this);
        label.setText(prefs.getString("progress_node_title_" + node, ""));
        label.setTextColor(Color.rgb(37, 52, 78));
        label.setTextSize(13);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(3);
        label.setPadding(dp(8), dp(4), dp(8), dp(4));
        label.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        int visualSize = Math.round(pageW * (248f / 768f));
        float cx = normX * pageW;
        float cy = normY * pageH;

        FrameLayout.LayoutParams labelLp = new FrameLayout.LayoutParams(visualSize, visualSize);
        labelLp.leftMargin = Math.round(cx - visualSize / 2f);
        labelLp.topMargin = Math.round(cy - visualSize / 2f);
        page.addView(label, labelLp);

        View touch = new View(this);
        touch.setClickable(true);
        touch.setFocusable(true);
        touch.setBackgroundColor(Color.TRANSPARENT);

        int touchSize = Math.round(visualSize * 1.02f);
        // Latest calibration: 0.5 mm lower than v33; use the same offset on both pages.
        float touchCy = cy + dp(1);
        FrameLayout.LayoutParams touchLp = new FrameLayout.LayoutParams(touchSize, touchSize);
        touchLp.leftMargin = Math.round(cx - touchSize / 2f);
        touchLp.topMargin = Math.round(touchCy - touchSize / 2f);
        page.addView(touch, touchLp);

        touch.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                GradientDrawable pressed = new GradientDrawable();
                pressed.setShape(GradientDrawable.OVAL);
                pressed.setColor(Color.argb(56, 86, 145, 255));
                pressed.setStroke(dp(3), Color.argb(235, 91, 150, 255));
                v.setBackground(pressed);
                v.animate().scaleX(.93f).scaleY(.93f).setDuration(70).start();
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(70).withEndAction(() -> {
                    new Handler().postDelayed(() -> {
                        v.setBackgroundColor(Color.TRANSPARENT);
                        if (currentProgressScroll != null) savedProgressScrollY = currentProgressScroll.getScrollY();
                        showProgressStageEditor(node);
                    }, 90);
                }).start();
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                v.setBackgroundColor(Color.TRANSPARENT);
                v.animate().scaleX(1f).scaleY(1f).setDuration(60).start();
                return true;
            }
            return true;
        });
    }

    private void showProgressStageEditor(int node) {
        onHome = false;
        onProgressPath = false;
        onProgressStage = true;
        refreshComboTimeout();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(244, 248, 253));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
        }

        // Visual template shared by every one of the 21 progress stages.
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.progress_stage_editor);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setAdjustViewBounds(false);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        // Title: type directly into the empty title box. It is persisted live and is also shown in the path circle.
        EditText titleInput = new EditText(this);
        titleInput.setText(prefs.getString("progress_node_title_" + node, ""));
        titleInput.setTextColor(Color.rgb(36, 48, 95));
        titleInput.setHintTextColor(Color.rgb(145, 155, 183));
        titleInput.setTextSize(16);
        titleInput.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        titleInput.setSingleLine(true);
        titleInput.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        titleInput.setBackgroundColor(Color.TRANSPARENT);
        titleInput.setPadding(dp(14), 0, dp(18), 0);
        root.addView(titleInput, new FrameLayout.LayoutParams(1, 1));
        titleInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                prefs.edit().putString("progress_node_title_" + node, s == null ? "" : s.toString().trim()).apply();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Dynamic values remain empty until the user makes a selection.
        TextView timeValue = stageValueText();
        TextView importanceValue = stageValueText();
        TextView repeatValue = stageValueText();
        TextView reminderValue = stageValueText();
        updateStageValueText(timeValue, prefs.getInt("progress_node_time_" + node, 0), "time");
        importanceValue.setText(prefs.getString("progress_node_importance_" + node, ""));
        repeatValue.setText(prefs.getString("progress_node_repeat_" + node, ""));
        String savedReminder = prefs.getString("progress_node_reminder_" + node, "");
        updateReminderCheck(reminderValue, savedReminder);
        root.addView(timeValue, new FrameLayout.LayoutParams(1, 1));
        root.addView(importanceValue, new FrameLayout.LayoutParams(1, 1));
        root.addView(repeatValue, new FrameLayout.LayoutParams(1, 1));
        root.addView(reminderValue, new FrameLayout.LayoutParams(1, 1));

        View timeTouch = transparentTouch();
        View importanceTouch = transparentTouch();
        View repeatTouch = transparentTouch();
        View reminderTouch = transparentTouch();
        View startTouch = transparentTouch();
        View backTouch = transparentTouch();
        root.addView(timeTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(importanceTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(repeatTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(reminderTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(startTouch, new FrameLayout.LayoutParams(1,1));
        root.addView(backTouch, new FrameLayout.LayoutParams(1,1));

        timeTouch.setOnClickListener(v -> {
            final String[] labels = {"5 min", "10 min", "20 min", "30 min"};
            final int[] values = {5, 10, 20, 30};
            new AlertDialog.Builder(this)
                .setTitle("زمان")
                .setItems(labels, (dialog, which) -> {
                    prefs.edit().putInt("progress_node_time_" + node, values[which]).apply();
                    updateStageValueText(timeValue, values[which], "time");
                }).show();
        });

        importanceTouch.setOnClickListener(v -> showStringChoice(
            "اهمیت", new String[]{"کم", "متوسط", "زیاد"},
            prefs.getString("progress_node_importance_" + node, ""),
            selected -> {
                prefs.edit().putString("progress_node_importance_" + node, selected).apply();
                importanceValue.setText(selected);
            }
        ));

        repeatTouch.setOnClickListener(v -> showStringChoice(
            "تکرار", new String[]{"بدون تکرار", "روزانه"},
            prefs.getString("progress_node_repeat_" + node, ""),
            selected -> {
                prefs.edit().putString("progress_node_repeat_" + node, selected).apply();
                repeatValue.setText(selected);
            }
        ));

        reminderTouch.setOnClickListener(v -> showStringChoice(
            "یادآور", new String[]{"خاموش", "5 دقیقه قبل", "10 دقیقه قبل", "30 دقیقه قبل"},
            prefs.getString("progress_node_reminder_" + node, ""),
            selected -> {
                prefs.edit().putString("progress_node_reminder_" + node, selected).apply();
                updateReminderCheck(reminderValue, selected);
            }
        ));

        startTouch.setOnClickListener(v -> {
            String title = titleInput.getText() == null ? "" : titleInput.getText().toString().trim();
            int minutes = prefs.getInt("progress_node_time_" + node, 0);
            if (title.isEmpty()) {
                Toast.makeText(this, "ابتدا عنوان مرحله را وارد کنید", Toast.LENGTH_SHORT).show();
                titleInput.requestFocus();
                return;
            }
            if (minutes == 0) {
                Toast.makeText(this, "زمان مرحله را انتخاب کنید", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit()
                .putString("progress_node_title_" + node, title)
                .putInt("active_progress_node", node)
                .apply();
            showRunningStage(node);
        });

        backTouch.setOnClickListener(v -> showProgressPath());

        // Place all live controls exactly over the matching areas of the 1:2 visual template.
        root.post(() -> {
            int w = root.getWidth() - root.getPaddingLeft() - root.getPaddingRight();
            int h = root.getHeight() - root.getPaddingTop() - root.getPaddingBottom();
            placeNormalized(titleInput, w, h, .455f, .244f, .468f, .068f);

            placeNormalized(timeTouch, w, h, .455f, .333f, .485f, .082f);
            placeNormalized(importanceTouch, w, h, .455f, .420f, .485f, .082f);
            placeNormalized(repeatTouch, w, h, .455f, .505f, .485f, .082f);
            placeNormalized(reminderTouch, w, h, .455f, .590f, .485f, .082f);
            placeNormalized(startTouch, w, h, .075f, .818f, .830f, .082f);
            placeNormalized(backTouch, w, h, .040f, .050f, .120f, .080f);

            // Keep every selected value on the exact same horizontal line as its row label.
            // Full-row height + a tiny downward optical correction prevents values from floating above the label baseline.
            placeNormalized(timeValue, w, h, .515f, .333f, .150f, .082f);
            placeNormalized(importanceValue, w, h, .500f, .420f, .165f, .082f);
            placeNormalized(repeatValue, w, h, .485f, .505f, .180f, .082f);
            placeNormalized(reminderValue, w, h, .500f, .590f, .165f, .082f);
            timeValue.setTranslationY(dp(2));
            importanceValue.setTranslationY(dp(2));
            repeatValue.setTranslationY(dp(2));
            reminderValue.setTranslationY(dp(2));
        });

        // Header and bottom bar are always the highest layer, exactly like the 7 path images.
        addTopBar();
        addBottomBar();
        setContentView(root);
    }

    private interface StageChoiceCallback { void onSelected(String value); }

    private void showStringChoice(String title, String[] options, String current, StageChoiceCallback callback) {
        int checked = -1;
        for (int i = 0; i < options.length; i++) if (options[i].equals(current)) checked = i;
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(options, checked, (dialog, which) -> {
                callback.onSelected(options[which]);
                dialog.dismiss();
            })
            .show();
    }

    private TextView stageValueText() {
        TextView t = new TextView(this);
        t.setTextColor(Color.rgb(104, 113, 145));
        t.setTextSize(10.5f);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        return t;
    }

    private void updateReminderCheck(TextView view, String reminder) {
        boolean enabled = reminder != null && !reminder.isEmpty() && !"خاموش".equals(reminder);
        view.setText(enabled ? "✓" : "");
        view.setTextColor(Color.BLACK);
        view.setTextSize(18);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    }

    private void updateStageValueText(TextView view, int value, String type) {
        if ("time".equals(type) && value > 0) {
            String text = value + " min";
            SpannableString styled = new SpannableString(text);
            int start = String.valueOf(value).length() + 1;
            styled.setSpan(new RelativeSizeSpan(.78f), start, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            styled.setSpan(new ForegroundColorSpan(Color.rgb(132, 140, 165)), start, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            view.setText(styled);
        } else view.setText("");
    }

    private View transparentTouch() {
        View v = new View(this);
        v.setClickable(true);
        v.setFocusable(true);
        v.setBackgroundColor(Color.TRANSPARENT);
        return v;
    }

    private void placeNormalized(View view, int parentW, int parentH, float left, float top, float width, float height) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            Math.round(parentW * width), Math.round(parentH * height));
        lp.leftMargin = Math.round(parentW * left);
        lp.topMargin = Math.round(parentH * top);
        view.setLayoutParams(lp);
    }

    private void showRunningStage(int node) {
        onHome = false;
        onProgressPath = false;
        onProgressStage = true;
        refreshComboTimeout();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(244, 248, 253));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
        }

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.progress_stage_editor);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setAlpha(.24f);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        String title = prefs.getString("progress_node_title_" + node, "مرحله " + node);
        int mins = prefs.getInt("progress_node_time_" + node, 10);
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(Color.rgb(35, 47, 93));
        titleView.setTextSize(24);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER);
        titleView.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView timer = new TextView(this);
        timer.setText(String.format(java.util.Locale.US, "%02d:00", mins));
        timer.setTextColor(Color.rgb(57, 92, 180));
        timer.setTextSize(44);
        timer.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        timer.setGravity(Gravity.CENTER);

        Button finish = new Button(this);
        finish.setText("Done");
        finish.setAllCaps(false);
        finish.setTextColor(Color.WHITE);
        GradientDrawable doneBg = new GradientDrawable();
        doneBg.setColor(Color.rgb(77, 164, 125));
        doneBg.setCornerRadius(dp(18));
        finish.setBackground(doneBg);
        finish.setOnClickListener(v -> {
            String importance = prefs.getString("progress_node_importance_" + node, "متوسط");
            int xp = "زیاد".equals(importance) ? 30 : ("کم".equals(importance) ? 10 : 20);
            int coins = "زیاد".equals(importance) ? 15 : ("کم".equals(importance) ? 5 : 10);
            awardMission(xp, coins, true);
            prefs.edit().putBoolean("progress_node_done_" + node, true).remove("active_progress_node").apply();
            showProgressPath();
        });

        root.addView(titleView, new FrameLayout.LayoutParams(-1, dp(70), Gravity.CENTER_HORIZONTAL));
        FrameLayout.LayoutParams titleLp = (FrameLayout.LayoutParams) titleView.getLayoutParams();
        titleLp.topMargin = dp(130); titleView.setLayoutParams(titleLp);
        root.addView(timer, new FrameLayout.LayoutParams(-1, dp(90), Gravity.CENTER));
        FrameLayout.LayoutParams doneLp = new FrameLayout.LayoutParams(dp(180), dp(54), Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        doneLp.bottomMargin = dp(85);
        root.addView(finish, doneLp);

        addTopBar();
        addBottomBar();
        setContentView(root);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override public void onBackPressed() {
        if (onProgressStage) {
            showProgressPath();
        } else if (!onHome) {
            showHome();
        } else {
            finish();
        }
    }
}

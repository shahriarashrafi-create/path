Journey-v42-stage-row-alignment

Changes in this version:
- Kept all 7 progress images, all 21 nodes, their calibrated touch zones, stage settings, persistent titles, Header and Bottom Bar.
- Moved Time / Importance / Repeat selected values down and vertically centered them on the exact same row as their fixed labels.
- Time still renders as 5/10/20/30 with a smaller "min" suffix.
- Importance and Repeat selections use the same aligned value column.
- Reminder no longer displays "5/10/30 minutes before" on the stage screen.
- If any reminder is enabled, a compact black check mark appears on the Reminder row; choosing Off removes the check.
- Stage title input remains right-aligned and was slightly reduced for a cleaner visual balance.
- Start Mission and all saved stage behavior remain unchanged.

Journey-v46-mission-result-persistence

Version 2 of the mission-result work:
- Done (✓) and Fail (✕) now finalize a mission exactly once, preventing duplicate rewards from rapid taps.
- Done records the node as completed and applies XP / Coin / Combo rewards based on importance and the current combo multiplier.
- Fail records the node as failed, gives no XP/Coin, and resets Combo plus its deadline.
- The result, result time, exact awarded XP/Coins, and combo state before the result are persisted per node for the upcoming reset/reward-reversal version.
- Active mission runtime keys are cleared only after a result is successfully finalized.
- A node with a saved Done/Fail result cannot be started again until the upcoming path reset flow resets it.
- The zero-timer state still waits for the user to choose ✓ or ✕ and never auto-completes.
- Mission state and the awaiting-result state remain persistent across app restarts.
- No notification feature added.

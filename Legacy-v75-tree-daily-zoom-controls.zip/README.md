Legacy v75 - Tree daily-state and interaction polish

Base: Legacy-v74-tree-crm-polish.zip

Changes applied:
1. Tree statistics layout at close zoom:
   - Stats appear only at a closer zoom threshold.
   - Name moves to the upper inside area of the circle and becomes smaller.
   - PV / GPV / count are centered in three separated columns.
   - Numeric font is regular sans-serif with no heavy bold/outline.
2. Action list is newest-first.
3. To Do list:
   - New items are inserted at the top.
   - Checked items automatically move to the bottom.
   - Each item has its own delete asset.
4. Search focus:
   - Live suggestions remain enabled.
   - Selecting a person centers and zooms much closer so statistics are visible.
5. Added a tree-wide expand/collapse asset beside Search and History.
   - Expand All opens every branch.
   - Collapse All closes every branch so only the root remains.
6. Daily statistics color state:
   - Light green circle interior when actual PV/GPV/count stats have been registered for the logical day.
   - Light red circle interior when no actual stats have been registered for that person that day.
   - Name/targets alone do not mark daily stats as registered.
7. Configurable day boundary in Settings:
   - Default start of day is 06:00.
   - User can choose a different time.
   - Mission Done/Fail daily reset, tree daily state/history, and subtask day boundary use the configured logical day.
8. Pinch/Pan gesture separation:
   - Pinch zoom remains exactly at the released scale/position.
   - No post-pinch snap/reset.
   - A very short 90ms gesture separation prevents the remaining finger from causing a jump before Pan/Zoom resumes.

Compatibility:
- Existing v74 tree data and older history snapshots remain readable.
- New history snapshots include the daily stats marker.

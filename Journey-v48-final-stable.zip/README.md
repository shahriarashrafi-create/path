Journey-v48-final-stable

Final stabilization of the current Journey Progress Path / Mission flow.

Included:
- 7 stacked Progress Path artworks with 21 stages.
- Persistent mission timer based on a saved end timestamp; closing or killing the app does not reset a running mission.
- Paused missions reopen paused with their exact saved remaining time.
- If the timer expires while the app is closed, reopening shows 00:00 and ? until the user chooses Done or Fail.
- Timer visual calibration retained: timer lifted ~0.5 mm; Pause/Resume lifted ~1 mm and slightly smaller.
- Only one active mission is allowed. Re-entering the same active stage resumes it instead of restarting its timer.
- Done = green path circle + struck-through title; Fail = red circle + struck-through title; Active = blue state.
- Tapping a completed/failed circle resets that result while preserving title/settings and returns that stage's recorded XP/coins.
- Result submission remains locked against duplicate rewards.
- Reduced SharedPreferences writes during countdown; the persisted end timestamp is the source of truth while running.
- Critical mission state transitions use synchronous persistence for stronger recovery after abrupt process termination.
- No Android notification/reminder scheduling in this version, per current requirement.
- Journey safe-area Header/Bottom Bar behavior remains unchanged.

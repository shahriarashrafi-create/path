plugins { id("com.android.application") }

android {
    namespace = "com.shahriar.gamification"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.shahriar.gamification"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

# Gamification New
Initial clean Android project. Home uses the supplied artwork. Header is native code. Six transparent touch targets are aligned to the six artwork sections and currently open placeholder pages.

Important: for GitHub Actions to trigger on a root ZIP push, `.github/workflows/build-apk.yml` must also exist in the repository itself (not only inside the ZIP).

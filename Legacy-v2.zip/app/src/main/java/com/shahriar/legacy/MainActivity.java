package com.shahriar.legacy;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout root, content;
    private long lastBackAt = 0;
    private final String[] names = {"مسیر پیشرفت","کاخ آرزوها","جنگل شکوفایی","سفر در زمان","مرکز خرید","جام جهانی"};
    // Coordinates measured against the supplied 709x1536 artwork. Centers are bottom -> top.
    private final float[][] centers = {{0.735f,0.626f},{0.715f,0.538f},{0.724f,0.447f},{0.716f,0.355f},{0.724f,0.260f},{0.713f,0.163f}};

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }
    private TextView tv(String text,int sp,int color){ TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void showHome(){
        root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(8,18,31));
        setContentView(root);
        // System bars remain owned by the phone; app content is laid out only between them.
        root.setFitsSystemWindows(true);

        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(14),dp(8),dp(12),dp(8));
        header.setBackgroundColor(Color.argb(238,9,25,43));
        page.addView(header,new LinearLayout.LayoutParams(-1,dp(82)));

        TextView avatar=tv("S",18,Color.WHITE); avatar.setBackground(bg(Color.rgb(37,72,102),dp(25)));
        header.addView(avatar,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.VERTICAL); stats.setPadding(dp(10),0,dp(8),0);
        TextView level=tv("سطح 1",15,Color.WHITE); level.setGravity(Gravity.START|Gravity.CENTER_VERTICAL); stats.addView(level,new LinearLayout.LayoutParams(-1,dp(25)));
        ProgressBar xp=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); xp.setMax(100); xp.setProgress(0); stats.addView(xp,new LinearLayout.LayoutParams(-1,dp(12)));
        TextView xpTxt=tv("0 / 100 XP",11,0xFFD8E6F2); xpTxt.setGravity(Gravity.START|Gravity.CENTER_VERTICAL); stats.addView(xpTxt,new LinearLayout.LayoutParams(-1,dp(23)));
        header.addView(stats,new LinearLayout.LayoutParams(0,dp(62),1f));
        TextView coin=tv("● 0",16,0xFFFFC94D); header.addView(coin,new LinearLayout.LayoutParams(dp(70),dp(50)));
        TextView gear=tv("⚙",27,Color.WHITE); gear.setOnClickListener(v->showPlaceholder("تنظیمات")); header.addView(gear,new LinearLayout.LayoutParams(dp(52),dp(52)));

        content=new FrameLayout(this); page.addView(content,new LinearLayout.LayoutParams(-1,0,1f));
        ImageView bg=new ImageView(this); bg.setImageResource(com.shahriar.legacy.R.drawable.home_background); bg.setScaleType(ImageView.ScaleType.FIT_XY); content.addView(bg,new FrameLayout.LayoutParams(-1,-1));

        // Transparent hit targets follow the six visible artwork buttons. They are deliberately generous for touch accessibility.
        content.post(()->{
            int w=content.getWidth(), h=content.getHeight();
            int hitW=(int)(w*0.46f), hitH=Math.max(dp(62),(int)(h*0.075f));
            for(int i=0;i<6;i++){
                final int idx=i; View hit=new View(this); hit.setContentDescription(names[i]);
                int cx=(int)(w*centers[i][0]), cy=(int)(h*centers[i][1]);
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(hitW,hitH); lp.leftMargin=Math.max(0,cx-(int)(hitW*0.42f)); lp.topMargin=Math.max(0,cy-hitH/2);
                hit.setOnClickListener(v->showPlaceholder(names[idx])); content.addView(hit,lp);
            }
        });
    }

    private void showPlaceholder(String title){
        // Rebuild Home shell first so the coded header stays identical on every page.
        showHome();
        content.removeAllViews();
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setGravity(Gravity.CENTER); p.setPadding(dp(24),dp(24),dp(24),dp(24)); p.setBackgroundColor(Color.rgb(10,31,51));
        TextView t=tv(title,28,Color.WHITE); p.addView(t,new LinearLayout.LayoutParams(-1,dp(80)));
        TextView note=tv("این بخش برای مرحله بعد آماده است",16,0xFFBFD4E6); p.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        Button back=new Button(this); back.setText("بازگشت"); back.setOnClickListener(v->showHome()); p.addView(back,new LinearLayout.LayoutParams(-1,dp(56)));
        content.addView(p,new FrameLayout.LayoutParams(-1,-1));
    }
    @Override public void onBackPressed(){
        // On a section, Back returns Home. On Home, double Back exits.
        if(content != null && content.getChildCount()==1 && content.getChildAt(0) instanceof LinearLayout){ showHome(); return; }
        long now=System.currentTimeMillis();
        if(now-lastBackAt<1800){ super.onBackPressed(); }
        else { lastBackAt=now; Toast.makeText(this,"برای خروج دوباره بزنید",Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int x){ return Math.round(x*getResources().getDisplayMetrics().density); }
}

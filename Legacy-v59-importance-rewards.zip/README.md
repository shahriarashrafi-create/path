Legacy v59
Changes:
- Mission rewards now depend only on mission importance (before existing combo multiplier):
  - Low: 10 XP, 2 Coin
  - Medium: 20 XP, 4 Coin
  - High: 35 XP, 7 Coin
- No time-based reward multiplier was added.
- Running Mission reward preview uses the same importance mapping.
- Notification Done action uses the same importance mapping.
- All v58 UI/art/touch behavior remains unchanged.

# Journey v4
Android app project for Journey.

- App name: Journey
- Background: 1080x2040 WebP (9:17)
- Background is fit to screen width without center-crop side loss.
- Edge-to-edge system bars remain transparent.

## v24
- Replaced Progress Path artwork with transparent adult-anime morning/stretch illustration.
- Optimized asset as high-quality WebP with alpha to reduce APK size while preserving visual quality.
- Existing scroll behavior, global header/bottom bars, and safe-area behavior retained.

Legacy v72 – Tree tasks/actions/editor polish

Changes:
- To Do now includes a Done checkbox and stores completion state per person.
- Added a dedicated Actions asset next to Add / To Do / Delete.
- Actions supports multiple records with completed action + next action, edit, delete, and "ثبت اقدام".
- Member card shows To Do completion state.
- Tree member stats are now rendered as three clearer columns (value + label) when zoomed in.
- Member editor subtitle now shows the person's name.
- Every editor input now has a visible field title beside it.
- Tapping/focusing an editor field clears it for fast entry; leaving it empty restores its previous value.
- Tree history snapshots now include To Do completion and Actions data.

Base: Legacy-v71-tree-search-history-actions.zip
